const functions = require("firebase-functions");
const admin = require("firebase-admin");
const express = require("express");
const cors = require("cors");

if (!admin.apps.length) {
  admin.initializeApp();
}

const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: "256kb" }));

// =====================================================================
// CENTRAL CONFIGURATION & ALLOWLISTS (TASK 1, 2, 3, 8)
// =====================================================================
const DEFAULT_MODEL_ID = "eleven_turbo_v2_5";

// Verified ElevenLabs Voice IDs for Chuma AI (Strict Allowlist)
const ALLOWED_VOICE_IDS = new Set([
  "Sy7d8PNbkbjIJxf1li2K", // Chuma — Female (Sim — Warm South African English)
  "xvDjI8KMgjF1nCoPoNKX", // Chuma — Male (Travis South African English Male)
  "fFAtoTPtP0TtMyhbR3L9"  // Chuma — Horizon (Amara — Warm African-British Professional)
]);

// Verified Conversational Low-Latency Models
const ALLOWED_MODELS = new Set([
  "eleven_turbo_v2_5",
  "eleven_multilingual_v2",
  "eleven_flash_v2_5"
]);

const MAX_TEXT_LENGTH = 600; // characters per synthesis chunk
const RATE_LIMIT_WINDOW_MS = 60000;
const MAX_REQUESTS_PER_WINDOW = 40;

// In-memory sliding-window rate limiter
const requestRateMap = new Map();

function isRateLimited(identifier) {
  const now = Date.now();
  const history = requestRateMap.get(identifier) || [];
  const validHistory = history.filter(ts => now - ts < RATE_LIMIT_WINDOW_MS);
  if (validHistory.length >= MAX_REQUESTS_PER_WINDOW) {
    return true;
  }
  validHistory.push(now);
  requestRateMap.set(identifier, validHistory);
  return false;
}

// Cleanup rate limiter map every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, history] of requestRateMap.entries()) {
    const valid = history.filter(ts => now - ts < RATE_LIMIT_WINDOW_MS);
    if (valid.length === 0) {
      requestRateMap.delete(key);
    } else {
      requestRateMap.set(key, valid);
    }
  }
}, 300000);

// =====================================================================
// AUTHENTICATION MIDDLEWARE (TASK 7)
// =====================================================================
async function optionalFirebaseAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const idToken = authHeader.split("Bearer ")[1].trim();
    try {
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      req.user = decodedToken;
    } catch (err) {
      return res.status(401).json({
        error: "INVALID_AUTHENTICATION_TOKEN",
        message: "Supplied Firebase ID token is invalid or expired."
      });
    }
  }
  next();
}

// =====================================================================
// NEURAL TTS PROXY HANDLER (Canonical: POST /api/voice/tts)
// =====================================================================
async function handleVoiceTts(req, res) {
  const requestStartTime = Date.now();

  // 1. Rate Limiting Check
  const clientIdentifier = req.user ? req.user.uid : (req.ip || "unknown_client");
  if (isRateLimited(clientIdentifier)) {
    return res.status(429).json({
      error: "RATE_LIMIT_EXCEEDED",
      message: "Too many speech requests. Please slow down."
    });
  }

  // 2. Validate Body & Non-Empty Text
  const { text, voice_id, model_id, voice_settings } = req.body || {};
  if (typeof text !== "string") {
    return res.status(400).json({
      error: "INVALID_TEXT",
      message: "Field 'text' must be a string."
    });
  }

  const trimmedText = text.trim();
  if (trimmedText.length === 0) {
    return res.status(400).json({
      error: "EMPTY_TEXT",
      message: "Speech text cannot be empty."
    });
  }

  if (trimmedText.length > MAX_TEXT_LENGTH) {
    return res.status(400).json({
      error: "TEXT_TOO_LONG",
      message: `Speech text chunk exceeds maximum length of ${MAX_TEXT_LENGTH} characters.`
    });
  }

  // 3. Strict Allowlist Validation for Voice ID
  if (!voice_id || typeof voice_id !== "string" || !ALLOWED_VOICE_IDS.has(voice_id)) {
    return res.status(400).json({
      error: "INVALID_VOICE_ID",
      message: "Provided voice_id is not in the approved Chuma AI voice allowlist."
    });
  }

  // 4. Validate or Default Model ID
  const resolvedModelId = (model_id && ALLOWED_MODELS.has(model_id)) ? model_id : DEFAULT_MODEL_ID;

  // 5. Clamp Voice Settings
  const speed = typeof voice_settings?.speed === "number"
    ? Math.max(0.7, Math.min(1.4, voice_settings.speed))
    : 1.0;
  const stability = typeof voice_settings?.stability === "number"
    ? Math.max(0.0, Math.min(1.0, voice_settings.stability))
    : 0.5;
  const similarityBoost = typeof voice_settings?.similarity_boost === "number"
    ? Math.max(0.0, Math.min(1.0, voice_settings.similarity_boost))
    : 0.8;

  // 6. Read ElevenLabs API Key from Server-Side Environment Secret
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: "ELEVENLABS_API_KEY_NOT_CONFIGURED",
      message: "Server-side ElevenLabs secret is not configured in backend environment."
    });
  }

  // 7. Server-to-Server ElevenLabs API Request
  try {
    const elevenLabsUrl = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice_id)}?output_format=mp3_44100_128`;
    const payload = {
      text: trimmedText,
      model_id: resolvedModelId,
      voice_settings: {
        stability: stability,
        similarity_boost: similarityBoost,
        speed: speed
      }
    };

    const upstreamResponse = await fetch(elevenLabsUrl, {
      method: "POST",
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg"
      },
      body: JSON.stringify(payload)
    });

    const upstreamLatency = Date.now() - requestStartTime;

    if (!upstreamResponse.ok) {
      console.warn(`[VOICE_TTS_BACKEND_ERROR] ElevenLabs returned HTTP ${upstreamResponse.status} in ${upstreamLatency}ms`);
      return res.status(upstreamResponse.status === 429 ? 429 : 502).json({
        error: "UPSTREAM_TTS_ERROR",
        status: upstreamResponse.status,
        message: "Speech synthesis service returned an error."
      });
    }

    const audioArrayBuffer = await upstreamResponse.arrayBuffer();
    const audioBuffer = Buffer.from(audioArrayBuffer);

    res.set({
      "Content-Type": "audio/mpeg",
      "Content-Length": audioBuffer.length,
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "X-Synthesis-Duration-Ms": upstreamLatency
    });

    return res.status(200).send(audioBuffer);
  } catch (err) {
    console.error("[VOICE_TTS_BACKEND_EXCEPTION] Synthesis call failed:", err.message);
    return res.status(500).json({
      error: "SYNTHESIS_EXECUTION_FAILURE",
      message: "Failed to communicate with speech synthesis provider."
    });
  }
}

// Canonical production endpoints (supports both hosting rewrites and direct function invocation)
app.post("/api/voice/tts", optionalFirebaseAuth, handleVoiceTts);
app.post("/voice/tts", optionalFirebaseAuth, handleVoiceTts);
app.post("/", optionalFirebaseAuth, handleVoiceTts);

// Export for Firebase Cloud Functions
exports.api = functions.https.onRequest(app);
exports.voiceTts = functions.https.onRequest(app);
