const http = require("http");
const assert = require("assert");

// Load the express app from index.js
// Mock process.env
delete process.env.ELEVENLABS_API_KEY;

const index = require("./index.js");
const app = index.api; // Express app wrapped in function or exported app

// Test server
const server = http.createServer(app);

server.listen(0, async () => {
  const port = server.address().port;
  const baseUrl = `http://localhost:${port}`;
  console.log(`[TEST] Test proxy running on ${baseUrl}`);

  let passed = 0;
  let total = 0;

  async function post(path, body, headers = {}) {
    const res = await fetch(`${baseUrl}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...headers
      },
      body: JSON.stringify(body)
    });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) {}
    return { status: res.status, headers: res.headers, text, json };
  }

  try {
    // 1. Test Empty Text
    total++;
    const res1 = await post("/api/voice/tts", { text: "", voice_id: "Sy7d8PNbkbjIJxf1li2K" });
    assert.strictEqual(res1.status, 400);
    assert.strictEqual(res1.json?.error, "EMPTY_TEXT");
    console.log("✓ Empty text rejected with 400 EMPTY_TEXT");
    passed++;

    // 2. Test Text Exceeding Max Length
    total++;
    const longText = "A".repeat(601);
    const res2 = await post("/api/voice/tts", { text: longText, voice_id: "Sy7d8PNbkbjIJxf1li2K" });
    assert.strictEqual(res2.status, 400);
    assert.strictEqual(res2.json?.error, "TEXT_TOO_LONG");
    console.log("✓ Long text (>600 chars) rejected with 400 TEXT_TOO_LONG");
    passed++;

    // 3. Test Invalid / Placeholder Voice ID Rejected
    total++;
    const res3 = await post("/api/voice/tts", { text: "Hello", voice_id: "chuma_female_neural" });
    assert.strictEqual(res3.status, 400);
    assert.strictEqual(res3.json?.error, "INVALID_VOICE_ID");
    console.log("✓ Placeholder voice ID rejected with 400 INVALID_VOICE_ID");
    passed++;

    // 4. Test Missing Secret returns 503
    total++;
    const res4 = await post("/api/voice/tts", { text: "Hello", voice_id: "Sy7d8PNbkbjIJxf1li2K" });
    assert.strictEqual(res4.status, 503);
    assert.strictEqual(res4.json?.error, "ELEVENLABS_API_KEY_NOT_CONFIGURED");
    console.log("✓ Missing ELEVENLABS_API_KEY returns 503 ELEVENLABS_API_KEY_NOT_CONFIGURED");
    passed++;

    // 5. Test Alternative Direct Route /voice/tts (Prevents /api/api double prefix)
    total++;
    const res5 = await post("/voice/tts", { text: "Hello", voice_id: "xvDjI8KMgjF1nCoPoNKX" });
    assert.strictEqual(res5.status, 503);
    assert.strictEqual(res5.json?.error, "ELEVENLABS_API_KEY_NOT_CONFIGURED");
    console.log("✓ Direct route /voice/tts handled properly");
    passed++;

    // 6. Test Direct Root Route / (When function is named voiceTts)
    total++;
    const res6 = await post("/", { text: "Hello", voice_id: "fFAtoTPtP0TtMyhbR3L9" });
    assert.strictEqual(res6.status, 503);
    assert.strictEqual(res6.json?.error, "ELEVENLABS_API_KEY_NOT_CONFIGURED");
    console.log("✓ Root route / handled properly for voiceTts function invocation");
    passed++;

    console.log(`\n[TEST SUMMARY] All ${passed}/${total} backend proxy tests passed successfully!`);
    server.close();
    process.exit(0);
  } catch (err) {
    console.error("[TEST FAILED]", err);
    server.close();
    process.exit(1);
  }
});
