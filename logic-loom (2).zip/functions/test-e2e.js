const http = require("http");
const assert = require("assert");

// Mock upstream ElevenLabs server
const upstreamElevenLabs = http.createServer((req, res) => {
  if (req.method === "POST" && req.url.includes("/v1/text-to-speech/")) {
    const authHeader = req.headers["xi-api-key"];
    if (!authHeader || authHeader !== "test_live_key_12345") {
      res.writeHead(401, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ detail: { message: "Invalid API key" } }));
      return;
    }

    let body = "";
    req.on("data", chunk => { body += chunk; });
    req.on("end", () => {
      const data = JSON.parse(body);
      // Return 256 bytes of mock MP3 binary data
      const mockMp3 = Buffer.alloc(256, 0xFF);
      res.writeHead(200, {
        "Content-Type": "audio/mpeg",
        "Content-Length": mockMp3.length
      });
      res.end(mockMp3);
    });
    return;
  }
  res.writeHead(404);
  res.end();
});

upstreamElevenLabs.listen(0, async () => {
  const upstreamPort = upstreamElevenLabs.address().port;
  const originalFetch = global.fetch;

  // Intercept fetch to point to our mock upstream ElevenLabs server
  global.fetch = async (url, opts) => {
    if (url.startsWith("https://api.elevenlabs.io")) {
      const redirected = url.replace("https://api.elevenlabs.io", `http://localhost:${upstreamPort}`);
      return originalFetch(redirected, opts);
    }
    return originalFetch(url, opts);
  };

  // Configure process.env with the test ElevenLabs API key
  process.env.ELEVENLABS_API_KEY = "test_live_key_12345";

  // Re-load the app with the API key set
  delete require.cache[require.resolve("./index.js")];
  const index = require("./index.js");
  const server = http.createServer(index.api);

  server.listen(0, async () => {
    const port = server.address().port;
    const baseUrl = `http://localhost:${port}`;
    console.log(`[TEST E2E] Proxy server on ${baseUrl}, upstream mock ElevenLabs on port ${upstreamPort}`);

    async function post(path, body) {
      const res = await originalFetch(`${baseUrl}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const buffer = await res.arrayBuffer();
      return { status: res.status, headers: res.headers, buffer: Buffer.from(buffer) };
    }

    try {
      // 1. Test Female Voice (Sim — Warm South African English)
      const resFemale = await post("/api/voice/tts", {
        text: "Hello, I am Chuma. How can I assist you with your academic schedule today?",
        voice_id: "Sy7d8PNbkbjIJxf1li2K",
        voice_settings: { speed: 1.0, stability: 0.5, similarity_boost: 0.8 }
      });
      assert.strictEqual(resFemale.status, 200);
      assert.strictEqual(resFemale.headers.get("content-type"), "audio/mpeg");
      assert.strictEqual(resFemale.buffer.length, 256);
      console.log("✓ Female voice (Sy7d8PNbkbjIJxf1li2K) synthesized successfully: 256 bytes MP3");

      // 2. Test Male Voice (Travis South African English Male)
      const resMale = await post("/api/voice/tts", {
        text: "Checking your upcoming deadlines and transport options now.",
        voice_id: "xvDjI8KMgjF1nCoPoNKX",
        voice_settings: { speed: 0.98, stability: 0.5, similarity_boost: 0.8 }
      });
      assert.strictEqual(resMale.status, 200);
      assert.strictEqual(resMale.headers.get("content-type"), "audio/mpeg");
      assert.strictEqual(resMale.buffer.length, 256);
      console.log("✓ Male voice (xvDjI8KMgjF1nCoPoNKX) synthesized successfully: 256 bytes MP3");

      // 3. Test Horizon Voice (Amara — Warm African-British Professional)
      const resHorizon = await post("/api/voice/tts", {
        text: "Analyzing your budget allocation and study goals.",
        voice_id: "fFAtoTPtP0TtMyhbR3L9",
        voice_settings: { speed: 1.05, stability: 0.5, similarity_boost: 0.8 }
      });
      assert.strictEqual(resHorizon.status, 200);
      assert.strictEqual(resHorizon.headers.get("content-type"), "audio/mpeg");
      assert.strictEqual(resHorizon.buffer.length, 256);
      console.log("✓ Horizon voice (fFAtoTPtP0TtMyhbR3L9) synthesized successfully: 256 bytes MP3");

      // 4. Test Upstream Error Handling (Simulate invalid API key upstream)
      process.env.ELEVENLABS_API_KEY = "wrong_invalid_key";
      const resErr = await post("/api/voice/tts", {
        text: "Testing error handling.",
        voice_id: "Sy7d8PNbkbjIJxf1li2K"
      });
      assert.strictEqual(resErr.status, 502);
      console.log("✓ Upstream 401 correctly translated to 502 without leaking secrets");

      console.log("\n[TEST SUMMARY] All E2E voice synthesis and error handling tests PASSED!");
      server.close();
      upstreamElevenLabs.close();
      process.exit(0);
    } catch (e) {
      console.error("[TEST E2E FAILED]", e);
      server.close();
      upstreamElevenLabs.close();
      process.exit(1);
    }
  });
});
