# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Preserve line numbers and source file attributes for stack traces
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod

# Jetpack Compose Rules
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}
-keep class androidx.compose.ui.platform.** { *; }
-keepclassmembers class * extends androidx.compose.ui.node.LayoutNode { *; }

# Hilt & Dagger Dependency Injection Rules
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.** { *; }
-keepclassmembers class * {
    @javax.inject.Inject <init>(...);
    @dagger.Provides <methods>;
}
-keep class * {
    @dagger.hilt.EntryPoint *;
    @dagger.hilt.InstallIn *;
}

# Room Database & Local Entities
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
-keep class com.example.data.local.** { *; }

# ViewModels and Benchmark Rules
-keep class com.example.ui.** { *; }
-keep class com.example.benchmark.** { *; }

