package com.example.ui

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AcademicTask
import com.example.data.local.BudgetGoal
import com.example.data.local.BudgetItem
import com.example.data.local.CanvasMateDao
import com.example.data.local.CanvasMateDatabase
import com.example.data.local.TodoTask
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthRepositoryImpl
import com.example.data.repository.CanvasMateRepository
import com.example.security.SecureSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CanvasMateViewModelTest {

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var database: CanvasMateDatabase
    private lateinit var dao: CanvasMateDao
    private lateinit var repository: CanvasMateRepository
    private lateinit var viewModel: CanvasMateViewModel
    private lateinit var application: Application

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        application = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(application, CanvasMateDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = database.dao()
        repository = CanvasMateRepository(dao)
        val sessionManager = SecureSessionManager(application)
        val authRepository = AuthRepositoryImpl(database.userAccountDao(), dao, sessionManager)
        viewModel = CanvasMateViewModel(application, repository, dao, authRepository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
        database.close()
    }

    // --- BUDGET MODULE VIEWMODEL TESTS ---

    @Test
    fun addBudgetItemUpdatesStateFlow() = runBlocking {
        val newBudgetItem = BudgetItem(
            title = "Tutoring Income",
            amount = 1200.0,
            type = "Income",
            category = "Salary",
            date = "2026-08-05"
        )

        viewModel.addBudgetItem(newBudgetItem)

        // Verify repository emission
        val items = repository.budgetItems.first { it.any { item -> item.title == "Tutoring Income" } }
        val addedItem = items.find { it.title == "Tutoring Income" }
        assertNotNull(addedItem)
        assertEquals(1200.0, addedItem?.amount ?: 0.0, 0.01)
        assertEquals("Income", addedItem?.type)
    }

    @Test
    fun updateBudgetItemUpdatesStateFlow() = runBlocking {
        val initialItem = BudgetItem(
            title = "Lab Lab Coat",
            amount = 350.0,
            type = "Expense",
            category = "Books"
        )
        val id = dao.insertBudgetItem(initialItem)

        val updatedItem = BudgetItem(
            id = id,
            title = "Lab Lab Coat & Safety Glasses",
            amount = 450.0,
            type = "Expense",
            category = "Books"
        )

        viewModel.updateBudgetItem(updatedItem)

        val items = repository.budgetItems.first()
        val found = items.find { it.id == id }
        assertNotNull(found)
        assertEquals("Lab Lab Coat & Safety Glasses", found?.title)
        assertEquals(450.0, found?.amount ?: 0.0, 0.01)
    }

    @Test
    fun deleteBudgetItemUpdatesStateFlow() = runBlocking {
        val item = BudgetItem(
            title = "Temporary Expense",
            amount = 100.0,
            type = "Expense",
            category = "Other"
        )
        val id = dao.insertBudgetItem(item)

        viewModel.deleteBudgetItem(id)

        val items = repository.budgetItems.first { it.none { b -> b.id == id } }
        val found = items.find { it.id == id }
        assertTrue(found == null)
    }

    @Test
    fun addUpdateDeleteBudgetGoalInViewModel() = runBlocking {
        val newGoal = BudgetGoal(
            title = "Conference Travel",
            targetAmount = 5000.0,
            currentAmount = 1500.0,
            deadline = "2026-11-01"
        )

        val goalId = dao.insertBudgetGoal(newGoal)

        val goalsList = repository.budgetGoals.first { it.any { g -> g.id == goalId } }
        val inserted = goalsList.find { it.id == goalId }
        assertNotNull(inserted)

        val updatedGoal = BudgetGoal(
            id = goalId,
            title = "Conference Travel",
            targetAmount = 5000.0,
            currentAmount = 3000.0,
            deadline = "2026-11-01"
        )
        viewModel.updateBudgetGoal(updatedGoal)

        val updatedGoalsList = repository.budgetGoals.first { it.any { g -> g.id == goalId && g.currentAmount == 3000.0 } }
        val updatedFound = updatedGoalsList.find { it.id == goalId }
        assertEquals(3000.0, updatedFound?.currentAmount ?: 0.0, 0.01)

        viewModel.deleteBudgetGoal(goalId)
        val finalGoalsList = repository.budgetGoals.first { it.none { g -> g.id == goalId } }
        assertFalse(finalGoalsList.any { it.id == goalId })
    }

    // --- TASK MODULE VIEWMODEL TESTS ---

    @Test
    fun addAcademicTaskUpdatesStateFlow() = runBlocking {
        val newTask = AcademicTask(
            title = "MTH3012S Assignment 4",
            module = "MTH3012S",
            description = "Differential Geometry problems",
            dueDate = "2026-08-25",
            priority = "High",
            taskType = "Assignment",
            status = "Pending",
            progress = 0
        )

        viewModel.addAcademicTask(newTask)

        val tasks = repository.academicTasks.first()
        val added = tasks.find { it.title == "MTH3012S Assignment 4" }
        assertNotNull(added)
        assertEquals("MTH3012S", added?.module)
        assertEquals("High", added?.priority)
    }

    @Test
    fun updateAcademicTaskUpdatesStateFlow() = runBlocking {
        val task = AcademicTask(
            title = "CSC3002F Quiz 1",
            module = "CSC3002F",
            dueDate = "2026-08-10",
            status = "Pending",
            progress = 0
        )
        val id = dao.insertAcademicTask(task)

        val updated = AcademicTask(
            id = id,
            title = "CSC3002F Quiz 1",
            module = "CSC3002F",
            dueDate = "2026-08-10",
            status = "Completed",
            progress = 100
        )

        viewModel.updateAcademicTask(updated)

        val tasks = repository.academicTasks.first()
        val found = tasks.find { it.id == id }
        assertNotNull(found)
        assertEquals("Completed", found?.status)
        assertEquals(100, found?.progress)
    }

    @Test
    fun deleteAcademicTaskUpdatesStateFlow() = runBlocking {
        val task = AcademicTask(
            title = "Draft Task to Remove",
            module = "INF3003W",
            dueDate = "2026-08-15"
        )
        val id = dao.insertAcademicTask(task)

        viewModel.deleteAcademicTask(id)
        kotlinx.coroutines.delay(100)

        val tasks = repository.academicTasks.first()
        val found = tasks.find { it.id == id }
        assertTrue(found == null)
    }

    @Test
    fun addUpdateDeleteTodoTaskInViewModel() = runBlocking {
        val todo = TodoTask(
            title = "Renew Gym Membership",
            priority = "Low",
            isCompleted = false,
            dueDate = "2026-08-10"
        )

        viewModel.addTodoTask(todo)
        kotlinx.coroutines.delay(100)

        val todoList = repository.todoTasks.first()
        val insertedTodo = todoList.find { it.title == "Renew Gym Membership" }
        assertNotNull(insertedTodo)

        val todoId = insertedTodo!!.id
        val updatedTodo = TodoTask(
            id = todoId,
            title = "Renew Gym Membership",
            priority = "Low",
            isCompleted = true,
            dueDate = "2026-08-10"
        )

        viewModel.updateTodoTask(updatedTodo)
        kotlinx.coroutines.delay(100)

        val updatedTodoList = repository.todoTasks.first()
        val foundUpdated = updatedTodoList.find { it.id == todoId }
        assertTrue(foundUpdated?.isCompleted == true)

        viewModel.deleteTodoTask(todoId)
        kotlinx.coroutines.delay(100)

        val finalTodoList = repository.todoTasks.first()
        assertFalse(finalTodoList.any { it.id == todoId })
    }

    // --- CHUMA V1 AI ASSISTANT TESTS ---

    @Test
    fun chumaAiRespondsToGeneralKnowledgeQueries() = runBlocking {
        // Test query: Who is Mark Zuckerberg?
        val zuckResponse = com.example.data.ai.GeminiClient.generateOfflineAiResponse("Who is Mark Zuckerberg?")
        assertTrue(zuckResponse.isNotBlank())
        assertTrue(zuckResponse.contains("Meta", ignoreCase = true) || zuckResponse.contains("Facebook", ignoreCase = true))

        // Test query: What is a calendar?
        val calResponse = com.example.data.ai.GeminiClient.generateOfflineAiResponse("What is a calendar?")
        assertTrue(calResponse.isNotBlank())
        assertTrue(calResponse.contains("days", ignoreCase = true) || calResponse.contains("schedule", ignoreCase = true) || calResponse.contains("time", ignoreCase = true))

        // Test query: Where is the Eastern Cape?
        val ecResponse = com.example.data.ai.GeminiClient.generateOfflineAiResponse("Where is the Eastern Cape?")
        assertTrue(ecResponse.isNotBlank())
        assertTrue(ecResponse.contains("South Africa", ignoreCase = true) || ecResponse.contains("province", ignoreCase = true))
    }

    @Test
    fun chumaAiInitialMessagesAreConfigured() {
        val initialMessages = viewModel.aiMessages.value
        assertTrue(initialMessages.isNotEmpty())
        val (_, aiText) = initialMessages.last()
        assertTrue(aiText.contains("Chuma AI"))
    }
}
