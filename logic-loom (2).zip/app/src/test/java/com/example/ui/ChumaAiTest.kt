package com.example.ui

import com.example.data.ai.CapabilityRegistry
import com.example.data.ai.DeviceCapabilityType
import com.example.data.ai.GeminiService
import com.example.data.ai.IntentRouter
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ChumaAiTest {

    private lateinit var geminiService: GeminiService

    @Before
    fun setup() {
        geminiService = GeminiService()
    }

    @Test
    fun testMarkZuckerbergQuestion() {
        val response = geminiService.generateOfflineAiResponse("Who is Mark Zuckerberg?")
        assertTrue(response.contains("Mark Zuckerberg", ignoreCase = true))
        assertTrue(response.contains("Meta", ignoreCase = true) || response.contains("Facebook", ignoreCase = true))
    }

    @Test
    fun testCalendarQuestion() {
        val response = geminiService.generateOfflineAiResponse("What is a calendar?")
        assertTrue(response.contains("calendar", ignoreCase = true))
        assertTrue(response.contains("organizing", ignoreCase = true) || response.contains("days", ignoreCase = true) || response.contains("time", ignoreCase = true))
    }

    @Test
    fun testEasternCapeQuestion() {
        val response = geminiService.generateOfflineAiResponse("Where is the Eastern Cape?")
        assertTrue(response.contains("Eastern Cape", ignoreCase = true))
        assertTrue(response.contains("South Africa", ignoreCase = true))
    }

    @Test
    fun testSouthAfricaQuestion() {
        val response = geminiService.generateOfflineAiResponse("What is South Africa?")
        assertTrue(response.contains("South Africa", ignoreCase = true))
        assertTrue(response.contains("African continent", ignoreCase = true) || response.contains("country", ignoreCase = true))
    }

    @Test
    fun testCapitalOfSouthAfrica() {
        val response = geminiService.generateOfflineAiResponse("What is the capital of South Africa?")
        assertTrue(response.contains("Pretoria", ignoreCase = true))
        assertTrue(response.contains("Cape Town", ignoreCase = true))
        assertTrue(response.contains("Bloemfontein", ignoreCase = true))
    }

    @Test
    fun testMachineLearningQuestion() {
        val response = geminiService.generateOfflineAiResponse("Explain machine learning simply")
        assertTrue(response.contains("Machine Learning", ignoreCase = true))
        assertTrue(response.contains("patterns", ignoreCase = true) || response.contains("data", ignoreCase = true))
    }

    @Test
    fun testArtificialIntelligenceQuestion() {
        val response = geminiService.generateOfflineAiResponse("What is artificial intelligence?")
        assertTrue(response.contains("Artificial Intelligence", ignoreCase = true))
        assertTrue(response.contains("computer science", ignoreCase = true))
    }

    @Test
    fun testPhotosynthesisQuestion() {
        val response = geminiService.generateOfflineAiResponse("What is photosynthesis?")
        assertTrue(response.contains("Photosynthesis", ignoreCase = true))
        assertTrue(response.contains("glucose", ignoreCase = true) || response.contains("chlorophyll", ignoreCase = true) || response.contains("light", ignoreCase = true))
    }

    @Test
    fun testBusinessInformaticsQuestion() {
        val response = geminiService.generateOfflineAiResponse("What is Business Informatics?")
        assertTrue(response.contains("Business Informatics", ignoreCase = true))
        assertTrue(response.contains("information technology", ignoreCase = true) || response.contains("management", ignoreCase = true))
    }

    @Test
    fun testArithmeticMultiplication() {
        val response = geminiService.generateOfflineAiResponse("What is 15 × 24?")
        assertTrue(response.contains("360"))
    }

    @Test
    fun testArithmeticDivision() {
        val response = geminiService.generateOfflineAiResponse("What is 450 ÷ 9?")
        assertTrue(response.contains("50"))
    }

    @Test
    fun testPercentageCalculation() {
        val response = geminiService.generateOfflineAiResponse("What is 20% of 500?")
        assertTrue(response.contains("100"))
    }

    @Test
    fun testEmailWritingAssistance() {
        val response = geminiService.generateOfflineAiResponse("Help me write an email to my lecturer asking for an extension")
        assertTrue(response.contains("Extension Request", ignoreCase = true))
        assertTrue(response.contains("Subject", ignoreCase = true))
        assertTrue(response.contains("Kind regards", ignoreCase = true))
    }

    @Test
    fun testCapabilityHonestyRideBooking() {
        val response = geminiService.generateOfflineAiResponse("Book me a Bolt ride to campus")
        assertTrue(response.contains("cannot book", ignoreCase = true) || response.contains("does not have", ignoreCase = true) || response.contains("external", ignoreCase = true))
        assertFalse(response.contains("driver on the way", ignoreCase = true))
    }

    @Test
    fun testCapabilityHonestyFoodOrdering() {
        val response = geminiService.generateOfflineAiResponse("Order pizza from Debonairs")
        assertTrue(response.contains("cannot place food orders", ignoreCase = true) || response.contains("external", ignoreCase = true))
    }

    @Test
    fun testIntentRouterDoesNotMisclassifyGeneralKnowledge() {
        val router = IntentRouter()
        val intent1 = router.routeLocalRule("What is a calendar?")
        assertTrue(intent1.action == "GeneralQuery" || intent1.action == "none")

        val intent2 = router.routeLocalRule("Who is Mark Zuckerberg?")
        assertTrue(intent2.action == "GeneralQuery" || intent2.action == "none")

        val intent3 = router.routeLocalRule("What is 15 × 24?")
        assertTrue(intent3.action == "GeneralQuery" || intent3.action == "none" || intent3.action == "Calculate")
    }

    @Test
    fun testIntentRouterCorrectlyIdentifiesValidAppActions() {
        val router = IntentRouter()
        val intent = router.routeLocalRule("Add task finish chemistry lab report due tomorrow")
        assertNotNull(intent)
        assertTrue(intent.action == "CreateTask" || intent.action == "add_task")
    }

    @Test
    fun testCapabilityRegistryStatus() {
        val report = CapabilityRegistry.getHonestCapabilityReport(DeviceCapabilityType.EXTERNAL_TRANSPORT_DISPATCH)
        assertFalse(report.isAvailable)
        assertTrue(report.message.contains("external transport", ignoreCase = true) || report.message.contains("cannot book", ignoreCase = true))
    }

    @Test
    fun testMultiTurnFollowUpElonMuskAge() {
        val history = listOf(
            "User" to "Who is Elon Musk?",
            "AI" to "Elon Musk is a South African-born technology entrepreneur, investor, and business magnate."
        )
        val response = geminiService.generateOfflineAiResponse("How old is he?", history = history)
        assertTrue(response.contains("Pretoria", ignoreCase = true) || response.contains("years old", ignoreCase = true) || response.contains("1971"))
    }

    @Test
    fun testTextSummarization() {
        val prompt = "Summarize this text: Artificial intelligence is transforming education by providing personalized tutoring, automating administrative tasks, and helping students learn at their own pace."
        val response = geminiService.generateOfflineAiResponse(prompt)
        assertTrue(response.contains("Summary", ignoreCase = true))
        assertTrue(response.contains("tutoring", ignoreCase = true) || response.contains("education", ignoreCase = true) || response.contains("learning", ignoreCase = true))
    }

    @Test
    fun testMultiPartComplexQuery() {
        val prompt = "Can you help me plan my day, calculate my grade if my test is 40% and I got 65%, and explain Newton's first law?"
        val response = geminiService.generateOfflineAiResponse(prompt)
        assertTrue(response.contains("Plan", ignoreCase = true) || response.contains("Day", ignoreCase = true))
        assertTrue(response.contains("26", ignoreCase = true) || response.contains("grade", ignoreCase = true) || response.contains("mark", ignoreCase = true))
        assertTrue(response.contains("Newton", ignoreCase = true) || response.contains("Inertia", ignoreCase = true))
    }
}
