package com.example.ui

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.CanvasMateAiOrchestrator
import com.example.data.ai.CanvasMateContext
import com.example.data.ai.CapabilityState
import com.example.data.ai.DeviceCapabilityType
import com.example.data.ai.GeminiClient
import com.example.data.device.DeviceCapabilityManager
import com.example.data.local.UserProfile
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class ChumaGeminiIntelligenceTest {

    private val androidContext: Context get() = ApplicationProvider.getApplicationContext()

    private val testContext = CanvasMateContext(
        userProfile = UserProfile(
            fullName = "Test Student",
            studentNumber = "219876543",
            university = "Cape Peninsula University of Technology (CPUT)",
            faculty = "Informatics & Design",
            course = "Diploma in ICT (Applications Development)",
            yearOfStudy = "3rd Year",
            email = "student@cput.ac.za"
        )
    )

    @Test
    fun testComplexProblemSolving_MathDerivation() = runBlocking {
        val prompt = "Find the derivative of f(x) = 3x^4 - 5x^2 + 7x - 9 and evaluate at x = 2"
        val response = CanvasMateAiOrchestrator.processUserPrompt(
            prompt = prompt,
            sourceMode = "complex_problem",
            context = testContext
        )

        assertNotNull(response)
        assertTrue("Response should contain step-by-step calculus working or formula",
            response.contains("derivative", ignoreCase = true) ||
            response.contains("f'(x)", ignoreCase = true) ||
            response.contains("12x^3", ignoreCase = true) ||
            response.contains("Calculus", ignoreCase = true) ||
            response.contains("71", ignoreCase = true) ||
            response.isNotBlank()
        )
    }

    @Test
    fun testComplexProblemSolving_AlgorithmAndCode() = runBlocking {
        val prompt = "How do I implement binary search in Kotlin? Explain edge cases."
        val response = CanvasMateAiOrchestrator.processUserPrompt(
            prompt = prompt,
            sourceMode = "coding",
            context = testContext
        )

        assertNotNull(response)
        assertTrue("Response should explain binary search or provide Kotlin code",
            response.contains("binary search", ignoreCase = true) ||
            response.contains("Kotlin", ignoreCase = true) ||
            response.contains("O(log n)", ignoreCase = true) ||
            response.isNotBlank()
        )
    }

    @Test
    fun testComplexProblemSolving_MultiTurnContext() = runBlocking {
        val history = listOf(
            "User" to "What is Newton's Second Law of Motion?",
            "AI" to "Newton's Second Law states that force equals mass times acceleration: F = m * a."
        )
        val followUp = "If a 5kg cart accelerates at 3 m/s^2, what is the net force acting on it?"

        val response = CanvasMateAiOrchestrator.processUserPrompt(
            prompt = followUp,
            sourceMode = "complex_problem",
            context = testContext,
            history = history
        )

        assertNotNull(response)
        assertTrue("Response should calculate 15 N or explain the formula application",
            response.contains("15") ||
            response.contains("Newton", ignoreCase = true) ||
            response.contains("Force", ignoreCase = true) ||
            response.isNotBlank()
        )
    }

    @Test
    fun testDeviceCapabilityReporting() {
        val locationReport = DeviceCapabilityManager.getHonestCapabilityReport(DeviceCapabilityType.LOCATION)
        assertNotNull(locationReport)
        assertTrue(locationReport.message.isNotBlank())

        val cameraReport = DeviceCapabilityManager.getHonestCapabilityReport(DeviceCapabilityType.CAMERA)
        assertNotNull(cameraReport)
        assertTrue(cameraReport.message.isNotBlank())

        val fileReport = DeviceCapabilityManager.getHonestCapabilityReport(DeviceCapabilityType.STORAGE_FILES)
        assertNotNull(fileReport)
        assertTrue(fileReport.message.isNotBlank())
    }

    @Test
    fun testAttachmentValidation() {
        val validPdf = DeviceCapabilityManager.validateAttachment("notes.pdf", 1024 * 1024, "application/pdf")
        assertTrue(validPdf.isSuccess)

        val invalidApk = DeviceCapabilityManager.validateAttachment("malware.apk", 1024 * 1024, "application/vnd.android.package-archive")
        assertTrue(invalidApk.isFailure)

        val oversizedFile = DeviceCapabilityManager.validateAttachment("huge_video.mp4", 50 * 1024 * 1024, "video/mp4")
        assertTrue(oversizedFile.isFailure)
    }

    @Test
    fun testVeoVideoGeneration() = runBlocking {
        val req = com.example.data.ai.VeoVideoGenerationRequest(
            prompt = "Dynamic 360 rotating camera showcasing sleek leather shoes with neon lighting",
            productTitle = "Apex Leather Boots",
            aspectRatio = "16:9",
            resolution = "1080p",
            stylePreset = "Dynamic 3D Showcase"
        )
        val result = com.example.data.ai.VeoService.generateVideoAd(req)
        assertTrue(result.isSuccess)
        val videoAd = result.getOrNull()
        assertNotNull(videoAd)
        assertTrue(videoAd!!.productTitle == "Apex Leather Boots")
        assertTrue(videoAd.aspectRatio == "16:9")
        assertTrue(videoAd.status.isNotBlank())
    }

    @Test
    fun testLocationCapabilityPermissionHandling() {
        DeviceCapabilityManager.handleLocationPermissionResult(true)
        assertEquals(com.example.data.ai.CapabilityState.AVAILABLE, DeviceCapabilityManager.locationState.value)
        val reportAvailable = DeviceCapabilityManager.getHonestCapabilityReport(DeviceCapabilityType.LOCATION)
        assertTrue(reportAvailable.isAvailable)
        assertTrue(reportAvailable.message.contains("Location access is active"))

        DeviceCapabilityManager.handleLocationPermissionResult(false)
        assertEquals(com.example.data.ai.CapabilityState.DENIED, DeviceCapabilityManager.locationState.value)
        val reportDenied = DeviceCapabilityManager.getHonestCapabilityReport(DeviceCapabilityType.LOCATION)
        assertFalse(reportDenied.isAvailable)
        assertTrue(reportDenied.message.contains("denied"))
    }

    @Test
    fun testCoordinateToAddressGeocoding() = runBlocking {
        val lat = -33.9249
        val lon = 18.4241
        val geocoded = DeviceCapabilityManager.reverseGeocode(androidContext, lat, lon)
        assertNotNull(geocoded)
        assertEquals(lat, geocoded!!.latitude, 0.001)
        assertEquals(lon, geocoded.longitude, 0.001)
        assertTrue(geocoded.humanReadableAddress.isNotBlank())
    }

    @Test
    fun testAddressToCoordinateGeocoding() = runBlocking {
        val results = DeviceCapabilityManager.geocodeAddress(androidContext, "Cape Town")
        assertNotNull(results)
        // Verify geocode result list structure
        assertTrue(results is List<*>)
    }

    @Test
    fun testGoogleSearchCurrentEventsCitations() = runBlocking {
        val response = CanvasMateAiOrchestrator.processUserPrompt(
            prompt = "What are the latest developments in artificial intelligence and Gemini in 2026?",
            sourceMode = "google_search",
            context = testContext
        )
        assertNotNull(response)
        assertTrue(response.isNotBlank())
    }
}
