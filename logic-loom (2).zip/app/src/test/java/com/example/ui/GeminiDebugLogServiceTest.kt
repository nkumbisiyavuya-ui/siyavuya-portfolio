package com.example.ui

import com.example.data.ai.GeminiClient
import com.example.data.ai.GeminiDebugLogService
import com.example.data.ai.GeminiLogStatus
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GeminiDebugLogServiceTest {

    @Before
    fun setup() {
        GeminiDebugLogService.clearLogs()
    }

    @Test
    fun testPayloadBindingVerification_exactMatch() {
        val rawPrompt = "What is the boiling point of water in Celsius?"
        val payloadJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", rawPrompt))
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", "You are Chuma AI."))
                })
            })
        }

        val report = GeminiDebugLogService.verifyPayloadBinding(rawPrompt, payloadJson)
        assertTrue(report.isValid)
        assertTrue(report.isExactMatch)
        assertTrue(report.isSystemIsolated)
        assertEquals(rawPrompt, report.extractedUserText)
        assertEquals("You are Chuma AI.", report.systemInstructionText)
        assertEquals(0, report.historyTurnsCount)
    }

    @Test
    fun testPayloadBindingVerification_detectsMismatchedOrStalePrompt() {
        val currentPrompt = "Tell me a joke about programming"
        val stalePayloadJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "Old cached question about Cape Town"))
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", "You are Chuma AI."))
                })
            })
        }

        val report = GeminiDebugLogService.verifyPayloadBinding(currentPrompt, stalePayloadJson)
        assertFalse("Should fail validation when payload contains stale data", report.isValid)
        assertFalse(report.isExactMatch)
        assertEquals("Old cached question about Cape Town", report.extractedUserText)
    }

    @Test
    fun testPayloadBindingVerification_withMultiTurnHistory() {
        val currentPrompt = "Can you show that in Kotlin?"
        val historyTurns = listOf(
            "user" to "How do I reverse a string in Python?",
            "model" to "You can use text[::-1]",
            "user" to currentPrompt
        )

        val payloadJson = JSONObject().apply {
            val contents = JSONArray()
            for ((role, text) in historyTurns) {
                contents.put(JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", text))
                    })
                })
            }
            put("contents", contents)
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", "Persona instructions"))
                })
            })
        }

        val report = GeminiDebugLogService.verifyPayloadBinding(currentPrompt, payloadJson)
        assertTrue(report.isValid)
        assertTrue(report.isExactMatch)
        assertEquals(currentPrompt, report.extractedUserText)
        assertEquals(2, report.historyTurnsCount)
    }

    @Test
    fun testRecordRequestStartAndSuccessLifecycle() {
        val requestId = "req-test-101"
        val prompt = "Solve the quadratic equation x^2 - 5x + 6 = 0"
        val payloadJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", "You are Chuma AI."))
                })
            })
        }

        val entry = GeminiDebugLogService.recordRequestStart(
            requestId = requestId,
            rawPrompt = prompt,
            payloadJson = payloadJson,
            taskType = "academic",
            systemInstruction = "You are Chuma AI.",
            targetModels = listOf("gemini-3.5-flash", "gemini-3.1-pro-preview")
        )

        assertEquals(GeminiLogStatus.IN_FLIGHT, entry.status)
        assertTrue(entry.isUserMessageBoundCorrectly)
        assertEquals(prompt, entry.boundUserMessage)
        assertEquals(1, GeminiDebugLogService.getAllLogs().size)

        // Record 200 OK Response
        GeminiDebugLogService.recordResponseSuccess(
            requestId = requestId,
            modelUsed = "gemini-3.5-flash",
            httpStatusCode = 200,
            responseText = "x = 2 or x = 3",
            rawResponseJson = "{\"candidates\":[{\"content\":{\"parts\":[{\"text\":\"x = 2 or x = 3\"}]}}]}",
            durationMs = 150L,
            citationsCount = 0
        )

        val updated = GeminiDebugLogService.getLatestLog()
        assertNotNull(updated)
        assertEquals(GeminiLogStatus.SUCCESS, updated?.status)
        assertEquals("gemini-3.5-flash", updated?.modelUsed)
        assertEquals(200, updated?.httpStatusCode)
        assertEquals(150L, updated?.durationMs)
        assertEquals("x = 2 or x = 3", updated?.responseSnippet)
    }

    @Test
    fun testAskGeminiIntegrationRecordsDebugLogs() = runBlocking {
        val prompt = "What is the capital of France?"
        val response = GeminiClient.askGemini(prompt = prompt, taskType = "general")

        assertNotNull(response)
        assertTrue(response.isNotBlank())

        val latest = GeminiDebugLogService.getLatestLog()
        assertNotNull("GeminiDebugLogService should have recorded the query", latest)
        assertEquals(prompt, latest?.rawUserPrompt)
        assertEquals(prompt, latest?.boundUserMessage)
        assertTrue("User message must be verified as correctly bound", latest?.isUserMessageBoundCorrectly == true)
    }
}
