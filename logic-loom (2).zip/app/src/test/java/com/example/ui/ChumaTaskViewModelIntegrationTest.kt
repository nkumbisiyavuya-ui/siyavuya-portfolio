package com.example.ui

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.datastore.ChumaTaskStatus
import com.example.data.local.CanvasMateDao
import com.example.data.local.CanvasMateDatabase
import com.example.data.repository.AuthRepositoryImpl
import com.example.data.repository.CanvasMateRepository
import com.example.security.SecureSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ChumaTaskViewModelIntegrationTest {

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var database: CanvasMateDatabase
    private lateinit var dao: CanvasMateDao
    private lateinit var repository: CanvasMateRepository
    private lateinit var viewModel: CanvasMateViewModel
    private lateinit var application: Application

    @Before
    fun setUp() = runBlocking {
        Dispatchers.setMain(testDispatcher)
        application = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(application, CanvasMateDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = database.dao()
        repository = CanvasMateRepository(dao)
        val sessionManager = SecureSessionManager(application)
        val authRepository = AuthRepositoryImpl(database.userAccountDao(), dao, sessionManager)
        viewModel = CanvasMateViewModel(application, repository, dao, authRepository)
        viewModel.chumaTaskDataStore.clearState()
    }

    @After
    fun tearDown() = runBlocking {
        viewModel.chumaTaskDataStore.clearState()
        database.close()
        Dispatchers.resetMain()
    }

    @Test
    fun testSendAiPromptPersistsAndCompletesTaskExecution() = runBlocking {
        val prompt = "What is the capital of South Africa?"
        viewModel.sendAiPrompt(prompt, "general")

        // Await the task completing in background coroutine
        val state = kotlinx.coroutines.withTimeout(10000) {
            viewModel.activeChumaTaskState.first { it.status == ChumaTaskStatus.COMPLETED || it.status == ChumaTaskStatus.FAILED }
        }
        assertNotNull(state)
        assertEquals(prompt, state.prompt)
        assertEquals("general", state.taskType)
        assertEquals(ChumaTaskStatus.COMPLETED, state.status)
        assertEquals(1.0f, state.progress, 0.001f)
        assertTrue(state.finalResponse.isNotBlank())
        assertFalse(state.isExecuting)

        // Verify it was persisted to DataStore
        val persisted = viewModel.chumaTaskDataStore.getCurrentState()
        assertEquals(state.taskId, persisted.taskId)
        assertEquals(ChumaTaskStatus.COMPLETED, persisted.status)
        assertEquals(state.finalResponse, persisted.finalResponse)
    }

    @Test
    fun testCancelAiGenerationUpdatesDataStore() = runBlocking {
        // Start a mock in-flight task in DataStore
        val taskId = "task_to_cancel_test"
        viewModel.chumaTaskDataStore.startTask(
            taskId = taskId,
            prompt = "Simulate long research process",
            taskType = "multi_source",
            initialStep = "Querying live sources",
            totalSteps = 4
        )
        // Ensure ViewModel state reflects active task
        kotlinx.coroutines.withTimeout(5000) {
            viewModel.activeChumaTaskState.first { it.taskId == taskId }
        }

        // Cancel generation
        viewModel.cancelAiGeneration()

        val state = kotlinx.coroutines.withTimeout(5000) {
            viewModel.activeChumaTaskState.first { it.status == ChumaTaskStatus.CANCELLED }
        }
        assertEquals(ChumaTaskStatus.CANCELLED, state.status)
        assertFalse(state.isExecuting)
    }

    @Test
    fun testClearActiveChumaTaskCleansDataStore() = runBlocking {
        val taskId = "task_clear_test"
        viewModel.chumaTaskDataStore.startTask(
            taskId = taskId,
            prompt = "Quick question",
            taskType = "general",
            initialStep = "Thinking",
            totalSteps = 1
        )
        kotlinx.coroutines.withTimeout(5000) {
            viewModel.activeChumaTaskState.first { it.taskId == taskId }
        }

        viewModel.clearActiveChumaTask()

        val state = kotlinx.coroutines.withTimeout(5000) {
            viewModel.activeChumaTaskState.first { it.taskId.isBlank() }
        }
        assertEquals("", state.taskId)
        assertEquals(ChumaTaskStatus.IDLE, state.status)
    }
}
