package com.example.ui

import com.example.data.ai.GeminiClient
import com.example.data.ai.GeminiService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ChumaPipelineRepairTest {

    private lateinit var geminiService: GeminiService

    @Before
    fun setup() {
        geminiService = GeminiService()
    }

    @Test
    fun test1_Arithmetic_2Plus2() {
        val response = geminiService.generateOfflineAiResponse("What is 2 + 2?")
        assertTrue("Expected 4 in response, got: $response", response.contains("4"))
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test2_MarkZuckerberg() {
        val response = geminiService.generateOfflineAiResponse("Who is Mark Zuckerberg?")
        assertTrue("Should mention Mark Zuckerberg", response.contains("Mark Zuckerberg", ignoreCase = true))
        assertTrue("Should mention Facebook or Meta", response.contains("Facebook", ignoreCase = true) || response.contains("Meta", ignoreCase = true))
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test3_CalendarDefinition() {
        val response = geminiService.generateOfflineAiResponse("What is a calendar?")
        assertTrue("Should explain what a calendar is", response.contains("calendar", ignoreCase = true))
        assertTrue("Should mention days/months/schedule/organizing",
            response.contains("days", ignoreCase = true) ||
            response.contains("months", ignoreCase = true) ||
            response.contains("organizing", ignoreCase = true) ||
            response.contains("schedule", ignoreCase = true)
        )
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test4_EasternCape() {
        val response = geminiService.generateOfflineAiResponse("Where is the Eastern Cape?")
        assertTrue("Should mention Eastern Cape", response.contains("Eastern Cape", ignoreCase = true))
        assertTrue("Should mention South Africa", response.contains("South Africa", ignoreCase = true))
        assertTrue("Should mention province", response.contains("province", ignoreCase = true))
    }

    @Test
    fun test5_Moraigne_Identity() {
        val response = geminiService.generateOfflineAiResponse("What is Moraigne?")
        assertTrue("Should identify Moraigne as developer of Logic Loom",
            response.contains("Moraigne", ignoreCase = true) &&
            response.contains("Logic Loom", ignoreCase = true)
        )
        assertFalse("Must NEVER answer with Cape Town for Moraigne", response.contains("Cape Town", ignoreCase = true))
    }

    @Test
    fun test6_Joke() {
        val response = geminiService.generateOfflineAiResponse("Tell me a joke.")
        assertTrue("Should return a joke", response.isNotBlank())
        assertTrue("Should contain punchline or humor text", response.contains("dark mode", ignoreCase = true) || response.contains("bugs", ignoreCase = true) || response.contains("Why", ignoreCase = true))
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test7_PythonCalculator() {
        val response = geminiService.generateOfflineAiResponse("Write a Python calculator.")
        assertTrue("Should contain python code block", response.contains("def add", ignoreCase = true) || response.contains("def calculator", ignoreCase = true) || response.contains("```python"))
        assertTrue("Should support basic arithmetic operations", response.contains("+") && response.contains("-") && response.contains("*"))
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test8_ExplainMachineLearning() {
        val response = geminiService.generateOfflineAiResponse("Explain machine learning like I'm a beginner.")
        assertTrue("Should mention machine learning or AI", response.contains("machine learning", ignoreCase = true) || response.contains("artificial intelligence", ignoreCase = true))
        assertTrue("Should use simple, beginner-friendly explanation", response.contains("learn", ignoreCase = true) && (response.contains("data", ignoreCase = true) || response.contains("experience", ignoreCase = true) || response.contains("patterns", ignoreCase = true)))
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test9_MultiTurnContext_FavouriteLanguage() {
        val history = listOf(
            "User" to "My favourite programming language is Python.",
            "AI" to "That's awesome! Python is great for data science, automation, and backend development."
        )
        val response = geminiService.generateOfflineAiResponse(
            prompt = "What is my favourite programming language?",
            history = history
        )
        assertTrue("Should remember Python from conversation history, got: $response", response.contains("Python", ignoreCase = true))
        assertFalse("Must not contain Cape Town", response.contains("Cape Town is the legislative capital"))
    }

    @Test
    fun test10_ContextSwitch_CapitalToMultiplication() {
        val history = listOf(
            "User" to "What is the capital of South Africa?",
            "AI" to "South Africa has three capitals: Pretoria, Cape Town, and Bloemfontein."
        )
        val response = geminiService.generateOfflineAiResponse(
            prompt = "What is 15 × 7?",
            history = history
        )
        assertTrue("Should answer 105 or calculation, got: $response", response.contains("105"))
        assertFalse("Must NOT discuss South Africa capitals on arithmetic query", response.contains("Pretoria", ignoreCase = true) || response.contains("capital", ignoreCase = true))
    }

    @Test
    fun testAntiRegression_10DistinctConsecutiveQueries() {
        val testQueries = listOf(
            "What is 2 + 2?",
            "Who is Mark Zuckerberg?",
            "What is a calendar?",
            "Where is the Eastern Cape?",
            "What is Moraigne?",
            "Tell me a joke.",
            "Write a Python calculator.",
            "Explain machine learning like I'm a beginner.",
            "What is 15 × 7?",
            "What is photosynthesis?"
        )

        val responses = mutableListOf<String>()
        for (query in testQueries) {
            val res = geminiService.generateOfflineAiResponse(query)
            assertNotNull(res)
            assertTrue("Response for '$query' should not be blank", res.isNotBlank())
            responses.add(res)
        }

        // Verify that all 10 responses are distinct and none produce the same canned response
        val uniqueResponses = responses.toSet()
        assertEquals("All 10 queries should produce distinct responses", 10, uniqueResponses.size)

        // Verify Cape Town is not in unrelated questions
        assertFalse("2+2 should not contain Cape Town", responses[0].contains("Cape Town"))
        assertFalse("Mark Zuckerberg should not contain Cape Town", responses[1].contains("Cape Town"))
        assertFalse("Calendar should not contain Cape Town", responses[2].contains("Cape Town"))
        assertFalse("Moraigne should not contain Cape Town", responses[4].contains("Cape Town"))
        assertFalse("Joke should not contain Cape Town", responses[5].contains("Cape Town"))
        assertFalse("Python calculator should not contain Cape Town", responses[6].contains("Cape Town"))
        assertFalse("Machine learning should not contain Cape Town", responses[7].contains("Cape Town"))
        assertFalse("15 x 7 should not contain Cape Town", responses[8].contains("Cape Town"))
    }
}
