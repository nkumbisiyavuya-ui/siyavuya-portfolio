package com.example.ui

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.ui.components.ConnectivityHeaderIndicator
import com.example.ui.theme.CanvasMateTheme
import com.example.util.ConnectivityStatus
import com.example.util.NetworkMonitor
import com.example.util.NetworkType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ConnectivityIndicatorTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testConnectivityStatusModel() {
        val onlineWifi = ConnectivityStatus(
            isConnected = true,
            networkType = NetworkType.WIFI,
            isMetered = false
        )
        assertTrue(onlineWifi.isConnected)
        assertEquals("Wi-Fi", onlineWifi.shortLabel)
        assertTrue(onlineWifi.detailedStatus.contains("Wi-Fi"))

        val onlineCellular = ConnectivityStatus(
            isConnected = true,
            networkType = NetworkType.CELLULAR,
            isMetered = true
        )
        assertTrue(onlineCellular.isConnected)
        assertEquals("Cellular", onlineCellular.shortLabel)

        val offline = ConnectivityStatus(
            isConnected = false,
            networkType = NetworkType.NONE
        )
        assertFalse(offline.isConnected)
        assertEquals("Offline", offline.shortLabel)
        assertTrue(offline.detailedStatus.contains("Local Vault Active"))
    }

    @Test
    fun testNetworkMonitorInitialization() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val monitor = NetworkMonitor(context)
        val status = monitor.currentStatus()
        assertNotNull(status)
    }

    @Test
    fun testConnectivityIndicatorRendersOnlineState() {
        val status = ConnectivityStatus(
            isConnected = true,
            networkType = NetworkType.WIFI,
            isMetered = false
        )

        composeTestRule.setContent {
            CanvasMateTheme {
                ConnectivityHeaderIndicator(status = status)
            }
        }

        composeTestRule.onNodeWithTag("connectivity_indicator").assertIsDisplayed()
        composeTestRule.onNodeWithText("Wi-Fi").assertIsDisplayed()
    }

    @Test
    fun testConnectivityIndicatorRendersOfflineState() {
        val status = ConnectivityStatus(
            isConnected = false,
            networkType = NetworkType.NONE
        )

        composeTestRule.setContent {
            CanvasMateTheme {
                ConnectivityHeaderIndicator(status = status)
            }
        }

        composeTestRule.onNodeWithTag("connectivity_indicator").assertIsDisplayed()
        composeTestRule.onNodeWithText("Offline").assertIsDisplayed()
    }

    @Test
    fun testClickingIndicatorOpensTelemetryDialog() {
        var refreshed = false
        val status = ConnectivityStatus(
            isConnected = true,
            networkType = NetworkType.WIFI,
            latencyEstimateMs = 24
        )

        composeTestRule.setContent {
            CanvasMateTheme {
                ConnectivityHeaderIndicator(
                    status = status,
                    onRefreshStatus = { refreshed = true }
                )
            }
        }

        // Tap the indicator
        composeTestRule.onNodeWithTag("connectivity_indicator").performClick()

        // Telemetry dialog should open
        composeTestRule.onNodeWithTag("connectivity_telemetry_dialog").assertIsDisplayed()
        composeTestRule.onNodeWithText("Network Connectivity").assertIsDisplayed()
        composeTestRule.onNodeWithText("Logic Loom Intelligence Mesh").assertIsDisplayed()
    }
}
