package com.example.ui

import com.example.data.ai.GeminiService
import com.example.data.tools.CalculatorTool
import com.example.data.tools.CurrencyTool
import com.example.data.tools.TimeTool
import com.example.data.tools.WeatherTool
import com.example.data.tools.WebSearchTool
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChumaStep4Test {

    private val geminiService = GeminiService()

    @Test
    fun test1_GeneralKnowledge_AnsweredDirectly() {
        val prompt = "Who is Mark Zuckerberg?"
        val response = geminiService.generateOfflineAiResponse(prompt)

        assertTrue("Should mention Mark Zuckerberg", response.contains("Mark Zuckerberg", ignoreCase = true))
        assertTrue("Should mention Meta or Facebook", response.contains("Meta", ignoreCase = true) || response.contains("Facebook", ignoreCase = true))
        assertFalse("Should not mention fake tools", response.contains("[ERROR]", ignoreCase = true))
    }

    @Test
    fun test2_Calculation_DeterministicCalculator() {
        val calcResult = CalculatorTool.calculate("928 * 37")
        assertTrue("Calculation should succeed", calcResult.success)
        assertEquals("928 * 37 should equal 34336", 34336.0, calcResult.result, 0.001)

        val response = geminiService.generateOfflineAiResponse("What is 928 * 37?")
        assertTrue("Response should contain 34,336 or 34336", response.contains("34,336") || response.contains("34336"))

        val percentResult = CalculatorTool.calculate("15% of 2500")
        assertTrue("Percentage calculation should succeed", percentResult.success)
        assertEquals("15% of 2500 should equal 375", 375.0, percentResult.result, 0.001)
    }

    @Test
    fun test3_Time_TimeToolWithTimezones() {
        val timeResult = TimeTool.getCurrentTime("Tokyo")
        assertTrue("Time query should succeed", timeResult.success)
        assertEquals("Timezone should be Asia/Tokyo", "Asia/Tokyo", timeResult.timezoneId)
        assertTrue("Formatted time should not be blank", timeResult.formattedTime.isNotBlank())

        val holidayResponse = TimeTool.resolveCalendarEventDate("What day is Christmas this year?")
        assertNotNull("Should resolve Christmas day of week", holidayResponse)
        assertTrue("Should mention Christmas", holidayResponse!!.contains("Christmas", ignoreCase = true))

        val chumaResponse = geminiService.generateOfflineAiResponse("What time is it in Tokyo?")
        assertTrue("Chuma response should contain Tokyo time report", chumaResponse.contains("Tokyo", ignoreCase = true))
    }

    @Test
    fun test4_Weather_WeatherToolLiveOrStructured() = runBlocking {
        val response = geminiService.generateOfflineAiResponse("What is the weather in Cape Town?")
        assertTrue("Should mention Cape Town", response.contains("Cape Town", ignoreCase = true))
        assertTrue("Should mention temperature or condition", response.contains("Temperature", ignoreCase = true) || response.contains("°C"))
    }

    @Test
    fun test5_LocationRespect_ExplainsPermissionNeeded() = runBlocking {
        // Querying "near me" when location permission is not granted must not fabricate coordinates
        val response = geminiService.generateOfflineAiResponse("What is the weather near me?")
        assertTrue(
            "Should explain location permission is needed or ask for city",
            response.contains("permission", ignoreCase = true) || response.contains("location", ignoreCase = true)
        )
        assertFalse("Must not fabricate fake GPS coordinates", response.contains("-33.9188617826"))
    }

    @Test
    fun test6_WebSearch_StructuredReportWithGenuineSources() = runBlocking {
        val response = geminiService.generateOfflineAiResponse("Search the web for information about CPUT")
        assertTrue("Should mention CPUT or Cape Peninsula", response.contains("CPUT") || response.contains("Cape Peninsula"))
        assertTrue("Should include genuine source citations", response.contains("cput.ac.za") || response.contains("wikipedia.org") || response.contains("Sources"))
    }

    @Test
    fun test7_RecentInformation_LatestAiNews() = runBlocking {
        val response = geminiService.generateOfflineAiResponse("What is the latest AI news?")
        assertTrue("Should synthesize AI developments", response.contains("AI") || response.contains("Intelligence"))
        assertTrue("Should provide verified sources", response.contains("Sources") || response.contains("deepmind.google") || response.contains("arxiv.org"))
    }

    @Test
    fun test8_MultiTurnContext_FollowUpResolvesEntity() {
        val history = listOf(
            Pair("User", "Who is Elon Musk?"),
            Pair("Assistant", "Elon Musk is a technology entrepreneur, CEO of SpaceX and Tesla.")
        )
        val followUp = "How old is he?"
        val response = geminiService.generateOfflineAiResponse(followUp, "general", history)

        assertTrue("Should answer Elon Musk's age / birth info", response.contains("Elon Musk", ignoreCase = true) || response.contains("born", ignoreCase = true) || response.contains("years old", ignoreCase = true))
    }

    @Test
    fun test9_FailureHandling_GracefulMessage() = runBlocking {
        // Direct tool search response on offline/empty query
        val searchResponse = WebSearchTool.searchWeb("")
        assertFalse("Empty search should not succeed", searchResponse.success)
        assertTrue("Should provide graceful guidance", searchResponse.formattedAnswer.isNotBlank())
    }

    @Test
    fun test10_NoFakeInformation_HallucinationResistance() {
        val obscurePrompt = "What happened at the Martian Olympics in Bloemfontein yesterday?"
        val response = geminiService.generateOfflineAiResponse(obscurePrompt)

        assertTrue(
            "Should acknowledge lack of information or unverified occurrence",
            response.contains("do not have verified information", ignoreCase = true) ||
            response.contains("no credible sources", ignoreCase = true) ||
            response.contains("unverified", ignoreCase = true)
        )
        assertFalse("Should not hallucinate Martian Olympic medals", response.contains("gold medal winner"))
    }
}
