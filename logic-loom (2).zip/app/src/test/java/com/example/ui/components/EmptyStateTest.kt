package com.example.ui.components

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EmptyStateTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun emptyStateDisplaysTitleDescriptionAndActionButton() {
        var actionClicked = false

        composeTestRule.setContent {
            EmptyState(
                title = "No Items Found",
                description = "Your list is currently empty.",
                actionLabel = "Add Item",
                onActionClick = { actionClicked = true }
            )
        }

        composeTestRule.onNodeWithTag("empty_state_container").assertIsDisplayed()
        composeTestRule.onNodeWithTag("empty_state_title").assertIsDisplayed()
        composeTestRule.onNodeWithText("No Items Found").assertIsDisplayed()
        composeTestRule.onNodeWithTag("empty_state_description").assertIsDisplayed()
        composeTestRule.onNodeWithText("Your list is currently empty.").assertIsDisplayed()

        composeTestRule.onNodeWithTag("empty_state_action_button").assertIsDisplayed()
        composeTestRule.onNodeWithText("Add Item").assertIsDisplayed()
        composeTestRule.onNodeWithTag("empty_state_action_button").performClick()

        assertTrue(actionClicked)
    }

    @Test
    fun emptyTasksStateDisplaysTaskSpecificText() {
        composeTestRule.setContent {
            EmptyTasksState()
        }

        composeTestRule.onNodeWithText("No Tasks Found").assertIsDisplayed()
        composeTestRule.onNodeWithTag("empty_state_icon").assertIsDisplayed()
    }
}
