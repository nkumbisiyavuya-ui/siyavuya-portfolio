package com.example.util

import com.google.firebase.auth.FirebaseAuthException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthUtilsTest {

    @Test
    fun testCustomTagIsAuthDiag() {
        assertEquals("AuthDiag", AuthUtils.TAG)
    }

    @Test
    fun testErrorCodeMappingForInvalidEmail() {
        val msg1 = AuthUtils.mapErrorCodeToUserMessage("INVALID_EMAIL")
        val msg2 = AuthUtils.mapErrorCodeToUserMessage("ERROR_INVALID_EMAIL")
        assertTrue(msg1.contains("invalid", ignoreCase = true))
        assertTrue(msg2.contains("invalid", ignoreCase = true))
    }

    @Test
    fun testErrorCodeMappingForUserNotFound() {
        val msg1 = AuthUtils.mapErrorCodeToUserMessage("USER_NOT_FOUND")
        val msg2 = AuthUtils.mapErrorCodeToUserMessage("ERROR_USER_NOT_FOUND")
        assertTrue(msg1.contains("No account found", ignoreCase = true))
        assertTrue(msg2.contains("No account found", ignoreCase = true))
    }

    @Test
    fun testErrorCodeMappingForMissingEmail() {
        val msg1 = AuthUtils.mapErrorCodeToUserMessage("MISSING_EMAIL")
        val msg2 = AuthUtils.mapErrorCodeToUserMessage("ERROR_MISSING_EMAIL")
        assertTrue(msg1.contains("enter your email", ignoreCase = true))
        assertTrue(msg2.contains("enter your email", ignoreCase = true))
    }

    @Test
    fun testErrorCodeMappingForTooManyRequests() {
        val msg = AuthUtils.mapErrorCodeToUserMessage("ERROR_TOO_MANY_REQUESTS")
        assertTrue(msg.contains("Too many", ignoreCase = true))
    }

    @Test
    fun testErrorCodeMappingForOperationNotAllowed() {
        val msg = AuthUtils.mapErrorCodeToUserMessage("ERROR_OPERATION_NOT_ALLOWED")
        assertTrue(msg.contains("disabled", ignoreCase = true))
    }

    @Test
    fun testErrorCodeMappingForUnknown() {
        val msg = AuthUtils.mapErrorCodeToUserMessage("CUSTOM_ERROR_123")
        assertTrue(msg.contains("CUSTOM_ERROR_123"))
    }

    @Test
    fun testMaskApiKey() {
        val masked = AuthUtils.maskApiKey("AIzaSyBLogicLoomAuthAppKey2026Secure01")
        assertEquals("AIzaSy...re01", masked)
        val shortMasked = AuthUtils.maskApiKey("12345")
        assertEquals("***", shortMasked)
        val nullMasked = AuthUtils.maskApiKey(null)
        assertEquals("none", nullMasked)
    }

    @Test
    fun testIsApiKeyErrorDetection() {
        val ex1 = Exception("An internal error has occurred [Api key not valid. Please pass a valid Api key]")
        assertTrue(AuthUtils.isApiKeyError(ex1))

        val ex2 = Exception("API_KEY_INVALID")
        assertTrue(AuthUtils.isApiKeyError(ex2))

        val ex3 = Exception("Normal exception")
        org.junit.Assert.assertFalse(AuthUtils.isApiKeyError(ex3))
    }

    @Test
    fun testIsConfigurationNotFoundErrorDetection() {
        val ex1 = Exception("CONFIGURATION_NOT_FOUND")
        assertTrue(AuthUtils.isConfigurationNotFoundError(ex1))

        val ex2 = Exception("An internal error has occurred [ CONFIGURATION_NOT_FOUND ]")
        assertTrue(AuthUtils.isConfigurationNotFoundError(ex2))

        val ex3 = Exception("Normal exception")
        org.junit.Assert.assertFalse(AuthUtils.isConfigurationNotFoundError(ex3))
    }
}
