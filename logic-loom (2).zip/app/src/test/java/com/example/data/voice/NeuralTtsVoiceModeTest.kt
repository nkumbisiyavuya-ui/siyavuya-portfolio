package com.example.data.voice

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NeuralTtsVoiceModeTest {

    @Test
    fun testStreamingTextChunker_SplitsOnSentenceBoundaries() {
        val chunker = StreamingTextChunker()
        val tokens = listOf(
            "An API is an ",
            "interface that allows different ",
            "software systems to communicate. ",
            "It acts as a messenger between ",
            "applications!"
        )

        val emitted = mutableListOf<String>()
        for (token in tokens) {
            val chunks = chunker.processToken(token)
            emitted.addAll(chunks)
        }
        val tail = chunker.flush()
        if (tail != null) emitted.add(tail)

        assertEquals(2, emitted.size)
        assertEquals("An API is an interface that allows different software systems to communicate.", emitted[0])
        assertEquals("It acts as a messenger between applications!", emitted[1])
    }

    @Test
    fun testStreamingTextChunker_CleansMarkdownArtifacts() {
        val raw = "**Welcome to Logic Loom!** Here is a `code snippet` and a [link](https://logicloom.ai)."
        val cleaned = StreamingTextChunker.cleanForSpeech(raw)

        assertFalse(cleaned.contains("**"))
        assertFalse(cleaned.contains("`"))
        assertFalse(cleaned.contains("https://"))
        assertTrue(cleaned.contains("Welcome to Logic Loom!"))
        assertTrue(cleaned.contains("link"))
    }

    @Test
    fun testStreamingTextChunker_FlushEmitsRemainingUnpunctuatedTail() {
        val chunker = StreamingTextChunker()
        chunker.processToken("This is a sentence without punctuation")
        val flushed = chunker.flush()

        assertNotNull(flushed)
        assertEquals("This is a sentence without punctuation", flushed)
    }

    @Test
    fun testVoiceProfiles_HaveRealVerifiedElevenLabsVoiceIds() {
        val female = CHUMA_VOICE_PROFILES.first { it.id == "female" }
        val male = CHUMA_VOICE_PROFILES.first { it.id == "male" }
        val horizon = CHUMA_VOICE_PROFILES.first { it.id == "horizon" }

        // TASK 1: Verified real ElevenLabs voice IDs
        assertEquals("Sy7d8PNbkbjIJxf1li2K", female.neuralVoiceId)
        assertEquals("xvDjI8KMgjF1nCoPoNKX", male.neuralVoiceId)
        assertEquals("fFAtoTPtP0TtMyhbR3L9", horizon.neuralVoiceId)

        // Verify placeholder IDs are completely eliminated
        for (profile in CHUMA_VOICE_PROFILES) {
            assertFalse(profile.neuralVoiceId?.contains("placeholder") == true)
            assertFalse(profile.neuralVoiceId?.contains("chuma_female_neural") == true)
            assertFalse(profile.neuralVoiceId?.contains("chuma_male_neural") == true)
            assertFalse(profile.neuralVoiceId?.contains("chuma_horizon_neural") == true)
        }
    }

    @Test
    fun testVoiceProfiles_KeepCorrectInternalNames() {
        assertEquals("Chuma — Female", CHUMA_VOICE_PROFILES[0].name)
        assertEquals("Chuma — Male", CHUMA_VOICE_PROFILES[1].name)
        assertEquals("Chuma — Horizon", CHUMA_VOICE_PROFILES[2].name)
    }

    @Test
    fun testCompositeTextToSpeechProvider_FallsBackGracefullyWhenNeuralUnconfigured() {
        val testProfile = CHUMA_VOICE_PROFILES[0]
        var fallbackCalled = false
        var fallbackSpokenText = ""

        val dummyFallback = object : TextToSpeechProvider {
            override val isReady: Boolean = true
            override val providerName: String = "Mock Android System TTS"
            override fun speak(
                text: String,
                profile: VoiceProfile,
                volume: Float,
                speed: Float,
                utteranceId: String,
                onStart: () -> Unit,
                onDone: () -> Unit,
                onError: (String) -> Unit
            ) {
                fallbackCalled = true
                fallbackSpokenText = text
                onStart()
                onDone()
            }
            override fun stop() {}
            override fun destroy() {}
        }

        val dummyUnconfiguredNeural = object : TextToSpeechProvider {
            override val isReady: Boolean = false
            override val providerName: String = "ElevenLabs Neural TTS"
            override fun speak(
                text: String,
                profile: VoiceProfile,
                volume: Float,
                speed: Float,
                utteranceId: String,
                onStart: () -> Unit,
                onDone: () -> Unit,
                onError: (String) -> Unit
            ) {
                onError("Backend proxy not configured")
            }
            override fun stop() {}
            override fun destroy() {}
        }

        val composite = CompositeTextToSpeechProvider(
            context = ApplicationProvider.getApplicationContext(),
            primaryProvider = dummyUnconfiguredNeural,
            fallbackProvider = dummyFallback
        )

        var turnStarted = false
        var turnDone = false

        composite.speak(
            text = "Hello from Logic Loom.",
            profile = testProfile,
            volume = 0.9f,
            speed = 1.0f,
            onStart = { turnStarted = true },
            onDone = { turnDone = true }
        )

        assertTrue("Fallback must be invoked when neural provider is unconfigured", fallbackCalled)
        assertEquals("Hello from Logic Loom.", fallbackSpokenText)
        assertTrue(composite.isUsingFallback.value)
        assertEquals("Using device voice", composite.statusNotice.value)
        assertTrue(turnStarted)
        assertTrue(turnDone)
    }

    @Test
    fun testBargeIn_StopsBothPrimaryAndFallbackImmediately() {
        var primaryStopped = false
        var fallbackStopped = false

        val dummyPrimary = object : TextToSpeechProvider {
            override val isReady: Boolean = true
            override fun speak(text: String, profile: VoiceProfile, volume: Float, speed: Float, utteranceId: String, onStart: () -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {}
            override fun stop() { primaryStopped = true }
            override fun destroy() {}
        }

        val dummyFallback = object : TextToSpeechProvider {
            override val isReady: Boolean = true
            override fun speak(text: String, profile: VoiceProfile, volume: Float, speed: Float, utteranceId: String, onStart: () -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {}
            override fun stop() { fallbackStopped = true }
            override fun destroy() {}
        }

        val composite = CompositeTextToSpeechProvider(
            context = ApplicationProvider.getApplicationContext(),
            primaryProvider = dummyPrimary,
            fallbackProvider = dummyFallback
        )

        composite.stop()

        assertTrue("Barge-in stop must stop primary provider immediately", primaryStopped)
        assertTrue("Barge-in stop must stop fallback provider immediately", fallbackStopped)
    }

    @Test
    fun testSequentialAudioPlayer_DiscardsStaleGenerationIdChunks() {
        val player = SequentialAudioPlayer(ApplicationProvider.getApplicationContext())
        val gen1 = player.startNewGeneration("gen_1")

        // Invalidate gen1 by starting gen2 (simulating user barge-in / interruption)
        val gen2 = player.startNewGeneration("gen_2")

        var playedStaleChunk = false
        player.enqueueChunk(
            audioBytes = byteArrayOf(1, 2, 3),
            generationId = gen1,
            onStart = { playedStaleChunk = true }
        )

        assertFalse("Stale chunk from superseded generation must be discarded immediately", playedStaleChunk)
        player.destroy()
    }

    @Test
    fun testBargeIn_InvalidatesActiveGenerationId() {
        val player = SequentialAudioPlayer(ApplicationProvider.getApplicationContext())
        val initialGen = player.activeGenerationId

        player.stop()

        val newGen = player.activeGenerationId
        assertNotEquals("Barge-in stop must generate a new activeGenerationId", initialGen, newGen)
        player.destroy()
    }
}
