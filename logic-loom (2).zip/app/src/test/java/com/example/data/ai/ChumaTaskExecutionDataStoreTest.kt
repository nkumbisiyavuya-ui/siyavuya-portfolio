package com.example.data.ai

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.datastore.ChumaTaskExecutionDataStore
import com.example.data.ai.datastore.ChumaTaskExecutionState
import com.example.data.ai.datastore.ChumaTaskStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ChumaTaskExecutionDataStoreTest {

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var context: Context
    private lateinit var dataStore: ChumaTaskExecutionDataStore

    @Before
    fun setUp() = runBlocking {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        dataStore = ChumaTaskExecutionDataStore(context)
        dataStore.clearState()
    }

    @After
    fun tearDown() = runBlocking {
        dataStore.clearState()
        Dispatchers.resetMain()
    }

    @Test
    fun testInitialStateIsDefaultAndIdle() = runBlocking {
        val state = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.IDLE, state.status)
        assertEquals("", state.taskId)
        assertEquals(0f, state.progress, 0.001f)
        assertFalse(state.isExecuting)
    }

    @Test
    fun testStartTaskPersistsState() = runBlocking {
        val taskId = "test_task_101"
        val prompt = "Explain Big-O time complexity with Python examples"
        val taskType = "complex_problem"

        dataStore.startTask(
            taskId = taskId,
            prompt = prompt,
            taskType = taskType,
            initialStep = "Analyzing query...",
            totalSteps = 4
        )

        val retrieved = dataStore.getCurrentState()
        assertEquals(taskId, retrieved.taskId)
        assertEquals(prompt, retrieved.prompt)
        assertEquals(taskType, retrieved.taskType)
        assertEquals(ChumaTaskStatus.QUEUED, retrieved.status)
        assertEquals("Analyzing query...", retrieved.currentStep)
        assertEquals(1, retrieved.currentStepIndex)
        assertEquals(4, retrieved.totalSteps)
        assertTrue(retrieved.isExecuting)
        assertTrue(retrieved.startedAt > 0L)
    }

    @Test
    fun testStepProgressionUpdatesPersistedState() = runBlocking {
        val taskId = "test_task_step_progression"
        dataStore.startTask(taskId, "Create personalized study plan", "study_plan")

        // Step 1
        dataStore.updateStep(
            taskId = taskId,
            status = ChumaTaskStatus.ANALYZING_INTENT,
            stepIndex = 1,
            stepDescription = "Classifying study plan request",
            progress = 0.25f
        )
        var state = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.ANALYZING_INTENT, state.status)
        assertEquals(0.25f, state.progress, 0.001f)
        assertEquals(25, state.percentInt)

        // Step 2
        dataStore.updateStep(
            taskId = taskId,
            status = ChumaTaskStatus.RETRIEVING_CONTEXT,
            stepIndex = 2,
            stepDescription = "Retrieving timetable and exam dates",
            progress = 0.50f
        )
        state = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.RETRIEVING_CONTEXT, state.status)
        assertEquals(0.50f, state.progress, 0.001f)
        assertEquals(50, state.percentInt)

        // Step 3
        dataStore.updateStep(
            taskId = taskId,
            status = ChumaTaskStatus.EXECUTING_TOOLS,
            stepIndex = 3,
            stepDescription = "Executing algorithmic scheduler",
            progress = 0.75f
        )
        state = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.EXECUTING_TOOLS, state.status)
        assertEquals(0.75f, state.progress, 0.001f)

        // Step 4
        dataStore.updateStep(
            taskId = taskId,
            status = ChumaTaskStatus.SYNTHESIZING,
            stepIndex = 4,
            stepDescription = "Synthesizing schedule output",
            progress = 0.95f,
            partialOutput = "Session 1: Mathematics"
        )
        state = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.SYNTHESIZING, state.status)
        assertEquals(0.95f, state.progress, 0.001f)
        assertEquals("Session 1: Mathematics", state.partialOutput)
    }

    @Test
    fun testCompleteTaskSetsFinalResponseAndProgress() = runBlocking {
        val taskId = "test_task_completion"
        dataStore.startTask(taskId, "What is Newton's second law?", "academic")

        val response = "Newton's second law states that F = m * a."
        dataStore.completeTask(taskId, response)

        val completedState = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.COMPLETED, completedState.status)
        assertEquals(1.0f, completedState.progress, 0.001f)
        assertEquals(response, completedState.finalResponse)
        assertFalse(completedState.isExecuting)
        assertNotNull(completedState.completedAt)
    }

    @Test
    fun testFailTaskRecordsErrorMessage() = runBlocking {
        val taskId = "test_task_failure"
        dataStore.startTask(taskId, "Network query", "general")

        val error = "Network connection timeout"
        dataStore.failTask(taskId, error)

        val failedState = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.FAILED, failedState.status)
        assertEquals(error, failedState.errorMessage)
        assertFalse(failedState.isExecuting)
    }

    @Test
    fun testCancelTaskMarksStatusCancelled() = runBlocking {
        val taskId = "test_task_cancel"
        dataStore.startTask(taskId, "Long running task", "general")
        dataStore.cancelTask(taskId)

        val state = dataStore.getCurrentState()
        assertEquals(ChumaTaskStatus.CANCELLED, state.status)
        assertFalse(state.isExecuting)
    }

    @Test
    fun testStateSurvivesAppRestartSimulation() = runBlocking {
        val taskId = "task_across_restart"
        val prompt = "Persistent task surviving process death"
        val taskType = "multi_source"

        // Instance 1 writes to DataStore
        val instance1 = ChumaTaskExecutionDataStore(context)
        instance1.startTask(taskId, prompt, taskType, "Analyzing intent...", 4)
        instance1.updateStep(
            taskId = taskId,
            status = ChumaTaskStatus.RETRIEVING_CONTEXT,
            stepIndex = 2,
            stepDescription = "Context retrieved successfully",
            progress = 0.55f,
            partialOutput = "Partial draft response"
        )

        // Verify instance 1 state
        val stateBeforeRestart = instance1.getCurrentState()
        assertEquals(taskId, stateBeforeRestart.taskId)
        assertEquals(0.55f, stateBeforeRestart.progress, 0.001f)

        // Instance 2 simulates process restart reading from disk DataStore
        val instance2 = ChumaTaskExecutionDataStore(context)
        val stateAfterRestart = instance2.getCurrentState()

        assertEquals(taskId, stateAfterRestart.taskId)
        assertEquals(prompt, stateAfterRestart.prompt)
        assertEquals(taskType, stateAfterRestart.taskType)
        assertEquals(ChumaTaskStatus.RETRIEVING_CONTEXT, stateAfterRestart.status)
        assertEquals("Context retrieved successfully", stateAfterRestart.currentStep)
        assertEquals(2, stateAfterRestart.currentStepIndex)
        assertEquals(0.55f, stateAfterRestart.progress, 0.001f)
        assertEquals("Partial draft response", stateAfterRestart.partialOutput)
        assertTrue(stateAfterRestart.isExecuting)
    }

    @Test
    fun testClearStateResetsAllKeys() = runBlocking {
        dataStore.startTask("task_to_clear", "test prompt", "general")
        dataStore.clearState()

        val clearedState = dataStore.getCurrentState()
        assertEquals(ChumaTaskExecutionState.DEFAULT, clearedState)
        assertEquals("", clearedState.taskId)
        assertEquals(ChumaTaskStatus.IDLE, clearedState.status)
    }
}
