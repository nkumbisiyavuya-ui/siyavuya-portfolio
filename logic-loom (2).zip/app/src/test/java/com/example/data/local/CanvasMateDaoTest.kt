package com.example.data.local

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CanvasMateDaoTest {

    private lateinit var database: CanvasMateDatabase
    private lateinit var dao: CanvasMateDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, CanvasMateDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = database.dao()
    }

    @After
    fun closeDb() {
        database.close()
    }

    // --- BUDGET MODULE TESTS ---

    @Test
    fun insertAndRetrieveBudgetItem() = runBlocking {
        val budgetItem = BudgetItem(
            title = "NSFAS Allowance",
            amount = 1750.0,
            type = "Income",
            category = "Bursary",
            date = "2026-08-01"
        )

        val id = dao.insertBudgetItem(budgetItem)
        assertTrue(id > 0)

        val retrievedItem = dao.getBudgetItemById(id).first()
        assertNotNull(retrievedItem)
        assertEquals("NSFAS Allowance", retrievedItem?.title)
        assertEquals(1750.0, retrievedItem?.amount ?: 0.0, 0.01)
        assertEquals("Income", retrievedItem?.type)
        assertEquals("Bursary", retrievedItem?.category)

        val allItems = dao.getAllBudgetItems().first()
        assertEquals(1, allItems.size)
        assertEquals(id, allItems[0].id)
    }

    @Test
    fun filterBudgetItemsByTypeAndCategory() = runBlocking {
        val item1 = BudgetItem(title = "Bursary Payment", amount = 3000.0, type = "Income", category = "Allowance")
        val item2 = BudgetItem(title = "Campus Cafeteria", amount = 150.0, type = "Expense", category = "Food")
        val item3 = BudgetItem(title = "Groceries", amount = 450.0, type = "Expense", category = "Food")

        dao.insertBudgetItem(item1)
        dao.insertBudgetItem(item2)
        dao.insertBudgetItem(item3)

        val expenses = dao.getBudgetItemsByType("Expense").first()
        assertEquals(2, expenses.size)
        assertTrue(expenses.all { it.type == "Expense" })

        val foodExpenses = dao.getBudgetItemsByCategory("Food").first()
        assertEquals(2, foodExpenses.size)
        assertTrue(foodExpenses.all { it.category == "Food" })

        val income = dao.getBudgetItemsByType("Income").first()
        assertEquals(1, income.size)
        assertEquals("Bursary Payment", income[0].title)
    }

    @Test
    fun updateAndDeleteBudgetItem() = runBlocking {
        val item = BudgetItem(title = "Textbooks", amount = 800.0, type = "Expense", category = "Books")
        val id = dao.insertBudgetItem(item)

        val updatedItem = BudgetItem(id = id, title = "Textbooks & Stationery", amount = 950.0, type = "Expense", category = "Books")
        dao.updateBudgetItem(updatedItem)

        val retrievedAfterUpdate = dao.getBudgetItemById(id).first()
        assertEquals("Textbooks & Stationery", retrievedAfterUpdate?.title)
        assertEquals(950.0, retrievedAfterUpdate?.amount ?: 0.0, 0.01)

        dao.deleteBudgetItem(id)
        val retrievedAfterDelete = dao.getBudgetItemById(id).first()
        assertNull(retrievedAfterDelete)

        val allItems = dao.getAllBudgetItems().first()
        assertTrue(allItems.isEmpty())
    }

    @Test
    fun insertUpdateDeleteBudgetGoal() = runBlocking {
        val goal = BudgetGoal(
            title = "New Laptop Fund",
            targetAmount = 15000.0,
            currentAmount = 5000.0,
            deadline = "2026-12-31"
        )
        val id = dao.insertBudgetGoal(goal)
        assertTrue(id > 0)

        val allGoals = dao.getAllBudgetGoals().first()
        assertEquals(1, allGoals.size)
        assertEquals("New Laptop Fund", allGoals[0].title)

        val updatedGoal = BudgetGoal(
            id = id,
            title = "New Laptop Fund",
            targetAmount = 15000.0,
            currentAmount = 8500.0,
            deadline = "2026-12-31"
        )
        dao.updateBudgetGoal(updatedGoal)

        val retrieved = dao.getBudgetGoalById(id).first()
        assertEquals(8500.0, retrieved?.currentAmount ?: 0.0, 0.01)

        dao.deleteBudgetGoal(id)
        val emptyGoals = dao.getAllBudgetGoals().first()
        assertTrue(emptyGoals.isEmpty())
    }

    // --- TASK MODULE TESTS ---

    @Test
    fun insertAndRetrieveAcademicTask() = runBlocking {
        val task = AcademicTask(
            title = "CSC3002F Project Milestone 1",
            module = "CSC3002F",
            description = "Submit system architecture & interface specs",
            dueDate = "2026-08-20",
            priority = "High",
            taskType = "Project",
            status = "In Progress",
            progress = 40
        )
        val id = dao.insertAcademicTask(task)
        assertTrue(id > 0)

        val retrieved = dao.getAcademicTaskById(id).first()
        assertNotNull(retrieved)
        assertEquals("CSC3002F Project Milestone 1", retrieved?.title)
        assertEquals("CSC3002F", retrieved?.module)
        assertEquals("High", retrieved?.priority)
        assertEquals("In Progress", retrieved?.status)
        assertEquals(40, retrieved?.progress)
    }

    @Test
    fun filterAcademicTasksByStatusAndModule() = runBlocking {
        val task1 = AcademicTask(title = "Assignment 1", module = "CSC3002F", dueDate = "2026-08-10", status = "Pending")
        val task2 = AcademicTask(title = "Assignment 2", module = "CSC3002F", dueDate = "2026-08-15", status = "Completed")
        val task3 = AcademicTask(title = "Lab 1", module = "MTH3012S", dueDate = "2026-08-12", status = "Pending")

        dao.insertAcademicTask(task1)
        dao.insertAcademicTask(task2)
        dao.insertAcademicTask(task3)

        val cscTasks = dao.getAcademicTasksByModule("CSC3002F").first()
        assertEquals(2, cscTasks.size)

        val pendingTasks = dao.getAcademicTasksByStatus("Pending").first()
        assertEquals(2, pendingTasks.size)

        val completedTasks = dao.getAcademicTasksByStatus("Completed").first()
        assertEquals(1, completedTasks.size)
        assertEquals("Assignment 2", completedTasks[0].title)
    }

    @Test
    fun updateAndDeleteAcademicTask() = runBlocking {
        val task = AcademicTask(
            title = "EEE3096S Practical Prep",
            module = "EEE3096S",
            dueDate = "2026-08-14",
            status = "Pending",
            progress = 0
        )
        val id = dao.insertAcademicTask(task)

        val updatedTask = AcademicTask(
            id = id,
            title = "EEE3096S Practical Prep",
            module = "EEE3096S",
            dueDate = "2026-08-14",
            status = "Completed",
            progress = 100
        )
        dao.updateAcademicTask(updatedTask)

        val retrievedAfterUpdate = dao.getAcademicTaskById(id).first()
        assertEquals("Completed", retrievedAfterUpdate?.status)
        assertEquals(100, retrievedAfterUpdate?.progress)

        dao.deleteAcademicTask(id)
        val allTasks = dao.getAllAcademicTasks().first()
        assertTrue(allTasks.isEmpty())
    }

    @Test
    fun insertUpdateDeleteTodoTask() = runBlocking {
        val todo = TodoTask(
            title = "Buy printing credits for library",
            priority = "High",
            isCompleted = false,
            dueDate = "2026-08-06"
        )
        val id = dao.insertTodoTask(todo)
        assertTrue(id > 0)

        val allTodos = dao.getAllTodoTasks().first()
        assertEquals(1, allTodos.size)
        assertEquals("Buy printing credits for library", allTodos[0].title)

        val updatedTodo = TodoTask(
            id = id,
            title = "Buy printing credits for library",
            priority = "High",
            isCompleted = true,
            dueDate = "2026-08-06"
        )
        dao.updateTodoTask(updatedTodo)

        val retrieved = dao.getTodoTaskById(id).first()
        assertTrue(retrieved?.isCompleted == true)

        dao.deleteTodoTask(id)
        val emptyTodos = dao.getAllTodoTasks().first()
        assertTrue(emptyTodos.isEmpty())
    }
}
