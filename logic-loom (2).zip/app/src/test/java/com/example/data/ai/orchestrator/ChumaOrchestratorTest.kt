package com.example.data.ai.orchestrator

import com.example.data.ai.CanvasMateContext
import com.example.data.ai.orchestrator.memory.DefaultMemoryProvider
import com.example.data.ai.orchestrator.tools.DefaultToolRegistry
import com.example.data.ai.orchestrator.tools.ToolRequest
import com.example.data.local.AcademicTask
import com.example.data.local.GpaModule
import com.example.data.local.UserProfile
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ChumaOrchestratorTest {

    private lateinit var toolRegistry: DefaultToolRegistry
    private lateinit var memoryProvider: DefaultMemoryProvider
    private lateinit var orchestrator: ChumaOrchestrator

    @Before
    fun setUp() {
        toolRegistry = DefaultToolRegistry()
        memoryProvider = DefaultMemoryProvider()
        orchestrator = ChumaOrchestrator(toolRegistry, memoryProvider)
    }

    @Test
    fun testTaskClassification_mathematics() {
        val intent = ChumaTaskClassifier.classify("Calculate 25 * 4 + 10")
        assertEquals(ChumaTaskType.MATHEMATICS, intent.taskType)
        assertTrue(intent.requiredCapabilities.contains(ChumaCapability.CALCULATOR))
    }

    @Test
    fun testTaskClassification_debugging() {
        val intent = ChumaTaskClassifier.classify("Why is my Kotlin app crashing with a NullPointerException in onCreate?")
        assertEquals(ChumaTaskType.DEBUGGING, intent.taskType)
        assertTrue(intent.requiredCapabilities.contains(ChumaCapability.CODE_ANALYSIS))
    }

    @Test
    fun testTaskClassification_writing() {
        val intent = ChumaTaskClassifier.classify("Write an email asking my lecturer for an extension on the assignment")
        assertEquals(ChumaTaskType.WRITING, intent.taskType)
    }

    @Test
    fun testTaskClassification_coding() {
        val intent = ChumaTaskClassifier.classify("How to write a Jetpack Compose LazyColumn with custom animations")
        assertEquals(ChumaTaskType.CODING, intent.taskType)
        assertTrue(intent.requiredCapabilities.contains(ChumaCapability.CODE_ANALYSIS))
    }

    @Test
    fun testTaskClassification_comparison() {
        val intent = ChumaTaskClassifier.classify("Compare these two laptops for computer science students")
        assertEquals(ChumaTaskType.COMPARISON, intent.taskType)
    }

    @Test
    fun testTaskClassification_multiStep() {
        val intent = ChumaTaskClassifier.classify("Find three universities offering this course, compare their fees and tell me which is cheapest")
        assertEquals(ChumaTaskType.MULTI_STEP_TASK, intent.taskType)
        assertTrue(intent.isMultiStep)
        assertTrue(intent.steps.isNotEmpty())
    }

    @Test
    fun testSearchDecision_currentInfoRequiresSearch() {
        assertTrue(ChumaTaskClassifier.shouldSearchWeb("latest android studio release 2026", "latest android studio release 2026"))
        assertTrue(ChumaTaskClassifier.shouldSearchWeb("search for computer science graduate internships", "search for computer science graduate internships"))
        assertTrue(ChumaTaskClassifier.shouldSearchWeb("what is the current price of gold today", "what is the current price of gold today"))
    }

    @Test
    fun testSearchDecision_stableKnowledgeDoesNotRequireSearch() {
        assertFalse(ChumaTaskClassifier.shouldSearchWeb("what is an api?", "what is an api?"))
        assertFalse(ChumaTaskClassifier.shouldSearchWeb("what is a compiler", "what is a compiler"))
        assertFalse(ChumaTaskClassifier.shouldSearchWeb("calculate 10 + 20", "calculate 10 + 20"))
        assertFalse(ChumaTaskClassifier.shouldSearchWeb("translate hello to spanish", "translate hello to spanish"))
    }

    @Test
    fun testToolRegistry_retrievesAndExecutesCalculator() = runBlocking {
        val calc = toolRegistry.get("calculator")
        assertNotNull(calc)
        assertTrue(calc!!.isAvailable())

        val result = calc.execute(
            ToolRequest(toolName = "calculator", parameters = mapOf("expression" to "12 * 8")),
            ChumaExecutionContext(userRequest = "12 * 8")
        )
        assertTrue(result.success)
        assertEquals("96.0", result.output)
    }

    @Test
    fun testToolRegistry_retrievesWeather() = runBlocking {
        val weather = toolRegistry.get("weather")
        assertNotNull(weather)
        assertTrue(weather!!.isAvailable())

        val result = weather.execute(
            ToolRequest(toolName = "weather", parameters = mapOf("location" to "Cape Town")),
            ChumaExecutionContext(userRequest = "weather in Cape Town")
        )
        assertTrue(result.success)
        assertTrue(result.output.contains("°C"))
    }

    @Test
    fun testVerificationEngine_correctsHallucinatedActions() {
        val intent = ChumaIntent(taskType = ChumaTaskType.GENERAL_QA)

        val unverifiedRide = ChumaVerificationEngine.verify(
            rawOutput = "I have booked your uber ride to campus!",
            intent = intent,
            executedTools = emptyList(),
            sources = emptyList(),
            isSearchAvailable = true
        )
        assertFalse(unverifiedRide.isValid)
        assertTrue(unverifiedRide.verifiedOutput.contains("ride dispatch"))

        val unverifiedPayment = ChumaVerificationEngine.verify(
            rawOutput = "Payment has been processed and I transferred the money.",
            intent = intent,
            executedTools = emptyList(),
            sources = emptyList(),
            isSearchAvailable = true
        )
        assertFalse(unverifiedPayment.isValid)
        assertTrue(unverifiedPayment.verifiedOutput.contains("bank fund transfers are unavailable"))
    }

    @Test
    fun testVerificationEngine_stripsFabricatedCitations() {
        val intent = ChumaIntent(taskType = ChumaTaskType.CURRENT_INFORMATION, isSearchRequired = true)
        val verified = ChumaVerificationEngine.verify(
            rawOutput = "Here is the news [https://fabricated-news.example.com/item1] from today.",
            intent = intent,
            executedTools = emptyList(),
            sources = emptyList(), // no real sources
            isSearchAvailable = true
        )
        assertFalse(verified.verifiedOutput.contains("https://fabricated-news.example.com"))
    }

    @Test
    fun testMemoryProvider_extractsEnrolledModulesAndTasksWithoutFabrication() = runBlocking {
        val mockContext = CanvasMateContext(
            userProfile = UserProfile(
                fullName = "Siyavuya Nkumbi",
                university = "University of Cape Town",
                course = "BSc Computer Science"
            ),
            gpaModules = listOf(
                GpaModule(moduleCode = "CSC3002F", credits = 18, mark = 78.0)
            ),
            academicTasks = listOf(
                AcademicTask(title = "Compiler Milestone 3", module = "CSC3002F", dueDate = "2026-09-20", status = "Pending")
            )
        )

        val memoryCourse = memoryProvider.retrieveRelevantMemory("What is my course?", "conv-1", mockContext)
        assertNotNull(memoryCourse)
        assertTrue(memoryCourse!!.contains("CSC3002F (78.0%)"))
        assertTrue(memoryCourse.contains("University of Cape Town"))

        val memoryTask = memoryProvider.retrieveRelevantMemory("What tasks are due?", "conv-1", mockContext)
        assertNotNull(memoryTask)
        assertTrue(memoryTask!!.contains("Compiler Milestone 3"))

        // Unrelated query should not fabricate memories
        val memoryUnrelated = memoryProvider.retrieveRelevantMemory("Tell me a poem about the sea", "conv-1", mockContext)
        assertNull(memoryUnrelated)
    }

    @Test
    fun testOrchestrator_handlesEmptyAndCancelledRequests() = runBlocking {
        // Empty prompt
        val emptyResult = orchestrator.process("", ChumaExecutionContext(userRequest = ""))
        assertTrue(emptyResult.output.contains("assist you with Logic Loom"))

        // Cancelled context
        val cancelledResult = orchestrator.process(
            "Write a long essay",
            ChumaExecutionContext(userRequest = "Write a long essay", isCancelled = { true })
        )
        assertTrue(cancelledResult.output.contains("stopped"))
    }

    @Test
    fun testOrchestrator_handlesMathEvaluationDirectly() = runBlocking {
        val result = orchestrator.process(
            "Calculate 100 / 4",
            ChumaExecutionContext(userRequest = "Calculate 100 / 4")
        )
        assertTrue(result.output.contains("25"))
        assertEquals(ChumaTaskType.MATHEMATICS, result.taskType)
    }
}
