package com.example.data.ai.orchestrator

import com.example.data.ai.ActionConfirmation
import com.example.data.ai.ActionRiskLevel
import com.example.data.model.UserDataField
import com.example.data.tools.HolidayCalendarEngine
import java.time.LocalDate
import java.time.Month
import org.junit.Assert.*
import org.junit.Test

class ChumaIntentAndTransportTest {

    @Test
    fun testFareInquiryIntentAndExtraction() {
        val prompt = "How much is the train from Cape Town to Bellville?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.FARE_LOOKUP, intent.taskType)
        assertEquals("Cape Town", intent.entities?.origin)
        assertEquals("Bellville", intent.entities?.destination)
        assertEquals("train", intent.entities?.subject)
        assertEquals("fare_inquiry", intent.entities?.requestedAction)
    }

    @Test
    fun testDistanceInquiryIntentAndExtraction() {
        val prompt = "How far is Cape Town to Bellville by train?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.TRANSPORT_LOOKUP, intent.taskType)
        assertEquals("Cape Town", intent.entities?.origin)
        assertEquals("Bellville", intent.entities?.destination)
        assertEquals("train", intent.entities?.subject)
        assertEquals("distance_inquiry", intent.entities?.requestedAction)
    }

    @Test
    fun testRouteInquiryIntentAndExtraction() {
        val prompt = "What trains can I use from Cape Town to Bellville?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.TRANSPORT_LOOKUP, intent.taskType)
        assertEquals("Cape Town", intent.entities?.origin)
        assertEquals("Bellville", intent.entities?.destination)
        assertEquals("train", intent.entities?.subject)
        assertEquals("route_inquiry", intent.entities?.requestedAction)
    }

    @Test
    fun testMissingOriginDestinationDoesNotInvent() {
        val prompt = "How much is the train?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.FARE_LOOKUP, intent.taskType)
        assertNull("Origin must NOT be fabricated when omitted", intent.entities?.origin)
        assertNull("Destination must NOT be fabricated when omitted", intent.entities?.destination)
        assertEquals("train", intent.entities?.subject)
    }

    @Test
    fun testExplicitDatePreservedAndNotReplacedByCurrentDate() {
        val prompt = "What is the holiday on 27 September in South Africa?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertNotEquals(ChumaTaskType.CURRENT_DATE, intent.taskType)
        assertEquals(ChumaTaskType.HOLIDAY_LOOKUP, intent.taskType)
        assertTrue(intent.entities?.date?.contains("27 September") == true)
        assertEquals("South Africa", intent.entities?.country)
    }

    @Test
    fun testHistoricalDateLookup() {
        val prompt = "What happened on 27 September?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.HISTORICAL_DATE_LOOKUP, intent.taskType)
        assertTrue(intent.entities?.date?.contains("27 September") == true)
    }

    @Test
    fun testDateDifferenceCalculation() {
        val prompt = "How many days until 27 September?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.DATE_DIFFERENCE, intent.taskType)
        assertTrue(intent.entities?.date?.contains("27 September") == true)
    }

    @Test
    fun testTodayDateIntent() {
        val prompt = "What is today's date?"
        val intent = ChumaTaskClassifier.classify(prompt)

        assertEquals(ChumaTaskType.CURRENT_DATE, intent.taskType)
    }

    @Test
    fun testPublicHolidayCheckFor27September() {
        val holidayInfo = HolidayCalendarEngine.evaluateSouthAfricanDate(LocalDate.of(2026, Month.SEPTEMBER, 27))
        assertFalse("27 September is not a national public holiday", holidayInfo.isPublicHoliday)
        assertTrue(holidayInfo.nearbyHolidaysNote?.contains("Heritage Day") == true)
    }

    @Test
    fun testPublicHolidayCheckFor24September() {
        val holidayInfo = HolidayCalendarEngine.evaluateSouthAfricanDate(LocalDate.of(2026, Month.SEPTEMBER, 24))
        assertTrue("24 September is a national public holiday (Heritage Day)", holidayInfo.isPublicHoliday)
        assertEquals("Heritage Day", holidayInfo.name)
    }

    @Test
    fun testActionConfirmationFiveTiers() {
        val infoTier = ActionConfirmation.evaluateRiskLevel("What is fiscal policy?")
        assertEquals(ActionRiskLevel.INFORMATION, infoTier)

        val suggestTier = ActionConfirmation.evaluateRiskLevel("I suggest a R500 grocery budget.")
        assertEquals(ActionRiskLevel.SUGGESTION, suggestTier)

        val modTier = ActionConfirmation.evaluateRiskLevel("Set budget to R500")
        assertEquals(ActionRiskLevel.USER_DATA_MODIFICATION, modTier)

        val extTier = ActionConfirmation.evaluateRiskLevel("Send email to lecturer")
        assertEquals(ActionRiskLevel.EXTERNAL_ACTION, extTier)

        val destructiveTier = ActionConfirmation.evaluateRiskLevel("Delete all tasks and wipe data")
        assertEquals(ActionRiskLevel.HIGH_IMPACT_IRREVERSIBLE, destructiveTier)
    }

    @Test
    fun testThreeStateUserDataModel() {
        val emptyField = UserDataField.empty<Double>()
        assertTrue(emptyField.isEmpty)
        assertFalse(emptyField.isSuggested)
        assertFalse(emptyField.isConfirmed)
        assertNull(emptyField.value)

        val suggestedField = UserDataField.suggested(500.0, "Based on average student grocery spending")
        assertFalse(suggestedField.isEmpty)
        assertTrue(suggestedField.isSuggested)
        assertFalse(suggestedField.isConfirmed)
        assertEquals(500.0, suggestedField.value)

        val confirmedField = UserDataField.confirmed(500.0)
        assertFalse(confirmedField.isEmpty)
        assertFalse(confirmedField.isSuggested)
        assertTrue(confirmedField.isConfirmed)
        assertEquals(500.0, confirmedField.value)
    }
}
