package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Utility object for location-aware time zone detection, time formatting,
 * dynamic user greetings, and real-time date/time calculations.
 */
object TimeUtils {

    /**
     * Resolves the active [TimeZone].
     * If [timeZoneId] is null, blank, or "auto", defaults to the system default [TimeZone].
     */
    fun getActiveTimeZone(timeZoneId: String? = null): TimeZone {
        if (timeZoneId.isNullOrBlank() || timeZoneId.equals("auto", ignoreCase = true)) {
            return TimeZone.getDefault()
        }
        return try {
            TimeZone.getTimeZone(timeZoneId)
        } catch (e: Exception) {
            TimeZone.getDefault()
        }
    }

    /**
     * Returns the current [Calendar] instance set to the given [timeZone].
     */
    fun getCurrentCalendar(timeZone: TimeZone = TimeZone.getDefault(), date: Date = Date()): Calendar {
        return Calendar.getInstance(timeZone).apply {
            time = date
        }
    }

    /**
     * Returns the hour of the day (0..23) for the specified date and time zone.
     */
    fun getHourOfDay(date: Date = Date(), timeZone: TimeZone = TimeZone.getDefault()): Int {
        return getCurrentCalendar(timeZone, date).get(Calendar.HOUR_OF_DAY)
    }

    /**
     * Generates a context-aware greeting string addressing the user specifically.
     *
     * - Morning (05:00 - 11:59): "Good morning, [userName]"
     * - Day / Midday (12:00 - 13:59): "Good day, [userName]"
     * - Afternoon (14:00 - 17:59): "Good afternoon, [userName]"
     * - Evening / Night (18:00 - 04:59): "Good evening, [userName]"
     */
    fun getDynamicGreeting(
        userName: String,
        date: Date = Date(),
        timeZone: TimeZone = TimeZone.getDefault()
    ): String {
        val cleanName = userName.ifBlank { "User" }.trim().split(" ").firstOrNull() ?: "User"
        val hour = getHourOfDay(date, timeZone)

        return when (hour) {
            in 5..11 -> "Good morning, $cleanName"
            in 12..13 -> "Good day, $cleanName"
            in 14..17 -> "Good afternoon, $cleanName"
            else -> "Good evening, $cleanName"
        }
    }

    /**
     * Formats a date into a localized full date string (e.g. "Monday, 7 August 2026").
     */
    fun formatFullDate(
        date: Date = Date(),
        timeZone: TimeZone = TimeZone.getDefault(),
        locale: Locale = Locale.getDefault()
    ): String {
        val sdf = SimpleDateFormat("EEEE, d MMMM yyyy", locale)
        sdf.timeZone = timeZone
        return sdf.format(date)
    }

    /**
     * Formats a date into a 24-hour time string with seconds (e.g. "14:30:45").
     */
    fun formatTimeString(
        date: Date = Date(),
        timeZone: TimeZone = TimeZone.getDefault(),
        includeSeconds: Boolean = true,
        locale: Locale = Locale.getDefault()
    ): String {
        val pattern = if (includeSeconds) "HH:mm:ss" else "HH:mm"
        val sdf = SimpleDateFormat(pattern, locale)
        sdf.timeZone = timeZone
        return sdf.format(date)
    }

    /**
     * Formats a timestamp into a short display format (e.g. "14:30").
     */
    fun formatShortTime(
        timestampMillis: Long,
        timeZone: TimeZone = TimeZone.getDefault()
    ): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        sdf.timeZone = timeZone
        return sdf.format(Date(timestampMillis))
    }

    /**
     * Formats a timestamp into a full date-time string (e.g. "07 Aug 2026, 14:30").
     */
    fun formatDateTime(
        timestampMillis: Long,
        timeZone: TimeZone = TimeZone.getDefault()
    ): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        sdf.timeZone = timeZone
        return sdf.format(Date(timestampMillis))
    }

    /**
     * Returns the short time zone name or abbreviation (e.g. "SAST", "EST", "GMT").
     */
    fun getTimeZoneDisplayName(
        timeZone: TimeZone = TimeZone.getDefault(),
        date: Date = Date()
    ): String {
        val isDaylight = timeZone.inDaylightTime(date)
        return timeZone.getDisplayName(isDaylight, TimeZone.SHORT)
    }

    /**
     * Formats relative time (e.g., "Just now", "5 mins ago", "2 hours ago", "Yesterday").
     */
    fun formatRelativeTime(
        timestampMillis: Long,
        nowMillis: Long = System.currentTimeMillis()
    ): String {
        val diffSeconds = (nowMillis - timestampMillis) / 1000
        if (diffSeconds < 30) return "Just now"
        if (diffSeconds < 60) return "${diffSeconds}s ago"

        val diffMinutes = diffSeconds / 60
        if (diffMinutes < 60) return "${diffMinutes}m ago"

        val diffHours = diffMinutes / 60
        if (diffHours < 24) return "${diffHours}h ago"

        val diffDays = diffHours / 24
        if (diffDays == 1L) return "Yesterday"
        if (diffDays < 7) return "${diffDays}d ago"

        val sdf = SimpleDateFormat("dd MMM", Locale.getDefault())
        return sdf.format(Date(timestampMillis))
    }
}
