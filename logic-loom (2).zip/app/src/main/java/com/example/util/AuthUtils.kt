package com.example.util

import android.util.Log
import com.google.firebase.auth.ActionCodeSettings
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import kotlinx.coroutines.tasks.await

/**
 * Utility object for Firebase Authentication operations.
 *
 * Provides a diagnostic wrapper function for [FirebaseAuth.sendPasswordResetEmail]
 * that logs the exact [FirebaseAuthException.errorCode] to Logcat with the custom tag
 * "AuthDiag" before re-throwing the exception for UI handling.
 */
object AuthUtils {

    const val TAG = "AuthDiag"

    /**
     * Wrapper for [FirebaseAuth.sendPasswordResetEmail].
     *
     * Catches [FirebaseAuthException], extracts the [FirebaseAuthException.getErrorCode],
     * and logs it to Logcat with tag [TAG] ("AuthDiag") before re-throwing the exception
     * for caller/UI handling.
     *
     * @param firebaseAuth The [FirebaseAuth] instance (defaults to [FirebaseAuth.getInstance]).
     * @param email The email address to send the password reset link to.
     * @throws FirebaseAuthException Re-thrown after capturing and logging the error code.
     * @throws Exception Any other unexpected exception re-thrown after logging.
     */
    suspend fun sendPasswordResetEmail(
        firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance(),
        email: String
    ) {
        val trimmedEmail = email.trim()
        Log.d(TAG, "Initiating sendPasswordResetEmail for: '$trimmedEmail'")

        try {
            firebaseAuth.sendPasswordResetEmail(trimmedEmail).await()
            Log.i(TAG, "sendPasswordResetEmail succeeded for: '$trimmedEmail'")
        } catch (e: FirebaseAuthException) {
            val errorCode = e.errorCode
            Log.e(
                TAG,
                "FirebaseAuthException caught in sendPasswordResetEmail! ErrorCode: [$errorCode], Message: ${e.message}",
                e
            )
            throw e
        } catch (e: Exception) {
            Log.e(
                TAG,
                "Exception caught in sendPasswordResetEmail: ${e.javaClass.simpleName} - ${e.message}",
                e
            )
            throw e
        }
    }

    /**
     * Wrapper for [FirebaseAuth.sendPasswordResetEmail] with [ActionCodeSettings].
     *
     * Catches [FirebaseAuthException], extracts the [FirebaseAuthException.getErrorCode],
     * and logs it to Logcat with tag [TAG] ("AuthDiag") before re-throwing the exception
     * for caller/UI handling.
     *
     * @param firebaseAuth The [FirebaseAuth] instance (defaults to [FirebaseAuth.getInstance]).
     * @param email The email address to send the password reset link to.
     * @param actionCodeSettings The [ActionCodeSettings] defining dynamic link/continue URL.
     * @throws FirebaseAuthException Re-thrown after capturing and logging the error code.
     * @throws Exception Any other unexpected exception re-thrown after logging.
     */
    suspend fun sendPasswordResetEmail(
        firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance(),
        email: String,
        actionCodeSettings: ActionCodeSettings
    ) {
        val trimmedEmail = email.trim()
        Log.d(TAG, "Initiating sendPasswordResetEmail with ActionCodeSettings for: '$trimmedEmail'")

        try {
            firebaseAuth.sendPasswordResetEmail(trimmedEmail, actionCodeSettings).await()
            Log.i(TAG, "sendPasswordResetEmail with ActionCodeSettings succeeded for: '$trimmedEmail'")
        } catch (e: FirebaseAuthException) {
            val errorCode = e.errorCode
            Log.e(
                TAG,
                "FirebaseAuthException caught in sendPasswordResetEmail! ErrorCode: [$errorCode], Message: ${e.message}",
                e
            )
            throw e
        } catch (e: Exception) {
            Log.e(
                TAG,
                "Exception caught in sendPasswordResetEmail with ActionCodeSettings: ${e.javaClass.simpleName} - ${e.message}",
                e
            )
            throw e
        }
    }

    /**
     * Masks an API key for secure logging without exposing sensitive secrets.
     * E.g. "AIzaSyBLogicLoomAuthAppKey2026Secure01" -> "AIzaSy...re01"
     */
    fun maskApiKey(apiKey: String?): String {
        if (apiKey.isNullOrEmpty()) return "none"
        return if (apiKey.length <= 10) {
            "***"
        } else {
            apiKey.take(6) + "..." + apiKey.takeLast(4)
        }
    }

    /**
     * Determines whether an exception was caused by an invalid, expired, or unauthorized API key.
     */
    fun isApiKeyError(throwable: Throwable): Boolean {
        val message = throwable.message.orEmpty()
        return message.contains("Api key not valid", ignoreCase = true) ||
                message.contains("API key not valid", ignoreCase = true) ||
                message.contains("API_KEY_INVALID", ignoreCase = true) ||
                (throwable is FirebaseAuthException && (
                        throwable.errorCode.contains("API_KEY", ignoreCase = true) ||
                        throwable.errorCode == "ERROR_INTERNAL_ERROR" && message.contains("Api key", ignoreCase = true)
                ))
    }

    /**
     * Determines whether an exception was caused by an unconfigured Firebase project or disabled Auth provider
     * (e.g. Identity Toolkit / Firebase Authentication Email/Password provider not enabled in Firebase Console).
     */
    fun isConfigurationNotFoundError(throwable: Throwable): Boolean {
        val message = throwable.message.orEmpty()
        return message.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                (throwable is FirebaseAuthException && (
                        throwable.errorCode.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                        throwable.errorCode == "ERROR_INTERNAL_ERROR" && message.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true)
                ))
    }

    /**
     * Translates a Firebase authentication error code into a user-friendly message
     * suitable for display in UI dialogs and snackbars.
     */
    fun mapErrorCodeToUserMessage(errorCode: String): String {
        return when (errorCode) {
            "ERROR_INVALID_EMAIL", "INVALID_EMAIL" -> "The email address is invalid or badly formatted."
            "ERROR_USER_NOT_FOUND", "USER_NOT_FOUND" -> "No account found with this email address."
            "ERROR_MISSING_EMAIL", "MISSING_EMAIL" -> "Please enter your email address."
            "ERROR_TOO_MANY_REQUESTS", "TOO_MANY_REQUESTS" -> "Too many reset attempts. Please wait and try again later."
            "ERROR_OPERATION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED" -> "Password reset is currently disabled in Firebase Console."
            "ERROR_UNAUTHORIZED_CONTINUE_URI", "UNAUTHORIZED_CONTINUE_URI" -> "The action URL domain is not authorized in Firebase Console."
            "ERROR_NETWORK_REQUEST_FAILED", "NETWORK_ERROR" -> "Network error: Please verify your internet connection."
            "ERROR_INVALID_API_KEY", "INVALID_API_KEY", "API_KEY_INVALID" -> "Firebase API key is invalid or not authorized."
            "CONFIGURATION_NOT_FOUND" -> "Firebase configuration error: Email/Password provider is not enabled in Firebase Console."
            else -> "Password reset failed: $errorCode"
        }
    }

    /**
     * Resolves Firebase Authentication exceptions into clean, diagnostic error messages.
     * In DEBUG builds, provides actionable diagnostic guidance for configuration errors.
     * In RELEASE builds, returns clean, secure user-facing messages.
     */
    fun resolveAuthErrorMessage(throwable: Throwable, operation: String = "Authentication"): String {
        if (isApiKeyError(throwable)) {
            Log.e(
                TAG,
                "CRITICAL: Firebase Authentication rejected the API key with 'Api key not valid'. " +
                        "Verify that google-services.json contains a valid API key with Identity Toolkit API enabled."
            )
            return if (com.example.BuildConfig.DEBUG) {
                "Firebase configuration error: Invalid API key. Please ensure google-services.json contains a valid API key for this project and Identity Toolkit API is enabled."
            } else {
                "Authentication service is currently unavailable. Please try again later."
            }
        }

        if (isConfigurationNotFoundError(throwable)) {
            Log.e(
                TAG,
                "CRITICAL: Firebase Authentication returned CONFIGURATION_NOT_FOUND. " +
                        "This indicates that Firebase Authentication or the Email/Password sign-in provider has not been enabled in the Firebase Console."
            )
            return if (com.example.BuildConfig.DEBUG) {
                "Firebase configuration error [CONFIGURATION_NOT_FOUND]: Email/Password provider is not enabled in Firebase Console. Go to Firebase Console > Build > Authentication > Sign-in method and enable Email/Password."
            } else {
                "Authentication service is currently misconfigured. Please contact support or try again later."
            }
        }

        if (throwable is com.google.firebase.FirebaseNetworkException) {
            return "Network error: Unable to connect to Firebase servers. Please verify your internet connection."
        }

        if (throwable is FirebaseAuthException) {
            return when (throwable.errorCode) {
                "ERROR_USER_NOT_FOUND", "USER_NOT_FOUND" ->
                    "No account found with this email address. Please check your email or register."
                "ERROR_WRONG_PASSWORD", "WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "INVALID_LOGIN_CREDENTIALS" ->
                    "Invalid email or password. Please check your credentials."
                "ERROR_USER_DISABLED", "USER_DISABLED" ->
                    "This account has been disabled. Please contact support."
                "ERROR_TOO_MANY_REQUESTS", "TOO_MANY_REQUESTS" ->
                    "Too many unsuccessful attempts. Please try again later or reset your password."
                "ERROR_EMAIL_ALREADY_IN_USE", "EMAIL_ALREADY_IN_USE" ->
                    "An account with this email address already exists. Please login instead."
                "ERROR_WEAK_PASSWORD", "WEAK_PASSWORD" ->
                    "The password is too weak. Please use at least 8 characters with numbers and letters."
                "ERROR_INVALID_EMAIL", "INVALID_EMAIL" ->
                    "The email address is invalid."
                "ERROR_OPERATION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED" ->
                    "This authentication provider is currently disabled in Firebase Console."
                else -> {
                    if (com.example.BuildConfig.DEBUG) {
                        "Firebase error [${throwable.errorCode}]: ${throwable.localizedMessage ?: "Operation failed"}"
                    } else {
                        "$operation failed. Please check your credentials and try again."
                    }
                }
            }
        }

        return throwable.localizedMessage ?: "$operation failed. Please try again."
    }
}

/**
 * Extension function for [FirebaseAuth] to invoke [AuthUtils.sendPasswordResetEmail].
 */
suspend fun FirebaseAuth.sendPasswordResetEmailWithAuthDiag(email: String) {
    AuthUtils.sendPasswordResetEmail(this, email)
}
