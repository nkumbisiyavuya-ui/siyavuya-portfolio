package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

enum class NetworkType {
    WIFI,
    CELLULAR,
    ETHERNET,
    OTHER,
    NONE
}

data class ConnectivityStatus(
    val isConnected: Boolean = true,
    val networkType: NetworkType = NetworkType.WIFI,
    val isMetered: Boolean = false,
    val label: String = "Connected",
    val latencyEstimateMs: Int? = null,
    val lastUpdatedMillis: Long = System.currentTimeMillis()
) {
    val shortLabel: String
        get() = when {
            !isConnected -> "Offline"
            networkType == NetworkType.WIFI -> "Wi-Fi"
            networkType == NetworkType.CELLULAR -> "Cellular"
            networkType == NetworkType.ETHERNET -> "LAN"
            else -> "Online"
        }

    val detailedStatus: String
        get() = when {
            !isConnected -> "Offline • Local Vault Active"
            networkType == NetworkType.WIFI -> "Live Wi-Fi • Chuma AI Ready"
            networkType == NetworkType.CELLULAR -> "Cellular Data • Sync Active"
            networkType == NetworkType.ETHERNET -> "Ethernet • Fast Sync"
            else -> "Connected • Cloud Active"
        }
}

class NetworkMonitor(private val context: Context) {

    private val connectivityManager: ConnectivityManager? =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    fun currentStatus(): ConnectivityStatus {
        val cm = connectivityManager ?: return ConnectivityStatus(
            isConnected = true,
            networkType = NetworkType.WIFI,
            label = "Online"
        )

        val activeNetwork = cm.activeNetwork ?: return ConnectivityStatus(
            isConnected = false,
            networkType = NetworkType.NONE,
            label = "Offline"
        )

        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return ConnectivityStatus(
            isConnected = false,
            networkType = NetworkType.NONE,
            label = "Offline"
        )

        return mapCapabilitiesToStatus(cm, capabilities)
    }

    val connectivityFlow: Flow<ConnectivityStatus> = callbackFlow {
        val cm = connectivityManager
        if (cm == null) {
            trySend(
                ConnectivityStatus(
                    isConnected = true,
                    networkType = NetworkType.WIFI,
                    label = "Online"
                )
            )
            awaitClose { }
            return@callbackFlow
        }

        // Emit initial status
        trySend(currentStatus())

        val networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val caps = cm.getNetworkCapabilities(network)
                trySend(mapCapabilitiesToStatus(cm, caps))
            }

            override fun onLost(network: Network) {
                // If there is still an active network, use that, otherwise offline
                val active = cm.activeNetwork
                if (active != null && active != network) {
                    val caps = cm.getNetworkCapabilities(active)
                    trySend(mapCapabilitiesToStatus(cm, caps))
                } else {
                    trySend(
                        ConnectivityStatus(
                            isConnected = false,
                            networkType = NetworkType.NONE,
                            label = "Offline"
                        )
                    )
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                trySend(mapCapabilitiesToStatus(cm, networkCapabilities))
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        try {
            cm.registerNetworkCallback(request, networkCallback)
        } catch (e: Exception) {
            // Fallback for restricted environments
            trySend(currentStatus())
        }

        awaitClose {
            try {
                cm.unregisterNetworkCallback(networkCallback)
            } catch (ignored: Exception) {
            }
        }
    }.distinctUntilChanged()

    private fun mapCapabilitiesToStatus(
        cm: ConnectivityManager,
        capabilities: NetworkCapabilities?
    ): ConnectivityStatus {
        if (capabilities == null) {
            return ConnectivityStatus(
                isConnected = false,
                networkType = NetworkType.NONE,
                label = "Offline"
            )
        }

        val hasInternet = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        if (!hasInternet) {
            return ConnectivityStatus(
                isConnected = false,
                networkType = NetworkType.NONE,
                label = "No Internet"
            )
        }

        val networkType = when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkType.CELLULAR
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            else -> NetworkType.OTHER
        }

        val isMetered = !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)

        return ConnectivityStatus(
            isConnected = true,
            networkType = networkType,
            isMetered = isMetered,
            label = if (networkType == NetworkType.WIFI) "Wi-Fi Connected" else "Mobile Connected",
            latencyEstimateMs = if (networkType == NetworkType.WIFI) 24 else 68
        )
    }
}
