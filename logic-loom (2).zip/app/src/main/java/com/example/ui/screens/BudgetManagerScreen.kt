package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BudgetGoal
import com.example.data.local.BudgetItem
import com.example.data.network.ExchangeRateNetworkService
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetManagerScreen(
    items: List<BudgetItem>,
    goals: List<BudgetGoal>,
    onAddItem: (BudgetItem) -> Unit,
    onDeleteItem: (Long) -> Unit,
    onAddGoal: (BudgetGoal) -> Unit,
    exchangeRates: Map<String, Double> = emptyMap(),
    isRatesLive: Boolean = false,
    isRatesFromRoomCache: Boolean = false,
    isLoadingRates: Boolean = false,
    onRefreshRates: () -> Unit = {}
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var prefilledTitle by remember { mutableStateOf("") }
    var prefilledAmountText by remember { mutableStateOf("0.00") }
    var prefilledCategory by remember { mutableStateOf("Food") }

    var showReportDialog by remember { mutableStateOf(false) }
    var showTemplateDialog by remember { mutableStateOf(false) }
    var showConverterDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<BudgetItem?>(null) }

    // Currency Converter local states
    var foreignAmountText by remember { mutableStateOf("120.00") }
    var selectedCurrency by remember { mutableStateOf("USD") }
    var itemNote by remember { mutableStateOf("International Textbook") }

    val currencyFormatter = remember {
        NumberFormat.getCurrencyInstance(Locale("en", "ZA")).apply {
            maximumFractionDigits = 2
        }
    }

    val totalIncome = items.filter { it.type == "Income" }.sumOf { it.amount }
    val totalExpense = items.filter { it.type == "Expense" }.sumOf { it.amount }
    val remainingBalance = totalIncome - totalExpense

    val expensesByCategory = items.filter { it.type == "Expense" }
        .groupBy { it.category }
        .mapValues { entry -> entry.value.sumOf { it.amount } }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log Transaction")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Text("Budget Manager (ZAR)", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Track Student Income, Expenses & Savings Goals in Rands", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            // Main Balance Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text("Current Monthly Balance", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currencyFormatter.format(remainingBalance),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (remainingBalance >= 0) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFFEF4444)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Income", style = MaterialTheme.typography.bodySmall)
                            Text(
                                currencyFormatter.format(totalIncome),
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }

                        Column {
                            Text("Total Expenses", style = MaterialTheme.typography.bodySmall)
                            Text(
                                currencyFormatter.format(totalExpense),
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF4444)
                            )
                        }

                        Column {
                            Text("Daily Average", style = MaterialTheme.typography.bodySmall)
                            Text(
                                currencyFormatter.format(totalExpense / 30.0),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Budget Alert Warning
            if (remainingBalance < 300.0) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Budget Warning: Low balance remaining! Consider reducing non-essential expenses this week.",
                            color = Color(0xFF991B1B),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Canvas Pie Chart for Expense Distribution
            if (expensesByCategory.isNotEmpty()) {
                Text("Expense Distribution Pie Chart", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Pie Chart Canvas
                        Box(modifier = Modifier.size(130.dp), contentAlignment = Alignment.Center) {
                            val colorsList = listOf(
                                Color(0xFF2563EB), Color(0xFF10B981), Color(0xFFF59E0B),
                                Color(0xFFEF4444), Color(0xFF8B5CF6), Color(0xFF06B6D4)
                            )

                            Canvas(modifier = Modifier.size(120.dp)) {
                                var startAngle = -90f
                                val total = expensesByCategory.values.sum()
                                expensesByCategory.entries.forEachIndexed { index, entry ->
                                    val sweep = if (total > 0) (entry.value / total * 360f).toFloat() else 0f
                                    drawArc(
                                        color = colorsList[index % colorsList.size],
                                        startAngle = startAngle,
                                        sweepAngle = sweep,
                                        useCenter = false,
                                        style = Stroke(width = 30f)
                                    )
                                    startAngle += sweep
                                }
                            }
                        }

                        // Legend
                        Column(modifier = Modifier.weight(1f).padding(start = 16.dp)) {
                            val colorsList = listOf(
                                Color(0xFF2563EB), Color(0xFF10B981), Color(0xFFF59E0B),
                                Color(0xFFEF4444), Color(0xFF8B5CF6), Color(0xFF06B6D4)
                            )
                            expensesByCategory.entries.take(4).forEachIndexed { index, entry ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(colorsList[index % colorsList.size])
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "${entry.key}: ${currencyFormatter.format(entry.value)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showTemplateDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Smart Templates")
                }

                OutlinedButton(
                    onClick = { showReportDialog = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Summarize, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export Report")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Live Retrofit ZAR Exchange Rate Converter Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CurrencyExchange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("International Price Converter", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("Live Retrofit rates for textbooks & travel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Surface(
                            color = when {
                                isLoadingRates -> Color(0xFFE2E8F0)
                                isRatesLive -> Color(0xFFD1FAE5)
                                isRatesFromRoomCache -> Color(0xFFDBEAFE)
                                else -> Color(0xFFFEF3C7)
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when {
                                        isLoadingRates -> "Updating..."
                                        isRatesLive -> "Live API"
                                        isRatesFromRoomCache -> "Offline (Room Cache)"
                                        else -> "Fallback Rates"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        isLoadingRates -> Color(0xFF475569)
                                        isRatesLive -> Color(0xFF065F46)
                                        isRatesFromRoomCache -> Color(0xFF1E40AF)
                                        else -> Color(0xFF92400E)
                                    }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(onClick = onRefreshRates, modifier = Modifier.size(20.dp)) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Refresh live rates",
                                        tint = when {
                                            isRatesLive -> Color(0xFF065F46)
                                            isRatesFromRoomCache -> Color(0xFF1E40AF)
                                            else -> Color(0xFF92400E)
                                        },
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val currencies = listOf("USD" to "$", "EUR" to "€", "GBP" to "£", "CAD" to "CA$", "AUD" to "A$", "JPY" to "¥", "CNY" to "¥")

                    ScrollableTabRow(
                        selectedTabIndex = currencies.indexOfFirst { it.first == selectedCurrency }.coerceAtLeast(0),
                        divider = {},
                        edgePadding = 0.dp
                    ) {
                        currencies.forEach { (code, symbol) ->
                            FilterChip(
                                selected = selectedCurrency == code,
                                onClick = { selectedCurrency = code },
                                label = { Text("$symbol $code", fontSize = 12.sp) },
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = itemNote,
                        onValueChange = { itemNote = it },
                        label = { Text("Expense Item Description") },
                        placeholder = { Text("e.g. Overseas Textbook / Software Sub / Flight") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val selectedSymbol = currencies.find { it.first == selectedCurrency }?.second ?: "$"
                    val foreignAmount = foreignAmountText.toDoubleOrNull() ?: 0.0
                    val ratePerZar = exchangeRates[selectedCurrency] ?: ExchangeRateNetworkService.fallbackRates[selectedCurrency] ?: 1.0
                    val zarAmount = if (ratePerZar > 0) foreignAmount / ratePerZar else 0.0
                    val zarPerForeign = if (ratePerZar > 0) 1.0 / ratePerZar else 0.0

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = foreignAmountText,
                            onValueChange = { foreignAmountText = it },
                            label = { Text("Price in $selectedCurrency") },
                            prefix = { Text("$selectedSymbol ") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Text("Equals in ZAR", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = currencyFormatter.format(zarAmount),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "1 $selectedCurrency ≈ R${"%.2f".format(zarPerForeign)}",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            prefilledTitle = if (itemNote.isNotBlank()) itemNote else "International ($selectedCurrency $foreignAmountText)"
                            prefilledAmountText = "%.2f".format(zarAmount)
                            prefilledCategory = "Books"
                            showAddDialog = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add ${currencyFormatter.format(zarAmount)} to Budget Log")
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Savings Goals Section
            Text("Savings Goals", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            goals.forEach { goal ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(goal.title, fontWeight = FontWeight.Bold)
                            Text("${currencyFormatter.format(goal.currentAmount)} / ${currencyFormatter.format(goal.targetAmount)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        val progress = if (goal.targetAmount > 0) (goal.currentAmount / goal.targetAmount).toFloat().coerceIn(0f, 1f) else 0f
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Recent Transactions List
            Text("Recent Transactions Log", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))

            if (items.isEmpty()) {
                com.example.ui.components.EmptyDataCard(
                    message = "No Budget or Transactions Logged",
                    subtitle = "Your financial log is currently empty. Tap below to record your first income or expense transaction.",
                    actionLabel = "Log Transaction",
                    onAction = { showAddDialog = true }
                )
            } else {
                items.forEach { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { editingItem = item },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = if (item.type == "Income") Color(0xFFD1FAE5) else Color(0xFFFEE2E2),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (item.type == "Income") Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                        contentDescription = null,
                                        tint = if (item.type == "Income") Color(0xFF10B981) else Color(0xFFEF4444)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Text("${item.category} • ${item.date}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${if (item.type == "Income") "+" else "-"}${currencyFormatter.format(item.amount)}",
                                fontWeight = FontWeight.Bold,
                                color = if (item.type == "Income") Color(0xFF10B981) else Color(0xFFEF4444)
                            )
                            IconButton(onClick = { editingItem = item }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Figure", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { onDeleteItem(item.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showAddDialog) {
        AddBudgetItemDialog(
            initialTitle = prefilledTitle,
            initialAmountText = prefilledAmountText,
            initialCategory = prefilledCategory,
            onDismiss = {
                showAddDialog = false
                prefilledTitle = ""
                prefilledAmountText = "0.00"
                prefilledCategory = "Food"
            },
            onConfirm = { item ->
                onAddItem(item)
                showAddDialog = false
                prefilledTitle = ""
                prefilledAmountText = "0.00"
                prefilledCategory = "Food"
            }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("ZAR Monthly Budget Report") },
            text = {
                Column {
                    Text("• Total Income: ${currencyFormatter.format(totalIncome)}", fontWeight = FontWeight.Bold)
                    Text("• Total Expenses: ${currencyFormatter.format(totalExpense)}", fontWeight = FontWeight.Bold)
                    Text("• Net Balance: ${currencyFormatter.format(remainingBalance)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Top Expense Categories:", fontWeight = FontWeight.SemiBold)
                    expensesByCategory.forEach { (cat, amt) ->
                        Text("  - $cat: ${currencyFormatter.format(amt)}")
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("✓ Exported as PDF statement to local downloads.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                Button(onClick = { showReportDialog = false }) { Text("Close") }
            }
        )
    }

    if (showTemplateDialog) {
        SmartBudgetTemplateDialog(
            onDismiss = { showTemplateDialog = false },
            onApplyTemplate = { templateItems ->
                templateItems.forEach { onAddItem(it) }
                showTemplateDialog = false
            }
        )
    }

    if (editingItem != null) {
        EditBudgetItemAmountDialog(
            item = editingItem!!,
            onDismiss = { editingItem = null },
            onSave = { updatedItem ->
                onDeleteItem(updatedItem.id)
                onAddItem(updatedItem)
                editingItem = null
            }
        )
    }
}

@Composable
fun SmartBudgetTemplateDialog(
    onDismiss: () -> Unit,
    onApplyTemplate: (List<BudgetItem>) -> Unit
) {
    var selectedTemplate by remember { mutableStateOf("Engineering Student") }

    val templates = listOf(
        "Engineering Student" to "🛠️ Engineering (Lab gear, textbooks, software, bursary & transport)",
        "Arts & Humanities" to "🎨 Arts & Humanities (Studio supplies, printing, books & accommodation)",
        "Medical & Health Sciences" to "🩺 Medical & Health (Scrubs, stethoscope, hospital transit & study manuals)",
        "Commuter & Part-Time" to "🚌 Commuter & Part-Time (Transit/fuel, part-time job, meals & data)"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Smart Budget Templates")
            }
        },
        text = {
            Column {
                Text(
                    "Select an academic-year budget template. All financial fields default to R0.00 so you can insert your actual figures!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                templates.forEach { (name, desc) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedTemplate = name },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedTemplate == name) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedTemplate == name,
                                onClick = { selectedTemplate = name }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text(desc, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val items = when (selectedTemplate) {
                        "Engineering Student" -> listOf(
                            BudgetItem(title = "NSFAS Bursary Allowance", amount = 0.00, type = "Income", category = "Bursary"),
                            BudgetItem(title = "Engineering Laptop Allowance", amount = 0.00, type = "Income", category = "Allowance"),
                            BudgetItem(title = "Lab Equipment & Safety Gear", amount = 0.00, type = "Expense", category = "Books"),
                            BudgetItem(title = "Engineering Textbooks & Software", amount = 0.00, type = "Expense", category = "Books"),
                            BudgetItem(title = "Monthly Groceries & Meals", amount = 0.00, type = "Expense", category = "Food"),
                            BudgetItem(title = "Jammie Shuttle & Transit", amount = 0.00, type = "Expense", category = "Transport"),
                            BudgetItem(title = "Mobile Data Bundle", amount = 0.00, type = "Expense", category = "Data")
                        )
                        "Arts & Humanities" -> listOf(
                            BudgetItem(title = "Academic Scholarship / Bursary", amount = 0.00, type = "Income", category = "Bursary"),
                            BudgetItem(title = "Parent Monthly Allowance", amount = 0.00, type = "Income", category = "Parents"),
                            BudgetItem(title = "Studio Printing & Art Supplies", amount = 0.00, type = "Expense", category = "Books"),
                            BudgetItem(title = "Course Books & Literature", amount = 0.00, type = "Expense", category = "Books"),
                            BudgetItem(title = "Residence Accommodation Rent", amount = 0.00, type = "Expense", category = "Accommodation"),
                            BudgetItem(title = "Daily Groceries & Lunch", amount = 0.00, type = "Expense", category = "Food")
                        )
                        "Medical & Health Sciences" -> listOf(
                            BudgetItem(title = "NSFAS Clinical Bursary Allowance", amount = 0.00, type = "Income", category = "Bursary"),
                            BudgetItem(title = "Medical Scrubs & Stethoscope", amount = 0.00, type = "Expense", category = "Shopping"),
                            BudgetItem(title = "Hospital Clinical Commute", amount = 0.00, type = "Expense", category = "Transport"),
                            BudgetItem(title = "Clinical Study Manuals", amount = 0.00, type = "Expense", category = "Books"),
                            BudgetItem(title = "Groceries & Living Expenses", amount = 0.00, type = "Expense", category = "Food")
                        )
                        else -> listOf(
                            BudgetItem(title = "Part-Time Job Earnings", amount = 0.00, type = "Income", category = "Salary"),
                            BudgetItem(title = "Family Allowance Support", amount = 0.00, type = "Income", category = "Parents"),
                            BudgetItem(title = "Public Transport / Commute Fuel", amount = 0.00, type = "Expense", category = "Transport"),
                            BudgetItem(title = "Campus Meals & Coffee", amount = 0.00, type = "Expense", category = "Food"),
                            BudgetItem(title = "Mobile Data Plan", amount = 0.00, type = "Expense", category = "Data"),
                            BudgetItem(title = "Emergency Savings Fund", amount = 0.00, type = "Expense", category = "Savings")
                        )
                    }
                    onApplyTemplate(items)
                }
            ) {
                Text("Apply Template (R0.00 Defaults)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun EditBudgetItemAmountDialog(
    item: BudgetItem,
    onDismiss: () -> Unit,
    onSave: (BudgetItem) -> Unit
) {
    var amountText by remember { mutableStateOf(if (item.amount == 0.0) "" else item.amount.toString()) }
    var titleText by remember { mutableStateOf(item.title) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Insert Personal Budget Amount") },
        text = {
            Column {
                Text("Update amount for '${item.title}' (${item.category}):", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("Item Title") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount in ZAR") },
                    prefix = { Text("R ") },
                    placeholder = { Text("0.00") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = amountText.toDoubleOrNull() ?: 0.0
                    onSave(item.copy(title = titleText, amount = parsed))
                }
            ) {
                Text("Save Figure")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddBudgetItemDialog(
    initialTitle: String = "",
    initialAmountText: String = "0.00",
    initialCategory: String = "Food",
    onDismiss: () -> Unit,
    onConfirm: (BudgetItem) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var amountText by remember { mutableStateOf(initialAmountText) }
    var type by remember { mutableStateOf("Expense") }
    var category by remember { mutableStateOf(if (initialCategory.isNotBlank()) initialCategory else "Food") }

    val incomeCategories = listOf("Allowance", "Salary", "Bursary", "Scholarship", "Parents", "Other")
    val expenseCategories = listOf("Food", "Transport", "Accommodation", "Entertainment", "Books", "Shopping", "Electricity", "Data", "Internet", "Medical", "Savings", "Other")

    val categories = if (type == "Income") incomeCategories else expenseCategories

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Transaction (ZAR R)") },
        text = {
            Column {
                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = type == "Expense",
                        onClick = { type = "Expense"; category = expenseCategories.first() },
                        label = { Text("Expense") },
                        modifier = Modifier.weight(1f).padding(end = 4.dp)
                    )
                    FilterChip(
                        selected = type == "Income",
                        onClick = { type = "Income"; category = incomeCategories.first() },
                        label = { Text("Income") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Description (e.g., Woolworths Groceries)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // MANDATORY REQUIREMENT: Default R0.00
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount in ZAR (R0.00)") },
                    prefix = { Text("R ") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("Category", style = MaterialTheme.typography.labelSmall)
                ScrollableTabRow(selectedTabIndex = categories.indexOf(category).coerceAtLeast(0), divider = {}) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedAmount = amountText.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank()) {
                        onConfirm(BudgetItem(title = title, amount = parsedAmount, type = type, category = category))
                    }
                }
            ) {
                Text("Save Transaction")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
