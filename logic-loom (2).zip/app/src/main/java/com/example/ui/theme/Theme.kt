package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class AppColorPalette(
    val themeId: String,
    val displayName: String,
    val description: String,
    val emoji: String,
    val primaryColor: Color,
    val primaryHoverColor: Color,
    val primaryDarkColor: Color,
    val lightAccentColor: Color,
    val secondaryBgColor: Color = Color(0xFFF8FAF9),
    val mainTextColor: Color = Color(0xFF111111),
    val secondaryTextColor: Color = Color(0xFF374151),
    val borderColor: Color = Color(0xFFE5E7EB)
) {
    LOGIC_LOOM(
        themeId = "logic_loom",
        displayName = "Logic Loom",
        description = "Deep Navy & Electric Blue",
        emoji = "⚡",
        primaryColor = Color(0xFF2563EB),
        primaryHoverColor = Color(0xFF1D4ED8),
        primaryDarkColor = Color(0xFF070D1E),
        lightAccentColor = Color(0xFFDBEAFE),
        secondaryBgColor = Color(0xFFF1F5F9),
        mainTextColor = Color(0xFF0F172A),
        secondaryTextColor = Color(0xFF475569),
        borderColor = Color(0xFFE2E8F0)
    ),
    CANVAS_GREEN(
        themeId = "canvas_green",
        displayName = "Emerald Sage",
        description = "Clean and balanced",
        emoji = "🌿",
        primaryColor = Color(0xFF14532D),
        primaryHoverColor = Color(0xFF166534),
        primaryDarkColor = Color(0xFF064E3B),
        lightAccentColor = Color(0xFFDCFCE7),
        secondaryBgColor = Color(0xFFF8FAF9)
    ),
    NAVY(
        themeId = "navy",
        displayName = "Navy",
        description = "Professional and focused",
        emoji = "🔵",
        primaryColor = Color(0xFF0F172A),
        primaryHoverColor = Color(0xFF1E293B),
        primaryDarkColor = Color(0xFF020617),
        lightAccentColor = Color(0xFFE2E8F0),
        secondaryBgColor = Color(0xFFF8FAFC)
    ),
    BURGANDY(
        themeId = "burgundy",
        displayName = "Burgundy",
        description = "Bold and confident",
        emoji = "🔴",
        primaryColor = Color(0xFF7F1D1D),
        primaryHoverColor = Color(0xFF991B1B),
        primaryDarkColor = Color(0xFF450A0A),
        lightAccentColor = Color(0xFFFEE2E2),
        secondaryBgColor = Color(0xFFFEF2F2)
    ),
    PINK(
        themeId = "pink",
        displayName = "Pink",
        description = "Bright and expressive",
        emoji = "🌸",
        primaryColor = Color(0xFF9D174D),
        primaryHoverColor = Color(0xFFBE185D),
        primaryDarkColor = Color(0xFF831843),
        lightAccentColor = Color(0xFFFCE7F3),
        secondaryBgColor = Color(0xFFFDF2F8)
    ),
    GOLD(
        themeId = "gold",
        displayName = "Gold",
        description = "Warm and optimistic",
        emoji = "🟡",
        primaryColor = Color(0xFF854D0E),
        primaryHoverColor = Color(0xFFA16207),
        primaryDarkColor = Color(0xFF713F12),
        lightAccentColor = Color(0xFFFEF3C7),
        secondaryBgColor = Color(0xFFFFFBEB)
    ),
    PURPLE(
        themeId = "purple",
        displayName = "Purple",
        description = "Creative and modern",
        emoji = "🟣",
        primaryColor = Color(0xFF581C87),
        primaryHoverColor = Color(0xFF6B21A8),
        primaryDarkColor = Color(0xFF3B0764),
        lightAccentColor = Color(0xFFF3E8FF),
        secondaryBgColor = Color(0xFFFAF5FF)
    ),
    OCEAN(
        themeId = "ocean",
        displayName = "Ocean",
        description = "Calm and refreshing",
        emoji = "🌊",
        primaryColor = Color(0xFF0F766E),
        primaryHoverColor = Color(0xFF115E59),
        primaryDarkColor = Color(0xFF134E4A),
        lightAccentColor = Color(0xFFCCFBF1),
        secondaryBgColor = Color(0xFFF0FDFA)
    );

    // Backward compatibility properties
    val secondaryColor: Color get() = primaryHoverColor
    val tertiaryColor: Color get() = primaryDarkColor
    val primaryContainerLight: Color get() = lightAccentColor
    val onPrimaryContainerLight: Color get() = primaryDarkColor
    val primaryContainerDark: Color get() = primaryDarkColor
    val onPrimaryContainerDark: Color get() = Color.White

    companion object {
        // Aliases for legacy palette names
        val CLASSIC_BLUE = NAVY
        val CANVASMATE_NAVY_CRIMSON = CANVAS_GREEN
        val SUNSET_CRIMSON = BURGANDY
        val EMERALD_SAGE = CANVAS_GREEN
    }
}

enum class AppFontStyle(
    val displayName: String,
    val sampleText: String,
    val fontFamily: FontFamily
) {
    DEFAULT(
        displayName = "Modern Sans",
        sampleText = "Aa Bb 123 • Clean Modern Sans",
        fontFamily = FontFamily.Default
    ),
    SERIF(
        displayName = "Classic Serif",
        sampleText = "Aa Bb 123 • Academic Serif",
        fontFamily = FontFamily.Serif
    ),
    MONOSPACE(
        displayName = "Tech Mono",
        sampleText = "Aa Bb 123 • Code Monospace",
        fontFamily = FontFamily.Monospace
    ),
    CURSIVE(
        displayName = "Handwritten",
        sampleText = "Aa Bb 123 • Elegant Cursive",
        fontFamily = FontFamily.Cursive
    ),
    SANS_SERIF(
        displayName = "Clean Sans-Serif",
        sampleText = "Aa Bb 123 • Standard Sans",
        fontFamily = FontFamily.SansSerif
    )
}

fun getCustomColorScheme(palette: AppColorPalette, isDark: Boolean): ColorScheme {
    return if (isDark) {
        if (palette == AppColorPalette.LOGIC_LOOM) {
            darkColorScheme(
                primary = Color(0xFF2563EB),
                onPrimary = Color.White,
                primaryContainer = Color(0xFF1D4ED8),
                onPrimaryContainer = Color.White,
                secondary = Color(0xFF06B6D4),
                onSecondary = Color(0xFF070D1E),
                secondaryContainer = Color(0xFF16243C),
                onSecondaryContainer = Color(0xFFF8FAFC),
                tertiary = Color(0xFF8B5CF6),
                onTertiary = Color.White,
                background = Color(0xFF070D1E),
                onBackground = Color(0xFFF8FAFC),
                surface = Color(0xFF0F1B2E),
                onSurface = Color(0xFFF8FAFC),
                surfaceVariant = Color(0xFF16243C),
                onSurfaceVariant = Color(0xFFCBD5E1),
                outline = Color(0xFF1E2F4D)
            )
        } else {
            darkColorScheme(
                primary = palette.lightAccentColor,
                onPrimary = palette.primaryDarkColor,
                primaryContainer = palette.primaryColor,
                onPrimaryContainer = Color.White,
                secondary = palette.lightAccentColor,
                onSecondary = palette.primaryDarkColor,
                tertiary = palette.primaryHoverColor,
                background = Color(0xFF0F172A),
                onBackground = Color.White,
                surface = Color(0xFF1E293B),
                onSurface = Color.White,
                surfaceVariant = Color(0xFF334155),
                onSurfaceVariant = Color(0xFFCBD5E1),
                outline = Color(0xFF475569)
            )
        }
    } else {
        lightColorScheme(
            primary = palette.primaryColor,
            onPrimary = Color.White,
            primaryContainer = palette.lightAccentColor,
            onPrimaryContainer = palette.primaryDarkColor,
            secondary = palette.primaryHoverColor,
            onSecondary = Color.White,
            secondaryContainer = palette.lightAccentColor,
            onSecondaryContainer = palette.primaryColor,
            tertiary = palette.primaryDarkColor,
            onTertiary = Color.White,
            background = Color.White,
            onBackground = palette.mainTextColor,
            surface = Color.White,
            onSurface = palette.mainTextColor,
            surfaceVariant = palette.secondaryBgColor,
            onSurfaceVariant = palette.secondaryTextColor,
            outline = palette.borderColor,
            outlineVariant = palette.borderColor.copy(alpha = 0.6f)
        )
    }
}

fun getCustomTypography(fontStyle: AppFontStyle): Typography {
    val family = fontStyle.fontFamily
    return Typography(
        headlineLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 40.sp),
        headlineMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
        headlineSmall = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 32.sp),
        titleLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
        titleMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
        titleSmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 20.sp),
        bodyLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.5.sp),
        bodyMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.25.sp),
        bodySmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
        labelLarge = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
        labelMedium = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
        labelSmall = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp)
    )
}

