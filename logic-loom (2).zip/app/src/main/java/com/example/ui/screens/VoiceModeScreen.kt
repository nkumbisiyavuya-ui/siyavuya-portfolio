package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.voice.*
import com.example.ui.CanvasMateViewModel
import com.example.ui.components.ChumaCLogo
import kotlinx.coroutines.launch

/**
 * Chuma AI Voice Mode V1 — Fullscreen Conversational Interface.
 *
 * Designed to 2026 AI-product aesthetic:
 * - Real-time speech recognition with streaming partial transcription
 * - Conversational turn detection & automatic silence detection
 * - Immediate conversational barge-in / interruption
 * - 3 distinct voice agents (Female, Male, Horizon/Neural)
 * - Animated audio-reactive orb and waveform visualizer
 * - Clean transcript history integrated with existing Chuma AI
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceModeScreen(
    viewModel: CanvasMateViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Microphone Permission State
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
    }

    // Voice Session Manager
    val sessionManager = remember {
        VoiceSessionManager(
            context = context,
            coroutineScope = coroutineScope,
            onSendPromptToAi = { prompt, onResponse ->
                viewModel.sendVoicePrompt(prompt, onChunk = null, onResponse = onResponse)
            },
            onStreamPromptToAi = { prompt, onChunk, onResponse ->
                viewModel.sendVoicePrompt(prompt, onChunk = onChunk, onResponse = onResponse)
            }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            sessionManager.destroy()
        }
    }

    val voiceState by sessionManager.voiceState.collectAsState()
    val liveTranscript by sessionManager.currentLiveTranscript.collectAsState()
    val currentAiSpeech by sessionManager.currentAiSpeech.collectAsState()
    val soundLevel by sessionManager.soundLevelRms.collectAsState()
    val voiceSettings by sessionManager.voiceSettings.collectAsState()
    val ttsStatusNotice by sessionManager.ttsStatusNotice.collectAsState()
    val transcripts by sessionManager.transcripts.collectAsState()
    val errorMessage by sessionManager.errorMessage.collectAsState()

    var showSettingsSheet by remember { mutableStateOf(false) }
    var showTranscriptSheet by remember { mutableStateOf(false) }

    // Request permission on launch if needed
    LaunchedEffect(Unit) {
        if (!hasMicPermission) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF060913),
                        Color(0xFF090E1D),
                        Color(0xFF060913)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("voice_mode_screen")
    ) {
        // Ambient background glow spots
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Center electric blue atmospheric glow
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        Color(0x222563EB),
                        Color(0x0C06B6D4),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.42f),
                    radius = w * 0.65f
                )
            )

            // Top-right subtle gold ambient detail
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        Color(0x10F59E0B),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.85f, h * 0.12f),
                    radius = w * 0.4f
                )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ==========================================
            // TOP BAR: Navigation, Voice Mode Title & Settings
            // ==========================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        sessionManager.pauseOrStopAll()
                        onNavigateBack()
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0x221E293B))
                        .border(1.dp, Color(0x333B82F6), CircleShape)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    when (voiceState) {
                                        VoiceState.LISTENING -> Color(0xFF10B981)
                                        VoiceState.SPEAKING -> Color(0xFF38BDF8)
                                        VoiceState.THINKING -> Color(0xFFF59E0B)
                                        VoiceState.INTERRUPTED -> Color(0xFFE11D48)
                                        VoiceState.ERROR -> Color(0xFFEF4444)
                                        VoiceState.IDLE -> Color(0xFF60A5FA)
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CHUMA VOICE MODE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp,
                            color = Color.White
                        )
                    }
                    Text(
                        text = if (!ttsStatusNotice.isNullOrBlank()) "${sessionManager.getSelectedProfile().name} • $ttsStatusNotice" else sessionManager.getSelectedProfile().name,
                        fontSize = 11.sp,
                        color = if (!ttsStatusNotice.isNullOrBlank()) Color(0xFFFBBF24) else Color(0xFF94A3B8)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { showTranscriptSheet = true },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0x221E293B))
                            .border(1.dp, Color(0x333B82F6), CircleShape)
                    ) {
                        Icon(
                            Icons.Outlined.Chat,
                            contentDescription = "View Transcript",
                            tint = Color(0xFF93C5FD),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0x221E293B))
                            .border(1.dp, Color(0x333B82F6), CircleShape)
                    ) {
                        Icon(
                            Icons.Outlined.Tune,
                            contentDescription = "Voice Settings",
                            tint = Color(0xFF93C5FD),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // ==========================================
            // QUICK VOICE SELECTOR CHIP ROW
            // ==========================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                CHUMA_VOICE_PROFILES.forEach { profile ->
                    val isSelected = profile.id == voiceSettings.selectedVoiceId
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) Brush.horizontalGradient(
                                    listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                ) else Brush.horizontalGradient(
                                    listOf(Color(0x221E293B), Color(0x111E293B))
                                )
                            )
                            .border(
                                1.dp,
                                if (isSelected) Color(0xFF60A5FA) else Color(0x223B82F6),
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { sessionManager.setVoiceProfile(profile.id) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = profile.genderLabel,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.4f))

            // ==========================================
            // CENTER: AUDIO-REACTIVE ORB / VISUALIZER
            // ==========================================
            VoiceOrbVisualizer(
                state = voiceState,
                soundLevel = soundLevel,
                onClick = {
                    if (!hasMicPermission) {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        when (voiceState) {
                            VoiceState.LISTENING -> sessionManager.stopListeningManually()
                            VoiceState.SPEAKING -> sessionManager.bargeIn()
                            VoiceState.THINKING -> { /* Processing turn */ }
                            else -> sessionManager.startListening()
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // ==========================================
            // STATE BANNER & INSTRUCTION
            // ==========================================
            VoiceStateBanner(
                state = voiceState,
                hasPermission = hasMicPermission,
                onGrantPermission = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                onRetry = { sessionManager.startListening() },
                errorMessage = errorMessage
            )

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // LIVE TRANSCRIPTION & AI SPEECH STREAM
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 90.dp, max = 150.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCC0D1527))
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(Color(0x443B82F6), Color(0x2206B6D4), Color(0x101E293B))
                        ),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                when {
                    voiceState == VoiceState.LISTENING -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (liveTranscript.isNotBlank()) liveTranscript else "Listening to your voice...",
                                fontSize = if (liveTranscript.isNotBlank()) 16.sp else 14.sp,
                                fontWeight = if (liveTranscript.isNotBlank()) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (liveTranscript.isNotBlank()) Color.White else Color(0xFF94A3B8),
                                textAlign = TextAlign.Center,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    voiceState == VoiceState.THINKING -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                color = Color(0xFF38BDF8),
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Chuma is reasoning...",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF93C5FD)
                            )
                        }
                    }
                    voiceState == VoiceState.SPEAKING -> {
                        Text(
                            text = if (currentAiSpeech.isNotBlank()) currentAiSpeech else "Chuma is speaking...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFE2E8F0),
                            textAlign = TextAlign.Center,
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    voiceState == VoiceState.INTERRUPTED -> {
                        Text(
                            text = "Interrupted. Listening again...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFF43F5E),
                            textAlign = TextAlign.Center
                        )
                    }
                    voiceState == VoiceState.ERROR -> {
                        Text(
                            text = errorMessage ?: "Voice recognition interrupted. Tap to speak again.",
                            fontSize = 13.sp,
                            color = Color(0xFFFCA5A5),
                            textAlign = TextAlign.Center
                        )
                    }
                    else -> {
                        val lastAi = transcripts.lastOrNull { it.sender == "Chuma" }?.text
                        Text(
                            text = lastAi?.take(120)?.let { "\"$it...\"" } ?: "Tap the center orb or microphone to start speaking.",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // ==========================================
            // BOTTOM CONTROLS: BARGE-IN & MIC CONTROLS
            // ==========================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Barge-in / Interrupt Button (Enabled when Chuma is speaking)
                Button(
                    onClick = { sessionManager.bargeIn() },
                    enabled = voiceState == VoiceState.SPEAKING,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0x33DC2626),
                        disabledContainerColor = Color(0x111E293B),
                        contentColor = Color(0xFFF43F5E),
                        disabledContentColor = Color(0xFF475569)
                    ),
                    modifier = Modifier.height(44.dp)
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Interrupt", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Primary Tap-to-Talk Button
                Box(
                    modifier = Modifier
                        .size(62.dp)
                        .shadow(
                            elevation = 12.dp,
                            shape = CircleShape,
                            ambientColor = Color(0x60000000),
                            spotColor = Color(0xFF2563EB)
                        )
                        .clip(CircleShape)
                        .background(
                            when (voiceState) {
                                VoiceState.LISTENING -> Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669)))
                                VoiceState.SPEAKING -> Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF06B6D4)))
                                VoiceState.THINKING -> Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))
                                else -> Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF1D4ED8)))
                            }
                        )
                        .border(
                            1.dp,
                            if (voiceState == VoiceState.LISTENING) Color(0xFF6EE7B7) else Color(0xFF60A5FA),
                            CircleShape
                        )
                        .clickable {
                            if (!hasMicPermission) {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                if (voiceState == VoiceState.LISTENING) {
                                    sessionManager.stopListeningManually()
                                } else if (voiceState == VoiceState.SPEAKING) {
                                    sessionManager.bargeIn()
                                } else {
                                    sessionManager.startListening()
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (voiceState) {
                            VoiceState.LISTENING -> Icons.Default.Mic
                            VoiceState.SPEAKING -> Icons.Default.VolumeUp
                            VoiceState.THINKING -> Icons.Default.HourglassTop
                            else -> Icons.Default.MicNone
                        },
                        contentDescription = "Microphone Action",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Pause / Stop Session Button
                Button(
                    onClick = { sessionManager.pauseOrStopAll() },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0x221E293B),
                        contentColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.height(44.dp)
                ) {
                    Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pause", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ==========================================
        // VOICE SETTINGS BOTTOM SHEET
        // ==========================================
        if (showSettingsSheet) {
            VoiceSettingsBottomSheet(
                currentSettings = voiceSettings,
                onDismiss = { showSettingsSheet = false },
                onUpdateSettings = { sessionManager.updateSettings(it) }
            )
        }

        // ==========================================
        // TRANSCRIPT HISTORY BOTTOM SHEET
        // ==========================================
        if (showTranscriptSheet) {
            VoiceTranscriptBottomSheet(
                transcripts = transcripts,
                onDismiss = { showTranscriptSheet = false },
                onClear = { sessionManager.clearTranscripts() }
            )
        }
    }
}

// -------------------------------------------------------------
// Interactive Audio-Reactive Chuma Orb Visualizer
// -------------------------------------------------------------
@Composable
private fun VoiceOrbVisualizer(
    state: VoiceState,
    soundLevel: Float,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbPulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    VoiceState.LISTENING -> 600
                    VoiceState.SPEAKING -> 800
                    VoiceState.THINKING -> 1100
                    else -> 2200
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orbPulseAnim"
    )

    val waveRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing)
        ),
        label = "orbRotation"
    )

    // Dynamic scale combines breathing and live sound energy
    val dynamicScale = remember(pulseScale, soundLevel, state) {
        if (state == VoiceState.LISTENING) {
            (1.0f + (soundLevel * 0.35f)).coerceIn(0.95f, 1.35f)
        } else {
            pulseScale
        }
    }

    Box(
        modifier = Modifier
            .size(210.dp)
            .scale(dynamicScale)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Outer radiant aura rings
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val baseRadius = size.width / 2 * 0.85f

            // Outer reactive glow circle
            drawCircle(
                color = when (state) {
                    VoiceState.LISTENING -> Color(0x3310B981)
                    VoiceState.SPEAKING -> Color(0x3338BDF8)
                    VoiceState.THINKING -> Color(0x33F59E0B)
                    VoiceState.INTERRUPTED -> Color(0x44E11D48)
                    VoiceState.ERROR -> Color(0x44EF4444)
                    VoiceState.IDLE -> Color(0x222563EB)
                },
                radius = baseRadius + (soundLevel * 24f),
                style = Stroke(width = 3.dp.toPx())
            )

            // Inner harmonic ring
            drawCircle(
                color = when (state) {
                    VoiceState.LISTENING -> Color(0x5534D399)
                    VoiceState.SPEAKING -> Color(0x5560A5FA)
                    VoiceState.THINKING -> Color(0x55FBBF24)
                    else -> Color(0x333B82F6)
                },
                radius = baseRadius * 0.78f,
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        // Central Chuma Living Core
        Box(
            modifier = Modifier
                .size(114.dp)
                .shadow(
                    elevation = 20.dp,
                    shape = CircleShape,
                    ambientColor = Color(0x80000000),
                    spotColor = when (state) {
                        VoiceState.LISTENING -> Color(0xFF10B981)
                        VoiceState.SPEAKING -> Color(0xFF38BDF8)
                        VoiceState.THINKING -> Color(0xFFF59E0B)
                        else -> Color(0xFF2563EB)
                    }
                )
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = when (state) {
                            VoiceState.LISTENING -> listOf(
                                Color(0xFF059669),
                                Color(0xFF064E3B),
                                Color(0xFF022C22)
                            )
                            VoiceState.SPEAKING -> listOf(
                                Color(0xFF0284C7),
                                Color(0xFF1D4ED8),
                                Color(0xFF0B132B)
                            )
                            VoiceState.THINKING -> listOf(
                                Color(0xFFD97706),
                                Color(0xFF78350F),
                                Color(0xFF1C0A00)
                            )
                            VoiceState.INTERRUPTED -> listOf(
                                Color(0xFFBE123C),
                                Color(0xFF4C0519),
                                Color(0xFF1A0006)
                            )
                            else -> listOf(
                                Color(0xFF2563EB),
                                Color(0xFF1E3A8A),
                                Color(0xFF070D1E)
                            )
                        }
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            Color(0xFF67E8F9),
                            Color(0x332563EB),
                            Color(0xFFF59E0B)
                        )
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            ChumaCLogo(
                size = 54.dp,
                showGlow = false,
                showBackgroundContainer = false
            )
        }
    }
}

// -------------------------------------------------------------
// Voice State Banner
// -------------------------------------------------------------
@Composable
private fun VoiceStateBanner(
    state: VoiceState,
    hasPermission: Boolean,
    onGrantPermission: () -> Unit,
    onRetry: () -> Unit,
    errorMessage: String?
) {
    if (!hasPermission) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0x33DC2626),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66DC2626))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Microphone access is required for voice.",
                    fontSize = 12.sp,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = onGrantPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Allow", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        return
    }

    when (state) {
        VoiceState.LISTENING -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Listening... Speak naturally",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF34D399)
                )
            }
        }
        VoiceState.SPEAKING -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Chuma is speaking (Tap to interrupt)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF38BDF8)
                )
            }
        }
        VoiceState.THINKING -> {
            Text(
                text = "Thinking and formulating answer...",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFFBBF24)
            )
        }
        VoiceState.INTERRUPTED -> {
            Text(
                text = "Interrupted. Listening for next question...",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFF43F5E)
            )
        }
        VoiceState.ERROR -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = errorMessage ?: "Voice interrupted.",
                    fontSize = 13.sp,
                    color = Color(0xFFFCA5A5)
                )
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onRetry) {
                    Text("Retry", fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                }
            }
        }
        VoiceState.IDLE -> {
            Text(
                text = "Tap to speak • Conversational AI Ready",
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF94A3B8)
            )
        }
    }
}

// -------------------------------------------------------------
// Voice Settings Bottom Sheet
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceSettingsBottomSheet(
    currentSettings: VoiceSettings,
    onDismiss: () -> Unit,
    onUpdateSettings: (VoiceSettings) -> Unit
) {
    var selectedVoiceId by remember { mutableStateOf(currentSettings.selectedVoiceId) }
    var volume by remember { mutableFloatStateOf(currentSettings.volume) }
    var speechRate by remember { mutableFloatStateOf(currentSettings.speechRate) }
    var autoPlay by remember { mutableStateOf(currentSettings.autoPlayResponses) }
    var liveTranscription by remember { mutableStateOf(currentSettings.liveTranscriptionEnabled) }

    ModalBottomSheet(
        onDismissRequest = {
            onUpdateSettings(
                currentSettings.copy(
                    selectedVoiceId = selectedVoiceId,
                    volume = volume,
                    speechRate = speechRate,
                    autoPlayResponses = autoPlay,
                    liveTranscriptionEnabled = liveTranscription
                )
            )
            onDismiss()
        },
        containerColor = Color(0xFF090E1D),
        scrimColor = Color(0xB3000000),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF334155))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Chuma Voice Settings",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                }
            }

            // Voice Profile Selection
            Column {
                Text(
                    text = "Voice Agent Profile",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(8.dp))
                CHUMA_VOICE_PROFILES.forEach { profile ->
                    val isSelected = profile.id == selectedVoiceId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0x222563EB) else Color(0x111E293B))
                            .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0x223B82F6), RoundedCornerShape(12.dp))
                            .clickable { selectedVoiceId = profile.id }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { selectedVoiceId = profile.id },
                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF38BDF8))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = profile.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = profile.personality,
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // Volume Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Voice Volume", fontSize = 13.sp, color = Color(0xFF94A3B8))
                    Text(text = "${(volume * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Slider(
                    value = volume,
                    onValueChange = { volume = it },
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF38BDF8),
                        activeTrackColor = Color(0xFF2563EB),
                        inactiveTrackColor = Color(0x331E293B)
                    )
                )
            }

            // Speaking Speed Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Speaking Speed", fontSize = 13.sp, color = Color(0xFF94A3B8))
                    val speedLabel = when {
                        speechRate < 0.9f -> "Slower (${String.format("%.2f", speechRate)}x)"
                        speechRate > 1.1f -> "Faster (${String.format("%.2f", speechRate)}x)"
                        else -> "Normal (1.0x)"
                    }
                    Text(text = speedLabel, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Slider(
                    value = speechRate,
                    onValueChange = { speechRate = it },
                    valueRange = 0.75f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF38BDF8),
                        activeTrackColor = Color(0xFF2563EB),
                        inactiveTrackColor = Color(0x331E293B)
                    )
                )
            }

            // Auto-play switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Auto-play Voice Responses", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
                    Text(text = "Speak aloud immediately upon AI response", fontSize = 11.sp, color = Color(0xFF94A3B8))
                }
                Switch(
                    checked = autoPlay,
                    onCheckedChange = { autoPlay = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF2563EB)
                    )
                )
            }

            // Live transcription switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Live Real-Time Transcription", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
                    Text(text = "Display partial transcription as you speak", fontSize = 11.sp, color = Color(0xFF94A3B8))
                }
                Switch(
                    checked = liveTranscription,
                    onCheckedChange = { liveTranscription = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF2563EB)
                    )
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Voice Conversation Transcript Bottom Sheet
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceTranscriptBottomSheet(
    transcripts: List<VoiceTranscriptItem>,
    onDismiss: () -> Unit,
    onClear: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF090E1D),
        scrimColor = Color(0xB3000000),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF334155))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f)
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Conversation Transcript",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Row {
                    if (transcripts.isNotEmpty()) {
                        TextButton(onClick = onClear) {
                            Text("Clear", color = Color(0xFFF43F5E), fontSize = 12.sp)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (transcripts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No voice turns recorded in this session yet.\nSpeak to Chuma to begin.",
                        fontSize = 13.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(transcripts) { item ->
                        val isUser = item.sender == "User"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .widthIn(max = 300.dp)
                                    .clip(
                                        RoundedCornerShape(
                                            topStart = 16.dp,
                                            topEnd = 16.dp,
                                            bottomStart = if (isUser) 16.dp else 4.dp,
                                            bottomEnd = if (isUser) 4.dp else 16.dp
                                        )
                                    )
                                    .background(
                                        if (isUser) Color(0xFF1D4ED8) else Color(0xCC0E1A33)
                                    )
                                    .border(
                                        1.dp,
                                        if (isUser) Color(0xFF3B82F6) else Color(0x2238BDF8),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Column {
                                    Text(
                                        text = item.sender,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isUser) Color(0xFF93C5FD) else Color(0xFF38BDF8)
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = item.text,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
