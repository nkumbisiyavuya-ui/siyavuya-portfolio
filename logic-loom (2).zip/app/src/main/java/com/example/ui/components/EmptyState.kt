package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/**
 * Reusable Empty State component for displaying friendly illustrations, titles,
 * descriptions, and optional primary action buttons when lists (tasks, budget, notes) are empty.
 */
@Composable
fun EmptyState(
    title: String,
    modifier: Modifier = Modifier,
    description: String? = null,
    icon: ImageVector = Icons.Outlined.Inbox,
    iconBadgeColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null,
    illustration: @Composable (() -> Unit)? = null
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("empty_state_container"),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (illustration != null) {
                illustration()
            } else {
                // Layered Icon Badge Illustration
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    iconBadgeColor,
                                    iconBadgeColor.copy(alpha = 0.4f)
                                )
                            )
                        )
                        .testTag("empty_state_illustration")
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                    )
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("empty_state_icon")
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("empty_state_title")
            )

            if (!description.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("empty_state_description")
                )
            }

            if (!actionLabel.isNullOrEmpty() && onActionClick != null) {
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onActionClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("empty_state_action_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Text(
                        text = actionLabel,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

/**
 * Specialized Empty State preset for Academic Tasks & To-Dos.
 */
@Composable
fun EmptyTasksState(
    modifier: Modifier = Modifier,
    onAddTask: (() -> Unit)? = null
) {
    EmptyState(
        title = "No Tasks Found",
        description = "Your task planner is currently clear. Add your academic assignments or personal to-dos to stay on track.",
        icon = Icons.Outlined.Assignment,
        iconBadgeColor = MaterialTheme.colorScheme.primaryContainer,
        iconTint = MaterialTheme.colorScheme.primary,
        actionLabel = "Add New Task",
        onActionClick = onAddTask,
        modifier = modifier
    )
}

/**
 * Specialized Empty State preset for Budget Items & Expenses.
 */
@Composable
fun EmptyBudgetState(
    modifier: Modifier = Modifier,
    onAddBudgetItem: (() -> Unit)? = null
) {
    EmptyState(
        title = "No Financial Records",
        description = "No income or expense entries found for this category. Keep track of your monthly student allowance and spending.",
        icon = Icons.Outlined.AccountBalanceWallet,
        iconBadgeColor = MaterialTheme.colorScheme.secondaryContainer,
        iconTint = MaterialTheme.colorScheme.secondary,
        actionLabel = "Add Budget Item",
        onActionClick = onAddBudgetItem,
        modifier = modifier
    )
}

/**
 * Specialized Empty State preset for Notes & Summaries.
 */
@Composable
fun EmptyNotesState(
    modifier: Modifier = Modifier,
    onAddNote: (() -> Unit)? = null
) {
    EmptyState(
        title = "No Lecture Notes Yet",
        description = "Create and organize your course summaries, lecture highlights, or study revision notes here.",
        icon = Icons.Outlined.Description,
        iconBadgeColor = MaterialTheme.colorScheme.tertiaryContainer,
        iconTint = MaterialTheme.colorScheme.tertiary,
        actionLabel = "Create Note",
        onActionClick = onAddNote,
        modifier = modifier
    )
}
