package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.example.data.device.DeviceCapabilityManager
import kotlinx.coroutines.launch
import com.example.data.local.PaymentMethodEntity
import com.example.data.local.ShoppingItem
import com.example.data.local.TransportRequest
import com.example.ui.CanvasMateViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeHubScreen(
    viewModel: CanvasMateViewModel,
    initialTab: String = "Transport",
    onNavigateToAssistant: (String) -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf(initialTab) }

    val tabs = listOf(
        "Transport" to Icons.Default.DirectionsCar,
        "Shopping" to Icons.Default.ShoppingCart,
        "Wallet & Pay" to Icons.Default.AccountBalanceWallet
    )

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Row Header
            ScrollableTabRow(
                selectedTabIndex = tabs.indexOfFirst { it.first == selectedTab }.coerceAtLeast(0),
                edgePadding = 16.dp,
                divider = {}
            ) {
                tabs.forEach { (title, icon) ->
                    Tab(
                        selected = selectedTab == title,
                        onClick = { selectedTab = title },
                        text = { Text(title, fontWeight = FontWeight.Bold) },
                        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            when (selectedTab) {
                "Transport" -> TransportHubView(viewModel = viewModel, onNavigateToAssistant = onNavigateToAssistant)
                "Shopping" -> ShoppingHubView(viewModel = viewModel)
                "Wallet & Pay" -> WalletAndPaymentCentreView(viewModel = viewModel, onAskAssistant = onNavigateToAssistant)
                else -> TransportHubView(viewModel = viewModel, onNavigateToAssistant = onNavigateToAssistant)
            }
        }
    }
}

/**
 * 🚆 LOGIC LOOM TRANSPORT & MOBILITY HUB
 * Integrates PRASA Metrorail & Bus route discovery with voice search & permission-based location.
 */
@Composable
fun TransportHubView(
    viewModel: CanvasMateViewModel,
    onNavigateToAssistant: (String) -> Unit = {}
) {
    com.example.ui.transport.LogicLoomTransportHub(
        viewModel = viewModel,
        onNavigateToAssistant = onNavigateToAssistant
    )
}

/**
 * 🛒 SHOPPING HUB VIEW
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingHubView(viewModel: CanvasMateViewModel) {
    val items by viewModel.shoppingItems.collectAsState()
    val budgetItems by viewModel.budgetItems.collectAsState()

    var showAddItemDialog by remember { mutableStateOf(false) }
    var itemTitle by remember { mutableStateOf("") }
    var itemCategory by remember { mutableStateOf("Groceries") }
    var itemPriceZar by remember { mutableStateOf("") }
    var itemIsUrgent by remember { mutableStateOf(false) }

    val totalShoppingCost = items.filter { !it.isPurchased }.sumOf { it.estimatedPriceZar }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Shopping Hub List", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Pending Total: R${"%.2f".format(totalShoppingCost)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Button(
                            onClick = { showAddItemDialog = true },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Item")
                        }
                    }
                }
            }
        }

        item {
            Text("Your Shopping Items (${items.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(items) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (item.isPurchased) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Checkbox(
                            checked = item.isPurchased,
                            onCheckedChange = { viewModel.toggleShoppingItemPurchased(item) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    item.itemTitle,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (item.isPurchased) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                                )
                                if (item.isUrgent) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.errorContainer) {
                                        Text("URGENT", modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                    }
                                }
                            }
                            Text("${item.category} • R${"%.2f".format(item.estimatedPriceZar)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    IconButton(onClick = { viewModel.deleteShoppingItem(item.id) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (showAddItemDialog) {
        AlertDialog(
            onDismissRequest = { showAddItemDialog = false },
            title = { Text("Add Shopping Item") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = itemTitle,
                        onValueChange = { itemTitle = it },
                        label = { Text("Item Name") },
                        placeholder = { Text("e.g. Milk, Exam Pad, Coffee") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = itemCategory,
                        onValueChange = { itemCategory = it },
                        label = { Text("Category") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = itemPriceZar,
                        onValueChange = { itemPriceZar = it },
                        label = { Text("Estimated Price (ZAR / R)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = itemIsUrgent, onCheckedChange = { itemIsUrgent = it })
                        Text("Mark as Urgent")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (itemTitle.isNotBlank()) {
                            viewModel.addShoppingItem(
                                ShoppingItem(
                                    itemTitle = itemTitle,
                                    category = itemCategory.ifBlank { "Groceries" },
                                    estimatedPriceZar = itemPriceZar.toDoubleOrNull() ?: 0.0,
                                    isUrgent = itemIsUrgent
                                )
                            )
                            itemTitle = ""
                            itemPriceZar = ""
                            showAddItemDialog = false
                        }
                    }
                ) { Text("Save Item") }
            },
            dismissButton = {
                TextButton(onClick = { showAddItemDialog = false }) { Text("Cancel") }
            }
        )
    }
}

/**
 * 💳 WALLET & PAYMENT CENTRE VIEW
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletAndPaymentCentreView(
    viewModel: CanvasMateViewModel,
    onAskAssistant: (String) -> Unit
) {
    val budgetItems by viewModel.budgetItems.collectAsState()
    val paymentMethods by viewModel.paymentMethods.collectAsState()

    val totalIncome = budgetItems.filter { it.type == "Income" }.sumOf { it.amount }
    val totalExpenses = budgetItems.filter { it.type == "Expense" }.sumOf { it.amount }
    val availableBalance = (totalIncome - totalExpenses).coerceAtLeast(0.0)

    var showGooglePayDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Main Wallet Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Logic Loom Wallet (ZAR)", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White.copy(alpha = 0.2f)
                        ) {
                            Text("CAPITEC / GOOGLE PAY", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("R${"%.2f".format(availableBalance)}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Available Financial Balance", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("INCOME", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                            Text("R${"%.2f".format(totalIncome)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF6EE7B7))
                        }
                        Column {
                            Text("EXPENSES", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                            Text("R${"%.2f".format(totalExpenses)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5))
                        }
                        Column {
                            Text("REMAINING", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                            Text("R${"%.2f".format(availableBalance)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        item {
            // Intelligent Daily Money Insights Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Intelligent Daily Spending Insight", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val daysRemaining = 5
                    val dailyAllowance = if (daysRemaining > 0) availableBalance / daysRemaining else 0.0

                    Text("Based on R${"%.2f".format(availableBalance)} available for the next $daysRemaining days:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surface) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("R${"%.2f".format(dailyAllowance)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("Daily Limit", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surface) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("R${"%.2f".format(dailyAllowance * 0.5)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                Text("Food/Day", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surface) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("R${"%.2f".format(dailyAllowance * 0.3)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                                Text("Transport/Day", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { onAskAssistant("I have R${availableBalance.toInt()} until Friday, help me plan my daily budget") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ask AI to Plan Week's Budget")
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Payment Methods", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = { showGooglePayDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Provider")
                }
            }
        }

        items(paymentMethods) { pm ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (pm.type == "GOOGLE_PAY") Icons.Default.Payment else Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(pm.name, fontWeight = FontWeight.Bold)
                            Text("Tokenized ending in ****${pm.last4}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    if (pm.isDefault) {
                        SuggestionChip(onClick = {}, label = { Text("Default") })
                    }
                }
            }
        }

        item {
            Text("Recent Budget Transactions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(budgetItems.take(10)) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("${item.category} • ${item.date}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        text = (if (item.type == "Income") "+R" else "-R") + "%.2f".format(item.amount),
                        fontWeight = FontWeight.Bold,
                        color = if (item.type == "Income") Color(0xFF10B981) else MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }

    if (showGooglePayDialog) {
        AlertDialog(
            onDismissRequest = { showGooglePayDialog = false },
            title = { Text("Google Pay Integration Architecture") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Logic Loom is architected for tokenized Google Pay and Capitec API integration.")
                    Text("No raw card numbers or CVV credentials are stored locally on device.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                Button(onClick = { showGooglePayDialog = false }) { Text("Got It") }
            }
        )
    }
}
