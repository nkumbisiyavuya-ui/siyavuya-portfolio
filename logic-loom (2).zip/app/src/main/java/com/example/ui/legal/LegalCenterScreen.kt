package com.example.ui.legal

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.legal.model.LegalConsentState
import com.example.legal.model.LegalDocument
import com.example.legal.model.LegalDocumentType
import com.example.legal.repository.LegalDocumentRegistry
import com.example.ui.theme.LocalThemeData

/**
 * Main Legal, Privacy & Safety Center screen for Logic Loom designed and engineered by Moraigne.
 * Displays all versioned legal documents, consent status chips, legal contact, and legal review notices.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalCenterScreen(
    consentState: LegalConsentState,
    onNavigateBack: () -> Unit,
    onOpenDocument: (LegalDocumentType) -> Unit,
    modifier: Modifier = Modifier
) {
    val themeData = LocalThemeData.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Legal & Safety Center",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Moraigne • Platform Compliance v${LegalDocumentRegistry.CURRENT_LEGAL_VERSION}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier.testTag("legal_center_screen")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(themeData.secondaryBg),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Hero Banner
            item {
                LegalCenterHeroHeader(
                    consentState = consentState
                )
            }

            // Legal Review Notice Banner
            item {
                LegalReviewNoticeCard()
            }

            // Section Header
            item {
                Text(
                    text = "Official Governance & Legal Policies",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )
            }

            // List of all 7 Legal Documents
            items(
                items = LegalDocumentRegistry.allDocuments,
                key = { it.type.id }
            ) { document ->
                LegalDocumentCard(
                    document = document,
                    consentState = consentState,
                    onClick = { onOpenDocument(document.type) }
                )
            }

            // Legal Contact & Moraigne Entity Card
            item {
                LegalContactCard()
            }

            // Bottom space
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

/**
 * Top Header Banner summarizing legal compliance and user consent state.
 */
@Composable
private fun LegalCenterHeroHeader(
    consentState: LegalConsentState
) {
    val themeData = LocalThemeData.current

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = themeData.primary
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "MORAIGNE COMPLIANCE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                if (consentState.isFullyConsented) {
                    Surface(
                        color = Color(0xFF22C55E),
                        shape = CircleShape
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Fully Consented", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Logic Loom Legal & Safety Center",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Logic Loom is designed and engineered by Moraigne. Review terms, privacy policies, AI usage rules, and data rights.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.9f)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Divider(color = Color.White.copy(alpha = 0.2f))

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Effective: ${LegalDocumentRegistry.EFFECTIVE_DATE}",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )

                Text(
                    text = "Version ${LegalDocumentRegistry.CURRENT_LEGAL_VERSION}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * Prominent disclaimer notifying users that draft legal content is subject to final Moraigne legal review.
 */
@Composable
private fun LegalReviewNoticeCard() {
    Surface(
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Notice",
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "NOTICE & LEGAL REVIEW STATUS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.tertiary
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "These draft legal documents establish the operational boundaries of Logic Loom. All sections marked [LEGAL REVIEW REQUIRED] are subject to final review and approval by Moraigne legal counsel before publication.",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
        }
    }
}

/**
 * Interactive card displaying an individual Legal Document in the list.
 */
@Composable
private fun LegalDocumentCard(
    document: LegalDocument,
    consentState: LegalConsentState,
    onClick: () -> Unit
) {
    val themeData = LocalThemeData.current

    val icon: ImageVector = when (document.type) {
        LegalDocumentType.TERMS -> Icons.Default.Gavel
        LegalDocumentType.PRIVACY -> Icons.Default.PrivacyTip
        LegalDocumentType.AI_GUIDELINES -> Icons.Default.AutoAwesome
        LegalDocumentType.ACCEPTABLE_USE -> Icons.Default.Rule
        LegalDocumentType.USER_CONTENT -> Icons.Default.Description
        LegalDocumentType.ACCOUNT_DELETION -> Icons.Default.DeleteForever
        LegalDocumentType.LEGAL_CONTACT -> Icons.Default.Mail
    }

    val isAccepted = when (document.type) {
        LegalDocumentType.TERMS -> consentState.hasAcceptedTerms
        LegalDocumentType.PRIVACY -> consentState.hasAcknowledgedPrivacy
        LegalDocumentType.AI_GUIDELINES -> consentState.hasUnderstoodAiGuidelines
        else -> true
    }

    val acceptedTimestamp = when (document.type) {
        LegalDocumentType.TERMS -> consentState.termsAcceptedAt
        LegalDocumentType.PRIVACY -> consentState.privacyAcceptedAt
        LegalDocumentType.AI_GUIDELINES -> consentState.aiGuidelinesAcceptedAt
        else -> ""
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = themeData.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border.copy(alpha = 0.7f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("legal_doc_card_${document.type.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Document Icon
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        if (isAccepted) themeData.lightAccent else MaterialTheme.colorScheme.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isAccepted) themeData.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Document Details
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = document.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        ),
                        color = themeData.mainText
                    )

                    // Version tag
                    Surface(
                        color = themeData.secondaryBg,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, themeData.border)
                    ) {
                        Text(
                            text = "v${document.version}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = themeData.secondaryText,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = document.summary,
                    style = MaterialTheme.typography.bodySmall,
                    color = themeData.secondaryText,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Status Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (document.type.isConsentRequired) {
                        if (isAccepted) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Accepted",
                                tint = Color(0xFF16A34A),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Accepted v${document.version}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF16A34A)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Action Required",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Action Required • Review & Accept",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Informational Policy",
                            tint = themeData.mutedText,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Informational Governance Policy",
                            fontSize = 11.sp,
                            color = themeData.mutedText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open Document",
                tint = themeData.mutedText,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * Official contact details card for Moraigne Legal & Compliance.
 */
@Composable
private fun LegalContactCard() {
    val themeData = LocalThemeData.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = themeData.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border.copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = themeData.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Legal & Regulatory Contact",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = themeData.mainText
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Logic Loom is designed and engineered by Moraigne. For regulatory disclosures, copyright notices, or legal inquiries:",
                style = MaterialTheme.typography.bodySmall,
                color = themeData.secondaryText
            )

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                color = themeData.secondaryBg,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Moraigne Legal & Compliance Team",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = themeData.mainText
                    )
                    Text(
                        text = "Email: ${LegalDocumentRegistry.SUPPORT_EMAIL}",
                        style = MaterialTheme.typography.bodySmall,
                        color = themeData.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Attribution: Developed and engineered by Moraigne",
                        style = MaterialTheme.typography.bodySmall,
                        color = themeData.mutedText
                    )
                }
            }
        }
    }
}
