package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ShuttleSchedule
import com.example.ui.CanvasMateViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShuttleScheduleScreen(
    viewModel: CanvasMateViewModel
) {
    val shuttles by viewModel.shuttleSchedules.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedDayFilter by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }

    val dayFilters = listOf("All", "Mon - Fri", "Saturday", "Sunday & Holidays")

    val filteredShuttles = shuttles.filter { shuttle ->
        val matchesDay = if (selectedDayFilter == "All") true else shuttle.daysOfWeek.contains(selectedDayFilter, ignoreCase = true)
        val matchesSearch = shuttle.routeName.contains(searchQuery, ignoreCase = true) ||
                shuttle.stopLocation.contains(searchQuery, ignoreCase = true)
        matchesDay && matchesSearch
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.DirectionsBus, contentDescription = "Add Shuttle Schedule")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Shuttle Schedules", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Campus Transit Timetables & Custom Routes", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                FilledTonalButton(
                    onClick = { showAddDialog = true },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Route", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search routes or bus stops (e.g., Tugwell, North Stop)...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Day Filter Tabs
            ScrollableTabRow(
                selectedTabIndex = dayFilters.indexOf(selectedDayFilter).coerceAtLeast(0),
                divider = {}
            ) {
                dayFilters.forEach { filter ->
                    FilterChip(
                        selected = selectedDayFilter == filter,
                        onClick = { selectedDayFilter = filter },
                        label = { Text(filter) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredShuttles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.DirectionsBus, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No shuttle schedules found.", fontWeight = FontWeight.Bold)
                        Text("Add your own shuttle timetable and departure times!", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { showAddDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add My Shuttle Schedule")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredShuttles, key = { it.id }) { shuttle ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primaryContainer),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.DirectionsBus, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(shuttle.routeName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                            Text("🏣 ${shuttle.stopLocation}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }

                                    IconButton(onClick = { viewModel.deleteShuttleSchedule(shuttle.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                                            Text("⏰ ${shuttle.departureTime} - ${shuttle.arrivalTime}", color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold)
                                        }
                                        Badge(containerColor = MaterialTheme.colorScheme.tertiaryContainer) {
                                            Text("🔄 Every ${shuttle.frequencyMinutes} mins", color = MaterialTheme.colorScheme.onTertiaryContainer)
                                        }
                                    }

                                    Text(shuttle.daysOfWeek, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }

                                if (shuttle.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("ℹ️ ${shuttle.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedButton(
                                    onClick = {
                                        viewModel.triggerScheduleNotification(
                                            title = "Shuttle Reminder Set",
                                            message = "${shuttle.routeName} departs at ${shuttle.departureTime} from ${shuttle.stopLocation}"
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Set Departure Alert Reminder", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddShuttleScheduleDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newShuttle ->
                viewModel.addShuttleSchedule(newShuttle)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddShuttleScheduleDialog(
    onDismiss: () -> Unit,
    onConfirm: (ShuttleSchedule) -> Unit
) {
    var routeName by remember { mutableStateOf("") }
    var stopLocation by remember { mutableStateOf("") }
    var departureTime by remember { mutableStateOf("07:30") }
    var arrivalTime by remember { mutableStateOf("07:45") }
    var daysOfWeek by remember { mutableStateOf("Mon - Fri") }
    var frequencyMinutes by remember { mutableStateOf("15") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Custom Shuttle Schedule") },
        text = {
            Column {
                OutlinedTextField(value = routeName, onValueChange = { routeName = it }, label = { Text("Route Name (e.g. Jammie Express North)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = stopLocation, onValueChange = { stopLocation = it }, label = { Text("Bus Stop Location (e.g. Tugwell Stop)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    OutlinedTextField(value = departureTime, onValueChange = { departureTime = it }, label = { Text("Departure Time") }, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(value = arrivalTime, onValueChange = { arrivalTime = it }, label = { Text("Arrival Time") }, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    OutlinedTextField(value = daysOfWeek, onValueChange = { daysOfWeek = it }, label = { Text("Days (e.g. Mon - Fri)") }, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(value = frequencyMinutes, onValueChange = { frequencyMinutes = it }, label = { Text("Frequency (mins)") }, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes (e.g. Runs peak hours)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (routeName.isNotBlank()) {
                        val freq = frequencyMinutes.toIntOrNull() ?: 15
                        onConfirm(
                            ShuttleSchedule(
                                routeName = routeName,
                                stopLocation = if (stopLocation.isBlank()) "Main Bus Stop" else stopLocation,
                                departureTime = departureTime,
                                arrivalTime = arrivalTime,
                                daysOfWeek = daysOfWeek,
                                frequencyMinutes = freq,
                                notes = notes
                            )
                        )
                    }
                }
            ) {
                Text("Save Schedule")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
