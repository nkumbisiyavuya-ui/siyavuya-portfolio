package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GoalItem
import com.example.data.local.GpaModule
import com.example.ui.CanvasMateViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalTrackerScreen(
    goals: List<GoalItem>,
    onAddGoal: (GoalItem) -> Unit,
    onUpdateGoal: (GoalItem) -> Unit,
    onDeleteGoal: (Long) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }

    val categories = listOf("All", "Academic", "Financial", "Health", "Personal", "Career")

    val filteredGoals = goals.filter { goal ->
        if (selectedCategory == "All") true else goal.category == selectedCategory
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Goal")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("Goal Tracker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Academic, Financial, Health, Personal & Career Goals", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                divider = {}
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredGoals.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No goals found in this category.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredGoals, key = { it.id }) { goal ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(goal.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text("Category: ${goal.category} • Target: ${goal.targetDate}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    IconButton(onClick = { onDeleteGoal(goal.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Progress: ${goal.progress}%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Slider(
                                        value = goal.progress.toFloat(),
                                        onValueChange = { onUpdateGoal(goal.copy(progress = it.toInt())) },
                                        valueRange = 0f..100f,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                if (goal.milestonesJson.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Milestones:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    goal.milestonesJson.split("|").forEach { m ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(m, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddGoalDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { goal ->
                onAddGoal(goal)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddGoalDialog(
    onDismiss: () -> Unit,
    onConfirm: (GoalItem) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Academic") }
    var targetDate by remember { mutableStateOf("2026-11-30") }
    var milestones by remember { mutableStateOf("Milestone 1|Milestone 2|Final Goal") }

    val categories = listOf("Academic", "Financial", "Health", "Personal", "Career")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Goal") },
        text = {
            Column {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Goal Title") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = targetDate, onValueChange = { targetDate = it }, label = { Text("Deadline (2026)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                Text("Category", style = MaterialTheme.typography.labelSmall)
                ScrollableTabRow(selectedTabIndex = categories.indexOf(category).coerceAtLeast(0), divider = {}) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = milestones, onValueChange = { milestones = it }, label = { Text("Milestones (separated by |)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(GoalItem(title = title, category = category, targetDate = targetDate, milestonesJson = milestones))
                    }
                }
            ) {
                Text("Add Goal")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun StudyTimerScreen(
    viewModel: CanvasMateViewModel
) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val minutes by viewModel.pomodoroMinutes.collectAsState()
    val timeLeftSec by viewModel.pomodoroTimeLeftSec.collectAsState()
    val isRunning by viewModel.isPomodoroRunning.collectAsState()
    val streak by viewModel.pomodoroStreak.collectAsState()
    val totalHours by viewModel.totalStudyHours.collectAsState()
    val isAutoMute by viewModel.isAutoMuteNotificationsOnPomodoro.collectAsState()
    val mutedCount by viewModel.mutedNotificationCountDuringSession.collectAsState()

    val formattedTime = remember(timeLeftSec) {
        val mins = timeLeftSec / 60
        val secs = timeLeftSec % 60
        "%02d:%02d".format(mins, secs)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Pomodoro Study Timer", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Boost Focus & Build Daily Study Habits", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(16.dp))

        // DND Notification Auto-Mute Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isRunning && isAutoMute) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isRunning && isAutoMute) Icons.Default.NotificationsOff else Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = if (isRunning && isAutoMute) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isRunning && isAutoMute) "🔕 Do Not Disturb Active" else "🔔 Auto-Disable Notifications",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = if (isRunning && isAutoMute) {
                                if (mutedCount > 0) "$mutedCount distracting alert(s) silenced"
                                else "Notifications are muted during active session"
                            } else {
                                "Mute distracting alerts during Pomodoro"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Switch(
                    checked = isAutoMute,
                    onCheckedChange = { viewModel.toggleAutoMuteNotificationsOnPomodoro(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Timer Preset Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            FilterChip(
                selected = minutes == 25,
                onClick = { viewModel.setPomodoroDuration(25) },
                label = { Text("25 Min Focus") }
            )
            FilterChip(
                selected = minutes == 50,
                onClick = { viewModel.setPomodoroDuration(50) },
                label = { Text("50 Min Deep Work") }
            )
            FilterChip(
                selected = minutes == 5,
                onClick = { viewModel.setPomodoroDuration(5) },
                label = { Text("5 Min Break") }
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Timer Circle Display
        Box(
            modifier = Modifier
                .size(240.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = formattedTime,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (isRunning) "STUDYING..." else "PAUSED",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Start / Pause & Reset Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = {
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                    viewModel.startPausePomodoro()
                },
                modifier = Modifier
                    .width(160.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isRunning) "Pause" else "Start", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(16.dp))

            OutlinedButton(
                onClick = {
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                    viewModel.resetPomodoro()
                },
                modifier = Modifier
                    .width(120.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reset")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Statistics Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Card(
                modifier = Modifier.weight(1f).padding(end = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("$streak Sessions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Study Streak", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Card(
                modifier = Modifier.weight(1f).padding(start = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("%.1f Hours".format(totalHours), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Total Focus Time", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GpaCalculatorScreen(
    viewModel: CanvasMateViewModel? = null,
    modules: List<GpaModule>,
    onAddModule: (GpaModule) -> Unit,
    onDeleteModule: (Long) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedScaleMode by remember { mutableStateOf("Percentage (%)") } // "Percentage (%)", "4.0 Scale", "5.0 Scale"
    var targetGpaInput by remember { mutableStateOf("75") }

    val gpaThresholdState = viewModel?.gpaAlertThreshold?.collectAsState()
    val gpaThreshold = gpaThresholdState?.value ?: 60.0
    val gpaAlertsEnabledState = viewModel?.gpaAlertsEnabled?.collectAsState()
    val gpaAlertsEnabled = gpaAlertsEnabledState?.value ?: true

    val totalCredits = modules.sumOf { it.credits }
    val weightedMarks = modules.sumOf { it.mark * it.credits }
    val cumulativeAverage = if (totalCredits > 0) weightedMarks / totalCredits else 0.0

    // Converted scale values
    val gpa4Scale = (cumulativeAverage / 100.0) * 4.0
    val gpa5Scale = (cumulativeAverage / 100.0) * 5.0

    val primaryDisplayValue = when (selectedScaleMode) {
        "4.0 Scale" -> "%.2f / 4.00".format(gpa4Scale)
        "5.0 Scale" -> "%.2f / 5.00".format(gpa5Scale)
        else -> "%.1f%%".format(cumulativeAverage)
    }

    val progressFraction = (cumulativeAverage / 100.0).toFloat().coerceIn(0f, 1f)

    // Academic Standing Grade & Color
    val (academicStanding, statusColor, standingEmoji) = when {
        cumulativeAverage >= 75.0 -> Triple("First Class Honours (1st)", Color(0xFF10B981), "🌟")
        cumulativeAverage >= 70.0 -> Triple("Upper Second Class (2A)", Color(0xFF3B82F6), "👍")
        cumulativeAverage >= 60.0 -> Triple("Lower Second Class (2B)", Color(0xFFF59E0B), "📈")
        cumulativeAverage >= 50.0 -> Triple("Pass (3rd Class)", Color(0xFF8B5CF6), "🎯")
        cumulativeAverage > 0.0 -> Triple("Fail / Academic Warning", Color(0xFFEF4444), "⚠️")
        else -> Triple("No Grades Recorded", MaterialTheme.colorScheme.onSurfaceVariant, "📊")
    }

    // Target GPA Simulator logic
    val targetVal = targetGpaInput.toDoubleOrNull() ?: 75.0
    val requiredAvgForNextCredits = remember(targetVal, totalCredits, cumulativeAverage) {
        val futureCredits = 36 // hypothetical next semester credits
        if (totalCredits == 0) targetVal
        else {
            val currentPoints = cumulativeAverage * totalCredits
            val totalFuturePoints = targetVal * (totalCredits + futureCredits)
            val neededPoints = totalFuturePoints - currentPoints
            (neededPoints / futureCredits).coerceIn(0.0, 100.0)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Module Grade")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Cumulative GPA Calculator", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Weighted Grade Point Average, Visual Progress & Academic Standing Alert System", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            // Grading System Mode Selector Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Percentage (%)", "4.0 Scale", "5.0 Scale").forEach { scale ->
                    FilterChip(
                        selected = selectedScaleMode == scale,
                        onClick = { selectedScaleMode = scale },
                        label = { Text(scale, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Visual GPA Card with Progress Bar
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Cumulative Academic Standing", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = statusColor.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "$standingEmoji $academicStanding",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = primaryDisplayValue,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Visual Progress Bar for Academic Standing
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Overall Progress", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                            Text("${(progressFraction * 100).toInt()}% of 100%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            color = statusColor,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Total Modules", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${modules.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.outlineVariant)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Total Credits", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("$totalCredits", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.outlineVariant)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("4.0 Equivalent", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("%.2f".format(gpa4Scale), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Active Alert Warning Banner if Cumulative GPA is below threshold
            if (gpaAlertsEnabled && totalCredits > 0 && cumulativeAverage < gpaThreshold) {
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("🚨 GPA Alert: Below Target Threshold", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Your cumulative average of %.1f%% is below your set warning threshold of %.1f%%. Review course subjects or generate an AI study plan.".format(cumulativeAverage, gpaThreshold),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // GPA Notification & Threshold Settings Card
            if (viewModel != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("GPA Alert Threshold System", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Switch(
                                checked = gpaAlertsEnabled,
                                onCheckedChange = { viewModel.toggleGpaAlerts(it) }
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Automatically triggers system alerts when grade updates cause your cumulative GPA to drop below your designated safety threshold.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (gpaAlertsEnabled) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Alert Threshold level:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(50.0, 60.0, 65.0, 70.0, 75.0).forEach { thresh ->
                                    FilterChip(
                                        selected = gpaThreshold == thresh,
                                        onClick = { viewModel.setGpaAlertThreshold(thresh) },
                                        label = { Text("${thresh.toInt()}%") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Target GPA Planner & Simulator Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Target GPA Goal Simulator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Estimate what average mark you need in your next 36 credits to reach your dream academic standing target.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedTextField(
                            value = targetGpaInput,
                            onValueChange = { targetGpaInput = it },
                            label = { Text("Target Goal %") },
                            modifier = Modifier.width(140.dp),
                            singleLine = true
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Required Next Avg:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "%.1f%%".format(requiredAvgForNextCredits),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (requiredAvgForNextCredits <= 100.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Course Modules List Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Enrolled Course Modules (${modules.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Module")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (modules.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No course modules added yet", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text("Tap 'Add Module' or + to record subject credits & marks.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                modules.forEach { mod ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = mod.moduleCode.take(2).uppercase(),
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(mod.moduleCode, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text("${mod.credits} Credits • Weighted: %.1f points".format(mod.mark * mod.credits), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (mod.mark >= 75) Color(0xFF10B981).copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = "%.1f%%".format(mod.mark),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        fontWeight = FontWeight.ExtraBold,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = if (mod.mark >= 75) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { onDeleteModule(mod.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddGpaModuleDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { mod ->
                onAddModule(mod)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddGpaModuleDialog(
    onDismiss: () -> Unit,
    onConfirm: (GpaModule) -> Unit
) {
    var moduleCode by remember { mutableStateOf("") }
    var creditsText by remember { mutableStateOf("18") }
    var markText by remember { mutableStateOf("75") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Course Module Grade") },
        text = {
            Column {
                OutlinedTextField(value = moduleCode, onValueChange = { moduleCode = it }, label = { Text("Module Code (e.g. CSC3002F)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = creditsText, onValueChange = { creditsText = it }, label = { Text("Credits (e.g. 18)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = markText, onValueChange = { markText = it }, label = { Text("Mark Percentage (e.g. 78)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val credits = creditsText.toIntOrNull() ?: 18
                    val mark = markText.toDoubleOrNull() ?: 75.0
                    if (moduleCode.isNotBlank()) {
                        onConfirm(GpaModule(moduleCode = moduleCode, credits = credits, mark = mark))
                    }
                }
            ) {
                Text("Add Grade")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
