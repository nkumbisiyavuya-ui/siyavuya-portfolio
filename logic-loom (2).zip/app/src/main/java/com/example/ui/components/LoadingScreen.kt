package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.*
import com.example.R

/**
 * Reusable loading screen and indicator component for database transactions,
 * API requests, AI generation, background syncs, or initial data loading.
 */
@Composable
fun LoadingScreen(
    modifier: Modifier = Modifier,
    message: String = "Loading...",
    fullScreen: Boolean = true,
    isAiLoading: Boolean = false
) {
    val isAiMode = isAiLoading || message.contains("AI", ignoreCase = true) || message.contains("thinking", ignoreCase = true) || message.contains("generating", ignoreCase = true)

    if (fullScreen) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .testTag("loading_screen"),
            contentAlignment = Alignment.Center
        ) {
            if (isAiMode) {
                AiOrbLoadingCard(
                    title = "Chuma AI",
                    subtitle = message,
                    modifier = Modifier.padding(24.dp)
                )
            } else {
                LoadingCard(message = message)
            }
        }
    } else {
        Box(
            modifier = modifier
                .padding(16.dp)
                .testTag("loading_screen"),
            contentAlignment = Alignment.Center
        ) {
            if (isAiMode) {
                AiResponseLoadingIndicator(
                    statusText = message,
                    showThoughtStages = true
                )
            } else {
                LoadingCard(message = message)
            }
        }
    }
}

@Composable
private fun LoadingCard(
    message: String
) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.ai_loading_lottie))
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        speed = 1.0f
    )

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
        tonalElevation = 6.dp,
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 32.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (composition != null) {
                LottieAnimation(
                    composition = composition,
                    progress = { progress },
                    modifier = Modifier
                        .size(64.dp)
                        .testTag("loading_indicator")
                )
            } else {
                CircularProgressIndicator(
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("loading_indicator"),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 4.dp
                )
            }
            
            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("loading_message")
                )
            }
        }
    }
}
