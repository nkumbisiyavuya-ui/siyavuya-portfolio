package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CanvasMateViewModel
import com.example.ui.components.ChumaTaskExecutionCard
import com.example.ui.components.StudyQuestionsGeneratorDialog
import com.example.ui.components.StudyQuestionsInteractiveQuizDialog
import com.example.ui.components.StudyQuestionsQuizCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    viewModel: CanvasMateViewModel,
    onNavigateToVoiceMode: () -> Unit = {}
) {
    val messages by viewModel.aiMessages.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    val chumaTaskState by viewModel.activeChumaTaskState.collectAsState()

    val academicTasks by viewModel.academicTasks.collectAsState()
    val calendarEvents by viewModel.calendarEvents.collectAsState()
    val gpaModules by viewModel.gpaModules.collectAsState()
    val notes by viewModel.notes.collectAsState()

    val activeStudyQuiz by viewModel.activeStudyQuiz.collectAsState()
    val isGeneratingStudyQuestions by viewModel.isGeneratingStudyQuestions.collectAsState()
    val presetNoteForStudyQuestions by viewModel.presetNoteForStudyQuestions.collectAsState()
    val showStudyQuestionsDialog by viewModel.showStudyQuestionsGeneratorDialog.collectAsState()
    val showInteractiveQuizDialog by viewModel.showInteractiveQuizDialog.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showStudyPlanSheet by remember { mutableStateOf(false) }
    var showNotificationManagementDialog by remember { mutableStateOf(false) }
    var showPayloadInspectorDialog by remember { mutableStateOf(false) }
    var selectedSourceMode by remember { mutableStateOf("multi_source") } // multi_source, scholar, wikipedia, youtube, facebook

    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current

    // Safely auto-scroll to latest message whenever messages list or loading state updates
    LaunchedEffect(messages.size, isLoading) {
        val totalCount = messages.size + if (isLoading) 1 else 0
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    val context = androidx.compose.ui.platform.LocalContext.current
    val voiceInputManager = remember { com.example.data.voice.VoiceInputManager(context) }
    val voiceState by voiceInputManager.voiceState.collectAsState()

    val micPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            voiceInputManager.startListening { spoken ->
                inputText = spoken
            }
        } else {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Microphone permission required for voice search.")
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceInputManager.stopListening()
        }
    }

    val quickPrompts = listOf(
        "🧠 What's Next?",
        "🚆 Train fare Cape Town to Bellville",
        "🌤️ What's the weather & what should I wear?",
        "📍 Find nearest library",
        "🎓 Calculate required exam mark",
        "💰 I have R400 left until Friday",
        "📚 Where is my next class?",
        "📄 Find my Economics assignment PDF",
        "🚕 Plan transport to campus",
        "🍔 Food under R100",
        "⏰ Remind me to study Economics at 7",
        "📅 Create Personalized Study Plan",
        "💻 Explain Big-O & Data Structures",
        "📈 Explain Elasticity in Economics"
    )


    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Multi-Source Research Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.TravelExplore,
                            contentDescription = "Research Grounding",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "✨ Chuma AI",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = "General-purpose AI assistant • Clear, direct, intelligent & comprehensive",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                            )
                        }
                        IconButton(
                            onClick = onNavigateToVoiceMode,
                            modifier = Modifier
                                .testTag("open_voice_mode_header_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Chuma Voice Mode",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = { showPayloadInspectorDialog = true },
                            modifier = Modifier.testTag("inspect_payload_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.BugReport,
                                contentDescription = "Inspect Payload",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Source Mode Badges
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedSourceMode == "multi_source",
                            onClick = { selectedSourceMode = "multi_source" },
                            label = { Text("🌐 All Sources", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            leadingIcon = if (selectedSourceMode == "multi_source") { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "google_search",
                            onClick = { selectedSourceMode = "google_search" },
                            label = { Text("🔍 Live Google Search & Citations", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            leadingIcon = if (selectedSourceMode == "google_search") { { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "complex_problem",
                            onClick = { selectedSourceMode = "complex_problem" },
                            label = { Text("🧠 Gemini Deep Reasoning", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            leadingIcon = if (selectedSourceMode == "complex_problem") { { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "veo_video",
                            onClick = { selectedSourceMode = "veo_video" },
                            label = { Text("🎬 Veo 3 Video Creator", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            leadingIcon = if (selectedSourceMode == "veo_video") { { Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "scholar",
                            onClick = { selectedSourceMode = "scholar" },
                            label = { Text("🎓 Google Scholar", fontSize = 11.sp) },
                            leadingIcon = if (selectedSourceMode == "scholar") { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "wikipedia",
                            onClick = { selectedSourceMode = "wikipedia" },
                            label = { Text("📚 Wikipedia", fontSize = 11.sp) },
                            leadingIcon = if (selectedSourceMode == "wikipedia") { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "youtube",
                            onClick = { selectedSourceMode = "youtube" },
                            label = { Text("📺 YouTube Lectures", fontSize = 11.sp) },
                            leadingIcon = if (selectedSourceMode == "youtube") { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                        FilterChip(
                            selected = selectedSourceMode == "facebook",
                            onClick = { selectedSourceMode = "facebook" },
                            label = { Text("👥 Facebook Groups", fontSize = 11.sp) },
                            leadingIcon = if (selectedSourceMode == "facebook") { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Persistent Chuma AI Task Execution Card (DataStore Preserved)
            ChumaTaskExecutionCard(
                taskState = chumaTaskState,
                onResume = { viewModel.resumeInterruptedChumaTask() },
                onCancel = { viewModel.cancelAiGeneration() },
                onClear = { viewModel.clearActiveChumaTask() },
                modifier = Modifier.padding(bottom = 10.dp)
            )

            // AI Study Suite: Note Questions Generator & Study Plan Generator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Targeted Study Questions from Notes
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.openStudyQuestionsGenerator() }
                        .testTag("study_questions_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.secondary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Quiz, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(14.dp))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "🎯 Note Questions",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "Test understanding from your notes.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Personalized Study Plan Generator
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showStudyPlanSheet = true }
                        .testTag("study_plan_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "✨ Study Plan",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Smart schedules & deadlines.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Suggestion Chips
            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                AssistChip(
                    onClick = { viewModel.openStudyQuestionsGenerator() },
                    label = { Text("🎯 Note-to-Quiz Generator", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.secondary) },
                    modifier = Modifier.padding(end = 6.dp)
                )

                quickPrompts.forEach { prompt ->
                    SuggestionChip(
                        onClick = {
                            if (prompt.contains("Study Plan", ignoreCase = true)) {
                                showStudyPlanSheet = true
                            } else if (prompt.contains("Reminders", ignoreCase = true)) {
                                showNotificationManagementDialog = true
                            } else {
                                val taskType = when {
                                    prompt.contains("Calculus", ignoreCase = true) || prompt.contains("Big-O", ignoreCase = true) || prompt.contains("Newton", ignoreCase = true) || prompt.contains("APA", ignoreCase = true) || prompt.contains("Economics", ignoreCase = true) -> "academic"
                                    prompt.contains("Research", ignoreCase = true) || prompt.contains("Scholar", ignoreCase = true) || prompt.contains("Wiki", ignoreCase = true) -> "research"
                                    else -> "general"
                                }
                                viewModel.sendAiPrompt(prompt, taskType = taskType)
                            }
                        },
                        label = { Text(prompt, fontSize = 11.sp) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Chat Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                com.example.ui.components.CanvasMate3DIcon(
                                    size = 56.dp,
                                    aiState = com.example.ui.components.CanvasMateAiState.IDLE
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Welcome to Chuma AI",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Your grounded intelligence assistant for university studies, mathematics, writing, and daily planning.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    AssistChip(
                                        onClick = { viewModel.sendAiPrompt("Explain photosynthesis simply.") },
                                        label = { Text("🌿 Photosynthesis", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                    AssistChip(
                                        onClick = { viewModel.sendAiPrompt("What is 15 * 24?") },
                                        label = { Text("🔢 15 × 24", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                items(messages) { (sender, text) ->
                    val isUser = sender == "User"
                    val isStudyPlan = !isUser && (
                        text.contains("Personalized Study Plan", ignoreCase = true) ||
                        text.contains("Actionable Study Tasks", ignoreCase = true) ||
                        text.contains("Suggested Module Study Sessions", ignoreCase = true)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            modifier = Modifier.widthIn(max = 340.dp),
                            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                        ) {
                            Surface(
                                color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 2.dp,
                                    bottomEnd = if (isUser) 2.dp else 16.dp
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (isUser) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = com.example.ui.theme.CanvasMateWhite,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        } else {
                                            com.example.ui.components.CanvasMate3DIcon(
                                                size = 22.dp,
                                                aiState = com.example.ui.components.CanvasMateAiState.RESPONDING,
                                                showGlow = false
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isUser) "You" else "Chuma AI",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isUser) com.example.ui.theme.CanvasMateCoolGray else com.example.ui.theme.CanvasMateWhite
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Clean display text by stripping raw card tags
                                    val cleanText = text
                                        .replace(Regex("\\[CARD_[A-Z_]+:[^\\]]+\\]"), "")
                                        .trim()

                                    Text(
                                        text = cleanText,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                                    )

                                    // Interactive Smart Cards & Actions for Chuma AI
                                    if (!isUser) {
                                        if (text.contains("[CARD_ALARM:")) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text("⏰ Alarm Set", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                        Text("Triggered via Android Clock app.", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                            }
                                        }

                                        if (text.contains("[CARD_NAV:")) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text("🚀 Navigation Action", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                        Text("Opened requested screen.", style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                            }
                                        }
                                    if (text.contains("[CARD_ACADEMIC:")) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("🎓 Academic Target Lock", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                    Text("Calculation recorded in Logic Loom Academic Engine.", style = MaterialTheme.typography.labelSmall)
                                                }
                                                Button(
                                                    onClick = {
                                                        showStudyPlanSheet = true
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Plan Study", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }

                                    if (text.contains("[CARD_LOCATION:")) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("📍 Location Grounded", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                    Text("Campus place verified.", style = MaterialTheme.typography.labelSmall)
                                                }
                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            snackbarHostState.showSnackbar("🗺️ Opening Campus Directions for Location...")
                                                        }
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Directions", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }

                                    if (text.contains("[CARD_WEATHER:")) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.WbSunny, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("🌤️ Weather & Clothing Advice", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                    Text("Tailored to your campus timetable & commute.", style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                        }
                                    }

                                    if (text.contains("[CARD_BUDGET:")) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("💰 ZAR Financial Reasoning", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                                    Text("Daily allowance calculated after transport.", style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                        }
                                    }

                                    // Direct Action Buttons for AI Generated Study Plans
                                    if (isStudyPlan || text.contains("[CARD_STUDY_PLAN:")) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                        Spacer(modifier = Modifier.height(10.dp))

                                        Text(
                                            text = "⚡ Import Plan directly into Logic Loom:",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Button(
                                                onClick = {
                                                    val count = viewModel.importStudyPlanToCalendar(text)
                                                    coroutineScope.launch {
                                                        snackbarHostState.showSnackbar("✓ Added $count study sessions to your Calendar!")
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("Calendar", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    val count = viewModel.importStudyPlanToTodoList(text)
                                                    coroutineScope.launch {
                                                        snackbarHostState.showSnackbar("✓ Added $count study tasks to To-Do List!")
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Checklist, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("To-Do", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    viewModel.importStudyPlanToNotes(text)
                                                    coroutineScope.launch {
                                                        snackbarHostState.showSnackbar("✓ Saved study plan to Notes!")
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("Notes", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = {
                                                    val count = viewModel.importStudyPlanReminders(text)
                                                    showNotificationManagementDialog = true
                                                    coroutineScope.launch {
                                                        snackbarHostState.showSnackbar("✓ Created $count study session reminders!")
                                                    }
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                                            ) {
                                                Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text("Reminders", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    // Direct Interactive Card for Generated Study Questions Quiz
                                    if (text.contains("Targeted Study Questions") || text.contains("[CARD_STUDY_QUIZ:") || text.contains("Study Quiz") || text.contains("Target Concept:")) {
                                        val currentQuiz = activeStudyQuiz
                                        if (currentQuiz != null) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            StudyQuestionsQuizCard(
                                                quiz = currentQuiz,
                                                onOpenInteractiveQuiz = { viewModel.openInteractiveQuiz() },
                                                onExportToFlashcards = { viewModel.exportQuizToFlashcards(currentQuiz) },
                                                onExportToNotes = { viewModel.exportQuizToNotes(currentQuiz) }
                                            )
                                        }
                                    }
                                }

                                if (!isUser) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(cleanText))
                                                coroutineScope.launch {
                                                    snackbarHostState.showSnackbar("Copied response to clipboard")
                                                }
                                            },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = "Copy response",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = {
                                                viewModel.retryLastAiPrompt()
                                            },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = "Retry prompt",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (!isUser) {
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Chuma AI can make mistakes. Please double-check important information.",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.padding(start = 4.dp, top = 2.dp, bottom = 4.dp)
                            )
                        }
                    }
                }
            }

                if (isLoading) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            com.example.ui.components.AiResponseLoadingIndicator(
                                statusText = "Chuma AI is thinking…",
                                showThoughtStages = true
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = { viewModel.cancelAiGeneration() },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = "Stop", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Stop Generation", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Text Input Field & Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = if (voiceState is com.example.data.voice.VoiceSearchState.Listening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("📎 Select document or PDF to analyze in Logic Loom Vault...")
                        }
                    },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(Icons.Default.AttachFile, contentDescription = "Attach File", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                IconButton(
                    onClick = {
                        inputText = "What's near my campus location right now?"
                    },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Location Grounding", tint = MaterialTheme.colorScheme.tertiary)
                }

                Spacer(modifier = Modifier.width(4.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Ask Chuma AI anything...", fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    shape = RoundedCornerShape(24.dp)
                )

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = onNavigateToVoiceMode,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .testTag("chat_voice_mode_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Chuma Voice Mode",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            val lower = inputText.lowercase()
                            val type = when {
                                lower.contains("study plan") || lower.contains("timetable") -> "study_plan"
                                selectedSourceMode != "multi_source" -> selectedSourceMode
                                lower.contains("math") || lower.contains("calculus") || lower.contains("physics") || lower.contains("chemistry") || lower.contains("biology") || lower.contains("economics") || lower.contains("formula") || lower.contains("algorithm") || lower.contains("proof") || lower.contains("essay") || lower.contains("thesis") || lower.contains("derivative") || lower.contains("integral") -> "academic"
                                else -> selectedSourceMode
                            }
                            viewModel.sendAiPrompt(inputText, taskType = type)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .testTag("chat_send_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        }
    }

    if (showNotificationManagementDialog) {
        NotificationManagementDialog(
            viewModel = viewModel,
            onDismiss = { showNotificationManagementDialog = false }
        )
    }

    // Modal Bottom Sheet for Personalized Study Plan Generator
    if (showStudyPlanSheet) {
        ModalBottomSheet(
            onDismissRequest = { showStudyPlanSheet = false }
        ) {
            var coursesText by remember { mutableStateOf("CSC3002F, MTH3012S, EEE3096S") }
            var deadlinesText by remember { mutableStateOf("CSC3002F Project due 12 Aug, MTH3012S Assignment due 15 Aug") }
            var examDatesText by remember { mutableStateOf("CSC3002F Final Exam on 22 Aug, MTH3012S Exam on 26 Aug") }

            var morningSelected by remember { mutableStateOf(true) }
            var afternoonSelected by remember { mutableStateOf(false) }
            var eveningSelected by remember { mutableStateOf(true) }
            var weekendSelected by remember { mutableStateOf(true) }

            var selectedScheduleType by remember { mutableStateOf("7-Day Weekly Master Plan") }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Build Personalized Study Plan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Text("Provide your study details to generate a prioritized, actionable schedule.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(16.dp))

                // Smart Plan Templates
                Text("Smart Plan Templates", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    FilterChip(
                        selected = false,
                        onClick = {
                            coursesText = "CSC3002F, MTH3012S"
                            deadlinesText = "CSC3002F Assignment 4 due tomorrow"
                            examDatesText = "CSC3002F Final Exam in 5 days"
                            morningSelected = true
                            eveningSelected = true
                        },
                        label = { Text("⚡ Exam Sprint Blitz") },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            coursesText = "CSC3002F, MTH3012S, EEE3096S"
                            deadlinesText = "Weekly Labs and Tutorial Problem Sets"
                            examDatesText = "Midterm Tests in 3 weeks"
                            afternoonSelected = true
                            weekendSelected = true
                        },
                        label = { Text("⚖️ Balanced Semester") },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            coursesText = "CSC3002F Capstone Project"
                            deadlinesText = "Final Architecture & Demo Submission due 15 Aug"
                            examDatesText = "System Oral Defense on 20 Aug"
                            eveningSelected = true
                            weekendSelected = true
                        },
                        label = { Text("🚀 Thesis & Project Blitz") },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            coursesText = "CSC3002F, Commerce Elective"
                            deadlinesText = "Part-Time Work (15h/wk) + Study Tasks"
                            examDatesText = "Final Exams end August"
                            morningSelected = true
                            weekendSelected = true
                        },
                        label = { Text("🚌 Work-Study & Commute") }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Current Courses
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("1. Current Courses / Modules", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    TextButton(
                        onClick = {
                            val modules = (academicTasks.map { it.module } + gpaModules.map { it.moduleCode }).distinct().filter { it.isNotBlank() }
                            if (modules.isNotEmpty()) coursesText = modules.joinToString(", ")
                        }
                    ) {
                        Text("⚡ Pull Enrolled", fontSize = 11.sp)
                    }
                }
                OutlinedTextField(
                    value = coursesText,
                    onValueChange = { coursesText = it },
                    placeholder = { Text("e.g. CSC3002F, MTH3012S, EEE3096S") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Assignment Deadlines
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("2. Assignment & Project Deadlines", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    TextButton(
                        onClick = {
                            val pending = academicTasks.filter { it.status != "Completed" }.take(3)
                            if (pending.isNotEmpty()) {
                                deadlinesText = pending.joinToString(", ") { "${it.module} ${it.title} due ${it.dueDate}" }
                            }
                        }
                    ) {
                        Text("⚡ Pull Deadlines", fontSize = 11.sp)
                    }
                }
                OutlinedTextField(
                    value = deadlinesText,
                    onValueChange = { deadlinesText = it },
                    placeholder = { Text("e.g. CSC3002F Project due 12 Aug") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Exam Dates
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("3. Exam Dates", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    TextButton(
                        onClick = {
                            val exams = calendarEvents.filter { it.category.contains("Exam", ignoreCase = true) }
                            if (exams.isNotEmpty()) {
                                examDatesText = exams.joinToString(", ") { "${it.title} on ${it.date}" }
                            }
                        }
                    ) {
                        Text("⚡ Pull Exams", fontSize = 11.sp)
                    }
                }
                OutlinedTextField(
                    value = examDatesText,
                    onValueChange = { examDatesText = it },
                    placeholder = { Text("e.g. CSC3002F Exam on 22 Aug") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Preferred Study Times
                Text("4. Preferred Study Times", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = morningSelected,
                        onClick = { morningSelected = !morningSelected },
                        label = { Text("☀️ Morning", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = afternoonSelected,
                        onClick = { afternoonSelected = !afternoonSelected },
                        label = { Text("🌤️ Afternoon", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = eveningSelected,
                        onClick = { eveningSelected = !eveningSelected },
                        label = { Text("🌙 Evening", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = weekendSelected,
                        onClick = { weekendSelected = !weekendSelected },
                        label = { Text("📅 Weekends", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Schedule Type
                Text("5. Schedule Format", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedScheduleType == "7-Day Weekly Master Plan",
                        onClick = { selectedScheduleType = "7-Day Weekly Master Plan" },
                        label = { Text("7-Day Weekly Plan") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedScheduleType == "Daily Focus Schedule",
                        onClick = { selectedScheduleType = "Daily Focus Schedule" },
                        label = { Text("Daily Focus Plan") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Generate Button
                Button(
                    onClick = {
                        val timesList = mutableListOf<String>()
                        if (morningSelected) timesList.add("Mornings (08:00 - 11:00)")
                        if (afternoonSelected) timesList.add("Afternoons (14:00 - 17:00)")
                        if (eveningSelected) timesList.add("Evenings (18:00 - 21:00)")
                        if (weekendSelected) timesList.add("Weekends (10:00 - 15:00)")
                        val preferredTimes = if (timesList.isEmpty()) "Mornings & Evenings" else timesList.joinToString(" & ")

                        val prompt = """
                            Create a $selectedScheduleType for me:
                            - Courses: $coursesText
                            - Deadlines: $deadlinesText
                            - Exams: $examDatesText
                            - Preferred Times: $preferredTimes

                            Please prioritize tasks by deadline urgency, map module study sessions into my preferred timeslots, and provide actionable study tasks.
                        """.trimIndent()

                        viewModel.sendAiPrompt(prompt, taskType = "study_plan")
                        showStudyPlanSheet = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate My Personalized Study Plan", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    if (showPayloadInspectorDialog) {
        com.example.ui.components.GeminiPayloadInspectorDialog(
            onDismiss = { showPayloadInspectorDialog = false }
        )
    }

    if (showStudyQuestionsDialog) {
        StudyQuestionsGeneratorDialog(
            notes = notes,
            presetNote = presetNoteForStudyQuestions,
            isGenerating = isGeneratingStudyQuestions,
            onDismiss = { viewModel.dismissStudyQuestionsGenerator() },
            onGenerate = { config ->
                viewModel.generateStudyQuestionsFromNote(config)
            }
        )
    }

    if (showInteractiveQuizDialog && activeStudyQuiz != null) {
        StudyQuestionsInteractiveQuizDialog(
            quiz = activeStudyQuiz!!,
            onDismiss = { viewModel.dismissInteractiveQuiz() },
            onOptionSelected = { qId, optIdx -> viewModel.selectOptionForStudyQuestion(qId, optIdx) },
            onUserAnswerTextChange = { qId, txt -> viewModel.setUserAnswerForStudyQuestion(qId, txt) },
            onToggleRevealAnswer = { qId -> viewModel.toggleRevealStudyQuestionAnswer(qId) },
            onToggleMastered = { qId -> viewModel.toggleMasteredStudyQuestion(qId) },
            onExportToFlashcards = { qz -> viewModel.exportQuizToFlashcards(qz) },
            onExportToNotes = { qz -> viewModel.exportQuizToNotes(qz) }
        )
    }
}

@Composable
fun CanvasMateAssistantScreen(viewModel: CanvasMateViewModel) {
    AiAssistantScreen(viewModel = viewModel)
}

