package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DiaryEntry
import com.example.data.local.TodoTask
import com.example.ui.components.VoiceInputIconButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoListScreen(
    tasks: List<TodoTask>,
    onAddTask: (TodoTask) -> Unit,
    onUpdateTask: (TodoTask) -> Unit,
    onDeleteTask: (Long) -> Unit
) {
    var selectedTab by remember { mutableStateOf("Pending") }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredTasks = tasks.filter { task ->
        if (selectedTab == "Pending") !task.isCompleted else task.isCompleted
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("To-Do List", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Daily Quick Tasks, Priorities & Recurring Checklist", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CloudDone,
                            contentDescription = "Room Database Local Cache",
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Offline Ready",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TabRow(selectedTabIndex = if (selectedTab == "Pending") 0 else 1) {
                Tab(
                    selected = selectedTab == "Pending",
                    onClick = { selectedTab = "Pending" },
                    text = { Text("Pending (${tasks.count { !it.isCompleted }})") }
                )
                Tab(
                    selected = selectedTab == "Completed",
                    onClick = { selectedTab = "Completed" },
                    text = { Text("Completed (${tasks.count { it.isCompleted }})") }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredTasks.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No tasks in this tab.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredTasks, key = { it.id }) { task ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Checkbox(
                                        checked = task.isCompleted,
                                        onCheckedChange = { onUpdateTask(task.copy(isCompleted = it)) }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(task.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                        Text("Due: ${task.dueDate} • ${task.recurring}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    PriorityChip(task.priority)
                                    IconButton(onClick = { onDeleteTask(task.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddTodoTaskDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { task ->
                onAddTask(task)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddTodoTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (TodoTask) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Medium") }
    var dueDate by remember { mutableStateOf("2026-08-05") }
    var recurring by remember { mutableStateOf("None") }

    val recurringOptions = listOf("None", "Daily", "Weekly", "Monthly")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add To-Do Task") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Description") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> title = if (title.isEmpty()) text else "$title $text" },
                            prompt = "Dictate to-do task..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = dueDate, onValueChange = { dueDate = it }, label = { Text("Due Date (2026)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                Text("Priority", style = MaterialTheme.typography.labelSmall)
                Row {
                    listOf("High", "Medium", "Low").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p) },
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Recurring", style = MaterialTheme.typography.labelSmall)
                ScrollableTabRow(selectedTabIndex = recurringOptions.indexOf(recurring).coerceAtLeast(0), divider = {}) {
                    recurringOptions.forEach { option ->
                        FilterChip(
                            selected = recurring == option,
                            onClick = { recurring = option },
                            label = { Text(option) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(TodoTask(title = title, priority = priority, dueDate = dueDate, recurring = recurring))
                    }
                }
            ) {
                Text("Add Task")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiaryScreen(
    entries: List<DiaryEntry>,
    onAddEntry: (DiaryEntry) -> Unit,
    onDeleteEntry: (Long) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Journal Entry")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("Private Student Journal & Diary", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Reflect, track moods & document your university journey in 2026", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            if (entries.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No journal entries yet. Write your first reflection!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(entries, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(entry.moodEmoji, fontSize = 24.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(entry.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(entry.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }

                                    IconButton(onClick = { onDeleteEntry(entry.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(entry.content, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddDiaryEntryDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { entry ->
                onAddEntry(entry)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddDiaryEntryDialog(
    onDismiss: () -> Unit,
    onConfirm: (DiaryEntry) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var moodEmoji by remember { mutableStateOf("😊") }
    var date by remember { mutableStateOf("2026-08-05") }

    val moodOptions = listOf("😊 Happy", "📚 Productive", "😴 Tired", "😤 Stressed", "😎 Confident")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Diary Entry") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Entry Title") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> title = if (title.isEmpty()) text else "$title $text" },
                            prompt = "Dictate journal title..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Reflections / Thoughts") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> content = if (content.isEmpty()) text else "$content $text" },
                            prompt = "Dictate journal thoughts..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Text("Mood Selector", style = MaterialTheme.typography.labelSmall)
                ScrollableTabRow(selectedTabIndex = moodOptions.indexOfFirst { it.startsWith(moodEmoji) }.coerceAtLeast(0), divider = {}) {
                    moodOptions.forEach { m ->
                        FilterChip(
                            selected = m.startsWith(moodEmoji),
                            onClick = { moodEmoji = m.take(2).trim() },
                            label = { Text(m) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(DiaryEntry(title = title, content = content, date = date, moodEmoji = moodEmoji))
                    }
                }
            ) {
                Text("Save Entry")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}


