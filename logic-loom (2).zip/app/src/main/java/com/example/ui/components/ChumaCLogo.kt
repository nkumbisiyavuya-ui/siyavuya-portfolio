package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Dedicated Chuma AI Identity - Geometric C Logo.
 *
 * Design:
 * - Strong, modern letter "C"
 * - Clean geometric construction
 * - Recognizable at small sizes (16dp-24dp) and prominent at hero sizes (64dp-96dp)
 * - Professional AI assistant visual language
 * - Supports AI States (IDLE, LISTENING, THINKING, RESPONDING, ERROR)
 */
@Composable
fun ChumaCLogo(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    aiState: CanvasMateAiState = CanvasMateAiState.IDLE,
    showGlow: Boolean = true,
    showBackgroundContainer: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "chumaLogoAnimation")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = when (aiState) {
            CanvasMateAiState.LISTENING -> 0.98f
            CanvasMateAiState.THINKING -> 0.96f
            CanvasMateAiState.RESPONDING -> 1.0f
            CanvasMateAiState.ERROR -> 0.98f
            CanvasMateAiState.IDLE -> 0.99f
        },
        targetValue = when (aiState) {
            CanvasMateAiState.LISTENING -> 1.06f
            CanvasMateAiState.THINKING -> 1.04f
            CanvasMateAiState.RESPONDING -> 1.05f
            CanvasMateAiState.ERROR -> 1.02f
            CanvasMateAiState.IDLE -> 1.01f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (aiState) {
                    CanvasMateAiState.LISTENING -> 800
                    CanvasMateAiState.THINKING -> 1100
                    CanvasMateAiState.RESPONDING -> 900
                    CanvasMateAiState.ERROR -> 600
                    CanvasMateAiState.IDLE -> 2600
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chumaPulse"
    )

    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = when (aiState) {
            CanvasMateAiState.LISTENING -> 0.85f
            CanvasMateAiState.THINKING -> 0.95f
            CanvasMateAiState.RESPONDING -> 0.75f
            CanvasMateAiState.ERROR -> 0.9f
            CanvasMateAiState.IDLE -> 0.45f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chumaAura"
    )

    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (aiState == CanvasMateAiState.THINKING) 2000 else 6000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "chumaSpin"
    )

    val primaryColor = when (aiState) {
        CanvasMateAiState.LISTENING -> Color(0xFF818CF8) // Indigo Light
        CanvasMateAiState.THINKING -> Color(0xFF38BDF8) // Sky Blue
        CanvasMateAiState.RESPONDING -> Color(0xFF34D399) // Emerald
        CanvasMateAiState.ERROR -> Color(0xFFF87171) // Red
        CanvasMateAiState.IDLE -> Color(0xFF6366F1) // Indigo Primary
    }

    val secondaryColor = when (aiState) {
        CanvasMateAiState.LISTENING -> Color(0xFFA78BFA) // Violet
        CanvasMateAiState.THINKING -> Color(0xFF60A5FA) // Blue
        CanvasMateAiState.RESPONDING -> Color(0xFF10B981) // Teal
        CanvasMateAiState.ERROR -> Color(0xFFDC2626) // Deep Red
        CanvasMateAiState.IDLE -> Color(0xFF4F46E5) // Deep Indigo
    }

    val cornerRadius = size * 0.26f

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .scale(pulseScale)
            .testTag("chuma_c_logo")
    ) {
        // Outer glowing ambiance
        if (showGlow) {
            Box(
                modifier = Modifier
                    .size(size * 1.2f)
                    .clip(RoundedCornerShape(cornerRadius * 1.25f))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = auraAlpha * 0.4f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        // Main Container Box
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .then(
                    if (showBackgroundContainer) {
                        Modifier
                            .shadow(
                                elevation = if (size > 36.dp) 6.dp else 2.dp,
                                shape = RoundedCornerShape(cornerRadius),
                                ambientColor = primaryColor,
                                spotColor = Color.Black
                            )
                            .clip(RoundedCornerShape(cornerRadius))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF1E1B4B), // Rich dark indigo
                                        Color(0xFF0F172A)  // Slate dark
                                    )
                                )
                            )
                            .border(
                                width = if (size > 36.dp) 1.5.dp else 1.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        primaryColor.copy(alpha = 0.8f),
                                        secondaryColor.copy(alpha = auraAlpha)
                                    )
                                ),
                                shape = RoundedCornerShape(cornerRadius)
                            )
                    } else Modifier
                )
        ) {
            // Draw Geometric "C" Canvas Mark
            Canvas(
                modifier = Modifier
                    .size(size * 0.72f)
            ) {
                drawChumaGeometricC(
                    primaryColor = primaryColor,
                    secondaryColor = secondaryColor,
                    spinAngle = if (aiState == CanvasMateAiState.THINKING) spinAngle else 0f,
                    aiState = aiState
                )
            }
        }
    }
}

/**
 * Geometric Vector rendering of the Chuma "C" lettermark inside Canvas DrawScope.
 */
private fun DrawScope.drawChumaGeometricC(
    primaryColor: Color,
    secondaryColor: Color,
    spinAngle: Float,
    aiState: CanvasMateAiState
) {
    val w = size.width
    val h = size.height
    val center = Offset(w / 2f, h / 2f)
    val outerRadius = w * 0.44f
    val innerRadius = w * 0.22f
    val strokeWidth = outerRadius - innerRadius

    rotate(spinAngle, pivot = center) {
        // 1. Outer dynamic accent arc (geometric outer rim)
        drawArc(
            brush = Brush.sweepGradient(
                listOf(
                    primaryColor,
                    secondaryColor,
                    Color(0xFFE0E7FF),
                    primaryColor
                ),
                center = center
            ),
            startAngle = 45f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(center.x - outerRadius, center.y - outerRadius),
            size = Size(outerRadius * 2f, outerRadius * 2f),
            style = Stroke(
                width = strokeWidth * 0.35f,
                cap = StrokeCap.Round
            )
        )

        // 2. Solid bold modern "C" letterform
        val cPath = Path().apply {
            val midRadius = (outerRadius + innerRadius) / 2f
            arcTo(
                rect = Rect(
                    left = center.x - midRadius,
                    top = center.y - midRadius,
                    right = center.x + midRadius,
                    bottom = center.y + midRadius
                ),
                startAngleDegrees = 40f,
                sweepAngleDegrees = 280f,
                forceMoveTo = false
            )
        }

        drawPath(
            path = cPath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White,
                    Color(0xFFE0E7FF),
                    primaryColor
                ),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            ),
            style = Stroke(
                width = strokeWidth,
                cap = StrokeCap.Round
            )
        )

        // 3. Central AI Intelligence Core Dot inside C aperture
        val coreDotOffset = Offset(center.x + outerRadius * 0.28f, center.y)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White,
                    primaryColor
                ),
                center = coreDotOffset,
                radius = strokeWidth * 0.6f
            ),
            radius = strokeWidth * 0.38f,
            center = coreDotOffset
        )
    }
}

/**
 * Avatar for Chuma AI with status ring/dot.
 */
@Composable
fun ChumaAiAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    aiState: CanvasMateAiState = CanvasMateAiState.IDLE
) {
    Box(
        contentAlignment = Alignment.BottomEnd,
        modifier = modifier
    ) {
        ChumaCLogo(
            size = size,
            aiState = aiState,
            showGlow = true
        )

        // Status indicator dot
        val dotColor = when (aiState) {
            CanvasMateAiState.IDLE -> Color(0xFF6366F1)
            CanvasMateAiState.LISTENING -> Color(0xFF818CF8)
            CanvasMateAiState.THINKING -> Color(0xFF38BDF8)
            CanvasMateAiState.RESPONDING -> Color(0xFF34D399)
            CanvasMateAiState.ERROR -> Color(0xFFEF4444)
        }

        Box(
            modifier = Modifier
                .offset(x = 2.dp, y = 2.dp)
                .size(size * 0.28f)
                .clip(CircleShape)
                .background(dotColor)
                .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
        )
    }
}
