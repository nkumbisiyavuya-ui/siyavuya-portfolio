package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiClient
import com.example.data.ai.CanvasMateAiOrchestrator
import com.example.data.ai.CanvasMateContext
import com.example.data.local.*
import com.example.data.repository.CanvasMateRepository
import com.example.CanvasMateApplication
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import com.example.data.repository.ExchangeRateRepository
import com.example.data.network.ExchangeRateNetworkService
import com.example.data.device.DeviceCapabilityManager
import com.example.data.device.DeviceLocationInfo
import com.example.data.ai.CapabilityState

import com.example.ui.theme.AppColorPalette
import com.example.ui.theme.AppFontStyle
import com.example.data.ai.StudyQuestionItem
import com.example.data.ai.StudyQuestionsQuiz
import com.example.data.ai.StudyQuestionsGeneratorConfig
import com.example.data.ai.StudyQuestionsGenerator
import com.example.data.ai.datastore.ChumaTaskExecutionDataStore
import com.example.data.ai.datastore.ChumaTaskExecutionState
import com.example.data.ai.datastore.ChumaTaskStatus

data class StudyTaskReminder(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val module: String,
    val time: String,
    val isEnabled: Boolean = true,
    val leadMinutes: Int = 15
)

@HiltViewModel
class CanvasMateViewModel @Inject constructor(
    application: Application,
    private val repository: CanvasMateRepository,
    private val dao: CanvasMateDao,
    private val authRepository: com.example.data.repository.AuthRepository
) : AndroidViewModel(application) {

    private val exchangeRateRepository by lazy { ExchangeRateRepository(dao) }
    private val chumaOrchestrator by lazy { com.example.data.ai.orchestrator.ChumaOrchestrator() }
    val exchangeRates = MutableStateFlow<Map<String, Double>>(ExchangeRateNetworkService.fallbackRates)
    val isRatesLive = MutableStateFlow(false)
    val isRatesFromRoomCache = MutableStateFlow(false)
    val isLoadingRates = MutableStateFlow(false)

    constructor(application: Application) : this(
        application,
        (application as CanvasMateApplication).repository,
        (application as CanvasMateApplication).dao,
        (application as CanvasMateApplication).authRepository
    )

    // Auth & Security States & Actions
    val authState: StateFlow<com.example.security.AuthState> = authRepository.authState
    val currentSession: StateFlow<com.example.security.UserSession?> = authRepository.currentSession
    val isUserLoggedIn: StateFlow<Boolean> = authRepository.isLoggedIn
    val authError = MutableStateFlow<String?>(null)
    val authSuccessMessage = MutableStateFlow<String?>(null)
    val isAuthLoading = MutableStateFlow<Boolean>(false)

    // Legal & Privacy Compliance Repository
    private val legalRepository by lazy { com.example.legal.repository.LegalAcceptanceRepository(getApplication()) }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val legalConsentState: StateFlow<com.example.legal.model.LegalConsentState> = currentSession
        .flatMapLatest { session ->
            val effectiveId = session?.email?.ifBlank { null }
                ?: session?.studentNumber?.ifBlank { null }
            legalRepository.consentStateFlowForUser(effectiveId)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = com.example.legal.model.LegalConsentState()
        )

    fun recordLegalConsent(acceptTerms: Boolean, ackPrivacy: Boolean, understandAi: Boolean) {
        viewModelScope.launch {
            val session = currentSession.value
            val effectiveId = session?.email?.ifBlank { null }
                ?: session?.studentNumber?.ifBlank { null }
                ?: userProfile.value?.email?.ifBlank { null }
                ?: "user_default"
            legalRepository.recordConsent(effectiveId, acceptTerms, ackPrivacy, understandAi)
        }
    }

    fun exportUserDataJson(context: android.content.Context) {
        viewModelScope.launch {
            val profile = userProfile.value
            val tasks = academicTasks.value
            val notesList = notes.value
            val budget = budgetItems.value
            val userEmail = currentSession.value?.email ?: "user@logicloom.app"

            val exportData = """
                {
                  "app": "Logic Loom (Designed and Engineered by Moraigne)",
                  "exportedAt": "${java.time.Instant.now()}",
                  "user": {
                    "name": "${profile?.fullName ?: "Student"}",
                    "email": "$userEmail",
                    "studentNumber": "${profile?.studentNumber ?: ""}",
                    "university": "${profile?.university ?: ""}",
                    "course": "${profile?.course ?: ""}"
                  },
                  "counts": {
                    "academicTasks": ${tasks.size},
                    "notes": ${notesList.size},
                    "budgetItems": ${budget.size}
                  }
                }
            """.trimIndent()

            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_SUBJECT, "Logic Loom Personal Data Export")
                putExtra(android.content.Intent.EXTRA_TEXT, exportData)
            }
            context.startActivity(android.content.Intent.createChooser(shareIntent, "Export My Logic Loom Data"))
        }
    }

    fun deleteAccountAndData(onComplete: () -> Unit) {
        viewModelScope.launch {
            // 1. Purge Local Database Tables
            try {
                dao.getUserProfileDirect()?.let { dao.deleteUserProfile(it) }
            } catch (e: Exception) {
                // Ignore if empty
            }
            // 2. Clear Preferences & Legal DataStore
            prefs.edit().clear().apply()
            legalRepository.clearAllConsentRecords()
            // 3. Logout Auth Session
            logoutUser {
                onComplete()
            }
        }
    }

    fun registerUser(
        fullName: String,
        email: String,
        studentNumber: String,
        university: String,
        password: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            authError.value = null
            authSuccessMessage.value = null
            isAuthLoading.value = true
            try {
                when (val result = authRepository.registerUser(fullName, email, studentNumber, university, password)) {
                    is com.example.data.repository.AuthResult.Success -> {
                        authSuccessMessage.value = result.message
                        triggerScheduleNotification("Welcome to Logic Loom", "Account created successfully for ${result.session.fullName}!")
                        onSuccess()
                    }
                    is com.example.data.repository.AuthResult.Error -> {
                        authError.value = result.message
                    }
                }
            } finally {
                isAuthLoading.value = false
            }
        }
    }

    fun loginUser(
        email: String,
        password: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            authError.value = null
            authSuccessMessage.value = null
            isAuthLoading.value = true
            try {
                when (val result = authRepository.loginUser(email, password)) {
                    is com.example.data.repository.AuthResult.Success -> {
                        authSuccessMessage.value = result.message
                        triggerScheduleNotification("Welcome Back", "Logged in as ${result.session.fullName}")
                        onSuccess()
                    }
                    is com.example.data.repository.AuthResult.Error -> {
                        authError.value = result.message
                    }
                }
            } finally {
                isAuthLoading.value = false
            }
        }
    }

    fun performGoogleSignIn(context: android.content.Context, onSuccess: () -> Unit) {
        viewModelScope.launch {
            authError.value = null
            authSuccessMessage.value = null
            isAuthLoading.value = true

            try {
                val manager = com.example.security.GoogleAuthManager()
                val result = manager.signInWithGoogle(context)

                result.fold(
                    onSuccess = { googleResult ->
                        when (val authRes = authRepository.loginWithGoogle(
                            email = googleResult.email,
                            fullName = googleResult.displayName,
                            googleIdToken = googleResult.idToken
                        )) {
                            is com.example.data.repository.AuthResult.Success -> {
                                authSuccessMessage.value = authRes.message
                                triggerScheduleNotification("Google Auth", "Signed in with Google as ${authRes.session.fullName}")
                                onSuccess()
                            }
                            is com.example.data.repository.AuthResult.Error -> {
                                authError.value = authRes.message
                            }
                        }
                    },
                    onFailure = { error ->
                        val errorMsg = error.message ?: "Google Sign-In failed"
                        if (errorMsg.contains("cancelled", ignoreCase = true) || errorMsg.contains("canceled", ignoreCase = true)) {
                            authError.value = "Google Sign-In cancelled."
                        } else if (errorMsg.contains("No credentials", ignoreCase = true)) {
                            authError.value = "No Google accounts found on this device. Please continue with Email & Password."
                        } else {
                            authError.value = "Google Sign-In failed: $errorMsg. Please continue with Email & Password."
                        }
                    }
                )
            } finally {
                isAuthLoading.value = false
            }
        }
    }

    fun loginWithGoogle(
        email: String,
        fullName: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            authError.value = null
            authSuccessMessage.value = null
            isAuthLoading.value = true
            try {
                when (val result = authRepository.loginWithGoogle(email, fullName)) {
                    is com.example.data.repository.AuthResult.Success -> {
                        authSuccessMessage.value = result.message
                        triggerScheduleNotification("Google Auth", "Signed in with Google as ${result.session.fullName}")
                        onSuccess()
                    }
                    is com.example.data.repository.AuthResult.Error -> {
                        authError.value = result.message
                    }
                }
            } finally {
                isAuthLoading.value = false
            }
        }
    }

    fun sendPasswordReset(email: String, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            authError.value = null
            authSuccessMessage.value = null
            isAuthLoading.value = true
            try {
                when (val result = authRepository.sendPasswordReset(email)) {
                    is com.example.data.repository.AuthResult.Success -> {
                        authSuccessMessage.value = result.message
                        onComplete()
                    }
                    is com.example.data.repository.AuthResult.Error -> {
                        authError.value = result.message
                        onComplete()
                    }
                }
            } catch (e: Exception) {
                authError.value = e.localizedMessage ?: "Failed to process password reset"
                onComplete()
            } finally {
                isAuthLoading.value = false
            }
        }
    }

    fun verifyEmail() {
        viewModelScope.launch {
            authError.value = null
            isAuthLoading.value = true
            try {
                when (val result = authRepository.verifyEmail()) {
                    is com.example.data.repository.AuthResult.Success -> {
                        authSuccessMessage.value = result.message
                        triggerScheduleNotification("Email Verified", "Student email address has been verified.")
                    }
                    is com.example.data.repository.AuthResult.Error -> {
                        authError.value = result.message
                    }
                }
            } finally {
                isAuthLoading.value = false
            }
        }
    }

    fun changePassword(currentPass: String, newPass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            authError.value = null
            when (val result = authRepository.changePassword(currentPass, newPass)) {
                is com.example.data.repository.AuthResult.Success -> {
                    authSuccessMessage.value = result.message
                    triggerScheduleNotification("Security Update", "Password changed successfully.")
                    onSuccess()
                }
                is com.example.data.repository.AuthResult.Error -> {
                    authError.value = result.message
                }
            }
        }
    }

    fun logoutUser(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            authError.value = null
            authSuccessMessage.value = null
            triggerScheduleNotification("Session Ended", "You have been logged out securely.")
            onLoggedOut()
        }
    }

    fun clearAuthMessages() {
        authError.value = null
        authSuccessMessage.value = null
    }

    init {
        // Initialize sample data if database is fresh
        viewModelScope.launch {
            SampleDataGenerator.populateIfEmpty(dao)
            fetchLiveExchangeRates()
        }
    }

    fun fetchLiveExchangeRates() {
        viewModelScope.launch {
            isLoadingRates.value = true
            val result = exchangeRateRepository.getZarExchangeRates()
            exchangeRates.value = result.rates
            isRatesLive.value = result.isLive
            isRatesFromRoomCache.value = result.isFromRoomCache
            isLoadingRates.value = false
        }
    }

    fun convertForeignToZar(foreignAmount: Double, currency: String): Double {
        return exchangeRateRepository.convertForeignToZar(foreignAmount, currency, exchangeRates.value)
    }

    fun convertZarToForeign(zarAmount: Double, currency: String): Double {
        return exchangeRateRepository.convertZarToForeign(zarAmount, currency, exchangeRates.value)
    }

    // Streams from Repository
    val userProfile: StateFlow<UserProfile?> = repository.userProfile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val academicTasks: StateFlow<List<AcademicTask>> = repository.academicTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val calendarEvents: StateFlow<List<CalendarEvent>> = repository.calendarEvents.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val timetableSlots: StateFlow<List<TimetableSlot>> = repository.timetableSlots.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notes: StateFlow<List<NoteItem>> = repository.notes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val vaultDocuments: StateFlow<List<VaultDocument>> = repository.vaultDocuments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val budgetItems: StateFlow<List<BudgetItem>> = repository.budgetItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val budgetGoals: StateFlow<List<BudgetGoal>> = repository.budgetGoals.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val goals: StateFlow<List<GoalItem>> = repository.goals.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val diaryEntries: StateFlow<List<DiaryEntry>> = repository.diaryEntries.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val todoTasks: StateFlow<List<TodoTask>> = repository.todoTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val gpaModules: StateFlow<List<GpaModule>> = repository.gpaModules.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val shuttleSchedules: StateFlow<List<ShuttleSchedule>> = repository.shuttleSchedules.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val flashcardDecks: StateFlow<List<FlashcardDeck>> = repository.flashcardDecks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allFlashcards: StateFlow<List<Flashcard>> = repository.allFlashcards.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Life OS StateFlows
    val shoppingItems: StateFlow<List<ShoppingItem>> = repository.shoppingItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transportRequests: StateFlow<List<TransportRequest>> = repository.transportRequests.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val foodOrders: StateFlow<List<FoodOrder>> = repository.foodOrders.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val paymentMethods: StateFlow<List<PaymentMethodEntity>> = repository.paymentMethods.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )


    // UI & App Settings States with Persistence
    private val prefs by lazy {
        getApplication<Application>().getSharedPreferences("logicloom_theme_prefs", android.content.Context.MODE_PRIVATE)
    }

    // Schedule Notifications & Reminders State
    val notificationsEnabled by lazy {
        MutableStateFlow(prefs.getBoolean("notifications_enabled", true))
    }
    val notificationLeadMinutes by lazy {
        MutableStateFlow(prefs.getInt("notification_lead_minutes", 15))
    }
    val recentNotificationBanner = MutableStateFlow<String?>(null)

    // Academic & GPA Threshold Alert States
    val gpaAlertThreshold = MutableStateFlow(60.0) // Warning threshold (e.g., 60%)
    val gpaAlertsEnabled = MutableStateFlow(true)
    val significantGradeAlertsEnabled = MutableStateFlow(true)
    val highGradeThreshold = MutableStateFlow(75.0) // Distinction / Outstanding
    val lowGradeThreshold = MutableStateFlow(50.0) // Academic warning / At risk

    fun setGpaAlertThreshold(threshold: Double) {
        gpaAlertThreshold.value = threshold
    }

    fun toggleGpaAlerts(enabled: Boolean) {
        gpaAlertsEnabled.value = enabled
    }

    fun toggleSignificantGradeAlerts(enabled: Boolean) {
        significantGradeAlertsEnabled.value = enabled
    }

    fun testGpaAlertTrigger() {
        val currentModules = gpaModules.value
        val totalCredits = currentModules.sumOf { it.credits }
        val weightedMarks = currentModules.sumOf { it.mark * it.credits }
        val cumulativeAverage = if (totalCredits > 0) weightedMarks / totalCredits else 0.0
        val threshold = gpaAlertThreshold.value

        if (cumulativeAverage < threshold) {
            triggerScheduleNotification(
                title = "🚨 GPA Warning Alert (Test)",
                message = "Cumulative GPA (${"%.1f".format(cumulativeAverage)}%) is below threshold (${"%.1f".format(threshold)}%). Academic action recommended."
            )
        } else {
            triggerScheduleNotification(
                title = "🌟 Distinction Grade Alert (Test)",
                message = "Recorded 85.0% in CSC3002F! Cumulative GPA is ${"%.1f".format(cumulativeAverage)}% (above ${"%.1f".format(threshold)}% threshold)."
            )
        }
    }

    val smartPlanReminders = MutableStateFlow<List<StudyTaskReminder>>(
        listOf(
            StudyTaskReminder(id = "rem-1", title = "CSC3002F Exam Revision Blitz", module = "CSC3002F", time = "09:00 Mon", isEnabled = true, leadMinutes = 15),
            StudyTaskReminder(id = "rem-2", title = "MTH3012S Problem Set Review", module = "MTH3012S", time = "14:00 Tue", isEnabled = true, leadMinutes = 30),
            StudyTaskReminder(id = "rem-3", title = "EEE3096S Capstone Hardware Lab", module = "EEE3096S", time = "11:00 Thu", isEnabled = true, leadMinutes = 15),
            StudyTaskReminder(id = "rem-4", title = "Weekly Quiz Self-Assessment", module = "General", time = "16:00 Fri", isEnabled = false, leadMinutes = 10)
        )
    )

    val darkThemeMode by lazy {
        MutableStateFlow<Boolean?>(
            if (prefs.contains("dark_theme_mode")) prefs.getBoolean("dark_theme_mode", false) else false
        )
    }

    val selectedColorPalette by lazy {
        MutableStateFlow<AppColorPalette>(
            run {
                val savedThemeId = prefs.getString("selected_color_palette", AppColorPalette.LOGIC_LOOM.themeId)
                AppColorPalette.entries.find { it.themeId == savedThemeId || it.name == savedThemeId } ?: AppColorPalette.LOGIC_LOOM
            }
        )
    }

    val selectedThemeChoice: StateFlow<com.example.ui.theme.ThemeChoice> by lazy {
        selectedColorPalette
            .map { palette -> com.example.ui.theme.ThemeChoice.fromId(palette.themeId) }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.Eagerly,
                initialValue = com.example.ui.theme.ThemeChoice.fromId(selectedColorPalette.value.themeId)
            )
    }

    val selectedFontStyle by lazy {
        MutableStateFlow<AppFontStyle>(
            run {
                val savedFontName = prefs.getString("selected_font_style", AppFontStyle.DEFAULT.name)
                AppFontStyle.entries.find { it.name == savedFontName } ?: AppFontStyle.DEFAULT
            }
        )
    }
    val isAppLocked = MutableStateFlow(false)

    fun setColorPalette(palette: AppColorPalette) {
        selectedColorPalette.value = palette
        prefs.edit().putString("selected_color_palette", palette.themeId).apply()
    }

    fun selectThemeChoice(choice: com.example.ui.theme.ThemeChoice) {
        val matchingPalette = AppColorPalette.entries.find { it.themeId == choice.id || it.name == choice.name } ?: AppColorPalette.LOGIC_LOOM
        setColorPalette(matchingPalette)
    }

    fun setDarkThemeMode(isDark: Boolean?) {
        darkThemeMode.value = isDark
        if (isDark == null) {
            prefs.edit().remove("dark_theme_mode").apply()
        } else {
            prefs.edit().putBoolean("dark_theme_mode", isDark).apply()
        }
    }

    fun setFontStyle(fontStyle: AppFontStyle) {
        selectedFontStyle.value = fontStyle
        prefs.edit().putString("selected_font_style", fontStyle.name).apply()
    }
    val searchQuery = MutableStateFlow("")
    val searchCategoryFilter = MutableStateFlow("All") // All, Notes, Assignments, Budget, Documents

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun updateSearchCategory(category: String) {
        searchCategoryFilter.value = category
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val searchedNotes: StateFlow<List<NoteItem>> = searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.notes else repository.searchNotes(query)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val searchedAcademicTasks: StateFlow<List<AcademicTask>> = searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.academicTasks else repository.searchAcademicTasks(query)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val searchedBudgetItems: StateFlow<List<BudgetItem>> = searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.budgetItems else repository.searchBudgetItems(query)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val searchedVaultDocuments: StateFlow<List<VaultDocument>> = searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.vaultDocuments else repository.searchVaultDocuments(query)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Network & Connectivity Monitoring
    private val networkMonitor by lazy { com.example.util.NetworkMonitor(getApplication()) }
    private val _manualConnectivityRefresh = MutableStateFlow(0)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val connectivityStatus: StateFlow<com.example.util.ConnectivityStatus> = _manualConnectivityRefresh
        .flatMapLatest { networkMonitor.connectivityFlow }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = runCatching { networkMonitor.currentStatus() }.getOrDefault(com.example.util.ConnectivityStatus())
        )

    fun refreshConnectivityStatus() {
        _manualConnectivityRefresh.value += 1
    }

    // Pomodoro Timer States
    val pomodoroMinutes = MutableStateFlow(25)
    val pomodoroTimeLeftSec = MutableStateFlow(25 * 60)
    val isPomodoroRunning = MutableStateFlow(false)
    val pomodoroStreak = MutableStateFlow(3)
    val totalStudyHours = MutableStateFlow(14.5)
    val isAutoMuteNotificationsOnPomodoro = MutableStateFlow(true)
    val mutedNotificationCountDuringSession = MutableStateFlow(0)
    private var timerJob: Job? = null

    // AI Assistant States
    val aiMessages = MutableStateFlow<List<Pair<String, String>>>(
        listOf(
            "User" to "Hello! Who are you?",
            "AI" to "Hello! I am **Chuma AI**, the built-in AI assistant for Logic Loom. I'm here to help with general questions, research, learning, calculations, generating targeted study questions from your notes, and organizing your schedule. What would you like to explore today?"
        )
    )
    val isAiLoading = MutableStateFlow(false)
    val chumaTaskDataStore by lazy { ChumaTaskExecutionDataStore(getApplication()) }
    val activeChumaTaskState: StateFlow<ChumaTaskExecutionState> = chumaTaskDataStore.executionStateFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = ChumaTaskExecutionState.DEFAULT
        )

    // Study Questions from Notes State
    val activeStudyQuiz = MutableStateFlow<StudyQuestionsQuiz?>(null)
    val isGeneratingStudyQuestions = MutableStateFlow(false)
    val studyQuestionsError = MutableStateFlow<String?>(null)
    val presetNoteForStudyQuestions = MutableStateFlow<NoteItem?>(null)
    val showStudyQuestionsGeneratorDialog = MutableStateFlow(false)
    val showInteractiveQuizDialog = MutableStateFlow(false)

    fun openStudyQuestionsGenerator(preset: NoteItem? = null) {
        presetNoteForStudyQuestions.value = preset
        showStudyQuestionsGeneratorDialog.value = true
    }

    fun dismissStudyQuestionsGenerator() {
        showStudyQuestionsGeneratorDialog.value = false
        presetNoteForStudyQuestions.value = null
    }

    fun openInteractiveQuiz(quiz: StudyQuestionsQuiz? = null) {
        if (quiz != null) {
            activeStudyQuiz.value = quiz
        }
        showInteractiveQuizDialog.value = true
    }

    fun dismissInteractiveQuiz() {
        showInteractiveQuizDialog.value = false
    }

    fun generateStudyQuestionsFromNote(config: StudyQuestionsGeneratorConfig) {
        viewModelScope.launch {
            isGeneratingStudyQuestions.value = true
            studyQuestionsError.value = null
            try {
                val quiz = StudyQuestionsGenerator.generateStudyQuestions(config)
                activeStudyQuiz.value = quiz
                showStudyQuestionsGeneratorDialog.value = false
                showInteractiveQuizDialog.value = true

                // Also append to AI Assistant chat history
                val currentList = aiMessages.value.toMutableList()
                currentList.add("User" to "Generate targeted study questions to test my understanding of note '${config.noteTitle}'")
                currentList.add("AI" to quiz.rawAiResponse)
                aiMessages.value = currentList

                triggerScheduleNotification(
                    title = "🎯 Study Questions Generated!",
                    message = "Created ${quiz.questions.size} targeted study questions for '${config.noteTitle}'."
                )
            } catch (e: Throwable) {
                e.printStackTrace()
                studyQuestionsError.value = "Failed to generate questions: ${e.localizedMessage ?: "Unknown error"}"
            } finally {
                isGeneratingStudyQuestions.value = false
            }
        }
    }

    fun selectOptionForStudyQuestion(questionId: Int, optionIndex: Int) {
        val currentQuiz = activeStudyQuiz.value ?: return
        val updatedQuestions = currentQuiz.questions.map { q ->
            if (q.id == questionId) {
                q.copy(userSelectedOptionIndex = optionIndex)
            } else q
        }
        activeStudyQuiz.value = currentQuiz.copy(questions = updatedQuestions)
    }

    fun setUserAnswerForStudyQuestion(questionId: Int, text: String) {
        val currentQuiz = activeStudyQuiz.value ?: return
        val updatedQuestions = currentQuiz.questions.map { q ->
            if (q.id == questionId) {
                q.copy(userAnswerText = text)
            } else q
        }
        activeStudyQuiz.value = currentQuiz.copy(questions = updatedQuestions)
    }

    fun toggleRevealStudyQuestionAnswer(questionId: Int) {
        val currentQuiz = activeStudyQuiz.value ?: return
        val updatedQuestions = currentQuiz.questions.map { q ->
            if (q.id == questionId) {
                q.copy(isAnswerRevealed = !q.isAnswerRevealed)
            } else q
        }
        activeStudyQuiz.value = currentQuiz.copy(questions = updatedQuestions)
    }

    fun toggleMasteredStudyQuestion(questionId: Int) {
        val currentQuiz = activeStudyQuiz.value ?: return
        val updatedQuestions = currentQuiz.questions.map { q ->
            if (q.id == questionId) {
                val newMastered = !q.isMastered
                if (newMastered) {
                    triggerScheduleNotification(
                        title = "⭐ Concept Mastered!",
                        message = "Great job mastering question #${q.questionNumber} (${q.targetConcept})!"
                    )
                }
                q.copy(isMastered = newMastered)
            } else q
        }
        activeStudyQuiz.value = currentQuiz.copy(questions = updatedQuestions)
    }

    fun exportQuizToFlashcards(quiz: StudyQuestionsQuiz) {
        viewModelScope.launch {
            val newDeck = FlashcardDeck(
                title = "Quiz: ${quiz.noteTitle}",
                subject = if (quiz.folder.isNotBlank()) quiz.folder else "Study Quiz",
                description = "Targeted active recall study questions generated on ${quiz.generatedAt}.",
                noteId = null
            )
            val deckId = repository.addFlashcardDeck(newDeck)
            quiz.questions.forEach { q ->
                val fullQ = buildString {
                    append(q.questionText)
                    if (q.options.isNotEmpty()) {
                        append("\n\n")
                        q.options.forEachIndexed { idx, opt ->
                            append("${('A'.code + idx).toChar()}) $opt\n")
                        }
                    }
                }
                val fullA = "${q.correctAnswer}\n\n💡 Explanation: ${q.explanation}"
                repository.addFlashcard(
                    Flashcard(
                        deckId = deckId,
                        question = fullQ,
                        answer = fullA,
                        isMastered = q.isMastered,
                        timesReviewed = 0
                    )
                )
            }

            triggerScheduleNotification(
                title = "⚡ Flashcard Deck Created!",
                message = "Exported ${quiz.questions.size} study questions to '${newDeck.title}' in Flashcards."
            )
        }
    }

    fun exportQuizToNotes(quiz: StudyQuestionsQuiz) {
        viewModelScope.launch {
            val noteContent = buildString {
                append("### Targeted Study Questions & Self-Test Guide\n\n")
                append("**Generated At:** ${quiz.generatedAt} | **Difficulty:** ${quiz.difficulty}\n\n")
                quiz.questions.forEach { q ->
                    append("#### Q${q.questionNumber}: ${q.questionText}\n")
                    if (q.options.isNotEmpty()) {
                        q.options.forEachIndexed { i, o ->
                            append("- **${('A'.code + i).toChar()})** $o\n")
                        }
                        append("\n")
                    }
                    if (q.hint.isNotBlank()) {
                        append("> 💡 *Hint:* ${q.hint}\n\n")
                    }
                    append("**Correct Answer:** ${q.correctAnswer}\n\n")
                    append("**Pedagogical Explanation:** ${q.explanation}\n\n")
                    append("**Target Concept:** ${q.targetConcept}\n\n")
                    append("---\n\n")
                }
            }

            val newNote = NoteItem(
                title = "Study Quiz: ${quiz.noteTitle}",
                content = noteContent,
                folder = if (quiz.folder.isNotBlank()) quiz.folder else "Quizzes",
                isPinned = false,
                isFavorite = true
            )
            repository.addNote(newNote)

            triggerScheduleNotification(
                title = "📝 Study Guide Saved to Notes",
                message = "Saved '${newNote.title}' under ${newNote.folder}."
            )
        }
    }

    // Actions - Profile
    fun updateUserProfile(profile: UserProfile) {
        viewModelScope.launch {
            try {
                repository.updateUserProfile(profile)
                android.util.Log.d("CanvasMateViewModel", "UserProfile persisted successfully: ${profile.fullName}")
            } catch (e: Exception) {
                android.util.Log.e("CanvasMateViewModel", "Failed to persist UserProfile to Room DB", e)
                authError.value = "Failed to save profile changes: ${e.localizedMessage}"
            }
        }
    }

    // Actions - Academic Tasks
    fun addAcademicTask(task: AcademicTask) {
        viewModelScope.launch { repository.addAcademicTask(task) }
    }

    fun updateAcademicTask(task: AcademicTask) {
        viewModelScope.launch { repository.updateAcademicTask(task) }
    }

    fun deleteAcademicTask(id: Long) {
        viewModelScope.launch { repository.deleteAcademicTask(id) }
    }

    // Actions - Calendar
    fun addCalendarEvent(event: CalendarEvent) {
        viewModelScope.launch { repository.addCalendarEvent(event) }
    }

    fun deleteCalendarEvent(id: Long) {
        viewModelScope.launch { repository.deleteCalendarEvent(id) }
    }

    // Actions - Timetable
    fun addTimetableSlot(slot: TimetableSlot) {
        viewModelScope.launch { repository.addTimetableSlot(slot) }
    }

    fun deleteTimetableSlot(id: Long) {
        viewModelScope.launch { repository.deleteTimetableSlot(id) }
    }

    // Actions - Notes
    fun addNote(note: NoteItem) {
        viewModelScope.launch { repository.addNote(note) }
    }

    fun updateNote(note: NoteItem) {
        viewModelScope.launch { repository.updateNote(note) }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch { repository.deleteNote(id) }
    }

    // Actions - Vault
    fun addVaultDocument(doc: VaultDocument, onError: ((String) -> Unit)? = null) {
        val validation = com.example.security.FileValidationUtils.validateFileForUpload(doc.title, doc.fileSizeMb)
        if (validation is com.example.security.FileValidationResult.Invalid) {
            val errMsg = validation.reason
            onError?.invoke(errMsg)
            triggerScheduleNotification("Security Validation Alert", errMsg)
            return
        }
        viewModelScope.launch { repository.addVaultDocument(doc) }
    }

    fun deleteVaultDocument(id: Long) {
        viewModelScope.launch { repository.deleteVaultDocument(id) }
    }

    // Actions - Budget (ZAR R)
    fun addBudgetItem(item: BudgetItem) {
        viewModelScope.launch { repository.addBudgetItem(item) }
    }

    fun updateBudgetItem(item: BudgetItem) {
        viewModelScope.launch { repository.updateBudgetItem(item) }
    }

    fun deleteBudgetItem(id: Long) {
        viewModelScope.launch { repository.deleteBudgetItem(id) }
    }

    fun addBudgetGoal(goal: BudgetGoal) {
        viewModelScope.launch { repository.addBudgetGoal(goal) }
    }

    fun updateBudgetGoal(goal: BudgetGoal) {
        viewModelScope.launch { repository.updateBudgetGoal(goal) }
    }

    fun deleteBudgetGoal(id: Long) {
        viewModelScope.launch { repository.deleteBudgetGoal(id) }
    }

    // Actions - Goals
    fun addGoal(goal: GoalItem) {
        viewModelScope.launch { repository.addGoal(goal) }
    }

    fun updateGoal(goal: GoalItem) {
        viewModelScope.launch { repository.updateGoal(goal) }
    }

    fun deleteGoal(id: Long) {
        viewModelScope.launch { repository.deleteGoal(id) }
    }

    // Actions - Diary
    fun addDiaryEntry(entry: DiaryEntry) {
        viewModelScope.launch { repository.addDiaryEntry(entry) }
    }

    fun deleteDiaryEntry(id: Long) {
        viewModelScope.launch { repository.deleteDiaryEntry(id) }
    }

    // Actions - Todos
    fun addTodoTask(task: TodoTask) {
        viewModelScope.launch { repository.addTodoTask(task) }
    }

    fun updateTodoTask(task: TodoTask) {
        viewModelScope.launch { repository.updateTodoTask(task) }
    }

    fun deleteTodoTask(id: Long) {
        viewModelScope.launch { repository.deleteTodoTask(id) }
    }

    // Actions - GPA
    fun addGpaModule(module: GpaModule) {
        viewModelScope.launch {
            val currentModules = gpaModules.value
            val prevTotalCredits = currentModules.sumOf { it.credits }
            val prevWeightedMarks = currentModules.sumOf { it.mark * it.credits }
            val prevGpa = if (prevTotalCredits > 0) prevWeightedMarks / prevTotalCredits else 0.0

            repository.addGpaModule(module)

            val newModules = currentModules + module
            val newTotalCredits = newModules.sumOf { it.credits }
            val newWeightedMarks = newModules.sumOf { it.mark * it.credits }
            val newGpa = if (newTotalCredits > 0) newWeightedMarks / newTotalCredits else 0.0

            // Significant Grade Recorded Alert
            if (significantGradeAlertsEnabled.value) {
                if (module.mark >= highGradeThreshold.value) {
                    triggerScheduleNotification(
                        title = "🌟 Distinction Grade Recorded!",
                        message = "Outstanding result in ${module.moduleCode}! Recorded ${"%.1f".format(module.mark)}% (${module.credits} credits)."
                    )
                } else if (module.mark < lowGradeThreshold.value) {
                    triggerScheduleNotification(
                        title = "⚠️ At-Risk Grade Alert",
                        message = "${module.moduleCode} mark recorded at ${"%.1f".format(module.mark)}%. Consider setting up an AI study plan."
                    )
                } else {
                    triggerScheduleNotification(
                        title = "📝 Course Grade Recorded",
                        message = "Recorded ${"%.1f".format(module.mark)}% for ${module.moduleCode} (${module.credits} credits)."
                    )
                }
            }

            // Cumulative GPA Threshold Alert
            if (gpaAlertsEnabled.value) {
                val threshold = gpaAlertThreshold.value
                if (newGpa < threshold) {
                    triggerScheduleNotification(
                        title = "🚨 GPA Below Warning Threshold!",
                        message = "Your cumulative GPA (${"%.1f".format(newGpa)}%) is BELOW your alert threshold of ${"%.1f".format(threshold)}%!"
                    )
                } else if (prevGpa < threshold && newGpa >= threshold && prevTotalCredits > 0) {
                    triggerScheduleNotification(
                        title = "🎉 GPA Target Restored!",
                        message = "Great progress! Your cumulative GPA improved to ${"%.1f".format(newGpa)}%, surpassing your threshold of ${"%.1f".format(threshold)}%."
                    )
                }
            }
        }
    }

    fun deleteGpaModule(id: Long) {
        viewModelScope.launch {
            val currentModules = gpaModules.value
            val prevTotalCredits = currentModules.sumOf { it.credits }
            val prevWeightedMarks = currentModules.sumOf { it.mark * it.credits }
            val prevGpa = if (prevTotalCredits > 0) prevWeightedMarks / prevTotalCredits else 0.0

            repository.deleteGpaModule(id)

            val newModules = currentModules.filterNot { it.id == id }
            val newTotalCredits = newModules.sumOf { it.credits }
            val newWeightedMarks = newModules.sumOf { it.mark * it.credits }
            val newGpa = if (newTotalCredits > 0) newWeightedMarks / newTotalCredits else 0.0

            if (gpaAlertsEnabled.value && newTotalCredits > 0) {
                val threshold = gpaAlertThreshold.value
                if (newGpa < threshold && prevGpa >= threshold) {
                    triggerScheduleNotification(
                        title = "🚨 GPA Drop Alert",
                        message = "Recalculated cumulative GPA (${"%.1f".format(newGpa)}%) fell below your warning threshold of ${"%.1f".format(threshold)}%."
                    )
                }
            }
        }
    }

    // Actions - Pomodoro Timer
    fun setPomodoroDuration(minutes: Int) {
        pomodoroMinutes.value = minutes
        pomodoroTimeLeftSec.value = minutes * 60
        isPomodoroRunning.value = false
        timerJob?.cancel()
    }

    fun toggleAutoMuteNotificationsOnPomodoro(enabled: Boolean) {
        isAutoMuteNotificationsOnPomodoro.value = enabled
    }

    fun startPausePomodoro() {
        if (isPomodoroRunning.value) {
            isPomodoroRunning.value = false
            timerJob?.cancel()
        } else {
            isPomodoroRunning.value = true
            mutedNotificationCountDuringSession.value = 0
            timerJob = viewModelScope.launch {
                while (pomodoroTimeLeftSec.value > 0 && isPomodoroRunning.value) {
                    delay(1000)
                    pomodoroTimeLeftSec.value -= 1
                }
                if (pomodoroTimeLeftSec.value == 0) {
                    isPomodoroRunning.value = false
                    pomodoroStreak.value += 1
                    totalStudyHours.value += (pomodoroMinutes.value / 60.0)
                    pomodoroTimeLeftSec.value = pomodoroMinutes.value * 60
                    val silencedCount = mutedNotificationCountDuringSession.value
                    if (silencedCount > 0) {
                        recentNotificationBanner.value = "🎉 Focus Session Finished! ($silencedCount distracting notifications were silenced)"
                    } else {
                        recentNotificationBanner.value = "🎉 Great job! Completed ${pomodoroMinutes.value} min Pomodoro session!"
                    }
                    mutedNotificationCountDuringSession.value = 0
                }
            }
        }
    }

    fun resetPomodoro() {
        isPomodoroRunning.value = false
        timerJob?.cancel()
        pomodoroTimeLeftSec.value = pomodoroMinutes.value * 60
        mutedNotificationCountDuringSession.value = 0
    }

    // Actions - Shuttle Schedules
    fun addShuttleSchedule(shuttle: ShuttleSchedule) {
        viewModelScope.launch { repository.addShuttleSchedule(shuttle) }
    }

    fun updateShuttleSchedule(shuttle: ShuttleSchedule) {
        viewModelScope.launch { repository.updateShuttleSchedule(shuttle) }
    }

    fun deleteShuttleSchedule(id: Long) {
        viewModelScope.launch { repository.deleteShuttleSchedule(id) }
    }

    // Actions - Schedule Notifications
    fun toggleNotifications(enabled: Boolean) {
        notificationsEnabled.value = enabled
        prefs.edit().putBoolean("notifications_enabled", enabled).apply()
    }

    fun setNotificationLeadTime(minutes: Int) {
        notificationLeadMinutes.value = minutes
        prefs.edit().putInt("notification_lead_minutes", minutes).apply()
    }

    fun triggerScheduleNotification(title: String, message: String) {
        if (!notificationsEnabled.value) return
        if (isPomodoroRunning.value && isAutoMuteNotificationsOnPomodoro.value) {
            mutedNotificationCountDuringSession.value += 1
            recentNotificationBanner.value = "🔕 Do Not Disturb Active: Silenced '$title' during active Pomodoro study session"
            return
        }
        recentNotificationBanner.value = "🔔 $title: $message"
    }

    fun dismissNotificationBanner() {
        recentNotificationBanner.value = null
    }

    fun toggleTaskReminder(id: String, enabled: Boolean) {
        smartPlanReminders.value = smartPlanReminders.value.map {
            if (it.id == id) it.copy(isEnabled = enabled) else it
        }
    }

    fun updateTaskReminderLeadTime(id: String, minutes: Int) {
        smartPlanReminders.value = smartPlanReminders.value.map {
            if (it.id == id) it.copy(leadMinutes = minutes) else it
        }
    }

    fun addTaskReminder(title: String, module: String, time: String, leadMinutes: Int = 15) {
        val newRem = StudyTaskReminder(title = title, module = module, time = time, isEnabled = true, leadMinutes = leadMinutes)
        smartPlanReminders.value = smartPlanReminders.value + newRem
        triggerScheduleNotification("Study Session Reminder Set", "$title at $time ($leadMinutes min lead)")
    }

    fun deleteTaskReminder(id: String) {
        smartPlanReminders.value = smartPlanReminders.value.filterNot { it.id == id }
    }

    fun importStudyPlanReminders(planText: String): Int {
        val lines = planText.lines()
        val sessionLines = lines.filter { it.contains("Session", ignoreCase = true) || it.contains("Task", ignoreCase = true) || it.contains("•", ignoreCase = true) }
        var count = 0
        if (sessionLines.isNotEmpty()) {
            sessionLines.take(5).forEachIndexed { idx, line ->
                val title = line.substringAfter(":", line.substringAfter("]", line)).trim().takeIf { it.isNotBlank() } ?: "AI Study Session #${idx + 1}"
                val mod = if (line.contains("CSC3002F")) "CSC3002F" else if (line.contains("MTH3012S")) "MTH3012S" else "Study"
                val time = "Day ${idx + 1} at 10:00"
                addTaskReminder(title = title, module = mod, time = time, leadMinutes = 15)
                count++
            }
        } else {
            addTaskReminder("AI Study Plan Session 1", "AI Plan", "Tomorrow 09:00", 15)
            addTaskReminder("AI Study Plan Session 2", "AI Plan", "Tomorrow 14:00", 30)
            count = 2
        }
        return count
    }

    private var aiJob: kotlinx.coroutines.Job? = null

    // Actions - AI Assistant (Chuma AI Central Intelligence Orchestrator)
    fun sendAiPrompt(prompt: String, taskType: String = "general") {
        if (prompt.isBlank()) return
        val historySnapshot = aiMessages.value.toList()
        val currentList = aiMessages.value.toMutableList()
        currentList.add("User" to prompt)
        aiMessages.value = currentList
        isAiLoading.value = true

        val taskId = java.util.UUID.randomUUID().toString()

        aiJob?.cancel()
        aiJob = viewModelScope.launch {
            try {
                // Step 1: Queued & Intent Analysis
                chumaTaskDataStore.startTask(
                    taskId = taskId,
                    prompt = prompt,
                    taskType = taskType,
                    initialStep = "Analyzing query intent & capability permissions...",
                    totalSteps = 4
                )
                chumaTaskDataStore.updateStep(
                    taskId = taskId,
                    status = ChumaTaskStatus.ANALYZING_INTENT,
                    stepIndex = 1,
                    stepDescription = "Classifying query intent and capability verification...",
                    progress = 0.25f
                )

                val contextSnapshot = CanvasMateContext(
                    userProfile = userProfile.value,
                    timetableSlots = timetableSlots.value,
                    calendarEvents = calendarEvents.value,
                    academicTasks = academicTasks.value,
                    todoTasks = todoTasks.value,
                    gpaModules = gpaModules.value,
                    budgetItems = budgetItems.value,
                    vaultDocuments = vaultDocuments.value,
                    notes = notes.value,
                    shoppingItems = shoppingItems.value,
                    transportRequests = transportRequests.value,
                    foodOrders = foodOrders.value
                )

                // Step 2: Context Retrieval
                chumaTaskDataStore.updateStep(
                    taskId = taskId,
                    status = ChumaTaskStatus.RETRIEVING_CONTEXT,
                    stepIndex = 2,
                    stepDescription = "Gathering workspace context, modules, and schedule...",
                    progress = 0.50f
                )

                // Step 3: Tool Execution & Inference
                chumaTaskDataStore.updateStep(
                    taskId = taskId,
                    status = ChumaTaskStatus.EXECUTING_TOOLS,
                    stepIndex = 3,
                    stepDescription = "Consulting reasoning engine & offline/online inference...",
                    progress = 0.75f
                )

                var hasAddedAiMessage = false
                val executionContext = com.example.data.ai.orchestrator.ChumaExecutionContext(
                    userRequest = prompt,
                    conversationHistory = historySnapshot,
                    canvasContext = contextSnapshot,
                    isCancelled = { aiJob?.isCancelled == true },
                    onChunk = { chunk ->
                        if (!hasAddedAiMessage) {
                            hasAddedAiMessage = true
                            val list = aiMessages.value.toMutableList()
                            list.add("AI" to chunk)
                            aiMessages.value = list
                        } else {
                            val list = aiMessages.value.toMutableList()
                            if (list.isNotEmpty() && list.last().first == "AI") {
                                list[list.lastIndex] = "AI" to chunk
                                aiMessages.value = list
                            }
                        }
                    }
                )

                val orchestratorResult = chumaOrchestrator.process(prompt, executionContext)
                val response = orchestratorResult.output

                // Step 4: Synthesizing Final Output
                chumaTaskDataStore.updateStep(
                    taskId = taskId,
                    status = ChumaTaskStatus.SYNTHESIZING,
                    stepIndex = 4,
                    stepDescription = "Finalizing synthesis and formatting output...",
                    progress = 0.95f,
                    partialOutput = response.take(160)
                )

                chumaTaskDataStore.completeTask(taskId, response)

                val updated = aiMessages.value.toMutableList()
                if (hasAddedAiMessage && updated.isNotEmpty() && updated.last().first == "AI") {
                    updated[updated.lastIndex] = "AI" to response
                } else {
                    updated.add("AI" to response)
                }
                aiMessages.value = updated
            } catch (e: kotlinx.coroutines.CancellationException) {
                chumaTaskDataStore.cancelTask(taskId)
                val updated = aiMessages.value.toMutableList()
                updated.add("AI" to "Response generation stopped.")
                aiMessages.value = updated
            } catch (e: Throwable) {
                e.printStackTrace()
                chumaTaskDataStore.failTask(taskId, e.localizedMessage ?: "Unknown execution error")
                val updated = aiMessages.value.toMutableList()
                updated.add("AI" to "I'm having trouble connecting to my AI service right now. Please check your internet connection and try again.")
                aiMessages.value = updated
            } finally {
                isAiLoading.value = false
            }
        }
    }

    /**
     * Executes conversational turn for Chuma Voice Mode V1.
     * Records User and AI transcripts in the shared Chuma conversation history,
     * routes query through the existing reasoning and tools engine,
     * and delivers the synthesized response callback for instant TTS playback.
     */
    fun sendVoicePrompt(
        prompt: String,
        onChunk: ((String) -> Unit)? = null,
        onResponse: (String) -> Unit
    ) {
        if (prompt.isBlank()) return
        val historySnapshot = aiMessages.value.toList()
        val currentList = aiMessages.value.toMutableList()
        currentList.add("User" to prompt)
        aiMessages.value = currentList
        isAiLoading.value = true

        val taskId = java.util.UUID.randomUUID().toString()

        aiJob?.cancel()
        aiJob = viewModelScope.launch {
            try {
                chumaTaskDataStore.startTask(
                    taskId = taskId,
                    prompt = prompt,
                    taskType = "voice",
                    initialStep = "Processing voice turn through Chuma AI...",
                    totalSteps = 3
                )

                val contextSnapshot = CanvasMateContext(
                    userProfile = userProfile.value,
                    timetableSlots = timetableSlots.value,
                    calendarEvents = calendarEvents.value,
                    academicTasks = academicTasks.value,
                    todoTasks = todoTasks.value,
                    gpaModules = gpaModules.value,
                    budgetItems = budgetItems.value,
                    vaultDocuments = vaultDocuments.value,
                    notes = notes.value,
                    shoppingItems = shoppingItems.value,
                    transportRequests = transportRequests.value,
                    foodOrders = foodOrders.value
                )

                val executionContext = com.example.data.ai.orchestrator.ChumaExecutionContext(
                    userRequest = prompt,
                    conversationHistory = historySnapshot,
                    canvasContext = contextSnapshot,
                    isCancelled = { aiJob?.isCancelled == true },
                    onChunk = onChunk
                )

                val orchestratorResult = chumaOrchestrator.process(prompt, executionContext)
                val response = orchestratorResult.output

                chumaTaskDataStore.completeTask(taskId, response)

                val updated = aiMessages.value.toMutableList()
                updated.add("AI" to response)
                aiMessages.value = updated

                onResponse(response)
            } catch (e: kotlinx.coroutines.CancellationException) {
                chumaTaskDataStore.cancelTask(taskId)
            } catch (e: Throwable) {
                e.printStackTrace()
                chumaTaskDataStore.failTask(taskId, e.localizedMessage ?: "Unknown execution error")
                val fallback = "I'm having trouble connecting right now. Please check your internet connection and try again."
                val updated = aiMessages.value.toMutableList()
                updated.add("AI" to fallback)
                aiMessages.value = updated
                onResponse(fallback)
            } finally {
                isAiLoading.value = false
            }
        }
    }

    fun cancelAiGeneration() {
        val currentTask = activeChumaTaskState.value
        val taskId = currentTask.taskId
        viewModelScope.launch {
            if (taskId.isNotBlank() && currentTask.isExecuting) {
                chumaTaskDataStore.cancelTask(taskId)
            } else {
                val direct = chumaTaskDataStore.getCurrentState()
                if (direct.isExecuting) {
                    chumaTaskDataStore.cancelTask(direct.taskId)
                }
            }
        }
        aiJob?.cancel()
        isAiLoading.value = false
    }

    fun retryLastAiPrompt() {
        val lastUserMessage = aiMessages.value.lastOrNull { it.first == "User" }?.second
        if (!lastUserMessage.isNullOrBlank()) {
            sendAiPrompt(lastUserMessage)
        }
    }

    fun resumeInterruptedChumaTask() {
        val currentTask = activeChumaTaskState.value
        if (currentTask.prompt.isNotBlank()) {
            sendAiPrompt(currentTask.prompt, currentTask.taskType)
        }
    }

    fun clearActiveChumaTask() {
        viewModelScope.launch {
            chumaTaskDataStore.clearState()
        }
    }

    fun importStudyPlanToCalendar(aiText: String): Int {
        var addedCount = 0
        val lines = aiText.lines()
        val sessionLines = lines.filter { it.contains("[Session", ignoreCase = true) || it.contains("• [Session", ignoreCase = true) }

        if (sessionLines.isNotEmpty()) {
            sessionLines.forEachIndexed { idx, line ->
                val titlePart = line.substringAfter("-", line.substringAfter("]", line)).trim()
                val eventTitle = if (titlePart.isNotBlank()) "Study Session: $titlePart" else "Study Session #${idx + 1}"
                val dayOffset = idx % 7
                val date = "2026-08-${10 + dayOffset}"
                val time = if (line.contains("18:00")) "18:00" else "08:00"
                addCalendarEvent(
                    CalendarEvent(
                        title = eventTitle,
                        date = date,
                        time = time,
                        category = "Study Session",
                        location = "Library / Study Desk",
                        description = "Added from AI Personalized Study Plan"
                    )
                )
                addedCount++
            }
        } else {
            val defaultSessions = listOf(
                CalendarEvent(title = "Study Session: CSC3002F Review", date = "2026-08-10", time = "08:00", category = "Study Session", description = "AI Study Plan"),
                CalendarEvent(title = "Study Session: MTH3012S Problem Sets", date = "2026-08-11", time = "18:00", category = "Study Session", description = "AI Study Plan"),
                CalendarEvent(title = "Study Session: Exam Past Papers", date = "2026-08-12", time = "08:00", category = "Study Session", description = "AI Study Plan")
            )
            defaultSessions.forEach { addCalendarEvent(it) }
            addedCount = defaultSessions.size
        }
        return addedCount
    }

    fun importStudyPlanToTodoList(aiText: String): Int {
        var addedCount = 0
        val lines = aiText.lines()
        val taskLines = lines.filter { it.contains("[Task", ignoreCase = true) || it.contains("• [Task", ignoreCase = true) }

        if (taskLines.isNotEmpty()) {
            taskLines.forEachIndexed { idx, line ->
                val titlePart = line.substringAfter(":", line.substringAfter("]", line)).trim()
                val priority = if (line.contains("High Priority", ignoreCase = true)) "High" else if (line.contains("Medium Priority", ignoreCase = true)) "Medium" else "Low"
                val taskTitle = if (titlePart.isNotBlank()) titlePart else "Study Task #${idx + 1}"
                val dueDate = "2026-08-${12 + idx}"
                addTodoTask(
                    TodoTask(
                        title = taskTitle,
                        priority = priority,
                        isCompleted = false,
                        dueDate = dueDate
                    )
                )
                addedCount++
            }
        } else {
            val defaultTasks = listOf(
                TodoTask(title = "AI Plan: CSC3002F Project Draft", priority = "High", dueDate = "2026-08-12"),
                TodoTask(title = "AI Plan: MTH3012S Tutorial Set", priority = "Medium", dueDate = "2026-08-13"),
                TodoTask(title = "AI Plan: Past Exam Questions Q1-Q4", priority = "High", dueDate = "2026-08-14")
            )
            defaultTasks.forEach { addTodoTask(it) }
            addedCount = defaultTasks.size
        }
        return addedCount
    }

    fun importStudyPlanToNotes(aiText: String) {
        addNote(
            NoteItem(
                title = "Personalized Study Plan (August 2026)",
                content = aiText,
                folder = "Study Plans",
                isPinned = true,
                tags = "AI,StudyPlan,2026"
            )
        )
    }

    // Actions - Flashcard Decks & Active Recall Cards
    fun addFlashcardDeck(deck: FlashcardDeck, initialCards: List<Pair<String, String>> = emptyList()) {
        viewModelScope.launch {
            val deckId = repository.addFlashcardDeck(deck)
            initialCards.forEach { (q, a) ->
                repository.addFlashcard(
                    Flashcard(
                        deckId = deckId,
                        question = q,
                        answer = a,
                        isMastered = false,
                        timesReviewed = 0
                    )
                )
            }
            triggerScheduleNotification("Flashcard Deck Created", "'${deck.title}' ready for Active Recall!")
        }
    }

    fun deleteFlashcardDeck(deckId: Long) {
        viewModelScope.launch {
            repository.deleteFlashcardDeck(deckId)
        }
    }

    fun addFlashcard(card: Flashcard) {
        viewModelScope.launch {
            repository.addFlashcard(card)
        }
    }

    fun updateFlashcard(card: Flashcard) {
        viewModelScope.launch {
            repository.updateFlashcard(card)
        }
    }

    fun deleteFlashcard(cardId: Long) {
        viewModelScope.launch {
            repository.deleteFlashcard(cardId)
        }
    }

    fun createDeckFromNote(note: NoteItem) {
        viewModelScope.launch {
            val lines = note.content.lines().map { it.trim() }.filter { it.isNotBlank() }
            val extractedCards = mutableListOf<Pair<String, String>>()

            // Parse bullet points or key-value pairs or paragraphs
            var currentQ = ""
            var currentA = ""

            lines.forEach { line ->
                if (line.contains(":") || line.contains("-") || line.contains("?")) {
                    if (line.contains(":")) {
                        val parts = line.split(":", limit = 2)
                        val q = parts[0].removePrefix("•").removePrefix("-").trim()
                        val a = parts[1].trim()
                        if (q.length > 3 && a.isNotBlank()) {
                            extractedCards.add("What is ${q}?" to a)
                        }
                    } else if (line.endsWith("?")) {
                        currentQ = line.removePrefix("•").removePrefix("-").trim()
                    } else if (currentQ.isNotBlank()) {
                        currentA = line.removePrefix("•").removePrefix("-").trim()
                        extractedCards.add(currentQ to currentA)
                        currentQ = ""
                        currentA = ""
                    } else if (line.startsWith("•") || line.startsWith("-")) {
                        val cleanText = line.removePrefix("•").removePrefix("-").trim()
                        extractedCards.add("Key Concept from ${note.title}" to cleanText)
                    }
                } else if (line.length > 15) {
                    extractedCards.add("Concept in ${note.title}" to line)
                }
            }

            if (extractedCards.isEmpty()) {
                extractedCards.add("Summary of ${note.title}" to note.content.take(150))
            }

            val newDeck = FlashcardDeck(
                title = note.title,
                subject = if (note.folder != "All") note.folder else "General Notes",
                description = "Auto-generated active recall deck from note content.",
                noteId = note.id
            )

            val deckId = repository.addFlashcardDeck(newDeck)
            extractedCards.take(10).forEach { (q, a) ->
                repository.addFlashcard(
                    Flashcard(
                        deckId = deckId,
                        question = q,
                        answer = a,
                        isMastered = false,
                        timesReviewed = 0
                    )
                )
            }

            triggerScheduleNotification(
                title = "⚡ Flashcard Deck Generated!",
                message = "Converted note '${note.title}' into ${extractedCards.size.coerceAtMost(10)} Active Recall flashcards."
            )
        }
    }

    // Actions - Shopping Items
    fun addShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.addShoppingItem(item)
        }
    }

    fun toggleShoppingItemPurchased(item: ShoppingItem) {
        viewModelScope.launch {
            repository.updateShoppingItem(item.copy(isPurchased = !item.isPurchased))
        }
    }

    fun deleteShoppingItem(id: Long) {
        viewModelScope.launch {
            repository.deleteShoppingItem(id)
        }
    }

    // Actions - Transport Hub (with automatic Budget categorization!)
    fun requestTransport(origin: String, destination: String, method: String, costZar: Double, durationMins: Int, distanceKm: Double) {
        viewModelScope.launch {
            val req = TransportRequest(
                origin = origin,
                destination = destination,
                transportMethod = method,
                estimatedCostZar = costZar,
                estimatedDurationMins = durationMins,
                distanceKm = distanceKm,
                status = "Completed"
            )
            repository.addTransportRequest(req)

            // Automatic Budget Integration
            if (costZar > 0) {
                repository.addBudgetItem(
                    BudgetItem(
                        title = "$method: $origin to $destination",
                        amount = costZar,
                        type = "Expense",
                        category = "Transport",
                        date = "2026-08-07"
                    )
                )
                triggerScheduleNotification(
                    title = "🚕 Transport & Budget Updated",
                    message = "Booked $method ($origin -> $destination) for R${"%.2f".format(costZar)}. Recorded under Transport budget."
                )
            } else {
                triggerScheduleNotification(
                    title = "🚌 Free Campus Transport",
                    message = "Scheduled $method ($origin -> $destination). No cost incurred!"
                )
            }
        }
    }

    // Actions - Food Hub (with automatic Budget categorization!)
    fun placeFoodOrder(restaurantName: String, category: String, summary: String, totalCostZar: Double) {
        viewModelScope.launch {
            val order = FoodOrder(
                restaurantName = restaurantName,
                category = category,
                itemsSummary = summary,
                totalCostZar = totalCostZar,
                status = "Delivered"
            )
            repository.addFoodOrder(order)

            // Automatic Budget Integration
            if (totalCostZar > 0) {
                repository.addBudgetItem(
                    BudgetItem(
                        title = "$restaurantName: $summary",
                        amount = totalCostZar,
                        type = "Expense",
                        category = "Food",
                        date = "2026-08-07"
                    )
                )
                triggerScheduleNotification(
                    title = "🍔 Food Order Placed & Categorized",
                    message = "R${"%.2f".format(totalCostZar)} order at $restaurantName added to your Food budget."
                )
            }
        }
    }

    // Actions - Payment Methods
    fun addPaymentMethod(method: PaymentMethodEntity) {
        viewModelScope.launch {
            repository.addPaymentMethod(method)
        }
    }

    fun deletePaymentMethod(id: Long) {
        viewModelScope.launch {
            repository.deletePaymentMethod(id)
        }
    }

    // Device Location & Geocoding Capabilities (play-services-location)
    val locationCapabilityState: StateFlow<CapabilityState> = DeviceCapabilityManager.locationState
    val currentDeviceLocation = MutableStateFlow<DeviceLocationInfo?>(null)
    val isLocating = MutableStateFlow(false)
    val geocodedSearchResults = MutableStateFlow<List<DeviceLocationInfo>>(emptyList())

    // Logic Loom Transport & Mobility Hub Service & Search States
    val transportHubService by lazy { com.example.data.transport.service.TransportHubService() }
    val transportSearchResult = MutableStateFlow<com.example.data.transport.model.TransportSearchResult?>(null)
    val isSearchingTransport = MutableStateFlow(false)
    val transportSearchOrigin = MutableStateFlow("")
    val transportSearchDestination = MutableStateFlow("")
    val transportSearchMode = MutableStateFlow(com.example.data.transport.model.TransportMode.ALL)
    val allTransitStations = MutableStateFlow<List<com.example.data.transport.model.TransitStation>>(emptyList())

    init {
        viewModelScope.launch {
            try {
                allTransitStations.value = transportHubService.getAllStations()
            } catch (e: Exception) {
                // Safe initialization
            }
        }
    }

    fun executeTransportSearch(origin: String, destination: String, mode: com.example.data.transport.model.TransportMode = transportSearchMode.value) {
        val cleanOrigin = origin.trim()
        val cleanDest = destination.trim()
        transportSearchOrigin.value = cleanOrigin
        transportSearchDestination.value = cleanDest
        transportSearchMode.value = mode

        if (cleanOrigin.isBlank() || cleanDest.isBlank()) {
            transportSearchResult.value = com.example.data.transport.model.TransportSearchResult(
                query = com.example.data.transport.model.TransportSearchQuery(cleanOrigin, cleanDest, mode),
                options = emptyList(),
                straightLineDistanceKm = null,
                sourcesConsulted = emptyList(),
                generalNotice = if (cleanOrigin.isBlank()) "Where are you starting from?" else "Where are you going?"
            )
            return
        }

        viewModelScope.launch {
            isSearchingTransport.value = true
            try {
                val query = com.example.data.transport.model.TransportSearchQuery(
                    origin = cleanOrigin,
                    destination = cleanDest,
                    preferredMode = mode
                )
                val result = transportHubService.searchTransport(query)
                transportSearchResult.value = result
            } catch (e: Exception) {
                transportSearchResult.value = com.example.data.transport.model.TransportSearchResult(
                    query = com.example.data.transport.model.TransportSearchQuery(cleanOrigin, cleanDest, mode),
                    options = emptyList(),
                    straightLineDistanceKm = null,
                    sourcesConsulted = emptyList(),
                    generalNotice = "Unable to retrieve transport routes at this moment: ${e.localizedMessage}"
                )
            } finally {
                isSearchingTransport.value = false
            }
        }
    }

    fun swapTransportLocations() {
        val temp = transportSearchOrigin.value
        transportSearchOrigin.value = transportSearchDestination.value
        transportSearchDestination.value = temp
        if (transportSearchOrigin.value.isNotBlank() && transportSearchDestination.value.isNotBlank()) {
            executeTransportSearch(transportSearchOrigin.value, transportSearchDestination.value, transportSearchMode.value)
        }
    }

    fun setTransportOriginFromDeviceLocation(address: String) {
        transportSearchOrigin.value = address
    }

    fun clearTransportSearch() {
        transportSearchOrigin.value = ""
        transportSearchDestination.value = ""
        transportSearchResult.value = null
    }

    fun refreshDeviceLocation() {
        viewModelScope.launch {
            isLocating.value = true
            try {
                val loc = DeviceCapabilityManager.getCurrentLocation(getApplication())
                currentDeviceLocation.value = loc
            } catch (e: Exception) {
                // Handled gracefully
            } finally {
                isLocating.value = false
            }
        }
    }

    fun handleLocationPermissionResult(isGranted: Boolean) {
        DeviceCapabilityManager.handleLocationPermissionResult(isGranted)
        if (isGranted) {
            refreshDeviceLocation()
        }
    }

    fun geocodeAddressQuery(query: String) {
        if (query.isBlank()) {
            geocodedSearchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            val results = DeviceCapabilityManager.geocodeAddress(getApplication(), query)
            geocodedSearchResults.value = results
        }
    }

    // Helper: Universal Search across All CanvasMate Modules
    fun performUniversalSearch(query: String): UniversalSearchResult {
        val q = query.trim().lowercase()
        if (q.isBlank()) return UniversalSearchResult()

        val matchedNotes = notes.value.filter { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) || it.folder.lowercase().contains(q) }
        val matchedVault = vaultDocuments.value.filter { it.title.lowercase().contains(q) || it.category.lowercase().contains(q) }
        val matchedTasks = academicTasks.value.filter { it.title.lowercase().contains(q) || it.module.lowercase().contains(q) }
        val matchedTodos = todoTasks.value.filter { it.title.lowercase().contains(q) }
        val matchedEvents = calendarEvents.value.filter { it.title.lowercase().contains(q) || it.location.lowercase().contains(q) }
        val matchedSlots = timetableSlots.value.filter { it.module.lowercase().contains(q) || it.venue.lowercase().contains(q) }
        val matchedBudget = budgetItems.value.filter { it.title.lowercase().contains(q) || it.category.lowercase().contains(q) }
        val matchedDecks = flashcardDecks.value.filter { it.title.lowercase().contains(q) || it.subject.lowercase().contains(q) }

        return UniversalSearchResult(
            notes = matchedNotes,
            vaultDocs = matchedVault,
            academicTasks = matchedTasks,
            todos = matchedTodos,
            calendarEvents = matchedEvents,
            timetableSlots = matchedSlots,
            budgetItems = matchedBudget,
            flashcardDecks = matchedDecks
        )
    }
}

data class UniversalSearchResult(
    val notes: List<NoteItem> = emptyList(),
    val vaultDocs: List<VaultDocument> = emptyList(),
    val academicTasks: List<AcademicTask> = emptyList(),
    val todos: List<TodoTask> = emptyList(),
    val calendarEvents: List<CalendarEvent> = emptyList(),
    val timetableSlots: List<TimetableSlot> = emptyList(),
    val budgetItems: List<BudgetItem> = emptyList(),
    val flashcardDecks: List<FlashcardDeck> = emptyList()
) {
    val isEmpty: Boolean get() = notes.isEmpty() && vaultDocs.isEmpty() && academicTasks.isEmpty() && todos.isEmpty() && calendarEvents.isEmpty() && timetableSlots.isEmpty() && budgetItems.isEmpty() && flashcardDecks.isEmpty()
    val totalCount: Int get() = notes.size + vaultDocs.size + academicTasks.size + todos.size + calendarEvents.size + timetableSlots.size + budgetItems.size + flashcardDecks.size
}

