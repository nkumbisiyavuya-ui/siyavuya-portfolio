package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.CanvasMateViewModel
import com.example.ui.navigation.NavRoutes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UniversalSearchDialog(
    viewModel: CanvasMateViewModel,
    onDismiss: () -> Unit,
    onNavigateTo: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResult = remember(searchQuery) { viewModel.performUniversalSearch(searchQuery) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Universal Life OS Search", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search docs, tasks, calendar, notes, budget...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (searchQuery.isBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ManageSearch, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Type anything to search across Logic Loom", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else if (searchResult.isEmpty) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No matching items found for '$searchQuery'", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (searchResult.notes.isNotEmpty()) {
                        item { Text("Notes (${searchResult.notes.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        items(searchResult.notes) { note ->
                            SearchResultCard(
                                title = note.title,
                                subtitle = note.content.take(60),
                                badge = note.folder,
                                icon = Icons.Default.Description
                            ) {
                                onDismiss()
                                onNavigateTo(NavRoutes.NOTES)
                            }
                        }
                    }

                    if (searchResult.vaultDocs.isNotEmpty()) {
                        item { Text("Document Vault (${searchResult.vaultDocs.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        items(searchResult.vaultDocs) { doc ->
                            SearchResultCard(
                                title = doc.title,
                                subtitle = "${doc.category} • ${doc.fileType}",
                                badge = doc.fileType,
                                icon = Icons.Default.Folder
                            ) {
                                onDismiss()
                                onNavigateTo(NavRoutes.VAULT)
                            }
                        }
                    }

                    if (searchResult.academicTasks.isNotEmpty()) {
                        item { Text("Academic Tasks (${searchResult.academicTasks.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        items(searchResult.academicTasks) { task ->
                            SearchResultCard(
                                title = task.title,
                                subtitle = "${task.module} • Due ${task.dueDate}",
                                badge = task.priority,
                                icon = Icons.Default.Assignment
                            ) {
                                onDismiss()
                                onNavigateTo(NavRoutes.ACADEMIC_PLANNER)
                            }
                        }
                    }

                    if (searchResult.calendarEvents.isNotEmpty()) {
                        item { Text("Calendar Events (${searchResult.calendarEvents.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        items(searchResult.calendarEvents) { event ->
                            SearchResultCard(
                                title = event.title,
                                subtitle = "${event.date} at ${event.time} • ${event.location}",
                                badge = event.category,
                                icon = Icons.Default.Event
                            ) {
                                onDismiss()
                                onNavigateTo(NavRoutes.CALENDAR)
                            }
                        }
                    }

                    if (searchResult.budgetItems.isNotEmpty()) {
                        item { Text("Budget Items (${searchResult.budgetItems.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        items(searchResult.budgetItems) { item ->
                            SearchResultCard(
                                title = item.title,
                                subtitle = "${item.category} • R${"%.2f".format(item.amount)}",
                                badge = item.type,
                                icon = Icons.Default.AttachMoney
                            ) {
                                onDismiss()
                                onNavigateTo(NavRoutes.BUDGET)
                            }
                        }
                    }

                    if (searchResult.flashcardDecks.isNotEmpty()) {
                        item { Text("Flashcard Decks (${searchResult.flashcardDecks.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        items(searchResult.flashcardDecks) { deck ->
                            SearchResultCard(
                                title = deck.title,
                                subtitle = deck.description,
                                badge = deck.subject,
                                icon = Icons.Default.AutoAwesome
                            ) {
                                onDismiss()
                                onNavigateTo(NavRoutes.FLASHCARDS)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            SuggestionChip(onClick = onClick, label = { Text(badge) })
        }
    }
}
