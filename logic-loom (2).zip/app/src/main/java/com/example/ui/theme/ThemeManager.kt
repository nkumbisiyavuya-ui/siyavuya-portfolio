package com.example.ui.theme

import android.content.Context
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Enum representing the 7 official theme choices for Logic Loom.
 */
enum class ThemeChoice(
    val id: String,
    val displayName: String,
    val description: String,
    val emoji: String,
    val primaryColor: Color,
    val primaryHoverColor: Color,
    val primaryDarkColor: Color,
    val lightAccentColor: Color,
    val secondaryBgColor: Color = Color(0xFFF8FAF9),
    val mainTextColor: Color = Color(0xFF111111),
    val secondaryTextColor: Color = Color(0xFF374151),
    val borderColor: Color = Color(0xFFE5E7EB)
) {
    LOGIC_LOOM(
        id = "logic_loom",
        displayName = "Logic Loom",
        description = "Deep Navy & Electric Blue",
        emoji = "⚡",
        primaryColor = Color(0xFF2563EB),
        primaryHoverColor = Color(0xFF1D4ED8),
        primaryDarkColor = Color(0xFF070D1E),
        lightAccentColor = Color(0xFFDBEAFE),
        secondaryBgColor = Color(0xFFF1F5F9),
        mainTextColor = Color(0xFF0F172A),
        secondaryTextColor = Color(0xFF475569),
        borderColor = Color(0xFFE2E8F0)
    ),
    CANVAS_GREEN(
        id = "canvas_green",
        displayName = "Emerald Sage",
        description = "Clean and balanced",
        emoji = "🌿",
        primaryColor = Color(0xFF14532D),
        primaryHoverColor = Color(0xFF166534),
        primaryDarkColor = Color(0xFF064E3B),
        lightAccentColor = Color(0xFFDCFCE7),
        secondaryBgColor = Color(0xFFF8FAF9)
    ),
    NAVY(
        id = "navy",
        displayName = "Navy",
        description = "Professional and focused",
        emoji = "🔵",
        primaryColor = Color(0xFF0F172A),
        primaryHoverColor = Color(0xFF1E293B),
        primaryDarkColor = Color(0xFF020617),
        lightAccentColor = Color(0xFFE2E8F0),
        secondaryBgColor = Color(0xFFF8FAFC)
    ),
    BURGANDY(
        id = "burgundy",
        displayName = "Burgundy",
        description = "Bold and confident",
        emoji = "🔴",
        primaryColor = Color(0xFF7F1D1D),
        primaryHoverColor = Color(0xFF991B1B),
        primaryDarkColor = Color(0xFF450A0A),
        lightAccentColor = Color(0xFFFEE2E2),
        secondaryBgColor = Color(0xFFFEF2F2)
    ),
    PINK(
        id = "pink",
        displayName = "Pink",
        description = "Bright and expressive",
        emoji = "🌸",
        primaryColor = Color(0xFF9D174D),
        primaryHoverColor = Color(0xFFBE185D),
        primaryDarkColor = Color(0xFF831843),
        lightAccentColor = Color(0xFFFCE7F3),
        secondaryBgColor = Color(0xFFFDF2F8)
    ),
    GOLD(
        id = "gold",
        displayName = "Gold",
        description = "Warm and optimistic",
        emoji = "🟡",
        primaryColor = Color(0xFF854D0E),
        primaryHoverColor = Color(0xFFA16207),
        primaryDarkColor = Color(0xFF713F12),
        lightAccentColor = Color(0xFFFEF3C7),
        secondaryBgColor = Color(0xFFFFFBEB)
    ),
    PURPLE(
        id = "purple",
        displayName = "Purple",
        description = "Creative and modern",
        emoji = "🟣",
        primaryColor = Color(0xFF581C87),
        primaryHoverColor = Color(0xFF6B21A8),
        primaryDarkColor = Color(0xFF3B0764),
        lightAccentColor = Color(0xFFF3E8FF),
        secondaryBgColor = Color(0xFFFAF5FF)
    ),
    OCEAN(
        id = "ocean",
        displayName = "Ocean",
        description = "Calm and refreshing",
        emoji = "🌊",
        primaryColor = Color(0xFF0F766E),
        primaryHoverColor = Color(0xFF115E59),
        primaryDarkColor = Color(0xFF134E4A),
        lightAccentColor = Color(0xFFCCFBF1),
        secondaryBgColor = Color(0xFFF0FDFA)
    );

    companion object {
        fun fromId(id: String?): ThemeChoice {
            return entries.find { it.id == id || it.name == id } ?: LOGIC_LOOM
        }
    }
}

/**
 * ThemeData holds design tokens provided globally via CompositionLocal.
 */
@Immutable
data class ThemeData(
    val primary: Color = Color(0xFF2563EB),
    val primaryHover: Color = Color(0xFF1D4ED8),
    val primaryDark: Color = Color(0xFF070D1E),
    val lightAccent: Color = Color(0xFFDBEAFE),
    val background: Color = Color(0xFFFFFFFF),
    val surface: Color = Color(0xFFFFFFFF),
    val secondaryBg: Color = Color(0xFFF1F5F9),
    val mainText: Color = Color(0xFF0F172A),
    val secondaryText: Color = Color(0xFF475569),
    val mutedText: Color = Color(0xFF94A3B8),
    val border: Color = Color(0xFFE2E8F0),
    val success: Color = Color(0xFF10B981),
    val error: Color = Color(0xFFEF4444),
    val warning: Color = Color(0xFFF59E0B)
) {
    companion object {
        fun fromChoice(choice: ThemeChoice, isDark: Boolean = false): ThemeData {
            return if (isDark) {
                if (choice == ThemeChoice.LOGIC_LOOM) {
                    ThemeData(
                        primary = Color(0xFF2563EB),
                        primaryHover = Color(0xFF1D4ED8),
                        primaryDark = Color(0xFF070D1E),
                        lightAccent = Color(0xFF06B6D4),
                        background = Color(0xFF070D1E),
                        surface = Color(0xFF0F1B2E),
                        secondaryBg = Color(0xFF16243C),
                        mainText = Color(0xFFF8FAFC),
                        secondaryText = Color(0xFF94A3B8),
                        mutedText = Color(0xFF64748B),
                        border = Color(0xFF1E2F4D)
                    )
                } else {
                    ThemeData(
                        primary = choice.lightAccentColor,
                        primaryHover = choice.lightAccentColor,
                        primaryDark = choice.primaryColor,
                        lightAccent = choice.primaryColor,
                        background = Color(0xFF0F172A),
                        surface = Color(0xFF1E293B),
                        secondaryBg = Color(0xFF334155),
                        mainText = Color(0xFFFFFFFF),
                        secondaryText = Color(0xFFCBD5E1),
                        mutedText = Color(0xFF94A3B8),
                        border = Color(0xFF475569)
                    )
                }
            } else {
                ThemeData(
                    primary = choice.primaryColor,
                    primaryHover = choice.primaryHoverColor,
                    primaryDark = choice.primaryDarkColor,
                    lightAccent = choice.lightAccentColor,
                    background = Color(0xFFFFFFFF),
                    surface = Color(0xFFFFFFFF),
                    secondaryBg = choice.secondaryBgColor,
                    mainText = choice.mainTextColor,
                    secondaryText = choice.secondaryTextColor,
                    mutedText = Color(0xFF6B7280),
                    border = choice.borderColor
                )
            }
        }
    }
}

/**
 * CompositionLocal to globally access theme tokens.
 */
val LocalThemeData = staticCompositionLocalOf { ThemeData() }

private val Context.themeDataStore: DataStore<Preferences> by preferencesDataStore(name = "logicloom_theme_datastore")

/**
 * DataStore repository for persisting user theme selection.
 */
class ThemeRepository(private val context: Context) {
    private val dataStore = context.themeDataStore

    companion object {
        val SELECTED_THEME_KEY = stringPreferencesKey("selected_color_palette")
        val IS_DARK_THEME_KEY = booleanPreferencesKey("dark_theme_mode")
    }

    val selectedThemeFlow: Flow<ThemeChoice> = dataStore.data.map { preferences ->
        val themeId = preferences[SELECTED_THEME_KEY] ?: ThemeChoice.CANVAS_GREEN.id
        ThemeChoice.fromId(themeId)
    }

    val isDarkThemeFlow: Flow<Boolean?> = dataStore.data.map { preferences ->
        preferences[IS_DARK_THEME_KEY]
    }

    suspend fun saveSelectedTheme(choice: ThemeChoice) {
        dataStore.edit { preferences ->
            preferences[SELECTED_THEME_KEY] = choice.id
        }
    }

    suspend fun saveIsDarkTheme(isDark: Boolean?) {
        dataStore.edit { preferences ->
            if (isDark == null) {
                preferences.remove(IS_DARK_THEME_KEY)
            } else {
                preferences[IS_DARK_THEME_KEY] = isDark
            }
        }
    }

    // Synchronous helper methods for callers that require immediate values
    fun getSelectedTheme(): ThemeChoice = runBlocking {
        selectedThemeFlow.first()
    }

    fun setSelectedTheme(choice: ThemeChoice) {
        runBlocking {
            saveSelectedTheme(choice)
        }
    }

    fun getIsDarkTheme(): Boolean? = runBlocking {
        isDarkThemeFlow.first()
    }

    fun setIsDarkTheme(isDark: Boolean?) {
        runBlocking {
            saveIsDarkTheme(isDark)
        }
    }
}

/**
 * ThemeManager manages theme state and persistence across the application.
 */
class ThemeManager(
    private val repository: ThemeRepository,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {
    val currentTheme: StateFlow<ThemeChoice> = repository.selectedThemeFlow
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = repository.getSelectedTheme()
        )

    val isDarkTheme: StateFlow<Boolean?> = repository.isDarkThemeFlow
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = repository.getIsDarkTheme()
        )

    val themeData: StateFlow<ThemeData> = currentTheme
        .map { choice -> ThemeData.fromChoice(choice) }
        .stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = ThemeData.fromChoice(currentTheme.value)
        )

    fun selectTheme(choice: ThemeChoice) {
        scope.launch {
            repository.saveSelectedTheme(choice)
        }
    }

    fun setDarkTheme(isDark: Boolean?) {
        scope.launch {
            repository.saveIsDarkTheme(isDark)
        }
    }

    /**
     * Verifies contrast ratio of the specified [choice] (or active theme) against a background (defaults to white).
     */
    fun verifyThemeContrast(
        choice: ThemeChoice = currentTheme.value,
        background: Color = Color.White,
        minRatio: Double = 4.5
    ): Boolean {
        return verifyContrastRatio(choice.primaryColor, background, minRatio)
    }

    /**
     * Returns the contrast ratio of the specified [choice] against a background (defaults to white).
     */
    fun getThemeContrastRatio(
        choice: ThemeChoice = currentTheme.value,
        background: Color = Color.White
    ): Double {
        return calculateContrastRatio(choice.primaryColor, background)
    }

    /**
     * Verifies contrast ratios for all seven themes against white background.
     */
    fun verifyAllThemesContrast(
        background: Color = Color.White,
        minRatio: Double = 4.5
    ): Map<ThemeChoice, Boolean> {
        return verifyAllThemesContrastAgainstWhite(background, minRatio)
    }

    companion object {
        /**
         * Calculates relative luminance of an sRGB [Color] according to WCAG 2.1 guidelines.
         */
        fun calculateLuminance(color: Color): Double {
            fun convertComponent(component: Float): Double {
                val c = component.toDouble()
                return if (c <= 0.04045) {
                    c / 12.92
                } else {
                    Math.pow((c + 0.055) / 1.055, 2.4)
                }
            }

            val r = convertComponent(color.red)
            val g = convertComponent(color.green)
            val b = convertComponent(color.blue)

            return 0.2126 * r + 0.7152 * g + 0.0722 * b
        }

        /**
         * Calculates the contrast ratio between two colors according to WCAG 2.1.
         * Returns a ratio >= 1.0 (e.g., 4.5 means 4.5:1).
         */
        fun calculateContrastRatio(color1: Color, color2: Color = Color.White): Double {
            val l1 = calculateLuminance(color1)
            val l2 = calculateLuminance(color2)
            val lighter = maxOf(l1, l2)
            val darker = minOf(l1, l2)
            return (lighter + 0.05) / (darker + 0.05)
        }

        /**
         * Verifies whether a color meets the WCAG 2.1 minimum contrast ratio against a background (defaults to white).
         * WCAG 2.1 AA standard for normal text requires a minimum ratio of 4.5:1.
         */
        fun verifyContrastRatio(
            color: Color,
            background: Color = Color.White,
            minRatio: Double = 4.5
        ): Boolean {
            return calculateContrastRatio(color, background) >= minRatio
        }

        /**
         * Verifies contrast ratios for all seven themes' primary colors against a background (defaults to white),
         * ensuring each meets WCAG 2.1 accessibility standards (minimum 4.5:1 ratio).
         */
        fun verifyAllThemesContrastAgainstWhite(
            background: Color = Color.White,
            minRatio: Double = 4.5
        ): Map<ThemeChoice, Boolean> {
            return ThemeChoice.entries.associateWith { choice ->
                verifyContrastRatio(choice.primaryColor, background, minRatio)
            }
        }

        /**
         * Returns true if all seven official themes pass WCAG 2.1 AA accessibility standards (min 4.5:1 ratio).
         */
        fun checkAllThemesPassWCAG(
            background: Color = Color.White,
            minRatio: Double = 4.5
        ): Boolean {
            return ThemeChoice.entries.all { choice ->
                verifyContrastRatio(choice.primaryColor, background, minRatio)
            }
        }
    }
}
