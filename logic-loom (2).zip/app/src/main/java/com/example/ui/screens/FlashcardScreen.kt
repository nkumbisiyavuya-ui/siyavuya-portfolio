package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.Flashcard
import com.example.data.local.FlashcardDeck
import com.example.data.local.NoteItem
import com.example.ui.CanvasMateViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlashcardScreen(
    viewModel: CanvasMateViewModel,
    onNavigateToNotes: () -> Unit = {}
) {
    val decks by viewModel.flashcardDecks.collectAsState()
    val allCards by viewModel.allFlashcards.collectAsState()
    val notes by viewModel.notes.collectAsState()

    var activeStudyDeck by remember { mutableStateOf<FlashcardDeck?>(null) }
    var editingDeck by remember { mutableStateOf<FlashcardDeck?>(null) }
    var selectedSubjectFilter by remember { mutableStateOf("All") }
    var showCreateDeckDialog by remember { mutableStateOf(false) }
    var showCreateFromNotesDialog by remember { mutableStateOf(false) }

    val subjects = remember(decks) {
        listOf("All") + decks.map { it.subject }.distinct().filter { it.isNotBlank() }
    }

    val filteredDecks = decks.filter { deck ->
        if (selectedSubjectFilter == "All") true else deck.subject == selectedSubjectFilter
    }

    // If active study mode is open
    if (activeStudyDeck != null) {
        val currentDeck = activeStudyDeck!!
        val deckCards = allCards.filter { it.deckId == currentDeck.id }

        ActiveRecallTestView(
            deck = currentDeck,
            cards = deckCards,
            onCardMasteryChanged = { card, isMastered ->
                viewModel.updateFlashcard(card.copy(isMastered = isMastered, timesReviewed = card.timesReviewed + 1))
            },
            onCloseTest = { activeStudyDeck = null }
        )
        return
    }

    // If deck card manager is open
    if (editingDeck != null) {
        val currentDeck = editingDeck!!
        val deckCards = allCards.filter { it.deckId == currentDeck.id }

        DeckCardsEditorView(
            deck = currentDeck,
            cards = deckCards,
            onAddCard = { q, a ->
                viewModel.addFlashcard(Flashcard(deckId = currentDeck.id, question = q, answer = a))
            },
            onDeleteCard = { cardId ->
                viewModel.deleteFlashcard(cardId)
            },
            onClose = { editingDeck = null }
        )
        return
    }

    Scaffold(
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End) {
                SmallFloatingActionButton(
                    onClick = { showCreateFromNotesDialog = true },
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("From Notes", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }

                FloatingActionButton(
                    onClick = { showCreateDeckDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create Deck")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("Active Recall Flashcards", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Test retention with swipe-to-reveal answers & generate decks from your notes", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            // Subject Filter Chips
            if (subjects.size > 1) {
                ScrollableTabRow(
                    selectedTabIndex = subjects.indexOf(selectedSubjectFilter).coerceAtLeast(0),
                    divider = {}
                ) {
                    subjects.forEach { subj ->
                        FilterChip(
                            selected = selectedSubjectFilter == subj,
                            onClick = { selectedSubjectFilter = subj },
                            label = { Text(subj) },
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (filteredDecks.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Style, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No Flashcard Decks Yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Create a deck manually or tap 'From Notes' to auto-generate active recall cards directly from your class notes!",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showCreateFromNotesDialog = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate Deck from Notes")
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredDecks) { deck ->
                        val cards = allCards.filter { it.deckId == deck.id }
                        val masteredCount = cards.count { it.isMastered }
                        val totalCards = cards.size
                        val progressPercent = if (totalCards > 0) (masteredCount.toFloat() / totalCards) else 0f

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            SuggestionChip(
                                                onClick = {},
                                                label = { Text(deck.subject, style = MaterialTheme.typography.labelSmall) },
                                                colors = SuggestionChipDefaults.suggestionChipColors(
                                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                                    labelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                "$totalCards Cards",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(deck.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        if (deck.description.isNotBlank()) {
                                            Text(
                                                deck.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    IconButton(onClick = { viewModel.deleteFlashcardDeck(deck.id) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Deck", tint = MaterialTheme.colorScheme.error)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Mastery Progress Bar
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Active Recall Mastery", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${(progressPercent * 100).toInt()}% ($masteredCount/$totalCards)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { progressPercent },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = if (progressPercent >= 0.8f) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { activeStudyDeck = deck },
                                        enabled = totalCards > 0,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Start Test")
                                    }

                                    OutlinedButton(
                                        onClick = { editingDeck = deck },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Edit Cards")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Create Manual Deck Dialog
    if (showCreateDeckDialog) {
        var deckTitle by remember { mutableStateOf("") }
        var deckSubject by remember { mutableStateOf("CSC3002F") }
        var deckDesc by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateDeckDialog = false },
            title = { Text("Create New Flashcard Deck") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = deckTitle,
                        onValueChange = { deckTitle = it },
                        label = { Text("Deck Title") },
                        placeholder = { Text("e.g. Distributed Systems Exam Terms") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = deckSubject,
                        onValueChange = { deckSubject = it },
                        label = { Text("Subject / Course Code") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = deckDesc,
                        onValueChange = { deckDesc = it },
                        label = { Text("Description (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (deckTitle.isNotBlank()) {
                            viewModel.addFlashcardDeck(
                                FlashcardDeck(
                                    title = deckTitle,
                                    subject = deckSubject.ifBlank { "General" },
                                    description = deckDesc
                                )
                            )
                            showCreateDeckDialog = false
                        }
                    }
                ) { Text("Create Deck") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDeckDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Create Deck From Notes Dialog
    if (showCreateFromNotesDialog) {
        AlertDialog(
            onDismissRequest = { showCreateFromNotesDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Deck from Notes")
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Select a note to automatically parse key concepts into Q&A active recall flashcards:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (notes.isEmpty()) {
                        Text("No notes found in workspace. Create notes first or click below to open Notes.", style = MaterialTheme.typography.bodyMedium)
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.heightIn(max = 260.dp)
                        ) {
                            items(notes) { note ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.createDeckFromNote(note)
                                            showCreateFromNotesDialog = false
                                        },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(note.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text("${note.folder} • ${note.content.length} chars", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (notes.isEmpty()) {
                    Button(
                        onClick = {
                            showCreateFromNotesDialog = false
                            onNavigateToNotes()
                        }
                    ) { Text("Go to Notes") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFromNotesDialog = false }) { Text("Close") }
            }
        )
    }
}

/**
 * Interactive Active Recall Test Screen with 3D Flip & Swipe Gestures
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveRecallTestView(
    deck: FlashcardDeck,
    cards: List<Flashcard>,
    onCardMasteryChanged: (Flashcard, Boolean) -> Unit,
    onCloseTest: () -> Unit
) {
    var currentIndex by remember { mutableIntStateOf(0) }
    var isAnswerRevealed by remember { mutableStateOf(false) }
    var masteredInSessionCount by remember { mutableIntStateOf(0) }
    var needsReviewInSessionCount by remember { mutableIntStateOf(0) }
    var isTestFinished by remember { mutableStateOf(false) }

    val totalCards = cards.size
    val currentCard = if (currentIndex in cards.indices) cards[currentIndex] else null

    // Card Flip Animation Angle
    val rotationAngle by animateFloatAsState(
        targetValue = if (isAnswerRevealed) 180f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "flip_animation"
    )

    // Swipe Gesture Offset
    var offsetX by remember { mutableFloatStateOf(0f) }

    fun nextCard(isMastered: Boolean) {
        if (currentCard != null) {
            onCardMasteryChanged(currentCard, isMastered)
            if (isMastered) masteredInSessionCount++ else needsReviewInSessionCount++
        }
        offsetX = 0f
        isAnswerRevealed = false
        if (currentIndex + 1 < totalCards) {
            currentIndex++
        } else {
            isTestFinished = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Active Recall: ${deck.title}", style = MaterialTheme.typography.titleMedium, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onCloseTest) {
                        Icon(Icons.Default.Close, contentDescription = "Close Test")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isTestFinished || currentCard == null) {
                // Session Summary View
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🎉 Active Recall Test Complete!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("You reviewed all $totalCards flashcards in '${deck.title}'.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(20.dp))

                        val scorePercent = if (totalCards > 0) ((masteredInSessionCount.toFloat() / totalCards) * 100).toInt() else 0

                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .clip(CircleShape)
                                .background(if (scorePercent >= 70) Color(0xFF10B981) else MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$scorePercent%", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Retention", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.9f))
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$masteredInSessionCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                Text("Mastered (Got It)", style = MaterialTheme.typography.labelMedium)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$needsReviewInSessionCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                Text("Needs Practice", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                currentIndex = 0
                                isAnswerRevealed = false
                                masteredInSessionCount = 0
                                needsReviewInSessionCount = 0
                                isTestFinished = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Restart Test Session")
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = onCloseTest,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Back to Flashcards Overview")
                        }
                    }
                }
            } else {
                // Test In-Progress View
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Card ${currentIndex + 1} of $totalCards", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF10B981).copy(alpha = 0.2f)
                        ) {
                            Text("✅ $masteredInSessionCount", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer
                        ) {
                            Text("❌ $needsReviewInSessionCount", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { (currentIndex + 1).toFloat() / totalCards },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Interactive 3D Flip Card with Drag/Swipe Gestures
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .offset { IntOffset(offsetX.roundToInt(), 0) }
                        .graphicsLayer {
                            rotationY = rotationAngle
                            cameraDistance = 12 * density
                            rotationZ = offsetX / 25f
                        }
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragEnd = {
                                    if (offsetX > 200f) {
                                        nextCard(isMastered = true)
                                    } else if (offsetX < -200f) {
                                        nextCard(isMastered = false)
                                    } else {
                                        offsetX = 0f
                                    }
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    offsetX += dragAmount.x
                                }
                            )
                        }
                        .clickable {
                            isAnswerRevealed = !isAnswerRevealed
                        }
                ) {
                    Card(
                        modifier = Modifier.fillMaxSize(),
                        shape = RoundedCornerShape(24.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (rotationAngle > 90f) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // Show Question (Front) when rotation < 90 deg, Answer (Back) when rotation > 90 deg
                            if (rotationAngle <= 90f) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text("QUESTION", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                                        )
                                        Text("Tap to Reveal Answer 🔄", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }

                                    Text(
                                        text = currentCard.question,
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 12.dp)
                                    )

                                    Text(
                                        "👈 Swipe Left: Needs Practice | Swipe Right: Got It! 👉",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                // Mirror the Back Content horizontally so text isn't reversed in 3D Y-rotation!
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer { rotationY = 180f },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text("ANSWER & RECALL", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(
                                                containerColor = MaterialTheme.colorScheme.primary,
                                                labelColor = Color.White
                                            )
                                        )
                                        Text("Tap to Hide 🔄", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }

                                    Text(
                                        text = currentCard.answer,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 12.dp)
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                                    ) {
                                        Text(
                                            "Grade your active recall performance using the swipe buttons below.",
                                            modifier = Modifier.padding(8.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }

                            // Swipe Feedback Badge Overlays
                            if (offsetX > 50f) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF10B981),
                                    modifier = Modifier.align(Alignment.TopEnd)
                                ) {
                                    Text("✅ MASTERED!", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                                }
                            } else if (offsetX < -50f) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.align(Alignment.TopStart)
                                ) {
                                    Text("❌ NEEDS PRACTICE", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Direct Action Grade Buttons (Alternative to Drag Gesture)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { nextCard(isMastered = false) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Needs Practice")
                    }

                    Button(
                        onClick = { nextCard(isMastered = true) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Got It! (Mastered)")
                    }
                }
            }
        }
    }
}

/**
 * Deck Cards Editor View - Allows adding & managing Q&A pairs inside a deck
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeckCardsEditorView(
    deck: FlashcardDeck,
    cards: List<Flashcard>,
    onAddCard: (String, String) -> Unit,
    onDeleteCard: (Long) -> Unit,
    onClose: () -> Unit
) {
    var newQuestion by remember { mutableStateOf("") }
    var newAnswer by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Deck: ${deck.title}") },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Card")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("${cards.size} Flashcards in Deck", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Add custom questions & answers or delete existing cards.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            if (cards.isEmpty()) {
                Text("No cards in this deck yet. Tap '+' below to add your first question & answer pair!", style = MaterialTheme.typography.bodyMedium)
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(cards) { card ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Q: ${card.question}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("A: ${card.answer}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { onDeleteCard(card.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Flashcard") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newQuestion,
                        onValueChange = { newQuestion = it },
                        label = { Text("Question (Front)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newAnswer,
                        onValueChange = { newAnswer = it },
                        label = { Text("Answer / Recall Concept (Back)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newQuestion.isNotBlank() && newAnswer.isNotBlank()) {
                            onAddCard(newQuestion, newAnswer)
                            newQuestion = ""
                            newAnswer = ""
                            showAddDialog = false
                        }
                    }
                ) { Text("Add Card") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }
}
