package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =================================================================
// LOGIC LOOM OFFICIAL BRAND DESIGN TOKENS
// =================================================================

// Primary Foundation: Deep Navy / Midnight
val LogicLoomDeepNavy = Color(0xFF070D1E)
val LogicLoomMidnight = Color(0xFF0A1128)
val LogicLoomNavySurface = Color(0xFF0F1B2E)
val LogicLoomCharcoal = Color(0xFF16243C)
val LogicLoomDarkBorder = Color(0xFF1E2F4D)

// Primary Accent: Electric Blue
val LogicLoomElectricBlue = Color(0xFF2563EB)
val LogicLoomBlueHover = Color(0xFF1D4ED8)
val LogicLoomBlueLight = Color(0xFFDBEAFE)

// Secondary Accents: Cyan and Violet (used sparingly for gradients, AI states, highlights)
val LogicLoomCyan = Color(0xFF06B6D4)
val LogicLoomViolet = Color(0xFF8B5CF6)
val LogicLoomPurple = Color(0xFF7C3AED)

// Neutral Tokens (Light & Dark)
val LogicLoomWhite = Color(0xFFFFFFFF)
val LogicLoomOffWhite = Color(0xFFF8FAFC)
val LogicLoomTextPrimaryDark = Color(0xFFF8FAFC)
val LogicLoomTextSecondaryDark = Color(0xFF94A3B8)
val LogicLoomTextPrimaryLight = Color(0xFF0F172A)
val LogicLoomTextSecondaryLight = Color(0xFF475569)
val LogicLoomBorderLight = Color(0xFFE2E8F0)

// Status Colors
val LogicLoomSuccess = Color(0xFF10B981)
val LogicLoomError = Color(0xFFEF4444)
val LogicLoomWarning = Color(0xFFF59E0B)

// Aliases for Existing Design System Integration
val CanvasGreenPrimary = LogicLoomElectricBlue
val CanvasGreenHover = LogicLoomBlueHover
val CanvasGreenDark = LogicLoomDeepNavy
val CanvasGreenLight = LogicLoomBlueLight

val CanvasMateBackground = LogicLoomWhite
val CanvasMateSurface = LogicLoomWhite
val CanvasMateSecondaryBg = LogicLoomOffWhite
val CanvasMateMainText = LogicLoomTextPrimaryLight
val CanvasMateSecondaryText = LogicLoomTextSecondaryLight
val CanvasMateMutedText = LogicLoomTextSecondaryDark
val CanvasMateBorder = LogicLoomBorderLight

val CanvasMateSuccess = LogicLoomSuccess
val CanvasMateError = LogicLoomError
val CanvasMateWarning = LogicLoomWarning

// Brand Palette Tokens
val CanvasMateNavyPrimary = LogicLoomElectricBlue
val CanvasMateNavyDark = LogicLoomDeepNavy
val CanvasMateNavyLight = LogicLoomCyan

val CanvasMateCrimson = LogicLoomElectricBlue
val CanvasMateCrimsonDark = LogicLoomDeepNavy
val CanvasMateCrimsonLight = LogicLoomViolet

val CanvasMateWhite = LogicLoomWhite
val CanvasMateCoolGray = LogicLoomTextSecondaryDark
val CanvasMateDarkSurface = LogicLoomDeepNavy
val CanvasMateDarkCard = LogicLoomNavySurface
val CanvasMateDarkBorder = LogicLoomDarkBorder

// Backward Compatibility Aliases
val BluePrimary = LogicLoomElectricBlue
val BlueSecondary = LogicLoomBlueHover
val BlueDark = LogicLoomDeepNavy
val BlueLight = LogicLoomBlueLight

val DarkBackground = LogicLoomDeepNavy
val DarkSurface = LogicLoomNavySurface
val DarkSurfaceVariant = LogicLoomCharcoal

val LightBackground = LogicLoomWhite
val LightSurface = LogicLoomWhite
val LightSurfaceVariant = LogicLoomOffWhite

val SlateText = CanvasMateMainText
val GreyAccent = CanvasMateMutedText
val LightGreyBorder = CanvasMateBorder

val AccentSuccess = LogicLoomSuccess
val AccentWarning = LogicLoomWarning
val AccentError = LogicLoomError
val AccentPurple = LogicLoomViolet



