package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ai.StudyQuestionItem
import com.example.data.ai.StudyQuestionType
import com.example.data.ai.StudyQuestionsGeneratorConfig
import com.example.data.ai.StudyQuestionsQuiz
import com.example.data.local.NoteItem
import com.example.ui.CanvasMateViewModel
import kotlinx.coroutines.launch

/**
 * Dialog to configure and generate targeted study questions from student notes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyQuestionsGeneratorDialog(
    notes: List<NoteItem>,
    presetNote: NoteItem? = null,
    isGenerating: Boolean,
    onDismiss: () -> Unit,
    onGenerate: (StudyQuestionsGeneratorConfig) -> Unit
) {
    var selectedTab by remember { mutableStateOf(if (presetNote != null || notes.isNotEmpty()) 0 else 1) } // 0 = Saved Notes, 1 = Custom Text
    var selectedNote by remember { mutableStateOf<NoteItem?>(presetNote ?: notes.firstOrNull()) }
    var noteSearchQuery by remember { mutableStateOf("") }

    // Custom Note Form fields
    var customTitle by remember { mutableStateOf(presetNote?.title ?: "") }
    var customFolder by remember { mutableStateOf(presetNote?.folder ?: "General") }
    var customContent by remember { mutableStateOf(presetNote?.content ?: "") }

    // Configuration Settings
    var selectedFormat by remember { mutableStateOf("Mixed (MCQ + Conceptual + Applied)") }
    var selectedDifficulty by remember { mutableStateOf("University Level") }
    var questionCount by remember { mutableFloatStateOf(5f) }
    var selectedFocusGoal by remember { mutableStateOf("Active Recall & Conceptual Mastery") }

    val filteredNotes = notes.filter {
        it.title.contains(noteSearchQuery, ignoreCase = true) ||
                it.folder.contains(noteSearchQuery, ignoreCase = true) ||
                it.content.contains(noteSearchQuery, ignoreCase = true)
    }

    Dialog(
        onDismissRequest = { if (!isGenerating) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Quiz,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "🎯 Study Questions Generator",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Transform student notes into targeted active recall questions",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isGenerating
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Tabs: From Saved Notes vs Custom Note Input
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("From Saved Notes (${notes.size})", fontWeight = FontWeight.Medium) },
                        icon = { Icon(Icons.Default.LibraryBooks, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Paste / Custom Note", fontWeight = FontWeight.Medium) },
                        icon = { Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (selectedTab == 0) {
                        // Section: Select from Saved Notes
                        Text(
                            text = "1. Select Note to Test",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        if (notes.isEmpty()) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("No saved notes found yet.", fontWeight = FontWeight.Bold)
                                    Text("Switch to the 'Paste / Custom Note' tab to enter your lecture notes directly.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = noteSearchQuery,
                                onValueChange = { noteSearchQuery = it },
                                placeholder = { Text("Search your notes...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Note Selector List
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 160.dp)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                filteredNotes.forEach { note ->
                                    val isSelected = selectedNote?.id == note.id
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedNote = note },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = { selectedNote = note }
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = note.title,
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = note.content.take(70),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                                                Text(note.folder, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Section: Custom Note Input
                        Text(
                            text = "1. Enter Note Material",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = customTitle,
                            onValueChange = { customTitle = it },
                            label = { Text("Note Title / Topic") },
                            placeholder = { Text("e.g., Computer Systems - Memory Hierarchies & Caching") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = customFolder,
                            onValueChange = { customFolder = it },
                            label = { Text("Course Code / Subject") },
                            placeholder = { Text("e.g., CSC3002F or Economics") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = customContent,
                            onValueChange = { customContent = it },
                            label = { Text("Note Content / Lecture Summary") },
                            placeholder = { Text("Paste your lecture notes, key formulas, definitions, or code descriptions here...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(16.dp))

                    // 2. Question Format Preference
                    Text(
                        text = "2. Question Format",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val formats = listOf(
                        "Mixed (MCQ + Conceptual + Applied)",
                        "Multiple Choice Only",
                        "Conceptual Short Answer",
                        "True / False",
                        "Applied Scenarios & Problems"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        formats.forEach { fmt ->
                            FilterChip(
                                selected = selectedFormat == fmt,
                                onClick = { selectedFormat = fmt },
                                label = { Text(fmt, fontSize = 11.sp) },
                                leadingIcon = if (selectedFormat == fmt) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                } else null
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 3. Difficulty Level
                    Text(
                        text = "3. Target Difficulty",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val difficulties = listOf(
                        "Foundation & Key Terms",
                        "University Level",
                        "Advanced / Exam Sprint"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        difficulties.forEach { diff ->
                            FilterChip(
                                selected = selectedDifficulty == diff,
                                onClick = { selectedDifficulty = diff },
                                label = { Text(diff, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                leadingIcon = if (selectedDifficulty == diff) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                } else null
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. Number of Questions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "4. Number of Questions",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${questionCount.toInt()} Questions",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Slider(
                        value = questionCount,
                        onValueChange = { questionCount = it },
                        valueRange = 3f..10f,
                        steps = 6,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // 5. Focus Goal
                    Text(
                        text = "5. Pedagogical Focus",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val goals = listOf(
                        "Active Recall & Conceptual Mastery",
                        "Critical Reasoning & Edge Cases",
                        "Definitions, Formulas & Mechanics"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        goals.forEach { g ->
                            FilterChip(
                                selected = selectedFocusGoal == g,
                                onClick = { selectedFocusGoal = g },
                                label = { Text(g, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Button
                val effectiveTitle = if (selectedTab == 0) selectedNote?.title.orEmpty() else customTitle
                val effectiveContent = if (selectedTab == 0) selectedNote?.content.orEmpty() else customContent
                val effectiveFolder = if (selectedTab == 0) selectedNote?.folder ?: "General" else customFolder
                val isButtonEnabled = effectiveTitle.isNotBlank() && effectiveContent.isNotBlank() && !isGenerating

                Button(
                    onClick = {
                        onGenerate(
                            StudyQuestionsGeneratorConfig(
                                selectedNoteId = if (selectedTab == 0) selectedNote?.id else null,
                                noteTitle = effectiveTitle,
                                noteContent = effectiveContent,
                                folder = effectiveFolder,
                                questionFormat = selectedFormat,
                                difficulty = selectedDifficulty,
                                questionCount = questionCount.toInt(),
                                focusArea = selectedFocusGoal
                            )
                        )
                    },
                    enabled = isButtonEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("generate_study_questions_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyzing Notes & Generating Questions...")
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Generate Targeted Study Questions",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Interactive Study Questions Practice Card shown in chat messages.
 */
@Composable
fun StudyQuestionsQuizCard(
    quiz: StudyQuestionsQuiz,
    onOpenInteractiveQuiz: () -> Unit,
    onExportToFlashcards: () -> Unit,
    onExportToNotes: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Quiz,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🎯 Targeted Study Questions Ready",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "${quiz.questions.size} Questions generated from '${quiz.noteTitle}' (${quiz.difficulty})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Launch Interactive Mode Button
            Button(
                onClick = onOpenInteractiveQuiz,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Launch Interactive Practice & Self-Test Mode", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Action row: Export to Flashcards & Notes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onExportToFlashcards,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Flashcards", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onExportToNotes,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save to Notes", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Full Interactive Practice Dialog where students can test understanding,
 * select answers, see hints, reveal in-depth explanations, and mark mastery.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyQuestionsInteractiveQuizDialog(
    quiz: StudyQuestionsQuiz,
    onDismiss: () -> Unit,
    onOptionSelected: (questionId: Int, optionIndex: Int) -> Unit,
    onUserAnswerTextChange: (questionId: Int, text: String) -> Unit,
    onToggleRevealAnswer: (questionId: Int) -> Unit,
    onToggleMastered: (questionId: Int) -> Unit,
    onExportToFlashcards: (StudyQuestionsQuiz) -> Unit,
    onExportToNotes: (StudyQuestionsQuiz) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var showCopiedSnackbar by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f)
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Quiz, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = quiz.noteTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${quiz.folder} • ${quiz.difficulty} • ${quiz.questions.size} Questions",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mastery Progress Bar
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🧠 Understanding & Mastery Progress",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${quiz.masteredCount} of ${quiz.totalCount} Mastered (${quiz.masteryPercentage}%)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (quiz.masteryPercentage >= 80) Color(0xFF16A34A) else MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { if (quiz.totalCount > 0) quiz.masteredCount.toFloat() / quiz.totalCount.toFloat() else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = if (quiz.masteryPercentage >= 80) Color(0xFF16A34A) else MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // List of Questions
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(quiz.questions, key = { _, item -> item.id }) { index, item ->
                        QuestionPracticeCard(
                            question = item,
                            index = index,
                            onOptionSelected = { optIdx -> onOptionSelected(item.id, optIdx) },
                            onUserAnswerTextChange = { txt -> onUserAnswerTextChange(item.id, txt) },
                            onToggleRevealAnswer = { onToggleRevealAnswer(item.id) },
                            onToggleMastered = { onToggleMastered(item.id) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Export & Persistence Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onExportToFlashcards(quiz) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add to Flashcards", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { onExportToNotes(quiz) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save as Note", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = {
                            val copyText = buildString {
                                append("🎯 Targeted Study Guide: ${quiz.noteTitle}\n")
                                append("Subject: ${quiz.folder} | Difficulty: ${quiz.difficulty}\n\n")
                                quiz.questions.forEach { q ->
                                    append("Q${q.questionNumber}: ${q.questionText}\n")
                                    if (q.options.isNotEmpty()) {
                                        q.options.forEachIndexed { i, o ->
                                            append("  ${('A'.code + i).toChar()}) $o\n")
                                        }
                                    }
                                    append("Answer: ${q.correctAnswer}\n")
                                    append("Explanation: ${q.explanation}\n\n")
                                }
                            }
                            clipboardManager.setText(AnnotatedString(copyText))
                            showCopiedSnackbar = true
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy all questions")
                    }
                }
            }
        }
    }
}

/**
 * Individual interactive question card with options, hints, answers, and explanations.
 */
@Composable
fun QuestionPracticeCard(
    question: StudyQuestionItem,
    index: Int,
    onOptionSelected: (Int) -> Unit,
    onUserAnswerTextChange: (String) -> Unit,
    onToggleRevealAnswer: () -> Unit,
    onToggleMastered: () -> Unit
) {
    var showHint by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (question.isMastered)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = if (question.isMastered)
            androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
        else null
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Question Badge & Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Badge(containerColor = MaterialTheme.colorScheme.primary) {
                        Text("Q${question.questionNumber}", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                        Text("${question.questionType.iconEmoji} ${question.questionType.displayName}", fontSize = 10.sp)
                    }
                    if (question.targetConcept.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = MaterialTheme.colorScheme.tertiaryContainer) {
                            Text(question.targetConcept, fontSize = 10.sp)
                        }
                    }
                }

                // Mastery Toggle
                IconButton(
                    onClick = onToggleMastered,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (question.isMastered) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Toggle Mastered",
                        tint = if (question.isMastered) Color(0xFF16A34A) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Question Text
            Text(
                text = question.questionText,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Options (For MCQ & True/False)
            if (question.options.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    question.options.forEachIndexed { optIndex, optionText ->
                        val isSelected = question.userSelectedOptionIndex == optIndex
                        val isCorrectOption = question.correctOptionIndex == optIndex
                        val isRevealed = question.isAnswerRevealed

                        val optionBgColor = when {
                            isRevealed && isCorrectOption -> Color(0xFFDCFCE7)
                            isRevealed && isSelected && !isCorrectOption -> Color(0xFFFEE2E2)
                            isSelected -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }

                        val optionBorderColor = when {
                            isRevealed && isCorrectOption -> Color(0xFF16A34A)
                            isRevealed && isSelected && !isCorrectOption -> Color(0xFFDC2626)
                            isSelected -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.outlineVariant
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOptionSelected(optIndex) },
                            shape = RoundedCornerShape(10.dp),
                            color = optionBgColor,
                            border = androidx.compose.foundation.BorderStroke(1.dp, optionBorderColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val letter = ('A'.code + optIndex).toChar()
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = letter.toString(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Text(
                                    text = optionText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f),
                                    color = if (isRevealed && isCorrectOption) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurface
                                )

                                if (isRevealed) {
                                    if (isCorrectOption) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "Correct", tint = Color(0xFF16A34A), modifier = Modifier.size(18.dp))
                                    } else if (isSelected) {
                                        Icon(Icons.Default.Cancel, contentDescription = "Incorrect", tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Short Answer / Scenario Text Input for self testing
                OutlinedTextField(
                    value = question.userAnswerText,
                    onValueChange = onUserAnswerTextChange,
                    placeholder = { Text("Type your answer or key points here to test recall...", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2,
                    maxLines = 4
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Hint Button
            if (question.hint.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = { showHint = !showHint },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFD97706))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showHint) "Hide Hint" else "Need a Hint?", fontSize = 11.sp, color = Color(0xFFD97706), fontWeight = FontWeight.Bold)
                    }
                }

                if (showHint) {
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF92400E), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(question.hint, style = MaterialTheme.typography.bodySmall, color = Color(0xFF92400E))
                        }
                    }
                }
            }

            // Reveal Answer / Explanation Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onToggleRevealAnswer,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = if (question.isAnswerRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (question.isAnswerRevealed) "Hide Explanation" else "Reveal Answer & Explanation",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                AssistChip(
                    onClick = onToggleMastered,
                    label = {
                        Text(
                            text = if (question.isMastered) "✓ Mastered" else "Mark Mastered",
                            fontSize = 11.sp,
                            fontWeight = if (question.isMastered) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    leadingIcon = if (question.isMastered) {
                        { Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(12.dp)) }
                    } else null
                )
            }

            // Revealed Answer & Explanation Block
            AnimatedVisibility(visible = question.isAnswerRevealed) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Model Answer:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                        Text(
                            text = question.correctAnswer,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Concept Tested & Pedagogical Reason:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                        Text(
                            text = question.explanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
