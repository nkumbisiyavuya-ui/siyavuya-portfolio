package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ai.GeminiDebugLogService
import com.example.data.ai.GeminiLogStatus
import com.example.data.ai.GeminiPayloadLogEntry

/**
 * Modal dialog for inspecting live and historical Gemini API payloads,
 * validating user message binding, checking for stale/cached data,
 * and viewing full JSON requests and responses.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeminiPayloadInspectorDialog(
    onDismiss: () -> Unit
) {
    val logs by GeminiDebugLogService.logs.collectAsState()
    val latestLog by GeminiDebugLogService.latestLog.collectAsState()

    var selectedEntryId by remember { mutableStateOf<String?>(null) }
    val activeEntry = logs.find { it.id == selectedEntryId } ?: latestLog ?: logs.firstOrNull()

    var selectedTab by remember { mutableStateOf(0) } // 0: Binding, 1: Request JSON, 2: System Prompt, 3: Response, 4: History
    val clipboardManager = LocalClipboardManager.current
    var copiedMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .testTag("gemini_payload_inspector_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.BugReport,
                                contentDescription = "Inspector Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Gemini Payload Inspector",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Verify prompt binding & prevent stale/cached data",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = {
                                GeminiDebugLogService.clearLogs()
                                selectedEntryId = null
                            },
                            modifier = Modifier.testTag("clear_logs_button")
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Logs", tint = MaterialTheme.colorScheme.error)
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_inspector_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close Inspector")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (activeEntry == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No API requests recorded yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Send a prompt in Chuma AI chat to inspect the generated payload.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                } else {
                    // Status Badge & Info Banner
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when (activeEntry.status) {
                                GeminiLogStatus.SUCCESS -> Color(0xFFE8F5E9)
                                GeminiLogStatus.FAILED -> Color(0xFFFFEBEE)
                                GeminiLogStatus.OFFLINE_EVALUATOR -> Color(0xFFE3F2FD)
                                GeminiLogStatus.IN_FLIGHT -> Color(0xFFFFF8E1)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val statusIcon = when (activeEntry.status) {
                                    GeminiLogStatus.SUCCESS -> Icons.Default.CheckCircle
                                    GeminiLogStatus.FAILED -> Icons.Default.Error
                                    GeminiLogStatus.OFFLINE_EVALUATOR -> Icons.Default.Memory
                                    GeminiLogStatus.IN_FLIGHT -> Icons.Default.Sync
                                }
                                val statusTint = when (activeEntry.status) {
                                    GeminiLogStatus.SUCCESS -> Color(0xFF2E7D32)
                                    GeminiLogStatus.FAILED -> Color(0xFFC62828)
                                    GeminiLogStatus.OFFLINE_EVALUATOR -> Color(0xFF1565C0)
                                    GeminiLogStatus.IN_FLIGHT -> Color(0xFFF57F17)
                                }
                                Icon(statusIcon, contentDescription = null, tint = statusTint, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Req #${activeEntry.id} • ${activeEntry.taskType.uppercase()} • ${activeEntry.formattedTimestamp}",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = statusTint
                                    )
                                    Text(
                                        text = if (activeEntry.isUserMessageBoundCorrectly) "✅ User Message Bound Directly (Fresh & Verified)" else "⚠️ Binding Warning Detected",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = statusTint
                                    )
                                }
                            }

                            if (activeEntry.durationMs > 0) {
                                Text(
                                    text = "${activeEntry.durationMs}ms",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Inspection Tabs
                    val tabs = listOf(
                        "🔍 Binding Integrity",
                        "📦 Request JSON",
                        "🛡️ System Instruction",
                        "💬 Response",
                        "📜 History (${logs.size})"
                    )

                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        edgePadding = 0.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = { Text(title, fontSize = 12.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Tab Content
                    Box(modifier = Modifier.weight(1f)) {
                        when (selectedTab) {
                            0 -> BindingIntegrityTab(activeEntry, onCopy = { text, label ->
                                clipboardManager.setText(AnnotatedString(text))
                                copiedMessage = "$label copied to clipboard!"
                            })
                            1 -> RequestJsonTab(activeEntry, onCopy = { text ->
                                clipboardManager.setText(AnnotatedString(text))
                                copiedMessage = "Full Request JSON copied!"
                            })
                            2 -> SystemInstructionTab(activeEntry)
                            3 -> ResponseTab(activeEntry)
                            4 -> HistoryTab(
                                logs = logs,
                                selectedId = activeEntry.id,
                                onSelect = { selectedEntryId = it }
                            )
                        }
                    }

                    if (copiedMessage != null) {
                        LaunchedEffect(copiedMessage) {
                            kotlinx.coroutines.delay(2000)
                            copiedMessage = null
                        }
                        Text(
                            text = copiedMessage ?: "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BindingIntegrityTab(
    entry: GeminiPayloadLogEntry,
    onCopy: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Assertions Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Payload Binding Assertions",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                entry.validationBadges.forEach { badge ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (badge.isPassed) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (badge.isPassed) Color(0xFF2E7D32) else Color(0xFFC62828),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${badge.title}: ",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Text(
                            text = badge.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Side-by-side / Comparison View
        Text(
            text = "1. Raw User Input (From UI)",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            SelectionContainer {
                Text(
                    text = entry.rawUserPrompt.ifBlank { "(empty prompt)" },
                    modifier = Modifier.padding(10.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Text(
            text = "2. Bound User Message (contents[last].parts[0].text)",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (entry.isUserMessageBoundCorrectly) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
            )
        ) {
            SelectionContainer {
                Text(
                    text = entry.boundUserMessage.ifBlank { "(empty user message in payload)" },
                    modifier = Modifier.padding(10.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = { onCopy(entry.boundUserMessage, "Bound User Message") },
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Copy Bound Prompt")
            }
        }
    }
}

@Composable
private fun RequestJsonTab(
    entry: GeminiPayloadLogEntry,
    onCopy: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Target Models: ${entry.modelsAttempted.joinToString(", ")}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FilledTonalButton(
                onClick = { onCopy(entry.payloadJsonPretty) },
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Copy JSON", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            SelectionContainer {
                Text(
                    text = entry.payloadJsonPretty,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState()),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun SystemInstructionTab(entry: GeminiPayloadLogEntry) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Isolated System Instruction & Persona",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleSmall
        )
        Text(
            text = "System rules and academic context are placed in the dedicated systemInstruction payload field to ensure the user prompt is never mutated or prepended.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            SelectionContainer {
                Text(
                    text = entry.systemInstructionText.ifBlank { "(No system instruction specified)" },
                    modifier = Modifier.padding(12.dp),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun ResponseTab(entry: GeminiPayloadLogEntry) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Model: ${entry.modelUsed ?: "Unknown"}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelLarge
            )
            Text(
                text = "HTTP ${entry.httpStatusCode ?: 0}",
                style = MaterialTheme.typography.labelLarge,
                color = if (entry.httpStatusCode == 200) Color(0xFF2E7D32) else Color(0xFFC62828)
            )
        }

        if (entry.groundingQueries.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text("🔍 Search Grounding Queries:", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    entry.groundingQueries.forEach { q ->
                        Text("• \"$q\"", fontSize = 11.sp)
                    }
                }
            }
        }

        Text(
            text = "Generated Output Text",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleSmall
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            SelectionContainer {
                Text(
                    text = entry.responseSnippet ?: "(No response recorded)",
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        if (!entry.rawResponseJsonPretty.isNullOrBlank()) {
            Text(
                text = "Raw Response JSON",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                SelectionContainer {
                    Text(
                        text = entry.rawResponseJsonPretty,
                        modifier = Modifier.padding(12.dp),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryTab(
    logs: List<GeminiPayloadLogEntry>,
    selectedId: String,
    onSelect: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(logs) { log ->
            val isSelected = log.id == selectedId
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(log.id) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "#${log.id}",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = log.formattedTimestamp,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = log.rawUserPrompt,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (log.isUserMessageBoundCorrectly) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${log.durationMs}ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
