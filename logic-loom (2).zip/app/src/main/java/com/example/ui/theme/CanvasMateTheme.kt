package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * CanvasMate Palette Colors Object
 * Core Brand Palette: Primary (#071A3D), Dark (#040D22), Crimson (#7A1024), White (#F7F9FC)
 */
object Colors {
    val Primary = Color(0xFF071A3D)
    val Dark = Color(0xFF040D22)
    val Crimson = Color(0xFF7A1024)
    val White = Color(0xFFF7F9FC)

    // Secondary & Accent Shades
    val LightNavy = Color(0xFF102B5C)
    val DarkCrimson = Color(0xFF430816)
    val LightCrimson = Color(0xFFA51D35)
    val CoolGray = Color(0xFFAAB4C3)
    val DarkSurface = Color(0xFF081225)
    val DarkCard = Color(0xFF0F1E36)
    val DarkBorder = Color(0xFF1A2E50)
}

/**
 * CanvasMate Shapes Token Object
 */
val Shapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

/**
 * CanvasMate Typography Hierarchy Object
 */
val CanvasMateTypography = Typography(
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp,
        letterSpacing = 0.5.sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp,
        letterSpacing = 0.25.sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 32.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.15.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.1.sp
    ),
    titleSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 15.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp
    ),
    bodySmall = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.4.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    )
)

// -------------------------------------------------------------
// Extended CompositionLocal Design Tokens
// -------------------------------------------------------------

@Immutable
data class CanvasMateColors(
    val primary: Color = Color(0xFF14532D),
    val primaryHover: Color = Color(0xFF166534),
    val primaryDark: Color = Color(0xFF064E3B),
    val primaryLight: Color = Color(0xFFDCFCE7),
    val background: Color = Color(0xFFFFFFFF),
    val surface: Color = Color(0xFFFFFFFF),
    val secondaryBg: Color = Color(0xFFF8FAF9),
    val mainText: Color = Color(0xFF111111),
    val secondaryText: Color = Color(0xFF374151),
    val mutedText: Color = Color(0xFF6B7280),
    val border: Color = Color(0xFFE5E7EB),
    val success: Color = Color(0xFF16A34A),
    val error: Color = Color(0xFFDC2626),
    val warning: Color = Color(0xFFD97706),

    // Legacy fields for backward compatibility
    val primaryNavy: Color = primary,
    val darkNavy: Color = primaryDark,
    val lightNavy: Color = primaryHover,
    val crimson: Color = primary,
    val darkCrimson: Color = primaryDark,
    val lightCrimson: Color = primaryHover,
    val white: Color = surface,
    val coolGray: Color = mutedText,
    val darkSurface: Color = background,
    val darkCard: Color = surface,
    val darkBorder: Color = border
)

@Immutable
data class CanvasMateSpacing(
    val xxs: Dp = 2.dp,
    val xs: Dp = 4.dp,
    val sm: Dp = 8.dp,
    val md: Dp = 16.dp,
    val lg: Dp = 24.dp,
    val xl: Dp = 32.dp,
    val xxl: Dp = 48.dp
)

@Immutable
data class CanvasMateRadii(
    val xs: RoundedCornerShape = RoundedCornerShape(4.dp),
    val small: RoundedCornerShape = RoundedCornerShape(8.dp),
    val medium: RoundedCornerShape = RoundedCornerShape(12.dp),
    val large: RoundedCornerShape = RoundedCornerShape(16.dp),
    val xlarge: RoundedCornerShape = RoundedCornerShape(24.dp),
    val pill: RoundedCornerShape = RoundedCornerShape(50)
)

@Immutable
data class CanvasMateElevation(
    val none: Dp = 0.dp,
    val low: Dp = 2.dp,
    val medium: Dp = 6.dp,
    val high: Dp = 12.dp
)

@Immutable
data class CanvasMateTypographyHierarchy(
    val displayLarge: TextStyle = CanvasMateTypography.headlineLarge,
    val displayMedium: TextStyle = CanvasMateTypography.headlineMedium,
    val titleLarge: TextStyle = CanvasMateTypography.titleLarge,
    val titleMedium: TextStyle = CanvasMateTypography.titleMedium,
    val bodyLarge: TextStyle = CanvasMateTypography.bodyLarge,
    val bodyMedium: TextStyle = CanvasMateTypography.bodyMedium,
    val labelMedium: TextStyle = CanvasMateTypography.labelMedium
)

val LocalCanvasMateColors = staticCompositionLocalOf { CanvasMateColors() }
val LocalCanvasMateSpacing = staticCompositionLocalOf { CanvasMateSpacing() }
val LocalCanvasMateRadii = staticCompositionLocalOf { CanvasMateRadii() }
val LocalCanvasMateElevation = staticCompositionLocalOf { CanvasMateElevation() }
val LocalCanvasMateTypography = staticCompositionLocalOf { CanvasMateTypographyHierarchy() }

object CanvasMateTokens {
    val colors: CanvasMateColors
        @Composable
        get() = LocalCanvasMateColors.current

    val spacing: CanvasMateSpacing
        @Composable
        get() = LocalCanvasMateSpacing.current

    val radii: CanvasMateRadii
        @Composable
        get() = LocalCanvasMateRadii.current

    val elevation: CanvasMateElevation
        @Composable
        get() = LocalCanvasMateElevation.current

    val typography: CanvasMateTypographyHierarchy
        @Composable
        get() = LocalCanvasMateTypography.current
}

@Composable
fun CanvasMateTokenProvider(
    colors: CanvasMateColors = CanvasMateColors(),
    spacing: CanvasMateSpacing = CanvasMateSpacing(),
    radii: CanvasMateRadii = CanvasMateRadii(),
    elevation: CanvasMateElevation = CanvasMateElevation(),
    typography: CanvasMateTypographyHierarchy = CanvasMateTypographyHierarchy(),
    themeData: ThemeData = ThemeData(
        primary = colors.primary,
        primaryHover = colors.primaryHover,
        primaryDark = colors.primaryDark,
        lightAccent = colors.primaryLight,
        background = colors.background,
        surface = colors.surface,
        secondaryBg = colors.secondaryBg,
        mainText = colors.mainText,
        secondaryText = colors.secondaryText,
        mutedText = colors.mutedText,
        border = colors.border,
        success = colors.success,
        error = colors.error,
        warning = colors.warning
    ),
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalCanvasMateColors provides colors,
        LocalCanvasMateSpacing provides spacing,
        LocalCanvasMateRadii provides radii,
        LocalCanvasMateElevation provides elevation,
        LocalCanvasMateTypography provides typography,
        LocalThemeData provides themeData,
        content = content
    )
}

/**
 * Main CanvasMate Theme Composable
 * Wraps values through MaterialTheme and provides CanvasMate design tokens.
 */
@Composable
fun CanvasMateTheme(
    forceDarkTheme: Boolean? = null,
    selectedPalette: AppColorPalette = AppColorPalette.LOGIC_LOOM,
    selectedFont: AppFontStyle = AppFontStyle.DEFAULT,
    content: @Composable () -> Unit
) {
    val darkTheme = forceDarkTheme ?: false // Default to bright experience
    val colorScheme = getCustomColorScheme(selectedPalette, darkTheme)
    val customTypography = getCustomTypography(selectedFont)

    val canvasMateColors = if (darkTheme) {
        if (selectedPalette == AppColorPalette.LOGIC_LOOM) {
            CanvasMateColors(
                primary = Color(0xFF2563EB),
                primaryHover = Color(0xFF1D4ED8),
                primaryDark = Color(0xFF070D1E),
                primaryLight = Color(0xFF06B6D4),
                background = Color(0xFF070D1E),
                surface = Color(0xFF0F1B2E),
                secondaryBg = Color(0xFF16243C),
                mainText = Color(0xFFF8FAFC),
                secondaryText = Color(0xFF94A3B8),
                mutedText = Color(0xFF64748B),
                border = Color(0xFF1E2F4D)
            )
        } else {
            CanvasMateColors(
                primary = selectedPalette.lightAccentColor,
                primaryHover = selectedPalette.lightAccentColor,
                primaryDark = selectedPalette.primaryColor,
                primaryLight = selectedPalette.primaryColor,
                background = Color(0xFF0F172A),
                surface = Color(0xFF1E293B),
                secondaryBg = Color(0xFF334155),
                mainText = Color(0xFFFFFFFF),
                secondaryText = Color(0xFFCBD5E1),
                mutedText = Color(0xFF94A3B8),
                border = Color(0xFF475569)
            )
        }
    } else {
        CanvasMateColors(
            primary = selectedPalette.primaryColor,
            primaryHover = selectedPalette.primaryHoverColor,
            primaryDark = selectedPalette.primaryDarkColor,
            primaryLight = selectedPalette.lightAccentColor,
            background = Color(0xFFFFFFFF),
            surface = Color(0xFFFFFFFF),
            secondaryBg = selectedPalette.secondaryBgColor,
            mainText = selectedPalette.mainTextColor,
            secondaryText = selectedPalette.secondaryTextColor,
            mutedText = Color(0xFF6B7280),
            border = selectedPalette.borderColor
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = customTypography,
        shapes = Shapes,
        content = {
            CanvasMateTokenProvider(
                colors = canvasMateColors,
                content = content
            )
        }
    )
}

/**
 * Logic Loom Brand Theme Alias
 */
@Composable
fun LogicLoomTheme(
    forceDarkTheme: Boolean? = null,
    selectedPalette: AppColorPalette = AppColorPalette.LOGIC_LOOM,
    selectedFont: AppFontStyle = AppFontStyle.DEFAULT,
    content: @Composable () -> Unit
) {
    CanvasMateTheme(
        forceDarkTheme = forceDarkTheme,
        selectedPalette = selectedPalette,
        selectedFont = selectedFont,
        content = content
    )
}
