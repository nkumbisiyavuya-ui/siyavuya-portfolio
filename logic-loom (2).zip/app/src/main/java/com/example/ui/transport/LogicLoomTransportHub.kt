package com.example.ui.transport

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.device.DeviceCapabilityManager
import com.example.data.transport.model.*
import com.example.data.voice.VoiceInputManager
import com.example.data.voice.VoiceSearchState
import com.example.ui.CanvasMateViewModel
import kotlinx.coroutines.launch

/**
 * Production-ready Logic Loom Transport & Mobility Hub UI.
 *
 * Adheres strictly to the master directives:
 * 1. NOT a transportation service (never claims to transport, book rides, or dispatch vehicles).
 * 2. NEVER auto-invents or assumes origins/destinations.
 * 3. Permission-based, optional, user-controlled location access ("Use my current location").
 * 4. Transparent distance breakdown (distinguishes straight-line vs actual travel/track distance).
 * 5. PRASA / Metrorail published fare matrix with explicit source attribution and disclaimer.
 * 6. Microphone-permission-based voice input with live feedback.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogicLoomTransportHub(
    viewModel: CanvasMateViewModel,
    modifier: Modifier = Modifier,
    onNavigateToAssistant: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val searchResult by viewModel.transportSearchResult.collectAsState()
    val isSearching by viewModel.isSearchingTransport.collectAsState()
    val originQuery by viewModel.transportSearchOrigin.collectAsState()
    val destQuery by viewModel.transportSearchDestination.collectAsState()
    val preferredMode by viewModel.transportSearchMode.collectAsState()
    val allStations by viewModel.allTransitStations.collectAsState()
    val isLocating by viewModel.isLocating.collectAsState()

    // Local input field buffers
    var originInput by remember(originQuery) { mutableStateOf(originQuery) }
    var destInput by remember(destQuery) { mutableStateOf(destQuery) }
    var selectedFilterMode by remember(preferredMode) { mutableStateOf(preferredMode) }

    // Voice Input Integration
    val voiceInputManager = remember { VoiceInputManager(context) }
    val voiceState by voiceInputManager.voiceState.collectAsState()
    var activeVoiceTarget by remember { mutableStateOf<String?>(null) } // "origin", "destination", or "query"
    var voiceSnackbarMessage by remember { mutableStateOf<String?>(null) }

    // Microphone Permission Launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            voiceInputManager.startListening { spokenText ->
                when (activeVoiceTarget) {
                    "origin" -> {
                        originInput = spokenText
                        viewModel.transportSearchOrigin.value = spokenText
                    }
                    "destination" -> {
                        destInput = spokenText
                        viewModel.transportSearchDestination.value = spokenText
                    }
                    else -> {
                        // Natural voice query parsing e.g. "Cape Town to Bellville" or "Train to Simon's Town"
                        val lower = spokenText.lowercase()
                        if (lower.contains(" to ")) {
                            val parts = spokenText.split(Regex("(?i)\\s+to\\s+"), 2)
                            val fromPart = parts[0].replace(Regex("(?i)^(from|find train from|how much is the train from|train from)\\s+"), "").trim()
                            val toPart = parts[1].replace(Regex("(?i)\\s+(by train|by bus|please|today).*"), "").trim()
                            originInput = fromPart
                            destInput = toPart
                            viewModel.transportSearchOrigin.value = fromPart
                            viewModel.transportSearchDestination.value = toPart
                            viewModel.executeTransportSearch(fromPart, toPart, selectedFilterMode)
                        } else {
                            destInput = spokenText
                            viewModel.transportSearchDestination.value = spokenText
                        }
                    }
                }
            }
        } else {
            voiceSnackbarMessage = "Microphone permission is required to search by voice."
        }
    }

    // Location Permission Launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        viewModel.handleLocationPermissionResult(granted)
        if (granted) {
            coroutineScope.launch {
                val loc = DeviceCapabilityManager.getCurrentLocation(context)
                if (loc != null) {
                    val address = loc.humanReadableAddress
                    originInput = address
                    viewModel.setTransportOriginFromDeviceLocation(address)
                }
            }
        } else {
            voiceSnackbarMessage = "Location permission denied. You can still type any station or origin manually."
        }
    }

    // Clean up voice listener on dispose
    DisposableEffect(Unit) {
        onDispose {
            voiceInputManager.stopListening()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("logic_loom_transport_hub"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Mandatory Product Purpose & Non-Transport Disclaimer Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Public Transport & Mobility Hub",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Discover and compare published rail (PRASA / Metrorail) and bus fares. Logic Loom is an informational tool and does not operate vehicles or issue transport bookings.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 2. Voice Feedback Banner if active
        if (voiceState is VoiceSearchState.Listening || voiceState is VoiceSearchState.Processing || voiceSnackbarMessage != null) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            if (voiceState is VoiceSearchState.Listening) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "🎤 Listening... Tap microphone to stop",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            } else if (voiceState is VoiceSearchState.Processing) {
                                Text(
                                    "Processing speech: ${(voiceState as VoiceSearchState.Processing).partialText}...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            } else {
                                Text(
                                    voiceSnackbarMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                        IconButton(
                            onClick = {
                                voiceInputManager.stopListening()
                                voiceSnackbarMessage = null
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // 3. Search Card: From, To, Use my location, Swap, Transport Mode, Search button
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Plan Your Route",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Enter origin and destination or use current location",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // FROM (Origin)
                    OutlinedTextField(
                        value = originInput,
                        onValueChange = {
                            originInput = it
                            viewModel.transportSearchOrigin.value = it
                        },
                        label = { Text("From") },
                        placeholder = { Text("Where are you starting from?") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.TripOrigin,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        activeVoiceTarget = "origin"
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Mic,
                                        contentDescription = "Voice input for origin",
                                        tint = if (voiceState is VoiceSearchState.Listening && activeVoiceTarget == "origin") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transport_origin_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Explicit "Use my current location" Action Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (DeviceCapabilityManager.hasLocationPermission(context)) {
                                    coroutineScope.launch {
                                        val loc = DeviceCapabilityManager.getCurrentLocation(context)
                                        if (loc != null) {
                                            originInput = loc.humanReadableAddress
                                            viewModel.setTransportOriginFromDeviceLocation(loc.humanReadableAddress)
                                        } else {
                                            voiceSnackbarMessage = "Unable to determine current GPS coordinates. Please type origin."
                                        }
                                    }
                                } else {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_use_my_location")
                        ) {
                            if (isLocating) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Detecting GPS...", fontSize = 11.sp)
                            } else {
                                Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Use my current location", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        IconButton(
                            onClick = {
                                viewModel.swapTransportLocations()
                                originInput = viewModel.transportSearchOrigin.value
                                destInput = viewModel.transportSearchDestination.value
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.SwapVert,
                                contentDescription = "Swap origin and destination",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // TO (Destination)
                    OutlinedTextField(
                        value = destInput,
                        onValueChange = {
                            destInput = it
                            viewModel.transportSearchDestination.value = it
                        },
                        label = { Text("To") },
                        placeholder = { Text("Where are you going?") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Place,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                        },
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    activeVoiceTarget = "destination"
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            ) {
                                Icon(
                                    Icons.Default.Mic,
                                    contentDescription = "Voice input for destination",
                                    tint = if (voiceState is VoiceSearchState.Listening && activeVoiceTarget == "destination") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transport_dest_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Mode Selection Chips
                    Text(
                        text = "Transport Mode",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(TransportMode.entries.toTypedArray()) { mode ->
                            val isSelected = selectedFilterMode == mode
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedFilterMode = mode
                                    viewModel.transportSearchMode.value = mode
                                },
                                label = {
                                    Text(
                                        when (mode) {
                                            TransportMode.TRAIN -> "🚆 Train (PRASA)"
                                            TransportMode.BUS -> "🚌 Bus (MyCiTi / GABS)"
                                            TransportMode.OTHER -> "🚕 Taxi / Transit"
                                            TransportMode.ALL -> "🌐 All Modes"
                                        },
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search Button
                    Button(
                        onClick = {
                            viewModel.executeTransportSearch(originInput, destInput, selectedFilterMode)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_search_transport"),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isSearching
                    ) {
                        if (isSearching) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Searching Transport Data...")
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Search Transport Options", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 4. Quick Suggestion / Stations Chips (No assumed destination, just clickable discovery station helpers)
        item {
            Column {
                Text(
                    text = "Key Rail Stations (PRASA Metrorail Network)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val quickStations = listOf(
                        "Cape Town", "Bellville", "Salt River", "Claremont", "Wynberg", "Mowbray", "Simon's Town", "Paarl"
                    )
                    items(quickStations) { st ->
                        SuggestionChip(
                            onClick = {
                                if (originInput.isBlank()) {
                                    originInput = st
                                    viewModel.transportSearchOrigin.value = st
                                } else if (destInput.isBlank()) {
                                    destInput = st
                                    viewModel.transportSearchDestination.value = st
                                } else {
                                    destInput = st
                                    viewModel.transportSearchDestination.value = st
                                }
                            },
                            label = { Text(st, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        // 5. Search Results Header & Distance Distinction Card
        val currentResults = searchResult
        if (currentResults != null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Discovered Options (${currentResults.options.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { viewModel.clearTransportSearch() }) {
                        Text("Clear")
                    }
                }
            }

            // Distance Distinction Banner
            if (currentResults.straightLineDistanceKm != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Straighten,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Straight-line Distance: ~${currentResults.straightLineDistanceKm} km",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Note: Straight-line distance is Euclidean separation. Actual rail track and road travel distance will be longer due to corridor geography.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }

            if (currentResults.generalNotice != null && currentResults.options.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = currentResults.generalNotice ?: "",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Tip: You can ask Chuma AI directly: \"How much is the train from Cape Town to Bellville?\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Results List
            items(currentResults.options) { option ->
                TransportOptionCard(
                    option = option,
                    onAskAssistant = {
                        onNavigateToAssistant("Tell me more about the ${option.operator} route from ${option.originStationOrStop} to ${option.destinationStationOrStop}")
                    }
                )
            }

            // Data Provenance & Freshness Footer
            if (currentResults.sourcesConsulted.isNotEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Data Sources & Freshness Metadata",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            currentResults.sourcesConsulted.forEach { src ->
                                Text(
                                    text = "• $src",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tariffs effective: 2024–2026. Real-time changes, engineering works, and line schedules must be verified with operator announcements prior to departure.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Dedicated Card presenting an authentic Transport Option with published fares,
 * operator details, track distances, and non-misleading action labels.
 */
@Composable
fun TransportOptionCard(
    option: TransportOption,
    onAskAssistant: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Operator Header & Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (option.mode == TransportMode.TRAIN) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (option.mode == TransportMode.TRAIN) Icons.Default.DirectionsSubway else Icons.Default.DirectionsBus,
                                contentDescription = null,
                                tint = if (option.mode == TransportMode.TRAIN) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = option.operator,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = option.routeName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = option.lastUpdatedDate,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Origin -> Destination with Track Distance
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TripOrigin, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = option.originStationOrStop, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = option.destinationStationOrStop, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    }
                    if (option.estimatedTrackDistanceKm != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        val distanceType = if (option.mode == TransportMode.TRAIN) "Estimated Rail Track Distance" else "Estimated Road Distance"
                        Text(
                            text = "$distanceType: ~${option.estimatedTrackDistanceKm} km (${option.intermediateStopsCount} intermediate stops)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Published Fare Section (Transparent, no false booking promises)
            if (option.publishedFare != null) {
                val fare = option.publishedFare
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Published Fare (${fare.fareCategory})",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (fare.singleZar != null) "Single: R${"%.2f".format(fare.singleZar)}" else "Tariff on enquiry",
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        if (fare.weeklyZar != null || fare.monthlyZar != null || fare.returnZar != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            val passText = listOfNotNull(
                                fare.returnZar?.let { "Return R${"%.2f".format(it)}" },
                                fare.weeklyZar?.let { "Weekly R${"%.2f".format(it)}" },
                                fare.monthlyZar?.let { "Monthly R${"%.2f".format(it)}" }
                            ).joinToString(" • ")
                            Text(
                                text = passText,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Data Type: ${fare.dataType.label} • ${fare.freshnessStatus}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Source: ${fare.sourceName} • ${fare.effectiveDateText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = fare.disclaimer,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Current fare unavailable. Please verify with the operator at the station ticket counter.",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timetable & Service Frequency Notice
            Text(
                text = "⏱ Frequency: ${option.frequencyNotice}",
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                text = "🕒 Service Hours: ${option.operatingHoursNotice}",
                style = MaterialTheme.typography.labelSmall
            )
            if (!option.serviceStatusNotice.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ℹ️ ${option.serviceStatusNotice}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: Informational only (no false booking promises)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAskAssistant,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ask Chuma AI", fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        // Provides honest informational confirmation
                    },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("View Station Info", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
