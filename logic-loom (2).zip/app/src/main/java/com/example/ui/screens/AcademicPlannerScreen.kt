package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AcademicTask
import com.example.ui.CanvasMateViewModel
import com.example.ui.components.VoiceInputIconButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AcademicPlannerScreen(
    tasks: List<AcademicTask>,
    onAddTask: (AcademicTask) -> Unit,
    onUpdateTask: (AcademicTask) -> Unit,
    onDeleteTask: (Long) -> Unit
) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    var selectedFilter by remember { mutableStateOf("All") }
    var selectedTab by remember { mutableStateOf("Active") } // Active vs Completed
    var showAddDialog by remember { mutableStateOf(false) }

    val filterOptions = listOf("All", "Assignment", "Project", "Presentation", "Practical", "Test", "Exam")

    val filteredTasks = tasks.filter { task ->
        val matchesTab = if (selectedTab == "Active") task.status != "Completed" else task.status == "Completed"
        val matchesCategory = if (selectedFilter == "All") true else task.taskType == selectedFilter
        matchesTab && matchesCategory
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Academic Planner", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Assignments, Projects, Presentations, Tests & Exams (2026)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CloudDone,
                            contentDescription = "Room Database Local Cache",
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Offline Ready",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Active vs Completed Tabs
            TabRow(
                selectedTabIndex = if (selectedTab == "Active") 0 else 1,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == "Active",
                    onClick = { selectedTab = "Active" },
                    text = { Text("Active Tasks (${tasks.count { it.status != "Completed" }})") }
                )
                Tab(
                    selected = selectedTab == "Completed",
                    onClick = { selectedTab = "Completed" },
                    text = { Text("Completed (${tasks.count { it.status == "Completed" }})") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category Filter Chips
            ScrollableTabRow(
                selectedTabIndex = filterOptions.indexOf(selectedFilter).coerceAtLeast(0),
                edgePadding = 0.dp,
                divider = {}
            ) {
                filterOptions.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredTasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.AssignmentTurnedIn,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (selectedTab == "Active") "No active academic tasks found!" else "No completed tasks yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredTasks, key = { it.id }) { task ->
                        AcademicTaskCard(
                            task = task,
                            onToggleComplete = {
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                val updatedStatus = if (task.status == "Completed") "Pending" else "Completed"
                                val updatedProgress = if (updatedStatus == "Completed") 100 else 50
                                onUpdateTask(task.copy(status = updatedStatus, progress = updatedProgress))
                            },
                            onProgressChange = { newProgress ->
                                if (newProgress >= 100) {
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                                } else {
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                }
                                val updatedStatus = if (newProgress >= 100) "Completed" else "In Progress"
                                onUpdateTask(task.copy(progress = newProgress, status = updatedStatus))
                            },
                            onDelete = {
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                onDeleteTask(task.id)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddTaskDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newTask ->
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                onAddTask(newTask)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AcademicTaskCard(
    task: AcademicTask,
    onToggleComplete: () -> Unit,
    onProgressChange: (Int) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Checkbox(
                        checked = task.status == "Completed",
                        onCheckedChange = { onToggleComplete() }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${task.module} • ${task.taskType} • Due: ${task.dueDate}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row {
                    PriorityChip(task.priority)
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                    }
                }
            }

            if (task.description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = task.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider & Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Progress: ${task.progress}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(12.dp))
                Slider(
                    value = task.progress.toFloat(),
                    onValueChange = { onProgressChange(it.toInt()) },
                    valueRange = 0f..100f,
                    modifier = Modifier.weight(1f)
                )
            }

            // Checklist section
            if (task.checklistJson.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                val items = task.checklistJson.split("|")
                items.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(item, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (AcademicTask) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var module by remember { mutableStateOf("CSC3002F") }
    var description by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("2026-08-25") }
    var priority by remember { mutableStateOf("Medium") }
    var taskType by remember { mutableStateOf("Assignment") }
    var checklist by remember { mutableStateOf("Draft structure|Main research|Final review") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Academic Task") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title (e.g., Term Test 2)") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> title = if (title.isEmpty()) text else "$title $text" },
                            prompt = "Dictate task title..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = module,
                        onValueChange = { module = it },
                        label = { Text("Module (e.g. MTH3012S)") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = dueDate,
                        onValueChange = { dueDate = it },
                        label = { Text("Due Date (2026)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> description = if (description.isEmpty()) text else "$description $text" },
                            prompt = "Dictate task details..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("Task Category", style = MaterialTheme.typography.labelSmall)
                val types = listOf("Assignment", "Project", "Presentation", "Practical", "Test", "Exam")
                ScrollableTabRow(selectedTabIndex = types.indexOf(taskType).coerceAtLeast(0), divider = {}) {
                    types.forEach { type ->
                        FilterChip(
                            selected = taskType == type,
                            onClick = { taskType = type },
                            label = { Text(type) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Priority", style = MaterialTheme.typography.labelSmall)
                Row {
                    listOf("High", "Medium", "Low").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p) },
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = checklist,
                    onValueChange = { checklist = it },
                    label = { Text("Checklist items (separated by |)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(
                            AcademicTask(
                                title = title,
                                module = module,
                                description = description,
                                dueDate = dueDate,
                                priority = priority,
                                taskType = taskType,
                                status = "Pending",
                                progress = 0,
                                checklistJson = checklist
                            )
                        )
                    }
                }
            ) {
                Text("Add Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun PriorityChip(priority: String) {
    val (bgColor, textColor) = when (priority.lowercase()) {
        "high" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "medium" -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = priority,
            color = textColor,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

