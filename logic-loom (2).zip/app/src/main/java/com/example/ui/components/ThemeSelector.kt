package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalThemeData
import com.example.ui.theme.ThemeChoice

/**
 * A main ThemeSelector component displaying cards for all 7 official Logic Loom themes
 * (Green, Navy, Burgundy, Pink, Gold, Purple, Ocean).
 * Includes theme name, description, emoji badge, color preview swatches, and checkmark selection state.
 */
@Composable
fun ThemeSelector(
    selectedTheme: ThemeChoice,
    onThemeSelected: (ThemeChoice) -> Unit,
    modifier: Modifier = Modifier,
    themes: List<ThemeChoice> = ThemeChoice.entries,
    useGrid: Boolean = false
) {
    if (useGrid) {
        ThemeSelectorGrid(
            selectedTheme = selectedTheme,
            onThemeSelected = onThemeSelected,
            modifier = modifier,
            themes = themes
        )
    } else {
        ThemeSelectorList(
            selectedTheme = selectedTheme,
            onThemeSelected = onThemeSelected,
            modifier = modifier,
            themes = themes
        )
    }
}

/**
 * Grid layout for ThemeSelector displaying cards in a 2-column or adaptive grid.
 */
@Composable
fun ThemeSelectorGrid(
    selectedTheme: ThemeChoice,
    onThemeSelected: (ThemeChoice) -> Unit,
    modifier: Modifier = Modifier,
    themes: List<ThemeChoice> = ThemeChoice.entries,
    minCardWidth: Int = 160
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = minCardWidth.dp),
        modifier = modifier.testTag("theme_selector_grid"),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(
            items = themes,
            key = { it.id }
        ) { themeChoice ->
            ThemeCard(
                themeChoice = themeChoice,
                isSelected = themeChoice == selectedTheme,
                onClick = { onThemeSelected(themeChoice) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Vertical list layout for ThemeSelector displaying theme cards sequentially.
 */
@Composable
fun ThemeSelectorList(
    selectedTheme: ThemeChoice,
    onThemeSelected: (ThemeChoice) -> Unit,
    modifier: Modifier = Modifier,
    themes: List<ThemeChoice> = ThemeChoice.entries
) {
    Column(
        modifier = modifier.testTag("theme_selector_list"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        themes.forEach { themeChoice ->
            ThemeCard(
                themeChoice = themeChoice,
                isSelected = themeChoice == selectedTheme,
                onClick = { onThemeSelected(themeChoice) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Individual card representing a single ThemeChoice.
 * Displays the theme name, description, emoji badge, color swatches preview, and checkmark indicator.
 */
@Composable
fun ThemeCard(
    themeChoice: ThemeChoice,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val themeData = LocalThemeData.current

    val borderWidth by animateDpAsState(
        targetValue = if (isSelected) 2.5.dp else 1.dp,
        animationSpec = spring(),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isSelected) themeChoice.primaryColor else themeData.border.copy(alpha = 0.6f),
        animationSpec = tween(300),
        label = "borderColor"
    )

    val containerColor by animateColorAsState(
        targetValue = if (isSelected) {
            themeChoice.lightAccentColor.copy(alpha = 0.35f)
        } else {
            themeData.surface
        },
        animationSpec = tween(300),
        label = "containerColor"
    )

    val cardElevation by animateDpAsState(
        targetValue = if (isSelected) 4.dp else 1.dp,
        animationSpec = spring(),
        label = "cardElevation"
    )

    val scaleState by animateFloatAsState(
        targetValue = if (isSelected) 1.01f else 1.0f,
        animationSpec = spring(),
        label = "scale"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Card(
        modifier = modifier
            .scale(scaleState)
            .testTag("theme_card_${themeChoice.id}")
            .semantics {
                role = Role.RadioButton
                selected = isSelected
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .border(
                width = borderWidth,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = containerColor
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = cardElevation
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left section: Emoji badge & Color Swatches + Name & Description
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Color Swatches & Emoji Preview Box
                ThemeColorSwatchesPreview(
                    themeChoice = themeChoice,
                    isSelected = isSelected
                )

                Spacer(modifier = Modifier.width(14.dp))

                // Text details: Name & Description
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = themeChoice.displayName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                fontSize = 16.sp,
                                color = if (isSelected) themeChoice.primaryColor else themeData.mainText
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            text = themeChoice.emoji,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = themeChoice.description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = themeData.secondaryText,
                            fontSize = 13.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Right section: Checkmark Selection Indicator
            ThemeSelectionCheckmark(
                isSelected = isSelected,
                primaryColor = themeChoice.primaryColor,
                lightAccentColor = themeChoice.lightAccentColor
            )
        }
    }
}

/**
 * Displays a colorful multi-swatch preview for the theme card (Primary, Hover, Light Accent, Dark Accent).
 */
@Composable
fun ThemeColorSwatchesPreview(
    themeChoice: ThemeChoice,
    isSelected: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        themeChoice.primaryColor,
                        themeChoice.primaryHoverColor,
                        themeChoice.primaryDarkColor
                    )
                )
            )
            .border(
                width = 1.dp,
                color = if (isSelected) themeChoice.primaryColor else Color.White.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        // Inner accent pill/circle
        Row(
            horizontalArrangement = Arrangement.spacedBy((-4).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(themeChoice.lightAccentColor)
                    .border(1.dp, Color.White, CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(themeChoice.primaryColor)
                    .border(1.dp, Color.White, CircleShape)
            )
        }
    }
}

/**
 * Animated Checkmark indicator showing selection status.
 */
@Composable
fun ThemeSelectionCheckmark(
    isSelected: Boolean,
    primaryColor: Color,
    lightAccentColor: Color,
    modifier: Modifier = Modifier
) {
    val checkmarkBgColor by animateColorAsState(
        targetValue = if (isSelected) primaryColor else Color.Transparent,
        animationSpec = tween(200),
        label = "checkmarkBg"
    )

    val checkmarkBorderColor by animateColorAsState(
        targetValue = if (isSelected) primaryColor else Color(0xFFD1D5DB),
        animationSpec = tween(200),
        label = "checkmarkBorder"
    )

    Box(
        modifier = modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(checkmarkBgColor)
            .border(
                width = if (isSelected) 0.dp else 1.5.dp,
                color = checkmarkBorderColor,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = isSelected,
            enter = fadeIn(animationSpec = tween(150)) + scaleIn(animationSpec = spring()),
            exit = fadeOut(animationSpec = tween(150)) + scaleOut(animationSpec = tween(150))
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Selected",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
