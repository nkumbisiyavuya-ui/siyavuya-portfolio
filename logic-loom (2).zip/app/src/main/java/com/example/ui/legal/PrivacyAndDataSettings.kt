package com.example.ui.legal

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.legal.model.LegalConsentState
import com.example.ui.theme.LocalThemeData

/**
 * Privacy & Data Controls section for Settings Screen.
 * Provides access to Legal Center, Data Export, AI Transparency disclosures, and Account Deletion.
 */
@Composable
fun PrivacyAndDataSettingsSection(
    consentState: LegalConsentState,
    onOpenLegalCenter: () -> Unit,
    onExportUserData: () -> Unit,
    onDeleteAccountAndData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val themeData = LocalThemeData.current
    var showDeletionDialog by remember { mutableStateOf(false) }

    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        // Section Header
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = themeData.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Privacy, Legal & Data Control",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = themeData.mainText
            )
        }

        // 1. Legal & Safety Center Button
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = themeData.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border.copy(alpha = 0.8f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_open_legal_center")
        ) {
            Surface(
                onClick = onOpenLegalCenter,
                color = Color.Transparent
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = themeData.primary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = null,
                                tint = themeData.primary,
                                modifier = Modifier
                                    .padding(10.dp)
                                    .size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = "Legal & Safety Center",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = themeData.mainText
                            )
                            Text(
                                text = "Terms & Conditions, Privacy Policy, AI Rules & Legal Contact",
                                style = MaterialTheme.typography.bodySmall,
                                color = themeData.secondaryText,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = themeData.mutedText,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 2. Local Data Categories Disclosure
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = themeData.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PrivacyTip, contentDescription = null, tint = themeData.primary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Data Collection & Storage Transparency",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = themeData.mainText
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Logic Loom is designed and engineered by Moraigne. All data is stored locally on your device in sandboxed databases. Categories collected include:",
                    style = MaterialTheme.typography.bodySmall,
                    color = themeData.secondaryText
                )

                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DataCategoryItem("Account & Student Profile", "Name, email, student number & degree course")
                    DataCategoryItem("Academic & Schedule Data", "Planner tasks, GPA modules, timetable & calendar")
                    DataCategoryItem("Study Notes & Vault Documents", "Notes, flashcards, diary & uploaded documents")
                    DataCategoryItem("Financial Budget Records", "Expense items (ZAR) & budget goals")
                    DataCategoryItem("AI Interaction History", "Gemini assistant prompts & responses stored locally")
                }
            }
        }

        // 3. Data Export & Account Deletion Actions
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Export Data Button
            OutlinedButton(
                onClick = onExportUserData,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_export_data")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export Data (JSON)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            // Account Deletion Button
            Button(
                onClick = { showDeletionDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("btn_delete_account_dialog")
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Delete Account", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Explicit Account Deletion Confirmation Dialog
    if (showDeletionDialog) {
        AccountDeletionConfirmationDialog(
            onDismiss = { showDeletionDialog = false },
            onConfirmDelete = {
                showDeletionDialog = false
                onDeleteAccountAndData()
            }
        )
    }
}

@Composable
private fun DataCategoryItem(
    title: String,
    subtitle: String
) {
    val themeData = LocalThemeData.current

    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        Text("• ", fontWeight = FontWeight.Bold, color = themeData.primary, fontSize = 12.sp)
        Column {
            Text(title, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = themeData.mainText)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = themeData.mutedText, fontSize = 11.sp)
        }
    }
}

/**
 * Account & Data Deletion explicit confirmation dialog.
 */
@Composable
fun AccountDeletionConfirmationDialog(
    onDismiss: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    var confirmationInput by remember { mutableStateOf("") }
    val canDelete = confirmationInput.trim().equals("DELETE", ignoreCase = true)

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Warning",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "Delete your Logic Loom account?",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.error
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "This action is permanent and cannot be undone. It will permanently purge all local data stored on this device for Logic Loom (by Moraigne):",
                    style = MaterialTheme.typography.bodySmall
                )

                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("• Student Profile & Credentials", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("• Academic Tasks & GPA Module Grades", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("• Study Notes, Flashcards & Vault Documents", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("• Financial Budget Records (ZAR) & Goals", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("• Timetable Slots, Calendar Events & Diary", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("• Gemini AI Assistant Chat History & Preferences", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = "Type \"DELETE\" below to confirm permanent account purge:",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = confirmationInput,
                    onValueChange = { confirmationInput = it },
                    placeholder = { Text("Type DELETE") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_confirm_delete")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmDelete,
                enabled = canDelete,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier.testTag("btn_confirm_delete_account")
            ) {
                Text("Permanently Delete Account", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
