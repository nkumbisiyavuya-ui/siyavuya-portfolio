package com.example.ui.legal

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.legal.model.LegalConsentState
import com.example.legal.model.LegalDocument
import com.example.legal.model.LegalDocumentSection
import com.example.legal.model.LegalDocumentType
import com.example.legal.repository.LegalDocumentRegistry
import com.example.ui.theme.LocalThemeData
import kotlinx.coroutines.launch

/**
 * Dedicated document viewing screen supporting headers, version tags, sections, bullet points,
 * official source links, and legal review notices for Logic Loom designed and engineered by Moraigne.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalDocumentViewerScreen(
    documentType: LegalDocumentType,
    consentState: LegalConsentState,
    onNavigateBack: () -> Unit,
    onAcceptDocument: (LegalDocumentType) -> Unit,
    modifier: Modifier = Modifier
) {
    val themeData = LocalThemeData.current
    val context = LocalContext.current
    val document = LegalDocumentRegistry.getDocument(documentType)

    val isAccepted = when (documentType) {
        LegalDocumentType.TERMS -> consentState.hasAcceptedTerms
        LegalDocumentType.PRIVACY -> consentState.hasAcknowledgedPrivacy
        LegalDocumentType.AI_GUIDELINES -> consentState.hasUnderstoodAiGuidelines
        else -> true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = document.title,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Version ${document.version} • Moraigne",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            shareDocumentText(context, document)
                        }
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share Document")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (documentType.isConsentRequired && !isAccepted) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = {
                                onAcceptDocument(documentType)
                                onNavigateBack()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = themeData.primary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Acknowledge & Record Consent", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        modifier = modifier.testTag("legal_document_viewer_${documentType.id}")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(themeData.secondaryBg),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Metadata Card
            item {
                DocumentHeaderCard(
                    document = document,
                    isAccepted = isAccepted
                )
            }

            // Document Summary
            item {
                DocumentSummaryCard(document = document)
            }

            // Legal Review Notice Section
            item {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Draft clauses are marked [LEGAL REVIEW REQUIRED] for final approval by Moraigne legal counsel prior to formal publication.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }

            // Document Sections
            items(
                items = document.sections,
                key = { it.id }
            ) { section ->
                DocumentSectionCard(section = section)
            }

            // Contact & Footer
            item {
                DocumentFooterCard(document = document)
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun DocumentHeaderCard(
    document: LegalDocument,
    isAccepted: Boolean
) {
    val themeData = LocalThemeData.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = themeData.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = themeData.primary.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "MORAIGNE LEGAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeData.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                if (isAccepted) {
                    Surface(
                        color = Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Consented v${document.version}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = document.title,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = themeData.mainText
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Effective: ${document.effectiveDate}",
                    fontSize = 12.sp,
                    color = themeData.secondaryText
                )
                Text(
                    text = "Updated: ${document.lastUpdated}",
                    fontSize = 12.sp,
                    color = themeData.secondaryText
                )
            }
        }
    }
}

@Composable
private fun DocumentSummaryCard(
    document: LegalDocument
) {
    val themeData = LocalThemeData.current

    Surface(
        color = themeData.lightAccent.copy(alpha = 0.3f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeData.primary.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "EXECUTIVE SUMMARY",
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                color = themeData.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = document.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = themeData.mainText
            )
        }
    }
}

@Composable
private fun DocumentSectionCard(
    section: LegalDocumentSection
) {
    val themeData = LocalThemeData.current

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = themeData.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = section.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = themeData.mainText,
                    modifier = Modifier.weight(1f)
                )

                if (section.isLegalReviewRequired) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "LEGAL REVIEW REQUIRED",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = section.body,
                style = MaterialTheme.typography.bodyMedium,
                color = themeData.secondaryText,
                lineHeight = 20.sp
            )

            if (section.bulletPoints.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    section.bulletPoints.forEach { point ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Text(
                                text = "• ",
                                fontWeight = FontWeight.Bold,
                                color = themeData.primary
                            )
                            Text(
                                text = point,
                                style = MaterialTheme.typography.bodySmall,
                                color = themeData.mainText
                            )
                        }
                    }
                }
            }

            if (section.officialLinks.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Official Verified References:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = themeData.primary
                    )
                    section.officialLinks.forEach { link ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, tint = themeData.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = link.label,
                                style = MaterialTheme.typography.bodySmall,
                                color = themeData.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DocumentFooterCard(
    document: LegalDocument
) {
    val themeData = LocalThemeData.current

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = themeData.secondaryBg),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeData.border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Official Publisher & Governance Entity",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = themeData.mainText
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Logic Loom is designed and engineered by Moraigne.",
                style = MaterialTheme.typography.bodySmall,
                color = themeData.secondaryText
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Contact: ${document.contactEmail}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = themeData.primary
            )
        }
    }
}

private fun shareDocumentText(context: Context, document: LegalDocument) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(
            Intent.EXTRA_SUBJECT,
            "Logic Loom Legal Document - ${document.title} (v${document.version})"
        )
        putExtra(
            Intent.EXTRA_TEXT,
            "Logic Loom (Designed and engineered by Moraigne)\n${document.title} (v${document.version})\nEffective: ${document.effectiveDate}\n\nSummary:\n${document.summary}\n\nFor full legal compliance details visit ${LegalDocumentRegistry.SUPPORT_EMAIL}"
        )
    }
    context.startActivity(Intent.createChooser(shareIntent, "Share Legal Document"))
}
