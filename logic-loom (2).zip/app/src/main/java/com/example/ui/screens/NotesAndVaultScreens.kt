package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.NoteItem
import com.example.data.local.VaultDocument
import com.example.ui.components.VoiceInputIconButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(
    notes: List<NoteItem>,
    onAddNote: (NoteItem) -> Unit,
    onUpdateNote: (NoteItem) -> Unit,
    onDeleteNote: (Long) -> Unit,
    onCreateFlashcardDeck: ((NoteItem) -> Unit)? = null,
    onGenerateStudyQuestions: ((NoteItem?) -> Unit)? = null
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFolder by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }
    var noteToEdit by remember { mutableStateOf<NoteItem?>(null) }
    var pdfExportMessage by remember { mutableStateOf<String?>(null) }

    val folders = listOf("All", "General", "CSC3002F", "Maths", "Commerce")

    val filteredNotes = notes.filter { note ->
        val matchesFolder = if (selectedFolder == "All") true else note.folder == selectedFolder
        val matchesSearch = note.title.contains(searchQuery, ignoreCase = true) || note.content.contains(searchQuery, ignoreCase = true)
        matchesFolder && matchesSearch
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Note")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text("Notes & Summaries", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Rich Text Notes, Voice Notes & Code Snippets", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search notes...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Folders Filter
            ScrollableTabRow(
                selectedTabIndex = folders.indexOf(selectedFolder).coerceAtLeast(0),
                divider = {}
            ) {
                folders.forEach { folder ->
                    FilterChip(
                        selected = selectedFolder == folder,
                        onClick = { selectedFolder = folder },
                        label = { Text(folder) },
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (onGenerateStudyQuestions != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable { onGenerateStudyQuestions(null) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.secondary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Quiz, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("🎯 Generate Study Questions", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            Text("Turn any note into an interactive test with Chuma AI", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f))
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            if (pdfExportMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Text(
                        pdfExportMessage!!,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            if (filteredNotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No notes found in this folder.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredNotes, key = { it.id }) { note ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { noteToEdit = note },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (note.isPinned) {
                                            Icon(Icons.Default.PushPin, contentDescription = "Pinned", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                        }
                                        Text(note.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }

                                    Row {
                                        IconButton(onClick = { onUpdateNote(note.copy(isFavorite = !note.isFavorite)) }) {
                                            Icon(
                                                imageVector = if (note.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                contentDescription = "Favorite",
                                                tint = if (note.isFavorite) Color.Red else Color.Gray
                                            )
                                        }
                                        IconButton(onClick = { onDeleteNote(note.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                        }
                                    }
                                }

                                Text(
                                    note.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )

                                if (note.codeBlock.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Surface(
                                        color = Color(0xFF1E293B),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = note.codeBlock,
                                            color = Color(0xFF38BDF8),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                        Text(note.folder)
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (onGenerateStudyQuestions != null) {
                                            FilledTonalButton(
                                                onClick = { onGenerateStudyQuestions(note) },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.padding(end = 4.dp)
                                            ) {
                                                Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Quiz Me", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        if (onCreateFlashcardDeck != null) {
                                            TextButton(onClick = { onCreateFlashcardDeck(note) }) {
                                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Deck", fontSize = 12.sp)
                                            }
                                        }

                                        TextButton(onClick = { pdfExportMessage = "📄 Note '${note.title}' exported to PDF in Downloads folder!" }) {
                                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("PDF", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddNoteDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newNote ->
                onAddNote(newNote)
                showAddDialog = false
            }
        )
    }

    if (noteToEdit != null) {
        AddNoteDialog(
            existingNote = noteToEdit,
            onDismiss = { noteToEdit = null },
            onConfirm = { updated ->
                onUpdateNote(updated)
                noteToEdit = null
            }
        )
    }
}

@Composable
fun AddNoteDialog(
    existingNote: NoteItem? = null,
    onDismiss: () -> Unit,
    onConfirm: (NoteItem) -> Unit
) {
    var title by remember { mutableStateOf(existingNote?.title ?: "") }
    var content by remember { mutableStateOf(existingNote?.content ?: "") }
    var folder by remember { mutableStateOf(existingNote?.folder ?: "General") }
    var codeBlock by remember { mutableStateOf(existingNote?.codeBlock ?: "") }
    var isPinned by remember { mutableStateOf(existingNote?.isPinned ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingNote == null) "Create New Note" else "Edit Note") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> title = if (title.isEmpty()) text else "$title $text" },
                            prompt = "Dictate note title..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Note Content / Lecture Summary") },
                    trailingIcon = {
                        VoiceInputIconButton(
                            onSpeechResult = { text -> content = if (content.isEmpty()) text else "$content $text" },
                            prompt = "Dictate lecture notes or summary..."
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = folder, onValueChange = { folder = it }, label = { Text("Folder / Module") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = codeBlock,
                    onValueChange = { codeBlock = it },
                    label = { Text("Code Snippet (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPinned, onCheckedChange = { isPinned = it })
                    Text("Pin Note to Top")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(
                            (existingNote ?: NoteItem(title = "", content = "")).copy(
                                title = title,
                                content = content,
                                folder = folder,
                                codeBlock = codeBlock,
                                isPinned = isPinned
                            )
                        )
                    }
                }
            ) {
                Text("Save Note")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(
    documents: List<VaultDocument>,
    onAddDocument: (VaultDocument) -> Unit,
    onDeleteDocument: (Long) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var previewDoc by remember { mutableStateOf<VaultDocument?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    var isSyncing by remember { mutableStateOf(false) }
    var lastSyncedText by remember { mutableStateOf("Synced 2 mins ago") }
    var showCloudSettings by remember { mutableStateOf(false) }
    var selectedCloudProvider by remember { mutableStateOf("All Storage") }
    val cloudProviders = listOf("All Storage", "Logic Loom Cloud", "Google Drive", "OneDrive")

    val categories = listOf("All", "Assignments", "Past Papers", "Lecture Notes", "PDFs", "CV", "Certificates", "Personal Documents")

    val totalUsedMb = documents.sumOf { it.fileSizeMb } + 142.5
    val totalQuotaGb = 15.0
    val totalUsedGb = totalUsedMb / 1024.0
    val storageProgress = (totalUsedGb / totalQuotaGb).toFloat().coerceIn(0f, 1f)

    val filteredDocs = documents.filter { doc ->
        val matchesCat = if (selectedCategory == "All") true else doc.category == selectedCategory
        val matchesSearch = doc.title.contains(searchQuery, ignoreCase = true)
        matchesCat && matchesSearch
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = "Upload to Cloud Storage")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Document Vault & Cloud Storage", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Encrypted Storage & Cloud Drive Sync for Academic Files", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { showCloudSettings = true }) {
                    Icon(Icons.Default.CloudSync, contentDescription = "Cloud Storage Sync Settings", tint = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Cloud Storage Quota & Sync Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudDone, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Logic Loom Cloud Sync Active", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Text(lastSyncedText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Button(
                            onClick = {
                                isSyncing = true
                                lastSyncedText = "Syncing with Cloud..."
                            },
                            enabled = !isSyncing,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            if (isSyncing) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Syncing...", fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sync Now", fontSize = 12.sp)
                            }
                        }
                    }

                    if (isSyncing) {
                        LaunchedEffect(Unit) {
                            kotlinx.coroutines.delay(2000)
                            isSyncing = false
                            lastSyncedText = "Just synced now ✓"
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Storage Usage Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cloud Storage Quota", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        Text("${String.format("%.2f", totalUsedGb)} GB of 15.0 GB used", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LinearProgressIndicator(
                        progress = { storageProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search cloud documents & PDFs...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Cloud Provider Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                cloudProviders.forEach { provider ->
                    FilterChip(
                        selected = selectedCloudProvider == provider,
                        onClick = { selectedCloudProvider = provider },
                        label = { Text(provider, fontSize = 11.sp) },
                        leadingIcon = if (selectedCloudProvider == provider) { { Icon(Icons.Default.Cloud, contentDescription = null, modifier = Modifier.size(12.dp)) } } else null
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Categories
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                divider = {}
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredDocs.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("No vault documents in this category.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredDocs, key = { it.id }) { doc ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { previewDoc = doc },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(doc.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${doc.category} • ${doc.fileSizeMb} MB • Uploaded ${doc.uploadDate}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                IconButton(onClick = { onDeleteDocument(doc.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddVaultDocDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { doc ->
                onAddDocument(doc)
                showAddDialog = false
            }
        )
    }

    if (showCloudSettings) {
        CloudStorageSettingsDialog(onDismiss = { showCloudSettings = false })
    }

    if (previewDoc != null) {
        AlertDialog(
            onDismissRequest = { previewDoc = null },
            title = { Text(previewDoc!!.title) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(80.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("PDF Document Preview", fontWeight = FontWeight.Bold)
                    Text("Category: ${previewDoc!!.category}")
                    Text("File Size: ${previewDoc!!.fileSizeMb} MB")
                    Text("Uploaded on: ${previewDoc!!.uploadDate}")
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("✓ Document is securely encrypted in Logic Loom Local Vault.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                Button(onClick = { previewDoc = null }) { Text("Close Preview") }
            }
        )
    }
}

@Composable
fun AddVaultDocDialog(
    onDismiss: () -> Unit,
    onConfirm: (VaultDocument) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("PDFs") }
    val categories = listOf("Assignments", "Past Papers", "Lecture Notes", "PDFs", "CV", "Certificates", "Personal Documents")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Upload Document to Vault") },
        text = {
            Column {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Document Title (e.g. Past_Paper_2025.pdf)") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                Text("Category", style = MaterialTheme.typography.labelSmall)
                ScrollableTabRow(selectedTabIndex = categories.indexOf(category).coerceAtLeast(0), divider = {}) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val formattedTitle = if (!title.endsWith(".pdf")) "$title.pdf" else title
                        onConfirm(VaultDocument(title = formattedTitle, category = category, fileSizeMb = 1.8, uploadDate = "2026-08-05"))
                    }
                }
            ) {
                Text("Upload Document")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun CloudStorageSettingsDialog(
    onDismiss: () -> Unit
) {
    var autoSyncWifiOnly by remember { mutableStateOf(true) }
    var encryptedBackup by remember { mutableStateOf(true) }
    var backupFrequency by remember { mutableStateOf("Daily") }
    val frequencies = listOf("Real-time", "Daily", "Weekly", "Manual")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cloud Storage & Sync Settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Manage your automated cloud backup, storage providers, and encryption protocols.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Divider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-Sync on Wi-Fi Only", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("Saves mobile data when syncing document vault & notes", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = autoSyncWifiOnly, onCheckedChange = { autoSyncWifiOnly = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("End-to-End Encryption", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Text("AES-256 bit encryption before cloud upload", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = encryptedBackup, onCheckedChange = { encryptedBackup = it })
                }

                Column {
                    Text("Cloud Sync Schedule", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        frequencies.forEach { freq ->
                            FilterChip(
                                selected = backupFrequency == freq,
                                onClick = { backupFrequency = freq },
                                label = { Text(freq, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Save & Close") }
        }
    )
}

