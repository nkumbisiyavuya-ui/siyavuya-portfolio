package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.*
import com.example.R
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.CanvasMateCoolGray
import com.example.ui.theme.CanvasMateNavyDark
import com.example.ui.theme.CanvasMateNavyPrimary
import com.example.ui.theme.CanvasMateWhite
import kotlinx.coroutines.delay

/**
 * Reusable Lottie-based AI Response Loading Indicator.
 * Displays smooth Lottie vector animations for AI response generation,
 * paired with dynamic thought stage updates.
 */
@Composable
fun AiResponseLoadingIndicator(
    modifier: Modifier = Modifier,
    statusText: String = "Chuma AI is thinking…",
    showThoughtStages: Boolean = true
) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.ai_loading_lottie))
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        speed = 1.0f
    )

    var currentStageIndex by remember { mutableIntStateOf(0) }
    val stages = remember {
        listOf(
            "✨ Understanding query & intent…",
            "🔍 Grounding campus timetable & location…",
            "💡 Synthesizing personalized response…",
            "⚡ Formatting insights for you…"
        )
    }

    if (showThoughtStages) {
        LaunchedEffect(Unit) {
            while (true) {
                delay(2200)
                currentStageIndex = (currentStageIndex + 1) % stages.size
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CanvasMateNavyDark),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .padding(vertical = 4.dp)
            .testTag("ai_lottie_loading_card")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Chuma C Logo or Lottie
            Box(
                modifier = Modifier.size(38.dp),
                contentAlignment = Alignment.Center
            ) {
                ChumaCLogo(
                    size = 32.dp,
                    aiState = CanvasMateAiState.THINKING,
                    showGlow = true
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Chuma AI",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF818CF8)
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                val displayText = if (showThoughtStages && stages.isNotEmpty()) stages[currentStageIndex] else statusText

                Text(
                    text = displayText,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = CanvasMateWhite,
                    modifier = Modifier.testTag("ai_loading_status_text")
                )
            }
        }
    }
}

/**
 * Featured Lottie AI Loading Card with Orb Pulse for full screen sheets or heavy generator tasks.
 */
@Composable
fun AiOrbLoadingCard(
    modifier: Modifier = Modifier,
    title: String = "Generating Study Plan",
    subtitle: String = "Chuma AI is building your schedule with courses & deadlines..."
) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.ai_orb_pulse_lottie))
    val progress by animateLottieCompositionAsState(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        speed = 1.2f
    )

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = CanvasMateNavyDark,
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_orb_loading_card")
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(45.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                AccentPurple.copy(alpha = 0.4f),
                                Color.Transparent
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                ChumaCLogo(
                    size = 56.dp,
                    aiState = CanvasMateAiState.THINKING,
                    showGlow = true
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = CanvasMateWhite
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = CanvasMateCoolGray,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}
