package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserProfile
import com.example.ui.navigation.NavRoutes
import com.example.ui.theme.CanvasMateCoolGray
import com.example.ui.theme.CanvasMateNavyDark
import com.example.ui.theme.CanvasMateNavyPrimary
import com.example.ui.theme.CanvasMateWhite

data class DrawerMenuItem(
    val label: String,
    val route: String,
    val icon: ImageVector,
    val badge: String? = null
)

data class DrawerMenuSection(
    val title: String,
    val items: List<DrawerMenuItem>
)

/**
 * Modern Material 3 Navigation Drawer component using androidx.navigation.compose
 * for structured app navigation across Dashboard, Planner, Budget, Settings, and extra modules.
 */
@Composable
fun AppNavigationDrawer(
    currentRoute: String,
    userProfile: UserProfile?,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val menuSections = listOf(
        DrawerMenuSection(
            title = "MAIN",
            items = listOf(
                DrawerMenuItem("Dashboard", NavRoutes.DASHBOARD, Icons.Default.Dashboard)
            )
        ),
        DrawerMenuSection(
            title = "ACADEMIC & PLANNER",
            items = listOf(
                DrawerMenuItem("Academic Planner", NavRoutes.ACADEMIC_PLANNER, Icons.Default.Assignment),
                DrawerMenuItem("Weekly Timetable", NavRoutes.TIMETABLE, Icons.Default.CalendarViewWeek),
                DrawerMenuItem("Calendar 2026", NavRoutes.CALENDAR, Icons.Default.CalendarMonth),
                DrawerMenuItem("Shuttle Schedules", NavRoutes.SHUTTLE_SCHEDULE, Icons.Default.DirectionsBus),
                DrawerMenuItem("Notes & Summaries", NavRoutes.NOTES, Icons.Default.Description),
                DrawerMenuItem("Flashcards (Active Recall)", NavRoutes.FLASHCARDS, Icons.Default.Style),
                DrawerMenuItem("GPA Calculator", NavRoutes.GPA_CALCULATOR, Icons.Default.Calculate)
            )
        ),
        DrawerMenuSection(
            title = "LIFE OPERATING SYSTEM",
            items = listOf(
                DrawerMenuItem("Life OS Hub", NavRoutes.LIFE_HUB, Icons.Default.Explore, badge = "NEW"),
                DrawerMenuItem("Transport Hub", NavRoutes.LIFE_TRANSPORT, Icons.Default.DirectionsCar),
                DrawerMenuItem("Shopping List", NavRoutes.LIFE_SHOPPING, Icons.Default.ShoppingCart),
                DrawerMenuItem("Wallet & Payment Centre", NavRoutes.LIFE_WALLET, Icons.Default.AccountBalanceWallet)
            )
        ),
        DrawerMenuSection(
            title = "FINANCE & GOALS",
            items = listOf(
                DrawerMenuItem("Budget Manager (ZAR)", NavRoutes.BUDGET, Icons.Default.AccountBalanceWallet),
                DrawerMenuItem("Goal Tracker", NavRoutes.GOALS, Icons.Default.TrackChanges)
            )
        ),

        DrawerMenuSection(
            title = "TOOLS & UTILITIES",
            items = listOf(
                DrawerMenuItem("To-Do List", NavRoutes.TODO_LIST, Icons.Default.Checklist),
                DrawerMenuItem("Study Timer", NavRoutes.STUDY_TIMER, Icons.Default.Timer),
                DrawerMenuItem("Chuma AI Assistant", NavRoutes.AI_ASSISTANT, Icons.Default.AutoAwesome, badge = "AI"),
                DrawerMenuItem("Veo 3 Video Studio", NavRoutes.VEO_STUDIO, Icons.Default.Videocam, badge = "VEO 3"),
                DrawerMenuItem("Document Vault", NavRoutes.VAULT, Icons.Default.FolderSpecial),
                DrawerMenuItem("Private Diary", NavRoutes.DIARY, Icons.Default.Book),
                DrawerMenuItem("Analytics", NavRoutes.ANALYTICS, Icons.Default.BarChart)
            )
        ),
        DrawerMenuSection(
            title = "ACCOUNT & SETTINGS",
            items = listOf(
                DrawerMenuItem("Student Profile", NavRoutes.PROFILE, Icons.Default.Person),
                DrawerMenuItem("Settings", NavRoutes.SETTINGS, Icons.Default.Settings),
                DrawerMenuItem("Legal & Safety Center", NavRoutes.LEGAL_CENTER, Icons.Default.Gavel),
                DrawerMenuItem("About Logic Loom", NavRoutes.ABOUT, Icons.Default.Info)
            )
        )
    )

    ModalDrawerSheet(
        modifier = modifier
            .width(300.dp)
            .testTag("nav_drawer_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 16.dp, horizontal = 12.dp)
        ) {
            // Profile Header with 3D Logic Loom Emblem
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .testTag("drawer_profile_header")
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.tertiary
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CanvasMate3DIcon(
                            size = 42.dp,
                            aiState = CanvasMateAiState.IDLE,
                            showGlow = false
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Logic Loom",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Text(
                                text = "Powered by Chuma AI",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = userProfile?.fullName?.ifBlank { null } ?: "Logic Loom Student",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Text(
                        text = userProfile?.email?.ifBlank { null } ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                color = MaterialTheme.colorScheme.outlineVariant
            )

            // Sections & Navigation Items
            menuSections.forEach { section ->
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = section.title,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 12.dp, bottom = 4.dp, top = 4.dp)
                )

                section.items.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationDrawerItem(
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        badge = if (item.badge != null) {
                            {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                                ) {
                                    Text(item.badge, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                        } else null,
                        selected = isSelected,
                        onClick = { onNavigate(item.route) },
                        modifier = Modifier
                            .height(44.dp)
                            .padding(vertical = 2.dp)
                            .testTag("drawer_item_${item.route}")
                    )
                }
            }
        }
    }
}
