package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.viewModelScope
import com.example.CanvasMateApplication
import com.example.data.local.AcademicTask
import com.example.data.local.Task
import com.example.data.local.TodoTask
import com.example.data.repository.CanvasMateRepository
import com.example.data.repository.TaskRepository
import com.example.ui.base.BaseHiltViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.*

@HiltViewModel
class TasksViewModel @Inject constructor(
    application: Application,
    private val repository: CanvasMateRepository,
    private val taskRepository: TaskRepository
) : BaseHiltViewModel(application) {

    constructor(application: Application) : this(
        application,
        (application as CanvasMateApplication).repository,
        (application as CanvasMateApplication).container.taskRepository
    )

    constructor(application: Application, repository: CanvasMateRepository) : this(
        application,
        repository,
        (application as CanvasMateApplication).container.taskRepository
    )

    val firestoreTasks: StateFlow<List<Task>> = taskRepository.firestoreTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allLocalTasks: StateFlow<List<Task>> = taskRepository.allTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val academicTasks: StateFlow<List<AcademicTask>> = repository.academicTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val todoTasks: StateFlow<List<TodoTask>> = repository.todoTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val searchQuery = MutableStateFlow("")
    val selectedAcademicFilter = MutableStateFlow("All")
    val selectedTodoTab = MutableStateFlow("Pending")

    val filteredAcademicTasks: StateFlow<List<AcademicTask>> = combine(
        academicTasks,
        searchQuery,
        selectedAcademicFilter
    ) { tasks, query, filter ->
        tasks.filter { task ->
            val matchesFilter = if (filter == "All") true else task.taskType.equals(filter, ignoreCase = true)
            val matchesQuery = task.title.contains(query, ignoreCase = true) ||
                    task.module.contains(query, ignoreCase = true) ||
                    task.description.contains(query, ignoreCase = true)
            matchesFilter && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val filteredTodoTasks: StateFlow<List<TodoTask>> = combine(
        todoTasks,
        searchQuery,
        selectedTodoTab
    ) { tasks, query, tab ->
        tasks.filter { task ->
            val matchesTab = if (tab == "Pending") !task.isCompleted else task.isCompleted
            val matchesQuery = task.title.contains(query, ignoreCase = true) ||
                    task.priority.contains(query, ignoreCase = true) ||
                    task.dueDate.contains(query, ignoreCase = true)
            matchesTab && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val pendingTodoCount: StateFlow<Int> = todoTasks.map { list ->
        list.count { !it.isCompleted }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val completedTodoCount: StateFlow<Int> = todoTasks.map { list ->
        list.count { it.isCompleted }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // Academic Tasks Actions
    fun addAcademicTask(task: AcademicTask) {
        launchSafe {
            repository.addAcademicTask(task)
        }
    }

    fun updateAcademicTask(task: AcademicTask) {
        launchSafe {
            repository.updateAcademicTask(task)
        }
    }

    fun deleteAcademicTask(id: Long) {
        launchSafe {
            repository.deleteAcademicTask(id)
        }
    }

    // Todo Tasks Actions
    fun addTodoTask(task: TodoTask) {
        launchSafe {
            repository.addTodoTask(task)
        }
    }

    fun updateTodoTask(task: TodoTask) {
        launchSafe {
            repository.updateTodoTask(task)
        }
    }

    fun toggleTodoTaskCompletion(task: TodoTask) {
        launchSafe {
            repository.updateTodoTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTodoTask(id: Long) {
        launchSafe {
            repository.deleteTodoTask(id)
        }
    }

    // Firestore Task Actions
    fun addFirestoreTask(task: Task) {
        launchSafe {
            taskRepository.insertTask(task)
        }
    }

    fun updateFirestoreTask(task: Task) {
        launchSafe {
            taskRepository.updateTask(task)
        }
    }

    fun deleteFirestoreTask(task: Task) {
        launchSafe {
            taskRepository.deleteTask(task)
        }
    }

    fun syncWithFirestore() {
        launchSafe {
            taskRepository.syncTasksWithFirestore()
        }
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setAcademicFilter(filter: String) {
        selectedAcademicFilter.value = filter
    }

    fun setTodoTab(tab: String) {
        selectedTodoTab.value = tab
    }
}
