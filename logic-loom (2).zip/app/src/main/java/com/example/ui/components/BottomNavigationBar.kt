package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.NavRoutes

data class PremiumNavItem(
    val label: String,
    val route: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val associatedRoutes: List<String> = emptyList()
)

/**
 * Logic Loom Premium Floating Glass Bottom Navigation System.
 *
 * Exact 5 primary destinations:
 * 1. Home
 * 2. Tools
 * 3. Chuma AI (Center Luminous Circular Control)
 * 4. Memory
 * 5. Settings
 */
@Composable
fun BottomNavigationBar(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val navItemsLeft = listOf(
        PremiumNavItem(
            label = "Home",
            route = NavRoutes.DASHBOARD,
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            associatedRoutes = listOf(NavRoutes.DASHBOARD)
        ),
        PremiumNavItem(
            label = "Tools",
            route = NavRoutes.TOOLS,
            selectedIcon = Icons.Filled.GridView,
            unselectedIcon = Icons.Outlined.GridView,
            associatedRoutes = listOf(
                NavRoutes.TOOLS,
                NavRoutes.LIFE_HUB,
                NavRoutes.ACADEMIC_PLANNER,
                NavRoutes.TIMETABLE,
                NavRoutes.CALENDAR,
                NavRoutes.STUDY_TIMER,
                NavRoutes.GPA_CALCULATOR,
                NavRoutes.FLASHCARDS,
                NavRoutes.BUDGET,
                NavRoutes.SHUTTLE_SCHEDULE,
                NavRoutes.VEO_STUDIO
            )
        )
    )

    val navItemsRight = listOf(
        PremiumNavItem(
            label = "Memory",
            route = NavRoutes.NOTES,
            selectedIcon = Icons.Filled.Psychology,
            unselectedIcon = Icons.Outlined.Psychology,
            associatedRoutes = listOf(
                NavRoutes.NOTES,
                NavRoutes.MEMORY,
                NavRoutes.VAULT,
                NavRoutes.DIARY,
                NavRoutes.GOALS,
                NavRoutes.TODO_LIST
            )
        ),
        PremiumNavItem(
            label = "Settings",
            route = NavRoutes.SETTINGS,
            selectedIcon = Icons.Filled.Settings,
            unselectedIcon = Icons.Outlined.Settings,
            associatedRoutes = listOf(
                NavRoutes.SETTINGS,
                NavRoutes.PROFILE,
                NavRoutes.ANALYTICS,
                NavRoutes.ABOUT,
                NavRoutes.LEGAL_CENTER
            )
        )
    )

    val isChumaActive = currentRoute == NavRoutes.AI_ASSISTANT

    val infiniteTransition = rememberInfiniteTransition(label = "bottomNavGlow")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chumaGlowAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        // Floating glass bar container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .shadow(
                    elevation = 14.dp,
                    shape = RoundedCornerShape(32.dp),
                    ambientColor = Color(0x60000000),
                    spotColor = Color(0x402563EB)
                )
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xE60D1527),
                            Color(0xF2070D1A)
                        )
                    )
                )
                .border(
                    1.dp,
                    Brush.horizontalGradient(
                        listOf(
                            Color(0x333B82F6),
                            Color(0x6606B6D4),
                            Color(0x333B82F6)
                        )
                    ),
                    RoundedCornerShape(32.dp)
                )
                .testTag("bottom_navigation_bar")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left items: Home & Tools
                navItemsLeft.forEach { item ->
                    val isSelected = currentRoute == item.route || item.associatedRoutes.contains(currentRoute)
                    StandardNavItemView(
                        item = item,
                        isSelected = isSelected,
                        onClick = { onNavigate(item.route) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Center placeholder spacer for elevated Chuma AI control
                Spacer(modifier = Modifier.width(54.dp))

                // Right items: Memory & Settings
                navItemsRight.forEach { item ->
                    val isSelected = currentRoute == item.route || item.associatedRoutes.contains(currentRoute)
                    StandardNavItemView(
                        item = item,
                        isSelected = isSelected,
                        onClick = { onNavigate(item.route) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Center Elevated Chuma AI Control
        Box(
            modifier = Modifier
                .offset(y = (-6).dp)
                .size(54.dp)
                .shadow(
                    elevation = if (isChumaActive) 14.dp else 8.dp,
                    shape = CircleShape,
                    ambientColor = Color(0x8006B6D4),
                    spotColor = if (isChumaActive) Color(0xFF38BDF8) else Color(0xFF2563EB)
                )
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = if (isChumaActive) {
                            listOf(
                                Color(0xFF38BDF8),
                                Color(0xFF2563EB),
                                Color(0xFF0F172A)
                            )
                        } else {
                            listOf(
                                Color(0xFF2563EB),
                                Color(0xFF1D4ED8),
                                Color(0xFF0A0F1D)
                            )
                        }
                    )
                )
                .border(
                    width = if (isChumaActive) 1.5.dp else 1.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            if (isChumaActive) Color(0xFF67E8F9) else Color(0x8838BDF8),
                            Color(0x332563EB)
                        )
                    ),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { onNavigate(NavRoutes.AI_ASSISTANT) }
                )
                .testTag("bottom_nav_chuma_center"),
            contentAlignment = Alignment.Center
        ) {
            ChumaCLogo(
                size = 28.dp,
                showGlow = false,
                showBackgroundContainer = false
            )
        }
    }
}

@Composable
private fun StandardNavItemView(
    item: PremiumNavItem,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconColor by animateColorAsState(
        targetValue = if (isSelected) Color(0xFF60A5FA) else Color(0xFF64748B),
        label = "navIconColor"
    )
    val textColor by animateColorAsState(
        targetValue = if (isSelected) Color(0xFFF1F5F9) else Color(0xFF64748B),
        label = "navTextColor"
    )

    Column(
        modifier = modifier
            .fillMaxHeight()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("bottom_nav_${item.route}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
            contentDescription = item.label,
            tint = iconColor,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = item.label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = textColor
        )
        Spacer(modifier = Modifier.height(2.dp))
        // Subtle active-state glow pill indicator
        Box(
            modifier = Modifier
                .width(12.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(if (isSelected) Color(0xFF38BDF8) else Color.Transparent)
        )
    }
}
