package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.GeneratedVideoAd
import com.example.data.ai.VeoService
import com.example.data.ai.VeoVideoGenerationRequest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class SampleProduct(
    val title: String,
    val category: String,
    val iconEmoji: String,
    val defaultPrompt: String,
    val primaryColor: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VeoStudioScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val sampleProducts = remember {
        listOf(
            SampleProduct("AirPulse Wireless Earbuds", "Electronics", "🎧", "A 360-degree floating camera rotation showcasing the sleek metallic finish with dynamic soundwaves and studio lighting.", Color(0xFF6750A4)),
            SampleProduct("Velocity Nitro Runner", "Footwear", "👟", "High-speed tracking shot of running shoes touching asphalt in slow motion with glowing neon particle trails.", Color(0xFF00668B)),
            SampleProduct("Lumina Glow Serum", "Cosmetics", "✨", "Elegant slow-motion fluid droplets falling around the glass skincare bottle with soft golden sunset lighting.", Color(0xFFB3261E)),
            SampleProduct("Apex Smart Watch", "Wearables", "⌚", "Holographic interface projecting time and fitness stats from the watch dial in a futuristic dark studio.", Color(0xFF2E6C38)),
            SampleProduct("Artisan Dark Roast Coffee", "Beverages", "☕", "Steaming espresso cup with swirling creamy latte art and warm café morning bokeh.", Color(0xFF7D5260))
        )
    }

    val stylePresets = remember {
        listOf(
            "Dynamic 3D Showcase",
            "Cinematic Zoom & Reveal",
            "Neon Cyberpunk Glow",
            "Social Media Reel",
            "Studio Lighting Reveal"
        )
    }

    var selectedProduct by remember { mutableStateOf(sampleProducts[0]) }
    var productTitle by remember { mutableStateOf(sampleProducts[0].title) }
    var promptText by remember { mutableStateOf(sampleProducts[0].defaultPrompt) }
    var selectedStyle by remember { mutableStateOf("Dynamic 3D Showcase") }
    var selectedAspectRatio by remember { mutableStateOf("16:9") } // "16:9", "9:16", "1:1"
    var selectedResolution by remember { mutableStateOf("1080p") }

    var isGenerating by remember { mutableStateOf(false) }
    var generationProgress by remember { mutableFloatStateOf(0f) }
    var generationStepText by remember { mutableStateOf("") }
    var currentVideoAd by remember { mutableStateOf<GeneratedVideoAd?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var playbackProgress by remember { mutableFloatStateOf(0f) }

    val generatedLibrary = remember {
        mutableStateListOf<GeneratedVideoAd>(
            GeneratedVideoAd(
                productTitle = "AirPulse Wireless Earbuds",
                prompt = "A 360-degree floating camera rotation showcasing sleek metallic finish with dynamic soundwaves.",
                stylePreset = "Dynamic 3D Showcase",
                aspectRatio = "16:9",
                resolution = "1080p",
                sampleVideoAnimationType = "orbit_3d"
            )
        )
    }

    // Set initial video ad
    LaunchedEffect(Unit) {
        if (currentVideoAd == null && generatedLibrary.isNotEmpty()) {
            currentVideoAd = generatedLibrary[0]
        }
    }

    // Playback ticker simulation
    LaunchedEffect(isPlaying, isGenerating) {
        if (isPlaying && !isGenerating) {
            while (true) {
                delay(50)
                playbackProgress = (playbackProgress + 0.015f) % 1.0f
            }
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            productTitle = "Custom Product Photo"
            promptText = "Dynamic camera orbit revealing product textures and vibrant lighting effects."
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Veo 3 Video Studio", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Text("AI VEO 3", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Bring product photos to life with dynamic video ads", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // VIDEO PLAYER CANVAS VIEW
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (isGenerating) Color(0xFFFFB703) else Color(0xFF06D6A0))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    if (isGenerating) "Veo 3 Generating..." else "Video Ad Ready",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    "${currentVideoAd?.aspectRatio ?: selectedAspectRatio} • ${currentVideoAd?.resolution ?: selectedResolution} • Veo 3.1",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    color = Color.White,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Video Playback Simulation Canvas
                        val targetRatio = when (currentVideoAd?.aspectRatio ?: selectedAspectRatio) {
                            "9:16" -> 9f / 16f
                            "1:1" -> 1f
                            else -> 16f / 9f
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(if (targetRatio < 1f) 300.dp else 210.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0xFF1E293B), Color(0xFF020617))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isGenerating) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(20.dp)
                                ) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        generationStepText.ifBlank { "Rendering dynamic video frames with Veo 3..." },
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = { generationProgress },
                                        modifier = Modifier
                                            .fillMaxWidth(0.7f)
                                            .height(6.dp)
                                            .clip(CircleShape),
                                    )
                                }
                            } else {
                                // Animated Canvas visualizing the Video Ad
                                AnimatedVideoAdCanvas(
                                    product = selectedProduct,
                                    playbackProgress = playbackProgress,
                                    style = currentVideoAd?.stylePreset ?: selectedStyle
                                )

                                // Video overlay watermark & branding
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(12.dp)
                                ) {
                                    Surface(
                                        modifier = Modifier.align(Alignment.TopStart),
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color.Black.copy(alpha = 0.6f)
                                    ) {
                                        Text(
                                            "🎬 ${currentVideoAd?.productTitle ?: selectedProduct.title}",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    // Floating Play / Pause icon
                                    IconButton(
                                        onClick = { isPlaying = !isPlaying },
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .size(48.dp)
                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                    ) {
                                        Icon(
                                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlaying) "Pause" else "Play",
                                            tint = Color.White,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Video scrubber
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "0:0${(playbackProgress * 5).toInt()}",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )
                            Slider(
                                value = playbackProgress,
                                onValueChange = {
                                    playbackProgress = it
                                    isPlaying = false
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                            )
                            Text("0:05", color = Color.LightGray, fontSize = 11.sp)
                        }

                        // Video Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    // Export simulated ad
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Export MP4", fontSize = 12.sp)
                            }
                            Button(
                                onClick = {
                                    // Share video
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share Ad", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // PRODUCT SELECTION SECTION
            item {
                Text("1. Select or Upload Product Photo", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { galleryLauncher.launch("image/*") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Upload Photo")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("Or choose a sample product to animate:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(sampleProducts) { product ->
                        val isSelected = selectedProduct.title == product.title
                        Card(
                            modifier = Modifier
                                .width(130.dp)
                                .clickable {
                                    selectedProduct = product
                                    productTitle = product.title
                                    promptText = product.defaultPrompt
                                },
                            shape = RoundedCornerShape(16.dp),
                            border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(product.iconEmoji, fontSize = 28.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    product.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // ANIMATION STYLE & PRESETS
            item {
                Text("2. Animation Style & Ad Preset", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(stylePresets) { preset ->
                        FilterChip(
                            selected = selectedStyle == preset,
                            onClick = { selectedStyle = preset },
                            label = { Text(preset, fontSize = 12.sp) },
                            leadingIcon = if (selectedStyle == preset) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            } else null
                        )
                    }
                }
            }

            // VIDEO SPECS: ASPECT RATIO & RESOLUTION
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Aspect Ratio", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("16:9", "9:16", "1:1").forEach { ratio ->
                                FilterChip(
                                    selected = selectedAspectRatio == ratio,
                                    onClick = { selectedAspectRatio = ratio },
                                    label = { Text(ratio, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Resolution", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("1080p", "720p").forEach { res ->
                                FilterChip(
                                    selected = selectedResolution == res,
                                    onClick = { selectedResolution = res },
                                    label = { Text(res, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // PROMPT INPUT
            item {
                Text("3. Dynamic Ad Direction (Prompt)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    placeholder = { Text("Describe camera movements, lighting, particles, and commercial vibe...") }
                )
            }

            // GENERATE BUTTON
            item {
                Button(
                    onClick = {
                        if (!isGenerating) {
                            isGenerating = true
                            generationProgress = 0.1f
                            generationStepText = "Initializing Veo 3 Video Engine..."

                            coroutineScope.launch {
                                delay(600)
                                generationProgress = 0.35f
                                generationStepText = "Synthesizing 3D product depth & lighting..."
                                delay(700)
                                generationProgress = 0.70f
                                generationStepText = "Applying dynamic camera physics & motion paths..."

                                val result = VeoService.generateVideoAd(
                                    VeoVideoGenerationRequest(
                                        prompt = promptText,
                                        productTitle = productTitle,
                                        aspectRatio = selectedAspectRatio,
                                        resolution = selectedResolution,
                                        stylePreset = selectedStyle
                                    )
                                )

                                generationProgress = 1.0f
                                generationStepText = "Finalizing video rendering..."
                                delay(400)

                                if (result.isSuccess) {
                                    val newAd = result.getOrNull()
                                    if (newAd != null) {
                                        currentVideoAd = newAd
                                        generatedLibrary.add(0, newAd)
                                    }
                                }

                                isGenerating = false
                                isPlaying = true
                                playbackProgress = 0f
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    enabled = !isGenerating && promptText.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Rendering with Veo 3...", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Bring Image to Life with Veo 3", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // RECENT GENERATED ADS LIBRARY
            if (generatedLibrary.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Generated Video Ads Library", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }

                items(generatedLibrary) { ad ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                currentVideoAd = ad
                                isPlaying = true
                                playbackProgress = 0f
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ad.productTitle, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${ad.stylePreset} • ${ad.aspectRatio} • ${ad.resolution}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(ad.timestamp, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                            }
                            IconButton(onClick = {
                                currentVideoAd = ad
                                isPlaying = true
                            }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Visual Canvas rendering dynamic product animations simulating Veo 3 motion graphics
 */
@Composable
fun AnimatedVideoAdCanvas(
    product: SampleProduct,
    playbackProgress: Float,
    style: String
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val rotationAngle = (playbackProgress * 360f) % 360f
    val bounceY = kotlin.math.sin(playbackProgress * Math.PI.toFloat() * 4f) * 15f

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Particle trails & glow background
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerOffset = Offset(size.width / 2f, size.height / 2f)

            // Dynamic glow ring
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(product.primaryColor.copy(alpha = 0.4f), Color.Transparent),
                    center = centerOffset,
                    radius = size.minDimension / 2.2f
                ),
                radius = size.minDimension / 2f
            )

            // Orbiting camera rings
            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                radius = (size.minDimension / 3f) * (0.8f + (playbackProgress * 0.4f)),
                style = Stroke(width = 2f)
            )

            // Particle sparks
            for (i in 0 until 8) {
                val angle = (i * 45f + rotationAngle * 0.5f) * (Math.PI.toFloat() / 180f)
                val dist = (size.minDimension / 2.8f) * (0.6f + ((playbackProgress + i * 0.12f) % 1.0f) * 0.5f)
                val x = centerOffset.x + kotlin.math.cos(angle) * dist
                val y = centerOffset.y + kotlin.math.sin(angle) * dist
                drawCircle(
                    color = product.primaryColor.copy(alpha = 0.8f),
                    radius = 4f,
                    center = Offset(x, y)
                )
            }
        }

        // Product Visual Presentation
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .scale(pulseScale)
                .rotate(if (style.contains("Spin", ignoreCase = true)) rotationAngle * 0.15f else 0f)
        ) {
            Surface(
                shape = CircleShape,
                color = product.primaryColor.copy(alpha = 0.25f),
                border = BorderStroke(2.dp, product.primaryColor.copy(alpha = 0.6f)),
                modifier = Modifier.size(88.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(product.iconEmoji, fontSize = 42.sp)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                product.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                textAlign = TextAlign.Center
            )
            Text(
                "Dynamic Ad • Powered by Veo 3",
                color = Color(0xFFFFB703),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
