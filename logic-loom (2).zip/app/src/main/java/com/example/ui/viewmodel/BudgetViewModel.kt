package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BudgetGoal
import com.example.data.local.BudgetItem
import com.example.data.repository.CanvasMateRepository
import com.example.CanvasMateApplication
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@HiltViewModel
class BudgetViewModel @Inject constructor(
    application: Application,
    private val repository: CanvasMateRepository
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application,
        (application as CanvasMateApplication).repository
    )

    val budgetItems: StateFlow<List<BudgetItem>> = repository.budgetItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val budgetGoals: StateFlow<List<BudgetGoal>> = repository.budgetGoals.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val totalIncome: StateFlow<Double> = budgetItems.map { items ->
        items.filter { it.type.equals("Income", ignoreCase = true) }.sumOf { it.amount }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0.0
    )

    val totalExpenses: StateFlow<Double> = budgetItems.map { items ->
        items.filter { it.type.equals("Expense", ignoreCase = true) }.sumOf { it.amount }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0.0
    )

    val netBalance: StateFlow<Double> = combine(totalIncome, totalExpenses) { income, expense ->
        income - expense
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0.0
    )

    val categoryExpenses: StateFlow<Map<String, Double>> = budgetItems.map { items ->
        items.filter { it.type.equals("Expense", ignoreCase = true) }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyMap()
    )

    fun addBudgetItem(item: BudgetItem) {
        viewModelScope.launch {
            repository.addBudgetItem(item)
        }
    }

    fun updateBudgetItem(item: BudgetItem) {
        viewModelScope.launch {
            repository.updateBudgetItem(item)
        }
    }

    fun deleteBudgetItem(id: Long) {
        viewModelScope.launch {
            repository.deleteBudgetItem(id)
        }
    }

    fun addBudgetGoal(goal: BudgetGoal) {
        viewModelScope.launch {
            repository.addBudgetGoal(goal)
        }
    }

    fun updateBudgetGoal(goal: BudgetGoal) {
        viewModelScope.launch {
            repository.updateBudgetGoal(goal)
        }
    }

    fun deleteBudgetGoal(id: Long) {
        viewModelScope.launch {
            repository.deleteBudgetGoal(id)
        }
    }
}
