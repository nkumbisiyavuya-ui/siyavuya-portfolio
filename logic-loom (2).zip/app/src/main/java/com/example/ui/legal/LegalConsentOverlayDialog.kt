package com.example.ui.legal

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.legal.model.LegalConsentState
import com.example.legal.model.LegalDocumentType
import com.example.legal.repository.LegalDocumentRegistry
import com.example.ui.theme.LocalThemeData
import kotlinx.coroutines.launch

/**
 * First-launch and updated terms legal consent dialog.
 * Requires explicit acknowledgement with default UNCHECKED consent controls.
 * Saves versioned consent with dynamic ISO timestamps.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalConsentOverlayDialog(
    consentState: LegalConsentState,
    onAcceptAllConsents: (acceptTerms: Boolean, ackPrivacy: Boolean, understandAi: Boolean) -> Unit,
    onOpenDocument: (LegalDocumentType) -> Unit,
    modifier: Modifier = Modifier
) {
    val themeData = LocalThemeData.current

    // Explicit UNCHECKED controls by default
    var checkedTerms by remember { mutableStateOf(false) }
    var checkedPrivacy by remember { mutableStateOf(false) }
    var checkedAiGuidelines by remember { mutableStateOf(false) }

    val allChecked = checkedTerms && checkedPrivacy && checkedAiGuidelines

    Dialog(
        onDismissRequest = { /* Block dismiss until consented */ },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = modifier
                .fillMaxSize()
                .testTag("first_launch_legal_dialog"),
            color = themeData.secondaryBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))

                    // Brand Badge
                    Surface(
                        color = themeData.primary.copy(alpha = 0.12f),
                        shape = CircleShape
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = themeData.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "MORAIGNE LEGAL & COMPLIANCE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = themeData.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (consentState.needsReconsent) "Updated Legal Terms Review" else "Welcome to Logic Loom",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = themeData.mainText,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Logic Loom is designed and engineered by Moraigne.",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = themeData.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Before accessing Logic Loom productivity tools, please review and accept our required legal agreements, privacy policy, and Chuma AI assistant guidelines.",
                        style = MaterialTheme.typography.bodySmall,
                        color = themeData.secondaryText,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Legal Review Notice Banner
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Logic Loom is a technology platform designed and engineered by Moraigne. Legal draft clauses are marked [LEGAL REVIEW REQUIRED] for final review by Moraigne legal counsel.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Required Unchecked Consent Items
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // 1. Terms & Conditions
                        ConsentCheckboxItem(
                            title = "Terms & Conditions (v${LegalDocumentRegistry.CURRENT_LEGAL_VERSION})",
                            subtitle = "Operated by Moraigne. Defines user responsibilities, AI limits, and service boundaries.",
                            isChecked = checkedTerms,
                            onCheckedChange = { checkedTerms = it },
                            onReadDocument = { onOpenDocument(LegalDocumentType.TERMS) },
                            icon = Icons.Default.Gavel,
                            testTag = "checkbox_terms"
                        )

                        // 2. Privacy Policy
                        ConsentCheckboxItem(
                            title = "Privacy Policy (v${LegalDocumentRegistry.CURRENT_LEGAL_VERSION})",
                            subtitle = "Discloses categories collected (Account, Notes, Vault, Budget ZAR, Timetable) and local storage.",
                            isChecked = checkedPrivacy,
                            onCheckedChange = { checkedPrivacy = it },
                            onReadDocument = { onOpenDocument(LegalDocumentType.PRIVACY) },
                            icon = Icons.Default.PrivacyTip,
                            testTag = "checkbox_privacy"
                        )

                        // 3. AI Guidelines
                        ConsentCheckboxItem(
                            title = "Chuma AI Guidelines (v${LegalDocumentRegistry.CURRENT_LEGAL_VERSION})",
                            subtitle = "Explains AI accuracy limits, verification requirements, and academic integrity.",
                            isChecked = checkedAiGuidelines,
                            onCheckedChange = { checkedAiGuidelines = it },
                            onReadDocument = { onOpenDocument(LegalDocumentType.AI_GUIDELINES) },
                            icon = Icons.Default.AutoAwesome,
                            testTag = "checkbox_ai_guidelines"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Bottom Action Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            if (allChecked) {
                                onAcceptAllConsents(checkedTerms, checkedPrivacy, checkedAiGuidelines)
                            }
                        },
                        enabled = allChecked,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = themeData.primary,
                            disabledContainerColor = themeData.border
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_accept_and_continue")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (allChecked) "Accept & Continue to Logic Loom" else "Select All Required Checkboxes to Continue",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "By continuing, your versioned consent (v${LegalDocumentRegistry.CURRENT_LEGAL_VERSION}) will be recorded with an ISO dynamic timestamp.",
                        fontSize = 11.sp,
                        color = themeData.mutedText,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun ConsentCheckboxItem(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    onReadDocument: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String
) {
    val themeData = LocalThemeData.current

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isChecked) themeData.lightAccent.copy(alpha = 0.35f) else themeData.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isChecked) 2.dp else 1.dp,
            color = if (isChecked) themeData.primary else themeData.border
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.Top
            ) {
                Checkbox(
                    checked = isChecked,
                    onCheckedChange = onCheckedChange,
                    colors = CheckboxDefaults.colors(
                        checkedColor = themeData.primary,
                        uncheckedColor = themeData.secondaryText
                    ),
                    modifier = Modifier.size(24.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isChecked) themeData.primary else themeData.mutedText,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isChecked) themeData.primary else themeData.mainText
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 12.sp,
                        color = themeData.secondaryText
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Read Full Document Button
                    Surface(
                        onClick = onReadDocument,
                        color = themeData.secondaryBg,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, themeData.border)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "Read Full Document",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = themeData.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = themeData.primary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
