package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserProfile
import com.example.security.PasswordStrengthLevel
import com.example.security.PasswordStrengthValidator
import com.example.ui.CanvasMateViewModel
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun OnboardingScreen(
    onFinishOnboarding: () -> Unit
) {
    var currentPage by remember { mutableStateOf(0) }

    val pages = listOf(
        OnboardingPageData(
            title = "Welcome to Logic Loom",
            description = "A smarter space for learning, thinking and creating.",
            icon = Icons.Default.AutoAwesome,
            color = MaterialTheme.colorScheme.primary
        ),
        OnboardingPageData(
            title = "Meet Chuma AI",
            description = "Your intelligent AI assistant for questions, ideas, research, writing and problem solving.",
            icon = Icons.Default.Psychology,
            color = MaterialTheme.colorScheme.secondary
        ),
        OnboardingPageData(
            title = "Bring your work",
            description = "Ask questions, analyze files, research topics and turn ideas into something useful.",
            icon = Icons.Default.FolderSpecial,
            color = MaterialTheme.colorScheme.tertiary
        ),
        OnboardingPageData(
            title = "Make it yours",
            description = "Logic Loom can adapt to the way you learn and work.",
            icon = Icons.Default.Tune,
            color = Color(0xFF2979FF)
        )
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onFinishOnboarding) {
                    Text("Skip", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            val page = pages[currentPage]
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(page.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    when (currentPage) {
                        0 -> {
                            com.example.ui.components.CanvasMate3DIcon(
                                size = 100.dp,
                                showGlow = true
                            )
                        }
                        1 -> {
                            com.example.ui.components.ChumaCLogo(
                                size = 80.dp,
                                showGlow = true
                            )
                        }
                        else -> {
                            Icon(
                                imageVector = page.icon,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = page.color
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Text(
                    text = page.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = page.description,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    pages.indices.forEach { index ->
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .size(if (index == currentPage) 24.dp else 8.dp, 8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (index == currentPage) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outlineVariant
                                )
                        )
                    }
                }

                Button(
                    onClick = {
                        if (currentPage < pages.size - 1) {
                            currentPage++
                        } else {
                            onFinishOnboarding()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        if (currentPage == pages.size - 1) "Get Started" else "Next",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

private data class OnboardingPageData(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val color: Color
)

// =========================================================================
// LOGIC LOOM 2026 AI-PRODUCT AUTHENTICATION SYSTEM
// Intelligence Layer: Chuma AI | Parent Company: Moraigne
// =========================================================================

private val DeepNavyBg = Color(0xFF070D1E)
private val DeepNavyCard = Color(0xFF0F1B2E)
private val NavyFieldBg = Color(0xFF0A1324)
private val NavyBorder = Color(0xFF1E2F4D)
private val ElectricBlue = Color(0xFF2563EB)
private val ElectricBlueHover = Color(0xFF1D4ED8)
private val ElectricCyan = Color(0xFF00E5FF)
private val ElectricViolet = Color(0xFF7C4DFF)

@Composable
fun AuthBackgroundContainer(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "authLoomTransition")
    val loomPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "authLoomPhase"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavyBg),
        contentAlignment = Alignment.Center
    ) {
        // Interconnected loom background canvas echoing welcoming splash screen
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.25f)
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h * 0.35f

            for (i in 0 until 5) {
                val offsetAngle = (i * Math.PI / 2.5).toFloat() + loomPhase
                val path = Path()
                val radius = (100f + i * 26f)

                val x1 = cx + radius * cos(offsetAngle)
                val y1 = cy + radius * sin(offsetAngle)
                val x2 = cx + radius * cos(offsetAngle + Math.PI.toFloat())
                val y2 = cy + radius * sin(offsetAngle + Math.PI.toFloat())

                path.moveTo(x1, y1)
                val ctrlX = cx + (radius * 0.55f) * cos(offsetAngle + 1.1f)
                val ctrlY = cy + (radius * 0.55f) * sin(offsetAngle + 1.1f)
                path.quadraticBezierTo(ctrlX, ctrlY, x2, y2)

                val threadColor = when (i % 3) {
                    0 -> ElectricCyan
                    1 -> ElectricBlue
                    else -> ElectricViolet
                }

                drawPath(
                    path = path,
                    color = threadColor.copy(alpha = 0.35f),
                    style = Stroke(width = 2f, cap = StrokeCap.Round)
                )

                drawCircle(
                    color = threadColor.copy(alpha = 0.7f),
                    radius = 4f,
                    center = Offset(x1, y1)
                )
            }
        }

        // Ambient radial light glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ElectricBlue.copy(alpha = 0.15f),
                            ElectricViolet.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        center = Offset.Unspecified,
                        radius = 800f
                    )
                )
        )

        // Safe area scrollable viewport
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 440.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                content()
            }
        }
    }
}

@Composable
fun AuthHeaderBranding() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(bottom = 20.dp)
    ) {
        com.example.ui.components.CanvasMate3DIcon(
            size = 52.dp,
            showGlow = true
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "LOGIC LOOM",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 3.5.sp,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            color = DeepNavyCard,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ElectricCyan,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Powered by Chuma AI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFCBD5E1)
                )
            }
        }
    }
}

@Composable
fun AuthCardPanel(
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = DeepNavyCard.copy(alpha = 0.90f),
        border = BorderStroke(1.dp, NavyBorder),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            content = content
        )
    }
}

@Composable
fun AuthFeedbackBanner(
    error: String? = null,
    success: String? = null,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(visible = error != null || success != null) {
        Column(modifier = modifier.padding(bottom = 16.dp)) {
            if (error != null) {
                Surface(
                    color = Color(0xFF3F1218).copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, Color(0xFF991B1B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = Color(0xFFF87171),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = error,
                            color = Color(0xFFFCA5A5),
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            } else if (success != null) {
                Surface(
                    color = Color(0xFF052F1C).copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, Color(0xFF166534)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircleOutline,
                            contentDescription = null,
                            tint = Color(0xFF4ADE80),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = success,
                            color = Color(0xFF86EFAC),
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AuthCustomTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onTogglePassword: (() -> Unit)? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 13.sp) },
        leadingIcon = {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
        },
        trailingIcon = if (isPassword && onTogglePassword != null) {
            {
                IconButton(onClick = onTogglePassword) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                        tint = if (passwordVisible) ElectricCyan else Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        } else null,
        visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
        shape = RoundedCornerShape(14.dp),
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ElectricBlue,
            unfocusedBorderColor = NavyBorder,
            focusedContainerColor = NavyFieldBg,
            unfocusedContainerColor = NavyFieldBg.copy(alpha = 0.65f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color(0xFFF1F5F9),
            focusedLabelColor = Color(0xFF38BDF8),
            unfocusedLabelColor = Color(0xFF94A3B8),
            cursorColor = ElectricCyan,
            focusedLeadingIconColor = Color(0xFF38BDF8),
            unfocusedLeadingIconColor = Color(0xFF64748B)
        ),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
    )
}

@Composable
fun AuthPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled && !isLoading,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = Color(0xFF1E293B)
        ),
        contentPadding = PaddingValues(0.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(
                if (enabled && !isLoading) {
                    Brush.horizontalGradient(listOf(ElectricBlue, ElectricBlueHover))
                } else {
                    Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))
                },
                shape = RoundedCornerShape(14.dp)
            )
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = Color.White,
                strokeWidth = 2.5.dp
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (enabled) Color.White else Color(0xFF64748B)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = if (enabled) Color.White else Color(0xFF64748B),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun GoogleLogoIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(19.dp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val r = w / 2f

        // Google colors
        val blue = Color(0xFF4285F4)
        val red = Color(0xFFEA4335)
        val yellow = Color(0xFFFBBC05)
        val green = Color(0xFF34A853)

        // Outer ring
        drawArc(color = red, startAngle = 180f, sweepAngle = 90f, useCenter = true)
        drawArc(color = yellow, startAngle = 90f, sweepAngle = 90f, useCenter = true)
        drawArc(color = green, startAngle = 0f, sweepAngle = 90f, useCenter = true)
        drawArc(color = blue, startAngle = 270f, sweepAngle = 90f, useCenter = true)

        // Inner cutout to make it a letter
        drawCircle(color = Color(0xFF132037), radius = r * 0.6f, center = Offset(cx, cy))

        // Center bar of G
        drawRect(
            color = blue,
            topLeft = Offset(cx, cy - (r * 0.22f)),
            size = androidx.compose.ui.geometry.Size(r * 0.95f, r * 0.44f)
        )
    }
}

@Composable
fun GoogleAuthButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    text: String = "Continue with Google"
) {
    Surface(
        onClick = onClick,
        enabled = !isLoading,
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF132037),
        border = BorderStroke(1.dp, Color(0xFF223554)),
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            GoogleLogoIcon()
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = text,
                color = Color(0xFFE2E8F0),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun AuthDivider() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = Color(0xFF1E2F4D),
            thickness = 1.dp
        )
        Text(
            text = "or",
            fontSize = 12.sp,
            color = Color(0xFF64748B),
            modifier = Modifier.padding(horizontal = 14.dp)
        )
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = Color(0xFF1E2F4D),
            thickness = 1.dp
        )
    }
}

@Composable
fun AuthFooterAttribution() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
    ) {
        Text(
            text = "Designed and engineered by Moraigne",
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.4.sp,
            color = Color(0xFF475569)
        )
    }
}

// =========================================================================
// 1. LOGIN SCREEN (LOGIC LOOM PREMIUM CINEMATIC RED ENTRANCE)
// =========================================================================

@Composable
fun LoginScreen(
    viewModel: CanvasMateViewModel,
    onLoginSuccess: () -> Unit,
    onNavigateRegister: () -> Unit,
    onNavigateForgotPassword: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }

    val authError by viewModel.authError.collectAsState()
    val authSuccessMsg by viewModel.authSuccessMessage.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()

    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    // Human-readable error translation
    val displayError = remember(authError) {
        authError?.let { err ->
            when {
                err.contains("password", ignoreCase = true) && (err.contains("wrong", ignoreCase = true) || err.contains("invalid", ignoreCase = true)) ->
                    "Incorrect password. Please verify and try again."
                err.contains("user", ignoreCase = true) && (err.contains("no user", ignoreCase = true) || err.contains("not found", ignoreCase = true)) ->
                    "No account found with this email. Please check or sign up."
                err.contains("network", ignoreCase = true) || err.contains("connection", ignoreCase = true) ->
                    "Network error. Please check your internet connection."
                err.contains("badly formatted", ignoreCase = true) || err.contains("format", ignoreCase = true) ->
                    "Please enter a valid email address."
                else -> err
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen_container")
    ) {
        // Fullscreen Cinematic Warm Background with Sunrise Atmosphere & Subtle Red Reflections
        LoginCinematicAtmosphericBackground()

        // Scrollable content respecting safe areas and soft keyboard
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(28.dp))

            // TOP BRAND AREA: Existing Logic Loom 3D Logo + "THINK / CREATE / ACHIEVE"
            com.example.ui.components.CanvasMate3DIcon(
                size = 48.dp,
                showGlow = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "THINK",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.2.sp
                )
                Text(
                    text = "  /  ",
                    color = Color(0xFFDC2626),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "CREATE",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.2.sp
                )
                Text(
                    text = "  /  ",
                    color = Color(0xFFDC2626),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "ACHIEVE",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.2.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // EDITORIAL MAIN HEADLINE
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Your Intelligence.",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 42.sp,
                    letterSpacing = (-0.8).sp,
                    color = Color.White
                )
                Text(
                    text = "Amplified.",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 42.sp,
                    letterSpacing = (-0.8).sp,
                    color = Color(0xFFE11D48)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // SUPPORTING COPY
                Text(
                    text = "Log in to unlock your AI assistant,\nproductivity tools and a smarter you.",
                    fontSize = 14.sp,
                    lineHeight = 21.sp,
                    color = Color(0xFFCBD5E1)
                )
            }

            Spacer(modifier = Modifier.height(26.dp))

            // FLOATING LOGIN GLASS PANEL
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(28.dp),
                        ambientColor = Color(0x80000000),
                        spotColor = Color(0x40DC2626)
                    )
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xE6130A10),
                                Color(0xF20F070C)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                Color(0x40FFFFFF),
                                Color(0x66DC2626),
                                Color(0x22DC2626),
                                Color(0x15FFFFFF)
                            )
                        ),
                        RoundedCornerShape(28.dp)
                    )
                    .padding(22.dp)
                    .testTag("login_glass_panel")
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Feedback Banner (Errors / Messages)
                    if (displayError != null || authSuccessMsg != null) {
                        AuthFeedbackBanner(
                            error = displayError,
                            success = authSuccessMsg,
                            modifier = Modifier.padding(bottom = 14.dp)
                        )
                    }

                    // Email Address Field
                    LoginGlassInputField(
                        value = email,
                        onValueChange = {
                            email = it
                            if (authError != null || authSuccessMsg != null) viewModel.clearAuthMessages()
                        },
                        label = "Email address",
                        leadingIcon = Icons.Outlined.Email,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        testTag = "login_email_input"
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Password Field
                    LoginGlassInputField(
                        value = password,
                        onValueChange = {
                            password = it
                            if (authError != null || authSuccessMsg != null) viewModel.clearAuthMessages()
                        },
                        label = "Password",
                        leadingIcon = Icons.Outlined.Lock,
                        isPassword = true,
                        passwordVisible = passwordVisible,
                        onTogglePassword = { passwordVisible = !passwordVisible },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                if (email.isNotBlank() && password.isNotBlank()) {
                                    viewModel.loginUser(email, password, onSuccess = onLoginSuccess)
                                }
                            }
                        ),
                        testTag = "login_password_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Remember Me & Forgot Password Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Remember Me custom toggle
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable { rememberMe = !rememberMe }
                                .padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(
                                        if (rememberMe) Color(0xFFDC2626) else Color(0x33FFFFFF)
                                    )
                                    .border(
                                        1.dp,
                                        if (rememberMe) Color(0xFFEF4444) else Color(0x55FFFFFF),
                                        RoundedCornerShape(5.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (rememberMe) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Remember me",
                                fontSize = 13.sp,
                                color = Color(0xFFCBD5E1),
                                fontWeight = FontWeight.Normal
                            )
                        }

                        // Forgot Password Link in Logic Loom Red
                        Text(
                            text = "Forgot password?",
                            color = Color(0xFFF43F5E),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable { onNavigateForgotPassword() }
                                .padding(vertical = 4.dp)
                                .testTag("forgot_password_link")
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // PRIMARY LOGIN BUTTON: Logic Loom Red Gradient CTA
                    LoginPrimaryButton(
                        text = "Log In   →",
                        isLoading = isAuthLoading,
                        enabled = email.isNotBlank() && password.isNotBlank(),
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.loginUser(email, password, onSuccess = onLoginSuccess)
                        },
                        modifier = Modifier.testTag("login_button")
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Social Divider: "or continue with"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = Color(0x33DC2626),
                            thickness = 1.dp
                        )
                        Text(
                            text = "or continue with",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = Color(0x33DC2626),
                            thickness = 1.dp
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Secondary Action: Google Sign-In (Real implementation only)
                    GoogleAuthButton(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.performGoogleSignIn(context, onSuccess = onLoginSuccess)
                        },
                        isLoading = isAuthLoading,
                        text = "Continue with Google",
                        modifier = Modifier.testTag("google_login_button")
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Switch to Sign Up: "Don't have an account? Sign Up"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Don't have an account? ",
                            fontSize = 13.sp,
                            color = Color(0xFFCBD5E1)
                        )
                        Text(
                            text = "Sign Up",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF43F5E),
                            modifier = Modifier
                                .clickable { onNavigateRegister() }
                                .padding(vertical = 4.dp)
                                .testTag("navigate_signup_link")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // FOOTER: "BUILT FOR A SMARTER TOMORROW" with red accent lines
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .width(28.dp)
                        .height(1.dp)
                        .background(Color(0x66DC2626))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "BUILT FOR A SMARTER TOMORROW",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .width(28.dp)
                        .height(1.dp)
                        .background(Color(0x66DC2626))
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// -------------------------------------------------------------
// Cinematic Warm Background with Sunrise & Subtle Red Light
// -------------------------------------------------------------
@Composable
private fun LoginCinematicAtmosphericBackground() {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = com.example.R.drawable.img_login_cinematic_bg_1790339301648),
            contentDescription = "Cinematic South African Sunrise Landscape",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Controlled dark/translucent scrim gradient and red ambient reflection
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Warm subtle red ambient aura reflection
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x38DC2626),
                        Color(0x14B91C1C),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.2f, h * 0.8f),
                    radius = w * 0.7f
                )
            )

            // Deep editorial vignette & translucent dark scrim for high contrast and readability
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0x75080507),
                        Color(0x900C0609),
                        Color(0xEE080507),
                        Color(0xFA050204)
                    )
                )
            )
        }
    }
}

// -------------------------------------------------------------
// Premium Glass Input Field with Logic Loom Red Focused State
// -------------------------------------------------------------
@Composable
private fun LoginGlassInputField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onTogglePassword: (() -> Unit)? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    testTag: String = ""
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = {
            Text(
                text = label,
                fontSize = 13.sp,
                color = if (isFocused) Color(0xFFF43F5E) else Color(0xFF94A3B8)
            )
        },
        leadingIcon = {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = if (isFocused) Color(0xFFF43F5E) else Color(0xFF94A3B8),
                modifier = Modifier.size(20.dp)
            )
        },
        trailingIcon = if (isPassword && onTogglePassword != null) {
            {
                IconButton(onClick = onTogglePassword) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                        tint = if (passwordVisible) Color(0xFFF43F5E) else Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        } else null,
        visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
        shape = RoundedCornerShape(16.dp),
        singleLine = true,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        interactionSource = interactionSource,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFDC2626),
            unfocusedBorderColor = Color(0x33FFFFFF),
            focusedContainerColor = Color(0x6624101A),
            unfocusedContainerColor = Color(0x40180B12),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color(0xFFF1F5F9),
            focusedLabelColor = Color(0xFFF43F5E),
            unfocusedLabelColor = Color(0xFF94A3B8),
            cursorColor = Color(0xFFEF4444)
        ),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .testTag(testTag)
    )
}

// -------------------------------------------------------------
// Primary Red CTA Button with Top Glass Edge & Press Animation
// -------------------------------------------------------------
@Composable
private fun LoginPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled && !isLoading) 0.98f else 1.0f,
        animationSpec = tween(120, easing = FastOutSlowInEasing),
        label = "loginBtnScale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .scale(scale)
            .shadow(
                elevation = if (enabled && !isLoading) 12.dp else 2.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = Color(0x40000000),
                spotColor = Color(0x99DC2626)
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (enabled && !isLoading) {
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xFFE11D48),
                            Color(0xFFDC2626),
                            Color(0xFFB91C1C)
                        )
                    )
                } else {
                    Brush.horizontalGradient(
                        listOf(
                            Color(0x3326121B),
                            Color(0x2226121B)
                        )
                    )
                }
            )
            .border(
                1.dp,
                if (enabled && !isLoading) {
                    Brush.linearGradient(
                        listOf(
                            Color(0x88FFA4B6),
                            Color(0x33DC2626)
                        )
                    )
                } else {
                    Brush.linearGradient(listOf(Color(0x22FFFFFF), Color.Transparent))
                },
                RoundedCornerShape(16.dp)
            )
            .clickable(
                enabled = enabled && !isLoading,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = Color.White,
                strokeWidth = 2.5.dp
            )
        } else {
            Text(
                text = text,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (enabled) Color.White else Color(0xFF64748B),
                letterSpacing = 0.5.sp
            )
        }
    }
}

// =========================================================================
// 2. SIGN-UP / REGISTER SCREEN
// =========================================================================

@Composable
fun RegisterScreen(
    viewModel: CanvasMateViewModel,
    onRegisterSuccess: () -> Unit,
    onNavigateLogin: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var studentNumber by remember { mutableStateOf("") }
    var university by remember { mutableStateOf("") }

    var passwordVisible by remember { mutableStateOf(false) }
    var confirmVisible by remember { mutableStateOf(false) }

    val authError by viewModel.authError.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()

    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    val passwordValidation = remember(password) {
        PasswordStrengthValidator.validate(password)
    }

    val passwordsMatch = remember(password, confirmPassword) {
        confirmPassword.isEmpty() || password == confirmPassword
    }

    AuthBackgroundContainer {
        AuthHeaderBranding()

        AuthCardPanel {
            Text(
                text = "Create your account",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Start building your workspace with Logic Loom",
                fontSize = 14.sp,
                color = Color(0xFF94A3B8)
            )

            Spacer(modifier = Modifier.height(22.dp))

            // Feedback Banner
            AuthFeedbackBanner(error = authError)

            // Full Name Input
            AuthCustomTextField(
                value = fullName,
                onValueChange = {
                    fullName = it
                    if (authError != null) viewModel.clearAuthMessages()
                },
                label = "Full Name",
                leadingIcon = Icons.Default.Person,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Email Input
            AuthCustomTextField(
                value = email,
                onValueChange = {
                    email = it
                    if (authError != null) viewModel.clearAuthMessages()
                },
                label = "Email Address",
                leadingIcon = Icons.Default.Email,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Password Input
            AuthCustomTextField(
                value = password,
                onValueChange = {
                    password = it
                    if (authError != null) viewModel.clearAuthMessages()
                },
                label = "Password",
                leadingIcon = Icons.Default.Lock,
                isPassword = true,
                passwordVisible = passwordVisible,
                onTogglePassword = { passwordVisible = !passwordVisible },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier.testTag("signup_password_input")
            )

            // Real-time password strength meter
            if (password.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                    val progress = (passwordValidation.score / 100f).coerceIn(0.1f, 1.0f)
                    val strengthColor = when (passwordValidation.level) {
                        PasswordStrengthLevel.WEAK -> Color(0xFFEF4444)
                        PasswordStrengthLevel.MEDIUM -> Color(0xFFF59E0B)
                        PasswordStrengthLevel.STRONG -> Color(0xFF10B981)
                        PasswordStrengthLevel.VERY_STRONG -> ElectricCyan
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = strengthColor,
                        trackColor = Color(0xFF1E2F4D)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Strength: ${passwordValidation.level.name.replace("_", " ")}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = strengthColor
                        )
                        Text(
                            text = passwordValidation.feedbackMessage,
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Confirm Password Input
            AuthCustomTextField(
                value = confirmPassword,
                onValueChange = {
                    confirmPassword = it
                    if (authError != null) viewModel.clearAuthMessages()
                },
                label = "Confirm Password",
                leadingIcon = Icons.Default.LockReset,
                isPassword = true,
                passwordVisible = confirmVisible,
                onTogglePassword = { confirmVisible = !confirmVisible },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { focusManager.clearFocus() }
                )
            )

            if (!passwordsMatch && confirmPassword.isNotEmpty()) {
                Text(
                    text = "Passwords do not match.",
                    fontSize = 11.sp,
                    color = Color(0xFFF87171),
                    modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Primary Action: Create Account
            val canSubmit = fullName.isNotBlank() &&
                    email.isNotBlank() &&
                    password.length >= 8 &&
                    passwordsMatch

            AuthPrimaryButton(
                text = "Create account",
                isLoading = isAuthLoading,
                enabled = canSubmit,
                onClick = {
                    focusManager.clearFocus()
                    val effectiveStudentNum = studentNumber.trim().ifEmpty {
                        "LL-" + (1000..9999).random()
                    }
                    val effectiveUni = university.trim()
                    viewModel.registerUser(
                        fullName = fullName,
                        email = email,
                        studentNumber = effectiveStudentNum,
                        university = effectiveUni,
                        password = password,
                        onSuccess = onRegisterSuccess
                    )
                }
            )

            // Social Divider
            AuthDivider()

            // Google Sign-In fast path
            GoogleAuthButton(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.performGoogleSignIn(context, onSuccess = onRegisterSuccess)
                },
                isLoading = isAuthLoading,
                text = "Sign up with Google"
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Switch to Login
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Already have an account? ",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
                Text(
                    text = "Sign in",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.clickable { onNavigateLogin() }
                )
            }
        }

        AuthFooterAttribution()
    }
}

// =========================================================================
// 3. PASSWORD RESET SCREEN
// =========================================================================

@Composable
fun ForgotPasswordScreen(
    viewModel: CanvasMateViewModel,
    onNavigateBack: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    val authSuccessMsg by viewModel.authSuccessMessage.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()

    val focusManager = LocalFocusManager.current

    AuthBackgroundContainer {
        AuthHeaderBranding()

        AuthCardPanel {
            Text(
                text = "Reset your password",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Enter your email and we'll help you regain access to your account.",
                fontSize = 14.sp,
                color = Color(0xFF94A3B8),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(22.dp))

            AuthFeedbackBanner(error = authError, success = authSuccessMsg)

            if (authSuccessMsg != null) {
                // Success State View
                Surface(
                    color = Color(0xFF052F1C).copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, Color(0xFF166534)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MarkEmailRead,
                                contentDescription = null,
                                tint = Color(0xFF4ADE80),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Instructions Sent",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF86EFAC)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Please check your inbox at $email for a link to reset your password.",
                            fontSize = 13.sp,
                            color = Color(0xFFD1FAE5),
                            lineHeight = 18.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                AuthPrimaryButton(
                    text = "Return to sign in",
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("back_to_login_button")
                )
            } else {
                // Reset Form
                AuthCustomTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        if (authError != null || authSuccessMsg != null) viewModel.clearAuthMessages()
                    },
                    label = "Email Address",
                    leadingIcon = Icons.Default.Email,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (email.contains("@")) {
                                viewModel.sendPasswordReset(email)
                            }
                        }
                    ),
                    modifier = Modifier.testTag("forgot_password_email_input")
                )

                Spacer(modifier = Modifier.height(20.dp))

                AuthPrimaryButton(
                    text = "Send reset link",
                    isLoading = isAuthLoading,
                    enabled = email.contains("@") && !isAuthLoading,
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.sendPasswordReset(email)
                    },
                    modifier = Modifier.testTag("send_reset_link_button")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Cancel and return to sign in",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF60A5FA),
                        modifier = Modifier
                            .clickable { onNavigateBack() }
                            .testTag("cancel_reset_button")
                    )
                }
            }
        }

        AuthFooterAttribution()
    }
}

// =========================================================================
// 4. EMAIL VERIFICATION SCREEN
// =========================================================================

@Composable
fun EmailVerificationScreen(
    viewModel: CanvasMateViewModel,
    onVerifiedSuccess: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val currentSession by viewModel.currentSession.collectAsState()
    val authSuccessMsg by viewModel.authSuccessMessage.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()

    val userEmail = currentSession?.email ?: "your registered email"

    AuthBackgroundContainer {
        AuthHeaderBranding()

        AuthCardPanel {
            Text(
                text = "Verify your email",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "We've sent a verification link to your email address. Please click the link to confirm your account.",
                fontSize = 14.sp,
                color = Color(0xFF94A3B8),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Email Display Card
            Surface(
                color = NavyFieldBg,
                border = BorderStroke(1.dp, NavyBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Sent to",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = userEmail,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            AuthFeedbackBanner(error = authError, success = authSuccessMsg)

            // Action 1: "I've verified my email"
            AuthPrimaryButton(
                text = "I've verified my email",
                isLoading = isAuthLoading,
                onClick = {
                    viewModel.verifyEmail()
                    onVerifiedSuccess()
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action 2: "Resend email"
            Surface(
                onClick = { viewModel.verifyEmail() },
                enabled = !isAuthLoading,
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF132037),
                border = BorderStroke(1.dp, Color(0xFF223554)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Resend verification email",
                        color = Color(0xFFE2E8F0),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Back to sign in",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF60A5FA),
                    modifier = Modifier.clickable { onNavigateBack() }
                )
            }
        }

        AuthFooterAttribution()
    }
}

@Composable
fun ProfileScreen(
    userProfile: UserProfile?,
    viewModel: CanvasMateViewModel,
    onSaveProfile: (UserProfile) -> Unit,
    onNavigateLogin: () -> Unit
) {
    val currentSession by viewModel.currentSession.collectAsState()
    val authSuccessMsg by viewModel.authSuccessMessage.collectAsState()
    val authError by viewModel.authError.collectAsState()

    var fullName by remember(currentSession, userProfile) {
        val name = currentSession?.fullName?.ifBlank { null } ?: userProfile?.fullName?.ifBlank { null } ?: ""
        mutableStateOf(name)
    }
    var studentNumber by remember(currentSession, userProfile) {
        val num = currentSession?.studentNumber?.ifBlank { null } ?: userProfile?.studentNumber?.ifBlank { null } ?: ""
        mutableStateOf(num)
    }
    var university by remember(currentSession, userProfile) {
        val uni = currentSession?.university?.ifBlank { null } ?: userProfile?.university?.ifBlank { null } ?: ""
        mutableStateOf(uni)
    }
    var faculty by remember(userProfile) { mutableStateOf(userProfile?.faculty ?: "") }
    var course by remember(userProfile) { mutableStateOf(userProfile?.course ?: "") }
    var yearOfStudy by remember(userProfile) { mutableStateOf(userProfile?.yearOfStudy ?: "") }
    var email by remember(currentSession, userProfile) {
        val em = currentSession?.email?.ifBlank { null } ?: userProfile?.email?.ifBlank { null } ?: ""
        mutableStateOf(em)
    }
    var phone by remember(userProfile) { mutableStateOf(userProfile?.phone ?: "") }
    var isSavedToast by remember { mutableStateOf(false) }

    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var currentPasswordInput by remember { mutableStateOf("") }
    var newPasswordInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (fullName.isNotBlank()) fullName.take(2).uppercase() else "LL",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = fullName.ifBlank { "Logic Loom User" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                val detailsSubtitle = listOf(studentNumber, university).filter { it.isNotBlank() }.joinToString(" • ")
                if (detailsSubtitle.isNotBlank()) {
                    Text(
                        text = detailsSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Verification Badge
                val isVerified = currentSession?.isEmailVerified == true
                AssistChip(
                    onClick = { if (!isVerified) viewModel.verifyEmail() },
                    label = {
                        Text(
                            if (isVerified) "Email Verified ✓" else "Unverified Email ⚠️ (Click to Verify)"
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = if (isVerified) Icons.Default.Verified else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (isVerified) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        authError?.let { err ->
            Text(
                text = err,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        authSuccessMsg?.let { msg ->
            Text(
                text = msg,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Text("Account & Security", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Authentication Provider: ${currentSession?.authProvider ?: "EMAIL_PASSWORD"}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text("Session ID: ${currentSession?.userId ?: "Active"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    OutlinedButton(
                        onClick = { showChangePasswordDialog = true },
                        enabled = currentSession?.authProvider != "GOOGLE"
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Change Password")
                    }

                    Button(
                        onClick = { viewModel.logoutUser(onLoggedOut = onNavigateLogin) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Log Out")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Student Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Name") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = studentNumber,
            onValueChange = { studentNumber = it },
            label = { Text("Student Number") },
            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = university,
            onValueChange = { university = it },
            label = { Text("University") },
            leadingIcon = { Icon(Icons.Default.School, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = faculty,
            onValueChange = { faculty = it },
            label = { Text("Faculty") },
            leadingIcon = { Icon(Icons.Default.Domain, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = course,
            onValueChange = { course = it },
            label = { Text("Course / Degree") },
            leadingIcon = { Icon(Icons.Default.Book, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = yearOfStudy,
            onValueChange = { yearOfStudy = it },
            label = { Text("Year of Study") },
            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Phone Number") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (isSavedToast) {
            Text(
                text = "✓ Profile updated successfully!",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Button(
            onClick = {
                val updated = (userProfile ?: UserProfile()).copy(
                    fullName = fullName,
                    studentNumber = studentNumber,
                    university = university,
                    faculty = faculty,
                    course = course,
                    yearOfStudy = yearOfStudy,
                    email = email,
                    phone = phone
                )
                onSaveProfile(updated)
                isSavedToast = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Save Profile Changes", fontWeight = FontWeight.Bold)
        }
    }

    if (showChangePasswordDialog) {
        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("Change Password") },
            text = {
                Column {
                    OutlinedTextField(
                        value = currentPasswordInput,
                        onValueChange = { currentPasswordInput = it },
                        label = { Text("Current Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPasswordInput,
                        onValueChange = { newPasswordInput = it },
                        label = { Text("New Password (8+ chars)") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.changePassword(currentPasswordInput, newPasswordInput) {
                            showChangePasswordDialog = false
                            currentPasswordInput = ""
                            newPasswordInput = ""
                        }
                    }
                ) {
                    Text("Update")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
