package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CalendarEvent
import com.example.data.local.TimetableSlot

import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(
    events: List<CalendarEvent>,
    userEmail: String? = null,
    onAddEvent: (CalendarEvent) -> Unit,
    onDeleteEvent: (Long) -> Unit
) {
    val context = LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

    // Real-time current date state
    val realCalendar = remember { Calendar.getInstance() }
    val todayYear = realCalendar.get(Calendar.YEAR)
    val todayMonth = realCalendar.get(Calendar.MONTH) // 0-indexed
    val todayDay = realCalendar.get(Calendar.DAY_OF_MONTH)

    var displayedYear by remember { mutableStateOf(todayYear) }
    var displayedMonth by remember { mutableStateOf(todayMonth) } // 0-indexed
    var selectedDay by remember { mutableStateOf(todayDay) }
    var viewMode by remember { mutableStateOf("Month") } // Month, Week, Day, Agenda

    var showAddDialog by remember { mutableStateOf(false) }
    var presetTitle by remember { mutableStateOf("") }
    var presetCategory by remember { mutableStateOf("Lecture") }
    var presetLocation by remember { mutableStateOf("") }
    var isSyncing by remember { mutableStateOf(false) }

    val categories = listOf("All", "Lecture", "Assignment Deadline", "Exam Date", "Birthday", "Meeting", "Study Session", "Event")
    var selectedCategory by remember { mutableStateOf("All") }

    // Dynamic month calculations
    val monthCal = remember(displayedYear, displayedMonth) {
        Calendar.getInstance().apply {
            set(Calendar.YEAR, displayedYear)
            set(Calendar.MONTH, displayedMonth)
            set(Calendar.DAY_OF_MONTH, 1)
        }
    }

    val daysInMonth = monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = monthCal.get(Calendar.DAY_OF_WEEK) // 1=Sunday, 2=Monday...
    val startOffset = if (firstDayOfWeek == Calendar.SUNDAY) 6 else firstDayOfWeek - 2

    val monthName = remember(displayedMonth) {
        SimpleDateFormat("MMMM", Locale.getDefault()).format(monthCal.time)
    }

    val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    val dateFormattedPrefix = "%04d-%02d".format(displayedYear, displayedMonth + 1)
    val selectedFullDateStr = "%04d-%02d-%02d".format(displayedYear, displayedMonth + 1, selectedDay)

    val filteredEvents = events.filter { event ->
        val matchesCategory = if (selectedCategory == "All") true else event.category == selectedCategory
        val matchesDay = when (viewMode) {
            "Agenda" -> true
            "Month" -> event.date == selectedFullDateStr
            "Day" -> event.date == selectedFullDateStr
            "Week" -> event.date.startsWith(dateFormattedPrefix)
            else -> event.date == selectedFullDateStr
        }
        matchesCategory && matchesDay
    }

    val realTimeFormatted = remember {
        SimpleDateFormat("EEEE, d MMMM yyyy • HH:mm 'SAST'", Locale.getDefault()).format(Date())
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    presetTitle = ""
                    presetCategory = "Lecture"
                    presetLocation = "Leslie Social LT1"
                    showAddDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Google Calendar Event")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(14.dp)
        ) {
            // Google Calendar Header & Live Sync Bar
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.CalendarMonth,
                                        contentDescription = "Google Calendar",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Google Calendar", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF10B981)
                                    ) {
                                        Text(
                                            "● Live Sync",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                val displayEmail = userEmail?.ifBlank { null } ?: "Connected Account"
                                Text(displayEmail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        IconButton(
                            onClick = {
                                isSyncing = true
                                Toast.makeText(context, "🔄 Syncing with Google Calendar...", Toast.LENGTH_SHORT).show()
                                isSyncing = false
                            }
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = "Sync Now", tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(realTimeFormatted, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Month Navigator & View Switcher Toolbar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Month / Year Navigation
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            if (displayedMonth == 0) {
                                displayedMonth = 11
                                displayedYear--
                            } else {
                                displayedMonth--
                            }
                        }
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                    }

                    Text(
                        text = "$monthName $displayedYear",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = {
                            if (displayedMonth == 11) {
                                displayedMonth = 0
                                displayedYear++
                            } else {
                                displayedMonth++
                            }
                        }
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                    }

                    OutlinedButton(
                        onClick = {
                            displayedYear = todayYear
                            displayedMonth = todayMonth
                            selectedDay = todayDay
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Today", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // View Mode Picker (Month, Week, Day, Agenda)
                ScrollableTabRow(
                    selectedTabIndex = listOf("Month", "Week", "Day", "Agenda").indexOf(viewMode),
                    edgePadding = 0.dp,
                    divider = {},
                    modifier = Modifier.width(180.dp)
                ) {
                    listOf("Month", "Week", "Day", "Agenda").forEach { mode ->
                        Tab(
                            selected = viewMode == mode,
                            onClick = { viewMode = mode },
                            text = { Text(mode, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Smart Event Planning Quick Presets
            Text("⚡ Quick Event Planning Presets", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    AssistChip(
                        onClick = {
                            presetTitle = "Study Session: Module Revision"
                            presetCategory = "Study Session"
                            presetLocation = "Main Library Floor 3"
                            showAddDialog = true
                        },
                        label = { Text("⚡ 2h Study Sprint") },
                        leadingIcon = { Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp)) }
                    )
                }
                item {
                    AssistChip(
                        onClick = {
                            presetTitle = "Google Meet: Group Project Sync"
                            presetCategory = "Meeting"
                            presetLocation = "https://meet.google.com/uct-cs-2026"
                            showAddDialog = true
                        },
                        label = { Text("🎓 Google Meet Call") },
                        leadingIcon = { Icon(Icons.Default.VideoCall, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp)) }
                    )
                }
                item {
                    AssistChip(
                        onClick = {
                            presetTitle = "Assignment Milestone 1"
                            presetCategory = "Assignment Deadline"
                            presetLocation = "Vula Portal"
                            showAddDialog = true
                        },
                        label = { Text("📝 Assignment Deadline") },
                        leadingIcon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp)) }
                    )
                }
                item {
                    AssistChip(
                        onClick = {
                            presetTitle = "Exam Revision Block"
                            presetCategory = "Exam Date"
                            presetLocation = "Maths Hall 1"
                            showAddDialog = true
                        },
                        label = { Text("🎯 Exam Preparation") },
                        leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp)) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Row
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                divider = {}
            ) {
                categories.forEach { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(category, fontSize = 12.sp) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Calendar Content Based on ViewMode
            if (viewMode == "Month") {
                // Days of week header
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    daysOfWeek.forEach { day ->
                        Text(
                            day,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Days Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(7),
                    modifier = Modifier.height(240.dp)
                ) {
                    items(startOffset) {
                        Box(modifier = Modifier.size(36.dp))
                    }
                    items(daysInMonth) { dayIndex ->
                        val dayNum = dayIndex + 1
                        val isToday = (displayedYear == todayYear && displayedMonth == todayMonth && dayNum == todayDay)
                        val isSelected = selectedDay == dayNum
                        val dateString = "%04d-%02d-%02d".format(displayedYear, displayedMonth + 1, dayNum)
                        val dayEvents = events.filter { it.date == dateString }

                        Box(
                            modifier = Modifier
                                .padding(2.dp)
                                .aspectRatio(1f)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isSelected -> MaterialTheme.colorScheme.primary
                                        isToday -> MaterialTheme.colorScheme.primaryContainer
                                        else -> Color.Transparent
                                    }
                                )
                                .border(
                                    width = if (isToday && !isSelected) 2.dp else 0.dp,
                                    color = if (isToday && !isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable {
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                    selectedDay = dayNum
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$dayNum",
                                    color = when {
                                        isSelected -> Color.White
                                        isToday -> MaterialTheme.colorScheme.onPrimaryContainer
                                        else -> MaterialTheme.colorScheme.onSurface
                                    },
                                    fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                                if (dayEvents.isNotEmpty()) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                        modifier = Modifier.padding(top = 1.dp)
                                    ) {
                                        dayEvents.take(3).forEach { evt ->
                                            val dotColor = when (evt.category) {
                                                "Assignment Deadline" -> Color(0xFFEF4444)
                                                "Exam Date" -> Color(0xFFF59E0B)
                                                "Birthday" -> Color(0xFFEC4899)
                                                "Study Session" -> Color(0xFF10B981)
                                                else -> if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(4.dp)
                                                    .clip(CircleShape)
                                                    .background(dotColor)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Events for $selectedDay $monthName $displayedYear",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                        Text("${filteredEvents.size} scheduled", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            } else if (viewMode == "Week") {
                Text(
                    text = "Weekly Schedule Overview • $monthName $displayedYear",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
            } else if (viewMode == "Day") {
                Text(
                    text = "Day Timeline: $selectedDay $monthName $displayedYear",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
            } else {
                Text(
                    text = "Google Calendar Agenda Timeline",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Events List
            if (filteredEvents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.EventAvailable,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "No events scheduled for this day/category.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                presetTitle = "New Calendar Event"
                                presetCategory = "Study Session"
                                presetLocation = "Campus Library"
                                showAddDialog = true
                            }
                        ) {
                            Text("+ Add Event Now")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredEvents, key = { it.id }) { event ->
                        CalendarEventCard(
                            event = event,
                            onDelete = { onDeleteEvent(event.id) }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEventDialog(
            defaultDate = selectedFullDateStr,
            initialTitle = presetTitle,
            initialCategory = presetCategory,
            initialLocation = presetLocation,
            onDismiss = { showAddDialog = false },
            onConfirm = { event ->
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                onAddEvent(event)
                showAddDialog = false
                Toast.makeText(context, "✅ Event synced to Google Calendar!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun CalendarEventCard(
    event: CalendarEvent,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val categoryColor = when (event.category) {
        "Assignment Deadline" -> Color(0xFFEF4444)
        "Exam Date" -> Color(0xFFF59E0B)
        "Birthday" -> Color(0xFFEC4899)
        "Study Session" -> Color(0xFF10B981)
        "Meeting" -> Color(0xFF7C3AED)
        else -> MaterialTheme.colorScheme.primary
    }

    val isGoogleMeet = event.location.contains("meet.google.com")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(54.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(categoryColor)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(event.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.width(8.dp))
                    Badge(containerColor = categoryColor.copy(alpha = 0.2f), contentColor = categoryColor) {
                        Text(event.category)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(event.time, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    if (event.location.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Icon(
                            if (isGoogleMeet) Icons.Default.VideoCall else Icons.Default.Place,
                            contentDescription = null,
                            modifier = Modifier.size(13.dp),
                            tint = if (isGoogleMeet) Color(0xFF2563EB) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            event.location,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isGoogleMeet) Color(0xFF2563EB) else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = if (isGoogleMeet) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
                if (event.description.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(event.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row {
                IconButton(
                    onClick = {
                        Toast.makeText(context, "📌 Event exported & synced to Google Calendar!", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.CloudSync, contentDescription = "Sync", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun AddEventDialog(
    defaultDate: String,
    initialTitle: String = "",
    initialCategory: String = "Lecture",
    initialLocation: String = "",
    onDismiss: () -> Unit,
    onConfirm: (CalendarEvent) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var date by remember { mutableStateOf(defaultDate) }
    var time by remember { mutableStateOf("10:00") }
    var category by remember { mutableStateOf(initialCategory) }
    var location by remember { mutableStateOf(initialLocation) }
    var reminderLead by remember { mutableStateOf("15 Minutes Before") }
    var recurrence by remember { mutableStateOf("Does Not Repeat") }
    var description by remember { mutableStateOf("") }

    val categories = listOf("Lecture", "Assignment Deadline", "Exam Date", "Birthday", "Meeting", "Study Session", "Event")
    val reminderOptions = listOf("15 Minutes Before", "30 Minutes Before", "1 Hour Before", "1 Day Before")
    val repeatOptions = listOf("Does Not Repeat", "Daily", "Weekly", "Monthly")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Google Calendar Event", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Event Title *") },
                    placeholder = { Text("e.g. CSC3002F Final Exam Review") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Time (HH:mm)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location / Google Meet Link") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = {
                        location = "https://meet.google.com/uct-cs-${(100..999).random()}"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.VideoCall, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("📹 Add Google Meet Video Call", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Category & Color Tag", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                ScrollableTabRow(selectedTabIndex = categories.indexOf(category).coerceAtLeast(0), divider = {}) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Reminder Notification", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                ScrollableTabRow(selectedTabIndex = reminderOptions.indexOf(reminderLead).coerceAtLeast(0), divider = {}) {
                    reminderOptions.forEach { rem ->
                        FilterChip(
                            selected = reminderLead == rem,
                            onClick = { reminderLead = rem },
                            label = { Text(rem, fontSize = 11.sp) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val finalDesc = if (reminderLead.isNotEmpty()) "$description [Reminder: $reminderLead]" else description
                        onConfirm(
                            CalendarEvent(
                                title = title,
                                date = date,
                                time = time,
                                category = category,
                                location = location,
                                description = finalDesc
                            )
                        )
                    }
                }
            ) {
                Text("Sync & Save Event")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen(
    slots: List<TimetableSlot>,
    onAddSlot: (TimetableSlot) -> Unit,
    onDeleteSlot: (Long) -> Unit
) {
    var selectedDay by remember { mutableStateOf("Monday") }
    var showAddDialog by remember { mutableStateOf(false) }

    val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday")
    val daySlots = slots.filter { it.dayOfWeek == selectedDay }.sortedBy { it.startTime }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Class")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Weekly Class Timetable", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Monday to Friday Lecture Schedule & Venues", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CloudDone,
                            contentDescription = "Room Database Local Cache",
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Offline Ready",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Days of week selector
            ScrollableTabRow(
                selectedTabIndex = daysOfWeek.indexOf(selectedDay),
                edgePadding = 0.dp
            ) {
                daysOfWeek.forEach { day ->
                    Tab(
                        selected = selectedDay == day,
                        onClick = { selectedDay = day },
                        text = { Text(day, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (daySlots.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FreeBreakfast, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No classes scheduled for $selectedDay! Free day 🎉", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(daySlots, key = { it.id }) { slot ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                        Text("${slot.startTime} - ${slot.endTime}", color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(slot.module, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("📍 Venue: ${slot.venue}", style = MaterialTheme.typography.bodySmall)
                                    if (slot.lecturer.isNotEmpty()) {
                                        Text("👤 Lecturer: ${slot.lecturer}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                IconButton(onClick = { onDeleteSlot(slot.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddTimetableSlotDialog(
            defaultDay = selectedDay,
            onDismiss = { showAddDialog = false },
            onConfirm = { newSlot ->
                onAddSlot(newSlot)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddTimetableSlotDialog(
    defaultDay: String,
    onDismiss: () -> Unit,
    onConfirm: (TimetableSlot) -> Unit
) {
    var dayOfWeek by remember { mutableStateOf(defaultDay) }
    var module by remember { mutableStateOf("CSC3002F") }
    var startTime by remember { mutableStateOf("08:00") }
    var endTime by remember { mutableStateOf("09:45") }
    var venue by remember { mutableStateOf("Leslie Social CS Lab") }
    var lecturer by remember { mutableStateOf("Prof. Adams") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Timetable Class") },
        text = {
            Column {
                OutlinedTextField(value = module, onValueChange = { module = it }, label = { Text("Module Code") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    OutlinedTextField(value = startTime, onValueChange = { startTime = it }, label = { Text("Start Time") }, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(value = endTime, onValueChange = { endTime = it }, label = { Text("End Time") }, modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = venue, onValueChange = { venue = it }, label = { Text("Venue / Lecture Hall") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = lecturer, onValueChange = { lecturer = it }, label = { Text("Lecturer Name") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (module.isNotBlank()) {
                        onConfirm(TimetableSlot(dayOfWeek = dayOfWeek, startTime = startTime, endTime = endTime, module = module, venue = venue, lecturer = lecturer))
                    }
                }
            ) {
                Text("Add Class")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
