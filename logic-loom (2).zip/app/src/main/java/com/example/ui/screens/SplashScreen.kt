package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.AuthState
import com.example.ui.components.CanvasMate3DIcon
import com.example.ui.components.CanvasMateAiState
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SplashScreen(
    authStateFlow: StateFlow<AuthState>,
    onSplashFinished: () -> Unit
) {
    val iconScale = remember { Animatable(0.7f) }
    val iconAlpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val loomAlpha = remember { Animatable(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "loomAnimation")
    val loomPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "loomPhase"
    )

    LaunchedEffect(Unit) {
        coroutineScope {
            launch {
                loomAlpha.animateTo(
                    targetValue = 1.0f,
                    animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing)
                )
            }
            launch {
                iconScale.animateTo(
                    targetValue = 1.0f,
                    animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
                )
            }
            launch {
                iconAlpha.animateTo(
                    targetValue = 1.0f,
                    animationSpec = tween(durationMillis = 500)
                )
            }
            launch {
                delay(200)
                textAlpha.animateTo(
                    targetValue = 1.0f,
                    animationSpec = tween(durationMillis = 600)
                )
            }
        }
        // Ensure minimum visual branding display time of 1200ms
        delay(1200)

        // Wait for Firebase Authentication state to resolve from INITIALIZING
        // Guard with a 4-second safety timeout so app never hangs if network/offline
        withTimeoutOrNull(4000) {
            authStateFlow.first { it != AuthState.INITIALIZING }
        }

        onSplashFinished()
    }

    val deepNavy = Color(0xFF060D1A)
    val electricBlue = Color(0xFF2979FF)
    val electricCyan = Color(0xFF00E5FF)
    val electricViolet = Color(0xFF7C4DFF)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(deepNavy)
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Interconnected loom canvas representing ideas, reasoning, and information woven together
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .alpha(loomAlpha.value * 0.45f)
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            // Weaving strands (sinusoidal threads connecting nodes)
            for (i in 0 until 6) {
                val offsetAngle = (i * Math.PI / 3).toFloat() + loomPhase
                val path = Path()
                val radius = (120f + i * 28f)

                val x1 = cx + radius * cos(offsetAngle)
                val y1 = cy + radius * sin(offsetAngle)
                val x2 = cx + radius * cos(offsetAngle + Math.PI.toFloat())
                val y2 = cy + radius * sin(offsetAngle + Math.PI.toFloat())

                path.moveTo(x1, y1)
                val ctrlX = cx + (radius * 0.6f) * cos(offsetAngle + 1.2f)
                val ctrlY = cy + (radius * 0.6f) * sin(offsetAngle + 1.2f)
                path.quadraticBezierTo(ctrlX, ctrlY, x2, y2)

                val threadColor = when (i % 3) {
                    0 -> electricCyan
                    1 -> electricBlue
                    else -> electricViolet
                }

                drawPath(
                    path = path,
                    color = threadColor.copy(alpha = 0.4f),
                    style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                )

                // Intersecting logic nodes
                drawCircle(
                    color = threadColor.copy(alpha = 0.85f),
                    radius = 5f,
                    center = Offset(x1, y1)
                )
            }
        }

        // Central ambient glow
        Box(
            modifier = Modifier
                .size(280.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            electricBlue.copy(alpha = 0.35f),
                            electricViolet.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Center Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 48.dp, horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Logic Loom 3D Emblem
                Box(
                    modifier = Modifier
                        .scale(iconScale.value)
                        .alpha(iconAlpha.value)
                ) {
                    CanvasMate3DIcon(
                        size = 112.dp,
                        aiState = CanvasMateAiState.IDLE,
                        showGlow = true
                    )
                }

                Spacer(modifier = Modifier.height(36.dp))

                // Typography & Branding
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.alpha(textAlpha.value)
                ) {
                    Text(
                        text = "LOGIC LOOM",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = 4.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Powered by Chuma AI Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF0F1B2E))
                            .border(1.dp, electricBlue.copy(alpha = 0.6f), RoundedCornerShape(50))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = electricCyan,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Powered by Chuma AI",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFE2E8F0),
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "The intelligent workspace for learning, thinking and creating",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF94A3B8),
                        letterSpacing = 0.2.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Footer Attribution
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.alpha(textAlpha.value)
            ) {
                Text(
                    text = "Designed and engineered by Moraigne",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.3.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

