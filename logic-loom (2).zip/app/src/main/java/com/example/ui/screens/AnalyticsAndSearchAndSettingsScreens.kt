package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import com.example.ui.CanvasMateViewModel
import com.example.ui.theme.AppColorPalette
import com.example.ui.theme.AppFontStyle
import com.example.ui.theme.ThemeChoice
import com.example.ui.components.EmptyState
import com.example.ui.components.ThemeSelector
import kotlinx.coroutines.launch

@Composable
fun AnalyticsScreen(
    viewModel: CanvasMateViewModel
) {
    val totalHours by viewModel.totalStudyHours.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Productivity Analytics", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Weekly Study Performance & Financial Overview 2026", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(16.dp))

        // Productivity Score Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Overall Productivity Score", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(4.dp))
                Text("92 / 100", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Spacer(modifier = Modifier.height(4.dp))
                Text("🔥 Excellent focus! You're in the top 5% of university students this semester.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Study Hours Bar Chart (Compose Canvas)
        Text("Weekly Study Hours (Canvas Graph)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                val studyData = listOf("Mon" to 3.5f, "Tue" to 4.2f, "Wed" to 5.0f, "Thu" to 2.8f, "Fri" to 4.5f, "Sat" to 6.0f, "Sun" to 3.0f)
                val maxHours = 7f

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    val barWidth = size.width / (studyData.size * 2)
                    studyData.forEachIndexed { index, (day, hours) ->
                        val barHeight = (hours / maxHours) * size.height
                        val x = index * (barWidth * 2) + barWidth / 2
                        val y = size.height - barHeight

                        drawRect(
                            color = Color(0xFF2563EB),
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    studyData.forEach { (day, _) ->
                        Text(day, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Key Milestones Reached", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("• Completed 14 Pomodoro study blocks", fontWeight = FontWeight.SemiBold)
                Text("• Managed monthly budget under R4,000.00 threshold", fontWeight = FontWeight.SemiBold)
                Text("• Recorded 100% attendance in CSC3002F lectures", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun GlobalSearchScreen(
    viewModel: CanvasMateViewModel
) {
    val query by viewModel.searchQuery.collectAsState()
    val activeFilter by viewModel.searchCategoryFilter.collectAsState()

    // Room DB Search Flows
    val searchedTasks by viewModel.searchedAcademicTasks.collectAsState()
    val searchedNotes by viewModel.searchedNotes.collectAsState()
    val searchedBudgetItems by viewModel.searchedBudgetItems.collectAsState()
    val searchedVaultDocs by viewModel.searchedVaultDocuments.collectAsState()

    val totalCount = searchedTasks.size + searchedNotes.size + searchedBudgetItems.size + searchedVaultDocs.size

    val categories = listOf(
        "All" to totalCount,
        "Assignments" to searchedTasks.size,
        "Notes" to searchedNotes.size,
        "Budget" to searchedBudgetItems.size,
        "Documents" to searchedVaultDocs.size
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Search Input Bar
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Search notes, assignments, budget entries, docs...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            trailingIcon = if (query.isNotEmpty()) {
                { IconButton(onClick = { viewModel.updateSearchQuery("") }) { Icon(Icons.Default.Clear, contentDescription = "Clear search") } }
            } else null,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
            ),
            singleLine = true
        )

        // Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            items(categories.size) { index ->
                val (categoryName, count) = categories[index]
                val isSelected = activeFilter == categoryName
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.updateSearchCategory(categoryName) },
                    label = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(categoryName, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            Spacer(modifier = Modifier.width(4.dp))
                            Badge(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ) {
                                Text("$count", fontSize = 11.sp)
                            }
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }

        if (query.isBlank()) {
            EmptyState(
                title = "Search Room Database",
                description = "Type keywords above to query your notes, academic assignments, ZAR budget entries, and document vault stored locally.",
                icon = Icons.Default.Search
            )
        } else if (totalCount == 0) {
            EmptyState(
                title = "No Matches Found",
                description = "No results found for \"$query\". Check spelling or try searching for course codes like 'CSC3002F', 'Allowance', or 'PDF'.",
                icon = Icons.Default.SearchOff
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // ASSIGNMENTS & ACADEMIC TASKS
                if ((activeFilter == "All" || activeFilter == "Assignments") && searchedTasks.isNotEmpty()) {
                    item {
                        Text(
                            text = "Academic Assignments & Tasks (${searchedTasks.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                        )
                    }
                    items(searchedTasks) { task ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Assignment, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(task.module, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(task.taskType, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(task.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                    if (task.description.isNotBlank()) {
                                        Text(task.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Due ${task.dueDate}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                // NOTES & SUMMARIES
                if ((activeFilter == "All" || activeFilter == "Notes") && searchedNotes.isNotEmpty()) {
                    item {
                        Text(
                            text = "Notes & Summaries (${searchedNotes.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                    }
                    items(searchedNotes) { note ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(note.folder, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                                    Text(note.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                    Text(note.content, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                                }
                            }
                        }
                    }
                }

                // BUDGET ENTRIES
                if ((activeFilter == "All" || activeFilter == "Budget") && searchedBudgetItems.isNotEmpty()) {
                    item {
                        Text(
                            text = "Budget Entries (ZAR) (${searchedBudgetItems.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                    }
                    items(searchedBudgetItems) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.tertiaryContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.category, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
                                    Text(item.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                    Text(item.type, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (item.type == "Income") "+R${"%.2f".format(item.amount)}" else "-R${"%.2f".format(item.amount)}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (item.type == "Income") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }

                // DOCUMENTS
                if ((activeFilter == "All" || activeFilter == "Documents") && searchedVaultDocs.isNotEmpty()) {
                    item {
                        Text(
                            text = "Vault Documents (${searchedVaultDocs.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                    }
                    items(searchedVaultDocs) { doc ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(doc.category, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    Text(doc.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                    Text("${doc.fileType} • ${doc.fileSizeMb} MB • Uploaded ${doc.uploadDate}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    viewModel: CanvasMateViewModel,
    onNavigateAbout: () -> Unit,
    onNavigateLegalCenter: () -> Unit = {}
) {
    val darkTheme by viewModel.darkThemeMode.collectAsState()
    val selectedPalette by viewModel.selectedColorPalette.collectAsState()
    val selectedThemeChoice by viewModel.selectedThemeChoice.collectAsState()
    val selectedFont by viewModel.selectedFontStyle.collectAsState()
    val isAppLocked by viewModel.isAppLocked.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    val legalConsentState by viewModel.legalConsentState.collectAsState()

    val context = androidx.compose.ui.platform.LocalContext.current
    var showNotificationDialog by remember { mutableStateOf(false) }
    var backupStatusMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("App Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Preferences, Security & Data Management", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(20.dp))

        // Appearance & Theme Section
        Text("🎨 Theme & Color Changer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Theme Mode (Light / Dark / System)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Theme Mode", fontWeight = FontWeight.Bold)
                        Text("Light (Recommended), Dark, or System", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row {
                        FilterChip(
                            selected = darkTheme == false,
                            onClick = { viewModel.setDarkThemeMode(false) },
                            label = { Text("Light") },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        FilterChip(
                            selected = darkTheme == true,
                            onClick = { viewModel.setDarkThemeMode(true) },
                            label = { Text("Dark") },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        FilterChip(
                            selected = darkTheme == null,
                            onClick = { viewModel.setDarkThemeMode(null) },
                            label = { Text("System") }
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp))

                // Color Palette Theme Customization
                Text("Theme Customization", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Choose your official Logic Loom color theme", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                ThemeSelector(
                    selectedTheme = selectedThemeChoice,
                    onThemeSelected = { choice ->
                        viewModel.selectThemeChoice(choice)
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(modifier = Modifier.padding(vertical = 14.dp))

                // Font Style Selector
                Text("Typography & Fonts", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text("Customize font style across all titles and text", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(AppFontStyle.values()) { fontStyle ->
                        val isSelected = fontStyle == selectedFont
                        Surface(
                            onClick = { viewModel.setFontStyle(fontStyle) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                            modifier = Modifier.width(140.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Aa Bb 123",
                                    fontFamily = fontStyle.fontFamily,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = fontStyle.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isSelected) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Active Font",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Live Theme Preview Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "✨ Live Theme Preview",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Text(
                                    text = "${selectedPalette.displayName} • ${selectedFont.displayName}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Logic Loom UI is dynamically styled using ${selectedFont.displayName} typography paired with ${selectedPalette.displayName} accents.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Security & Notifications
        Text("Security & Notifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PIN / Biometric Security Lock")
                    Switch(
                        checked = isAppLocked,
                        onCheckedChange = { viewModel.isAppLocked.value = it }
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Deadline & Task Reminders")
                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = { viewModel.toggleNotifications(it) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = { showNotificationDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Manage AI Smart Plan Reminders")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Transport & Device Capabilities Status Card
        Text("Transport Hub & Device Permissions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("GPS & Location Access", fontWeight = FontWeight.Bold)
                        Text(
                            "User-controlled, on-demand for discovering nearest PRASA / transit stations. Never tracks in background.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    AssistChip(
                        onClick = {},
                        label = { Text("Permission-based", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Voice Search & Microphone", fontWeight = FontWeight.Bold)
                        Text(
                            "Activates only when microphone button is tapped. Does not record continuously or store audio.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    AssistChip(
                        onClick = {},
                        label = { Text("On-demand", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PRASA / Rail Data Provider", fontWeight = FontWeight.Bold)
                        Text(
                            "Source: PRASA / Metrorail published tariffs. Information provided without transport warranties or bookings.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    AssistChip(
                        onClick = {},
                        label = { Text("Verified Tariffs", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.DirectionsSubway, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }
            }
        }

        if (showNotificationDialog) {
            NotificationManagementDialog(
                viewModel = viewModel,
                onDismiss = { showNotificationDialog = false }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Backup & Data
        Text("Data & Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        if (backupStatusMessage != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Text(backupStatusMessage!!, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Button(
                    onClick = { backupStatusMessage = "✓ Local SQLite backup saved successfully to Device Storage!" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Create Encrypted Local Backup")
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { backupStatusMessage = "✓ Database restored from latest backup!" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restore Database")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Startup Performance & Baseline Profile Benchmark Section
        Text("Startup Performance & Jetpack Benchmark", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        val context = androidx.compose.ui.platform.LocalContext.current
        val coroutineScope = rememberCoroutineScope()
        var benchmarkReport by remember { mutableStateOf<com.example.benchmark.StartupBenchmarkReport?>(null) }
        var isBenchmarking by remember { mutableStateOf(false) }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Baseline Profile Status", fontWeight = FontWeight.Bold)
                        Text("AOT compilation rules pre-compiled for sub-150ms startup", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    AssistChip(
                        onClick = {},
                        label = { Text("Active • AOT", fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                if (benchmarkReport != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "Total Initialization: ${benchmarkReport!!.totalStartupMs} ms",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("• Room Database Cold Start: ${benchmarkReport!!.databaseInitMs} ms", style = MaterialTheme.typography.bodySmall)
                            Text("• ViewModel Reactive Flows: ${benchmarkReport!!.viewModelInitMs} ms", style = MaterialTheme.typography.bodySmall)
                            Text("• Theme & Token Resolution: ${benchmarkReport!!.themeResolutionMs} ms", style = MaterialTheme.typography.bodySmall)
                            if (benchmarkReport!!.bottleneckWarning != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("⚠️ ${benchmarkReport!!.bottleneckWarning}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        isBenchmarking = true
                        coroutineScope.launch {
                            benchmarkReport = com.example.benchmark.StartupPerformanceBenchmark.benchmarkInitializationSequence(context, viewModel)
                            isBenchmarking = false
                        }
                    },
                    enabled = !isBenchmarking,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isBenchmarking) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Profiling Startup Sequence...")
                    } else {
                        Icon(Icons.Default.Speed, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Run Jetpack Startup Benchmark")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Privacy, Legal & Data Control Section
        com.example.ui.legal.PrivacyAndDataSettingsSection(
            consentState = legalConsentState,
            onOpenLegalCenter = onNavigateLegalCenter,
            onExportUserData = { viewModel.exportUserDataJson(context) },
            onDeleteAccountAndData = {
                viewModel.deleteAccountAndData {
                    // Reset completed
                }
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // About Button
        OutlinedButton(
            onClick = onNavigateAbout,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Info, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("About Logic Loom v1.0.0")
        }
    }
}

@Composable
fun AboutScreen(
    onNavigateLegalCenter: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        com.example.ui.components.CanvasMate3DIcon(
            size = 90.dp,
            showGlow = true
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Logic Loom",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "Powered by Chuma AI • Designed and engineered by Moraigne",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Text(
            text = "Version 1.0.0 (2026 Build)",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "\"A smarter space for learning, thinking and creating.\"",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Logic Loom is an intelligent workspace designed to help people learn, think, create, research and get things done with the help of AI.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Platform", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Logic Loom", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Intelligence", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Powered by Chuma AI (Gemini Foundation)", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Developer & Company", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Designed and engineered by Moraigne", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Copyright & Governance", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Copyright © 2026 Moraigne. All rights reserved.", style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Legal & Compliance Policies",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))

                val legalPolicies = listOf(
                    "Privacy Policy",
                    "Terms of Service",
                    "Acceptable Use Policy",
                    "AI Transparency & Safety"
                )

                legalPolicies.forEach { policy ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = policy,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = onNavigateLegalCenter) {
                            Text("View", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
