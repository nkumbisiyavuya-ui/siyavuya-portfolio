package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CanvasMateCrimson
import com.example.ui.theme.CanvasMateCrimsonLight
import com.example.ui.theme.CanvasMateNavyDark
import com.example.ui.theme.CanvasMateNavyLight
import com.example.ui.theme.CanvasMateNavyPrimary

enum class CanvasMateAiState {
    IDLE,
    LISTENING,
    THINKING,
    RESPONDING,
    ERROR
}

/**
 * The official 3D Logic Loom Crescent + Star Brand Symbol.
 * Supports dynamic size scales and contextual AI states.
 */
@Composable
fun CanvasMate3DIcon(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    aiState: CanvasMateAiState = CanvasMateAiState.IDLE,
    showGlow: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "aiStateAnimation")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = when (aiState) {
            CanvasMateAiState.LISTENING -> 1.0f
            CanvasMateAiState.THINKING -> 0.98f
            CanvasMateAiState.RESPONDING -> 1.02f
            CanvasMateAiState.ERROR -> 0.96f
            CanvasMateAiState.IDLE -> 0.98f
        },
        targetValue = when (aiState) {
            CanvasMateAiState.LISTENING -> 1.08f
            CanvasMateAiState.THINKING -> 1.04f
            CanvasMateAiState.RESPONDING -> 1.05f
            CanvasMateAiState.ERROR -> 1.02f
            CanvasMateAiState.IDLE -> 1.02f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (aiState) {
                    CanvasMateAiState.LISTENING -> 800
                    CanvasMateAiState.THINKING -> 1200
                    CanvasMateAiState.RESPONDING -> 1000
                    CanvasMateAiState.ERROR -> 600
                    CanvasMateAiState.IDLE -> 2500
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val borderGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = when (aiState) {
            CanvasMateAiState.LISTENING -> 0.8f
            CanvasMateAiState.THINKING -> 0.9f
            CanvasMateAiState.RESPONDING -> 0.7f
            CanvasMateAiState.ERROR -> 0.9f
            CanvasMateAiState.IDLE -> 0.4f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "borderGlow"
    )

    val auraColor = when (aiState) {
        CanvasMateAiState.LISTENING -> CanvasMateCrimsonLight
        CanvasMateAiState.THINKING -> CanvasMateNavyLight
        CanvasMateAiState.RESPONDING -> CanvasMateCrimson
        CanvasMateAiState.ERROR -> Color(0xFFE53935)
        CanvasMateAiState.IDLE -> CanvasMateNavyPrimary
    }

    val cornerRadius = size * 0.28f

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .scale(pulseScale)
            .testTag("logic_loom_3d_icon")
    ) {
        // Outer ambient glow ring for AI states
        if (showGlow) {
            Box(
                modifier = Modifier
                    .size(size * 1.15f)
                    .clip(RoundedCornerShape(cornerRadius * 1.2f))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                auraColor.copy(alpha = borderGlowAlpha * 0.5f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        // Primary 3D Icon Surface Container
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .shadow(
                    elevation = if (size > 40.dp) 8.dp else 4.dp,
                    shape = RoundedCornerShape(cornerRadius),
                    spotColor = CanvasMateNavyDark,
                    ambientColor = auraColor
                )
                .clip(RoundedCornerShape(cornerRadius))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            CanvasMateNavyPrimary,
                            CanvasMateNavyDark
                        )
                    )
                )
                .border(
                    width = if (size > 40.dp) 1.5.dp else 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            CanvasMateNavyLight.copy(alpha = 0.8f),
                            auraColor.copy(alpha = borderGlowAlpha)
                        )
                    ),
                    shape = RoundedCornerShape(cornerRadius)
                )
        ) {
            // Render the high-resolution 3D asset
            Image(
                painter = painterResource(id = R.drawable.logic_loom_icon),
                contentDescription = "Logic Loom Icon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(cornerRadius))
            )
        }
    }
}

/**
 * Logic Loom Logo composable alias.
 */
@Composable
fun LogicLoomLogo(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    aiState: CanvasMateAiState = CanvasMateAiState.IDLE,
    showGlow: Boolean = true
) {
    CanvasMate3DIcon(
        modifier = modifier,
        size = size,
        aiState = aiState,
        showGlow = showGlow
    )
}

/**
 * Compact AI Assistant Avatar component with live status dot.
 */
@Composable
fun CanvasMateAiAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    aiState: CanvasMateAiState = CanvasMateAiState.IDLE
) {
    Box(
        contentAlignment = Alignment.BottomEnd,
        modifier = modifier
    ) {
        CanvasMate3DIcon(
            size = size,
            aiState = aiState,
            showGlow = true
        )

        // Status indicator dot
        val dotColor = when (aiState) {
            CanvasMateAiState.IDLE -> CanvasMateCrimson
            CanvasMateAiState.LISTENING -> CanvasMateCrimsonLight
            CanvasMateAiState.THINKING -> Color(0xFF38BDF8)
            CanvasMateAiState.RESPONDING -> Color(0xFF34D399)
            CanvasMateAiState.ERROR -> Color(0xFFEF4444)
        }

        Box(
            modifier = Modifier
                .offset(x = 2.dp, y = 2.dp)
                .size(size * 0.28f)
                .clip(CircleShape)
                .background(dotColor)
                .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
        )
    }
}
