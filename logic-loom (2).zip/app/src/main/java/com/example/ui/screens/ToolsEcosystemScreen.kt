package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.NavRoutes

data class ToolDefinition(
    val id: String,
    val name: String,
    val description: String,
    val category: String,
    val icon: ImageVector,
    val route: String,
    val badge: String? = null
)

val LOGIC_LOOM_TOOLS = listOf(
    // Academic Intelligence
    ToolDefinition(
        id = "academic_planner",
        name = "Academic Planner",
        description = "Assignments, exam deadlines & task milestones",
        category = "Academic Intelligence",
        icon = Icons.Outlined.Assignment,
        route = NavRoutes.ACADEMIC_PLANNER,
        badge = "Core"
    ),
    ToolDefinition(
        id = "timetable",
        name = "Weekly Timetable",
        description = "Campus lectures, venues & recurring slots",
        category = "Academic Intelligence",
        icon = Icons.Outlined.CalendarViewWeek,
        route = NavRoutes.TIMETABLE
    ),
    ToolDefinition(
        id = "calendar",
        name = "Calendar 2026",
        description = "Academic calendar, holidays & sync",
        category = "Academic Intelligence",
        icon = Icons.Outlined.CalendarMonth,
        route = NavRoutes.CALENDAR
    ),
    ToolDefinition(
        id = "flashcards",
        name = "Active Recall Flashcards",
        description = "Spaced repetition & AI question decks",
        category = "Academic Intelligence",
        icon = Icons.Outlined.Style,
        route = NavRoutes.FLASHCARDS,
        badge = "AI"
    ),
    ToolDefinition(
        id = "voice_mode",
        name = "Chuma Voice Mode",
        description = "Live conversational AI voice, real-time speech & barge-in",
        category = "Academic Intelligence",
        icon = Icons.Outlined.GraphicEq,
        route = NavRoutes.VOICE_MODE,
        badge = "Voice V1"
    ),
    ToolDefinition(
        id = "gpa_calculator",
        name = "GPA Calculator",
        description = "Credit weighted grading & academic targets",
        category = "Academic Intelligence",
        icon = Icons.Outlined.Calculate,
        route = NavRoutes.GPA_CALCULATOR
    ),
    ToolDefinition(
        id = "study_timer",
        name = "Pomodoro Timer",
        description = "Interval focus sessions & study telemetry",
        category = "Academic Intelligence",
        icon = Icons.Outlined.Timer,
        route = NavRoutes.STUDY_TIMER
    ),

    // Memory & Knowledge
    ToolDefinition(
        id = "notes",
        name = "Notes & Summaries",
        description = "Course notes, lecture transcriptions & flashcards",
        category = "Memory & Knowledge",
        icon = Icons.Outlined.Description,
        route = NavRoutes.NOTES
    ),
    ToolDefinition(
        id = "vault",
        name = "Document Vault",
        description = "Encrypted storage for certificates, IDs & PDFs",
        category = "Memory & Knowledge",
        icon = Icons.Outlined.Lock,
        route = NavRoutes.VAULT,
        badge = "Secure"
    ),
    ToolDefinition(
        id = "diary",
        name = "Private Diary",
        description = "End-to-end encrypted personal reflections",
        category = "Memory & Knowledge",
        icon = Icons.Outlined.MenuBook,
        route = NavRoutes.DIARY
    ),
    ToolDefinition(
        id = "todo",
        name = "To-Do Master",
        description = "Daily checklists, priorities & reminder alarms",
        category = "Memory & Knowledge",
        icon = Icons.Outlined.CheckCircleOutline,
        route = NavRoutes.TODO_LIST
    ),
    ToolDefinition(
        id = "goals",
        name = "Goal Tracker",
        description = "Long-term milestones & personal growth",
        category = "Memory & Knowledge",
        icon = Icons.Outlined.Flag,
        route = NavRoutes.GOALS
    ),

    // Life OS & Intelligence
    ToolDefinition(
        id = "life_hub",
        name = "Life OS Hub",
        description = "Transport, campus shopping & wallet management",
        category = "Life OS & Services",
        icon = Icons.Outlined.Explore,
        route = NavRoutes.LIFE_HUB,
        badge = "OS"
    ),
    ToolDefinition(
        id = "shuttle_schedule",
        name = "Shuttle Schedules",
        description = "Live campus route timings & stop departure maps",
        category = "Life OS & Services",
        icon = Icons.Outlined.DirectionsBus,
        route = NavRoutes.SHUTTLE_SCHEDULE
    ),
    ToolDefinition(
        id = "budget",
        name = "Budget Manager",
        description = "Real-time ZAR cashflow & live FX conversion",
        category = "Life OS & Services",
        icon = Icons.Outlined.AccountBalanceWallet,
        route = NavRoutes.BUDGET
    ),
    ToolDefinition(
        id = "veo_studio",
        name = "Veo Studio Video",
        description = "AI cinematic video creation & prompt generation",
        category = "Life OS & Services",
        icon = Icons.Outlined.MovieCreation,
        route = NavRoutes.VEO_STUDIO,
        badge = "AI"
    ),
    ToolDefinition(
        id = "analytics",
        name = "Productivity Analytics",
        description = "Study habit tracking & cognitive telemetry",
        category = "Life OS & Services",
        icon = Icons.Outlined.Insights,
        route = NavRoutes.ANALYTICS
    ),
    ToolDefinition(
        id = "legal_center",
        name = "Legal & Safety Center",
        description = "Privacy policy, AI ethics, terms & compliance",
        category = "Life OS & Services",
        icon = Icons.Outlined.Gavel,
        route = NavRoutes.LEGAL_CENTER
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsEcosystemScreen(
    onNavigate: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Academic Intelligence", "Memory & Knowledge", "Life OS & Services")

    val filteredTools = remember(searchQuery, selectedCategory) {
        LOGIC_LOOM_TOOLS.filter { tool ->
            val matchesCategory = selectedCategory == "All" || tool.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    tool.name.contains(searchQuery, ignoreCase = true) ||
                    tool.description.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF060913),
                        Color(0xFF090E1D),
                        Color(0xFF060913)
                    )
                )
            )
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Tools Ecosystem",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "From ideas to execution — all in one place.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0x223B82F6))
                                .border(1.dp, Color(0x443B82F6), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search input
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = {
                            Text(
                                "Search tools, capabilities, modules...",
                                color = Color(0xFF64748B),
                                fontSize = 14.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Outlined.Search,
                                contentDescription = null,
                                tint = Color(0xFF60A5FA),
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = if (searchQuery.isNotEmpty()) {
                            {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(
                                        Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        } else null,
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF3B82F6),
                            unfocusedBorderColor = Color(0x333B82F6),
                            focusedContainerColor = Color(0xCC0E172A),
                            unfocusedContainerColor = Color(0x990A1020),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Category Filter Pills
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { category ->
                            val isSelected = selectedCategory == category
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        if (isSelected) Brush.horizontalGradient(
                                            listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                        ) else Brush.horizontalGradient(
                                            listOf(Color(0x221E293B), Color(0x111E293B))
                                        )
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) Color(0xFF60A5FA) else Color(0x223B82F6),
                                        RoundedCornerShape(20.dp)
                                    )
                                    .clickable { selectedCategory = category }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = category.replace(" Intelligence", "").replace(" & Services", "").replace(" & Knowledge", ""),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }

            // Grid of Tools
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    filteredTools.chunked(2).forEach { rowTools ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowTools.forEach { tool ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(126.dp)
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(
                                                    Color(0xD90E172A),
                                                    Color(0xB3090F1E)
                                                )
                                            )
                                        )
                                        .border(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    Color(0x443B82F6),
                                                    Color(0x1806B6D4),
                                                    Color(0x101E293B)
                                                )
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                        .shadow(
                                            elevation = 6.dp,
                                            shape = RoundedCornerShape(18.dp),
                                            ambientColor = Color(0x40000000),
                                            spotColor = Color(0x302563EB)
                                        )
                                        .clickable { onNavigate(tool.route) }
                                        .padding(12.dp)
                                        .testTag("tool_card_${tool.id}")
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0x222563EB))
                                                    .border(1.dp, Color(0x443B82F6), RoundedCornerShape(10.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    tool.icon,
                                                    contentDescription = tool.name,
                                                    tint = Color(0xFF60A5FA),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (tool.badge != null) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(Color(0x333B82F6))
                                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = tool.badge,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF38BDF8)
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                }
                                                Icon(
                                                    Icons.Default.NorthEast,
                                                    contentDescription = null,
                                                    tint = Color(0x6694A3B8),
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }

                                        Column {
                                            Text(
                                                text = tool.name,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = tool.description,
                                                fontSize = 10.sp,
                                                lineHeight = 13.sp,
                                                color = Color(0xFF94A3B8),
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                            if (rowTools.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
