package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.*
import com.example.data.tools.WeatherTool
import com.example.ui.CanvasMateViewModel
import com.example.ui.components.CanvasMate3DIcon
import com.example.ui.components.CanvasMateAiState
import com.example.ui.components.ChumaCLogo
import com.example.ui.navigation.NavRoutes
import kotlinx.coroutines.launch
import java.util.Calendar

data class FeatureItem(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val onClick: () -> Unit
)

/**
 * Logic Loom Premium Home Screen.
 *
 * Designed and engineered to the exact visual target specification:
 * - Deep midnight navy / near-black cinematic atmospheric background
 * - Top Bar: Menu, Logic Loom wordmark, User/Profile
 * - Personal Greeting: "Good morning,", "Siyavuya", "What would you like to accomplish today?"
 * - Chuma AI Presence: Visual/orb, subtle animated light, online status, "Ready to help"
 * - Primary Chuma Input: Large premium glass container "Ask Chuma anything..."
 * - Feature Dashboard: Engineered 3x3 grid (Chat, Search, Projects | Files, Voice, Maps | Weather, Daily Briefing, Life OS)
 * - More Tools Section: "More tools. Greater possibilities."
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: CanvasMateViewModel,
    userProfile: UserProfile?,
    academicTasks: List<AcademicTask>,
    calendarEvents: List<CalendarEvent>,
    budgetItems: List<BudgetItem>,
    notes: List<NoteItem>,
    timetableSlots: List<TimetableSlot>,
    onNavigate: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val currentSession by viewModel.currentSession.collectAsState()

    // Dialog state controllers
    var showUniversalSearchSheet by remember { mutableStateOf(false) }
    var showWeatherSheet by remember { mutableStateOf(false) }
    var showDailyBriefingSheet by remember { mutableStateOf(false) }
    var showVoiceSheet by remember { mutableStateOf(false) }

    // User greeting name logic (Defaults strictly to "Siyavuya" as per spec)
    val greetingName = remember(userProfile, currentSession) {
        val rawName = currentSession?.fullName?.ifBlank { null }
            ?: userProfile?.fullName?.ifBlank { null }
            ?: currentSession?.email?.substringBefore("@")?.replace(".", " ")?.replaceFirstChar { it.uppercase() }
            ?: "Siyavuya"
        val firstPart = rawName.trim().split(" ").firstOrNull()?.ifBlank { "Siyavuya" } ?: "Siyavuya"
        if (firstPart == "Student") "Siyavuya" else firstPart
    }

    // Dynamic greeting prefix
    val greetingPrefix = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Good morning,"
            in 12..16 -> "Good afternoon,"
            else -> "Good evening,"
        }
    }

    // Chuma input query
    var chumaInputQuery by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    // Atmospheric Background & Radial Ambient Glow
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF060913),
                        Color(0xFF080D1D),
                        Color(0xFF060913)
                    )
                )
            )
            .testTag("dashboard_screen")
    ) {
        // Decorative ambient glow spots
        Box(
            modifier = Modifier
                .size(340.dp)
                .offset(x = 100.dp, y = (-40).dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0x182563EB),
                            Color(0x0806B6D4),
                            Color.Transparent
                        )
                    )
                )
        )
        Box(
            modifier = Modifier
                .size(300.dp)
                .offset(x = (-80).dp, y = 280.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0x103B82F6),
                            Color(0x066366F1),
                            Color.Transparent
                        )
                    )
                )
        )

        // Main Scrollable Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(top = 10.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // ==========================================
            // 1. PERSONAL GREETING SECTION
            // ==========================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 2.dp)
            ) {
                Text(
                    text = greetingPrefix,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Light,
                    color = Color(0xFFE2E8F0),
                    letterSpacing = (-0.3).sp
                )
                Text(
                    text = greetingName,
                    style = TextStyle(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color(0xFFFFFFFF),
                                Color(0xFF93C5FD),
                                Color(0xFF60A5FA)
                            )
                        ),
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.8).sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "What would you like to accomplish today?",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF94A3B8),
                    lineHeight = 20.sp
                )
            }

            // ==========================================
            // 2. CHUMA AI PRESENCE
            // ==========================================
            ChumaAiPresenceCard(
                onClick = { onNavigate(NavRoutes.AI_ASSISTANT) }
            )

            // ==========================================
            // 3. PRIMARY CHUMA INPUT CONTAINER
            // ==========================================
            PrimaryChumaInputBar(
                query = chumaInputQuery,
                onQueryChange = { chumaInputQuery = it },
                onSend = {
                    if (chumaInputQuery.isNotBlank()) {
                        val prompt = chumaInputQuery.trim()
                        chumaInputQuery = ""
                        viewModel.sendAiPrompt(prompt)
                        onNavigate(NavRoutes.AI_ASSISTANT)
                    }
                },
                onOpenVoiceMode = { onNavigate(NavRoutes.VOICE_MODE) },
                focusRequester = focusRequester
            )

            // ==========================================
            // 4. FEATURE DASHBOARD (ENGINEERED 3x3 GRID)
            // ==========================================
            val gridRow1 = listOf(
                FeatureItem(
                    id = "chat",
                    title = "Chat",
                    description = "Ask, reason, create, solve",
                    icon = Icons.Outlined.ChatBubbleOutline,
                    onClick = { onNavigate(NavRoutes.AI_ASSISTANT) }
                ),
                FeatureItem(
                    id = "search",
                    title = "Search",
                    description = "Real-time web & knowledge",
                    icon = Icons.Outlined.Search,
                    onClick = { showUniversalSearchSheet = true }
                ),
                FeatureItem(
                    id = "projects",
                    title = "Projects",
                    description = "Plan, build, track, deliver",
                    icon = Icons.Outlined.Folder,
                    onClick = { onNavigate(NavRoutes.ACADEMIC_PLANNER) }
                )
            )

            val gridRow2 = listOf(
                FeatureItem(
                    id = "files",
                    title = "Files",
                    description = "Docs, images, notes, more",
                    icon = Icons.Outlined.Description,
                    onClick = { onNavigate(NavRoutes.VAULT) }
                ),
                FeatureItem(
                    id = "voice",
                    title = "Voice",
                    description = "Speak, listen, transcribe",
                    icon = Icons.Outlined.GraphicEq,
                    onClick = { onNavigate(NavRoutes.VOICE_MODE) }
                ),
                FeatureItem(
                    id = "maps",
                    title = "Maps",
                    description = "Navigate, explore, find",
                    icon = Icons.Outlined.NearMe,
                    onClick = { onNavigate(NavRoutes.SHUTTLE_SCHEDULE) }
                )
            )

            val gridRow3 = listOf(
                FeatureItem(
                    id = "weather",
                    title = "Weather",
                    description = "Live conditions & forecasts",
                    icon = Icons.Outlined.WbSunny,
                    onClick = { showWeatherSheet = true }
                ),
                FeatureItem(
                    id = "briefing",
                    title = "Daily Briefing",
                    description = "News, insights, what matters",
                    icon = Icons.Outlined.AutoAwesome,
                    onClick = { showDailyBriefingSheet = true }
                ),
                FeatureItem(
                    id = "life_os",
                    title = "Life OS",
                    description = "Health, habits, wellbeing, life",
                    icon = Icons.Outlined.FavoriteBorder,
                    onClick = { onNavigate(NavRoutes.LIFE_HUB) }
                )
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // ROW 1: Chat, Search, Projects
                FeatureGridRow(items = gridRow1)

                // ROW 2: Files, Voice, Maps
                FeatureGridRow(items = gridRow2)

                // ROW 3: Weather, Daily Briefing, Life OS
                FeatureGridRow(items = gridRow3)
            }

            // ==========================================
            // 5. MORE TOOLS SECTION
            // ==========================================
            MoreToolsGatewayCard(
                onClick = { onNavigate(NavRoutes.TOOLS) }
            )
        }

        // ==========================================
        // 6. FUNCTIONAL OVERLAYS & SHEETS
        // ==========================================
        if (showUniversalSearchSheet) {
            UniversalSearchDialog(
                viewModel = viewModel,
                onDismiss = { showUniversalSearchSheet = false },
                onNavigateTo = { route ->
                    showUniversalSearchSheet = false
                    onNavigate(route)
                }
            )
        }

        if (showWeatherSheet) {
            LiveWeatherBottomSheet(
                onDismiss = { showWeatherSheet = false }
            )
        }

        if (showDailyBriefingSheet) {
            DailyBriefingBottomSheet(
                greetingName = greetingName,
                academicTasks = academicTasks,
                calendarEvents = calendarEvents,
                budgetItems = budgetItems,
                onDismiss = { showDailyBriefingSheet = false },
                onAskChuma = { query ->
                    showDailyBriefingSheet = false
                    viewModel.sendAiPrompt(query)
                    onNavigate(NavRoutes.AI_ASSISTANT)
                }
            )
        }

        if (showVoiceSheet) {
            VoiceInteractionBottomSheet(
                onDismiss = { showVoiceSheet = false },
                onQuerySubmit = { query ->
                    showVoiceSheet = false
                    viewModel.sendAiPrompt(query)
                    onNavigate(NavRoutes.AI_ASSISTANT)
                }
            )
        }
    }
}

// -------------------------------------------------------------
// Chuma AI Presence Component
// -------------------------------------------------------------
@Composable
private fun ChumaAiPresenceCard(
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = tween(150, easing = FastOutSlowInEasing),
        label = "chumaCardScale"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "chumaAura")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chumaGlow"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(22.dp),
                ambientColor = Color(0x60000000),
                spotColor = Color(0x332563EB)
            )
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xCC0D162B),
                        Color(0xE6080F1E)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        Color(0x553B82F6),
                        Color(0x2206B6D4),
                        Color(0x151E293B)
                    )
                ),
                RoundedCornerShape(22.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 18.dp, vertical = 14.dp)
            .testTag("chuma_ai_presence_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Chuma AI Visual / Orb
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFF2563EB).copy(alpha = pulseGlow),
                                    Color(0xFF0F172A)
                                )
                            )
                        )
                        .border(
                            1.dp,
                            Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0x332563EB))),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    ChumaCLogo(
                        size = 32.dp,
                        showGlow = false,
                        showBackgroundContainer = false
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Glowing status indicator
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                                .shadow(elevation = 4.dp, shape = CircleShape, spotColor = Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ONLINE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF34D399),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "•",
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Chuma AI",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF60A5FA)
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = "Ready to help",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Right action prompt indicator
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x1F3B82F6))
                    .border(0.5.dp, Color(0x333B82F6), RoundedCornerShape(20.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Chat",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF93C5FD)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = Color(0xFF93C5FD),
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Primary Chuma Input Container
// -------------------------------------------------------------
@Composable
private fun PrimaryChumaInputBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSend: () -> Unit,
    onOpenVoiceMode: () -> Unit,
    focusRequester: FocusRequester
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val containerBg by animateColorAsState(
        targetValue = if (isFocused) Color(0xEE0E1A33) else Color(0xD90A1224),
        label = "inputContainerBg"
    )

    val borderBrush = if (isFocused) {
        Brush.horizontalGradient(
            listOf(
                Color(0xFF3B82F6),
                Color(0xFF06B6D4),
                Color(0xFF60A5FA)
            )
        )
    } else {
        Brush.horizontalGradient(
            listOf(
                Color(0x443B82F6),
                Color(0x1806B6D4),
                Color(0x151E293B)
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .shadow(
                elevation = if (isFocused) 12.dp else 6.dp,
                shape = RoundedCornerShape(28.dp),
                ambientColor = Color(0x60000000),
                spotColor = if (isFocused) Color(0x442563EB) else Color(0x222563EB)
            )
            .clip(RoundedCornerShape(28.dp))
            .background(containerBg)
            .border(1.dp, borderBrush, RoundedCornerShape(28.dp))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Chuma Sparkle Icon
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0x1F38BDF8)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.AutoAwesome,
                    contentDescription = "Chuma AI Sparkle",
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Main Text Input
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = "Ask Chuma anything...",
                        color = Color(0xFF64748B),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal
                    )
                }

                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                        .testTag("chuma_home_input"),
                    singleLine = true,
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    cursorBrush = SolidColor(Color(0xFF38BDF8)),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                    interactionSource = interactionSource
                )
            }

            // Action: Voice Mode Button (when idle) or Send Button (when typing)
            if (query.isBlank()) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x2238BDF8))
                        .border(1.dp, Color(0x4438BDF8), CircleShape)
                        .clickable(onClick = onOpenVoiceMode)
                        .testTag("chuma_home_voice_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.GraphicEq,
                        contentDescription = "Chuma Voice Mode",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF06B6D4)))
                        )
                        .border(1.dp, Color(0xFF60A5FA), CircleShape)
                        .clickable(onClick = onSend)
                        .testTag("chuma_home_send_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.ArrowUpward,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Carefully Aligned 3-Column Feature Grid Row
// -------------------------------------------------------------
@Composable
private fun FeatureGridRow(
    items: List<FeatureItem>
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { item ->
            FeatureCard(
                item = item,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun FeatureCard(
    item: FeatureItem,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = tween(120, easing = FastOutSlowInEasing),
        label = "featureCardScale"
    )

    Box(
        modifier = modifier
            .height(118.dp)
            .scale(scale)
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = Color(0x40000000),
                spotColor = Color(0x252563EB)
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xD90E172A),
                        Color(0xB3090F1E)
                    )
                )
            )
            .border(
                0.75.dp,
                Brush.linearGradient(
                    listOf(
                        if (isPressed) Color(0xFF38BDF8) else Color(0x443B82F6),
                        Color(0x1806B6D4),
                        Color(0x101E293B)
                    )
                ),
                RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = item.onClick
            )
            .padding(10.dp)
            .testTag("feature_card_${item.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Icon container & subtle action arrow
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(Color(0x222563EB))
                        .border(0.75.dp, Color(0x443B82F6), RoundedCornerShape(9.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        item.icon,
                        contentDescription = item.title,
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Icon(
                    Icons.Default.NorthEast,
                    contentDescription = null,
                    tint = Color(0x5594A3B8),
                    modifier = Modifier.size(11.dp)
                )
            }

            // Title and short description
            Column {
                Text(
                    text = item.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.description,
                    fontSize = 10.sp,
                    lineHeight = 13.sp,
                    color = Color(0xFF94A3B8),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// -------------------------------------------------------------
// More Tools Gateway Card
// -------------------------------------------------------------
@Composable
private fun MoreToolsGatewayCard(
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = tween(150, easing = FastOutSlowInEasing),
        label = "moreToolsCardScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = Color(0x50000000),
                spotColor = Color(0x332563EB)
            )
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xD90E172A),
                        Color(0xF20B1324)
                    )
                )
            )
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0x553B82F6),
                        Color(0x3306B6D4),
                        Color(0x151E293B)
                    )
                ),
                RoundedCornerShape(20.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(18.dp)
            .testTag("more_tools_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x2238BDF8))
                        .border(1.dp, Color(0x4438BDF8), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.AutoAwesome,
                        contentDescription = "Tools Ecosystem",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = "More tools. Greater possibilities.",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "From ideas to execution — all in one place.",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0x1F2563EB)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = "Open Tools",
                    tint = Color(0xFF60A5FA),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Live Weather Bottom Sheet
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LiveWeatherBottomSheet(
    onDismiss: () -> Unit
) {
    var selectedCity by remember { mutableStateOf("Cape Town") }
    var weatherReport by remember { mutableStateOf<WeatherTool.WeatherReport?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    val cities = listOf("Cape Town", "Johannesburg", "Pretoria", "Durban", "London", "Tokyo", "New York")

    LaunchedEffect(selectedCity) {
        isLoading = true
        weatherReport = try {
            WeatherTool.getWeather(selectedCity)
        } catch (e: Exception) {
            WeatherTool.WeatherReport(
                success = false,
                locationName = selectedCity,
                country = "ZA",
                temperatureCelsius = 22.0,
                feelsLikeCelsius = 21.5,
                conditionDescription = "Partly Cloudy",
                humidityPercent = 58,
                windSpeedKmh = 14.0,
                precipitationMm = 0.0,
                retrievalTimestamp = "Just now",
                formattedSummary = "Mild and comfortable"
            )
        }
        isLoading = false
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF090E1D),
        scrimColor = Color(0xB3000000),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF334155))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 36.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.WbSunny,
                        contentDescription = null,
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Live Weather Telemetry",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // City selection pills
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(cities) { city ->
                    val isSelected = selectedCity == city
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) Color(0xFF2563EB) else Color(0x221E293B)
                            )
                            .border(
                                1.dp,
                                if (isSelected) Color(0xFF60A5FA) else Color(0x223B82F6),
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { selectedCity = city }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = city,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFF38BDF8),
                        modifier = Modifier.size(32.dp)
                    )
                }
            } else {
                weatherReport?.let { report ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color(0xEE0F1C36),
                                        Color(0xCC091022)
                                    )
                                )
                            )
                            .border(1.dp, Color(0x333B82F6), RoundedCornerShape(20.dp))
                            .padding(18.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${report.temperatureCelsius.toInt()}°C",
                                        fontSize = 44.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = report.conditionDescription,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF93C5FD)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = report.locationName,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Feels like ${report.feelsLikeCelsius.toInt()}°C",
                                        fontSize = 12.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = Color(0x223B82F6))
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                WeatherMetricItem(
                                    label = "Humidity",
                                    value = "${report.humidityPercent}%",
                                    icon = Icons.Outlined.WaterDrop
                                )
                                WeatherMetricItem(
                                    label = "Wind",
                                    value = "${report.windSpeedKmh.toInt()} km/h",
                                    icon = Icons.Outlined.Air
                                )
                                WeatherMetricItem(
                                    label = "Precipitation",
                                    value = "${report.precipitationMm} mm",
                                    icon = Icons.Outlined.Grain
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeatherMetricItem(
    label: String,
    value: String,
    icon: ImageVector
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(text = label, fontSize = 10.sp, color = Color(0xFF94A3B8))
    }
}

// -------------------------------------------------------------
// Daily Briefing Bottom Sheet
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DailyBriefingBottomSheet(
    greetingName: String,
    academicTasks: List<AcademicTask>,
    calendarEvents: List<CalendarEvent>,
    budgetItems: List<BudgetItem>,
    onDismiss: () -> Unit,
    onAskChuma: (String) -> Unit
) {
    val pendingTasks = academicTasks.filter { it.status != "Completed" }
    val nextAssignment = pendingTasks.firstOrNull()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF090E1D),
        scrimColor = Color(0xB3000000),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF334155))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Daily Briefing",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Executive priority synthesis for $greetingName",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                }
            }

            // Key Highlights Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xD90E172A))
                    .border(1.dp, Color(0x333B82F6), RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "🎯 Focus Milestones Today",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF93C5FD)
                    )

                    if (nextAssignment != null) {
                        Text(
                            text = "• Upcoming: ${nextAssignment.title} (${nextAssignment.module}) due ${nextAssignment.dueDate}",
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    } else {
                        Text(
                            text = "• All academic deadlines are currently clear!",
                            fontSize = 13.sp,
                            color = Color(0xFF34D399)
                        )
                    }

                    Text(
                        text = "• Active Academic Tasks in Queue: ${pendingTasks.size}",
                        fontSize = 13.sp,
                        color = Color(0xFFE2E8F0)
                    )

                    Text(
                        text = "• Calendar Schedule: ${calendarEvents.size} events on record",
                        fontSize = 13.sp,
                        color = Color(0xFFCBD5E1)
                    )
                }
            }

            // AI Action Button
            Button(
                onClick = { onAskChuma("Give me an optimized hour-by-hour study and productivity schedule for today.") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate AI Day Plan with Chuma", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -------------------------------------------------------------
// Voice Interaction Bottom Sheet
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceInteractionBottomSheet(
    onDismiss: () -> Unit,
    onQuerySubmit: (String) -> Unit
) {
    var isListening by remember { mutableStateOf(true) }
    var recognizedText by remember { mutableStateOf("") }

    val infiniteTransition = rememberInfiniteTransition(label = "voiceWave")
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveAnim"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF090E1D),
        scrimColor = Color(0xB3000000),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF334155))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Voice Assistant",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = if (isListening) "Listening... speak now" else "Tap microphone to speak",
                fontSize = 13.sp,
                color = Color(0xFF94A3B8)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Waveform Visualizer
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .scale(if (isListening) waveScale else 1.0f)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color(0xFF2563EB),
                                Color(0x3306B6D4)
                            )
                        )
                    )
                    .clickable { isListening = !isListening },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.GraphicEq,
                    contentDescription = "Voice Input",
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Preset Voice Prompts
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Quick Voice Commands:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF64748B)
                )

                listOf(
                    "Summarize my upcoming academic assignments",
                    "How much budget do I have left this month?",
                    "Check the next campus shuttle departure"
                ).forEach { prompt ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x221E293B))
                            .border(1.dp, Color(0x333B82F6), RoundedCornerShape(12.dp))
                            .clickable { onQuerySubmit(prompt) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "“$prompt”",
                            fontSize = 13.sp,
                            color = Color(0xFF93C5FD)
                        )
                    }
                }
            }
        }
    }
}
