package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ShuttleSchedule
import com.example.data.repository.CanvasMateRepository
import com.example.CanvasMateApplication
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@HiltViewModel
class ShuttleViewModel @Inject constructor(
    application: Application,
    private val repository: CanvasMateRepository
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application,
        (application as CanvasMateApplication).repository
    )

    val shuttleSchedules: StateFlow<List<ShuttleSchedule>> = repository.shuttleSchedules.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val searchQuery = MutableStateFlow("")
    val selectedDayFilter = MutableStateFlow("All")

    val filteredShuttles: StateFlow<List<ShuttleSchedule>> = combine(
        shuttleSchedules,
        searchQuery,
        selectedDayFilter
    ) { shuttles, query, filter ->
        shuttles.filter { shuttle ->
            val matchesDay = if (filter == "All") true else shuttle.daysOfWeek.contains(filter, ignoreCase = true)
            val matchesSearch = shuttle.routeName.contains(query, ignoreCase = true) ||
                    shuttle.stopLocation.contains(query, ignoreCase = true)
            matchesDay && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val activeReminders = MutableStateFlow<Set<Long>>(emptySet())

    fun addShuttleSchedule(shuttle: ShuttleSchedule) {
        viewModelScope.launch {
            repository.addShuttleSchedule(shuttle)
        }
    }

    fun updateShuttleSchedule(shuttle: ShuttleSchedule) {
        viewModelScope.launch {
            repository.updateShuttleSchedule(shuttle)
        }
    }

    fun deleteShuttleSchedule(id: Long) {
        viewModelScope.launch {
            repository.deleteShuttleSchedule(id)
        }
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setDayFilter(filter: String) {
        selectedDayFilter.value = filter
    }

    fun toggleReminder(shuttleId: Long) {
        val current = activeReminders.value
        if (current.contains(shuttleId)) {
            activeReminders.value = current - shuttleId
        } else {
            activeReminders.value = current + shuttleId
        }
    }
}
