package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ai.datastore.ChumaTaskExecutionState
import com.example.data.ai.datastore.ChumaTaskStatus

/**
 * Visual card displaying the active Chuma AI task execution state persisted via Jetpack DataStore.
 * Allows observing the multi-step reasoning progression and resuming interrupted tasks across app restarts.
 */
@Composable
fun ChumaTaskExecutionCard(
    taskState: ChumaTaskExecutionState,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (taskState.taskId.isBlank() || taskState.status == ChumaTaskStatus.IDLE) {
        return
    }

    val isVisible = taskState.isExecuting || taskState.isInterrupted ||
            taskState.status == ChumaTaskStatus.FAILED ||
            taskState.status == ChumaTaskStatus.CANCELLED

    if (!isVisible) return

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("chuma_task_execution_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                taskState.isInterrupted -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f)
                taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.errorContainer
                taskState.status == ChumaTaskStatus.CANCELLED -> MaterialTheme.colorScheme.surfaceVariant
                else -> MaterialTheme.colorScheme.primaryContainer
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            // Header Row: Agent Badge & Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.primary
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                taskState.isInterrupted -> Icons.Default.Warning
                                taskState.status == ChumaTaskStatus.FAILED -> Icons.Default.ErrorOutline
                                taskState.status == ChumaTaskStatus.CANCELLED -> Icons.Default.Cancel
                                else -> Icons.Default.Sync
                            },
                            contentDescription = "Chuma Agent Status",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Text(
                        text = "CHUMA AGENT • STATE PERSISTED",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.onErrorContainer
                            else -> MaterialTheme.colorScheme.onPrimaryContainer
                        }
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        taskState.isInterrupted -> MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                        taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                        taskState.status == ChumaTaskStatus.CANCELLED -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f)
                        else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = when {
                            taskState.isInterrupted -> "Interrupted Across Restart"
                            taskState.status == ChumaTaskStatus.FAILED -> "Execution Error"
                            taskState.status == ChumaTaskStatus.CANCELLED -> "Stopped"
                            else -> "In Progress (${taskState.percentInt}%)"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = when {
                            taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.primary
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Task Goal / Prompt
            Text(
                text = "“${taskState.prompt}”",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = when {
                    taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.onErrorContainer
                    else -> MaterialTheme.colorScheme.onPrimaryContainer
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Current Step & Progress Percentage
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Step ${taskState.currentStepIndex}/${taskState.totalSteps}: ${taskState.currentStep}",
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                    color = when {
                        taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                        else -> MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${taskState.percentInt}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.onErrorContainer
                        else -> MaterialTheme.colorScheme.onPrimaryContainer
                    }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { taskState.progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = when {
                    taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.primary
                },
                trackColor = when {
                    taskState.isInterrupted || taskState.status == ChumaTaskStatus.FAILED -> MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                    else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                }
            )

            // Explanatory note for interrupted or failed state
            if (taskState.isInterrupted) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "App restarted while agent was executing. Task progress preserved in DataStore. You can resume or discard.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.9f)
                )
            } else if (taskState.errorMessage != null && taskState.status == ChumaTaskStatus.FAILED) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = taskState.errorMessage,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (taskState.isExecuting && !taskState.isInterrupted) {
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("cancel_chuma_task_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stop", style = MaterialTheme.typography.labelMedium)
                    }
                } else {
                    TextButton(
                        onClick = onClear,
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("dismiss_chuma_task_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("Dismiss", style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onResume,
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("resume_chuma_task_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            if (taskState.status == ChumaTaskStatus.FAILED) "Retry" else "Resume",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}
