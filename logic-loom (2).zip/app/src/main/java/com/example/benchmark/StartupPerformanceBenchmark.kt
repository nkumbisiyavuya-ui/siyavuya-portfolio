package com.example.benchmark

import android.content.Context
import android.util.Log
import androidx.tracing.trace
import com.example.data.local.CanvasMateDatabase
import com.example.ui.CanvasMateViewModel
import com.example.ui.theme.AppColorPalette
import com.example.ui.theme.AppFontStyle
import com.example.ui.theme.getCustomColorScheme
import com.example.ui.theme.getCustomTypography
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Benchmark Report containing metrics for each phase of Logic Loom initialization.
 */
data class StartupBenchmarkReport(
    val databaseInitMs: Long,
    val viewModelInitMs: Long,
    val themeResolutionMs: Long,
    val totalStartupMs: Long,
    val isBaselineProfileActive: Boolean = true,
    val bottleneckWarning: String? = null
) {
    val isOptimalStartup: Boolean get() = totalStartupMs < 150
}

/**
 * Jetpack Benchmark utility for identifying bottlenecks in the application's startup
 * and initialization sequence.
 */
object StartupPerformanceBenchmark {

    private const val TAG = "StartupBenchmark"

    /**
     * Executes the full startup benchmarking suite to measure and analyze initialization performance.
     */
    suspend fun benchmarkInitializationSequence(
        context: Context,
        viewModel: CanvasMateViewModel
    ): StartupBenchmarkReport = withContext(Dispatchers.Default) {
        var dbTime = 0L
        var vmTime = 0L
        var themeTime = 0L

        val startTime = System.currentTimeMillis()

        // 1. Benchmark Room Database Initialization & Open Helper
        trace("Benchmark_Database_Init") {
            val dbStart = System.currentTimeMillis()
            val db = CanvasMateDatabase.getDatabase(context.applicationContext)
            // Access DAO to ensure database connection warm-up
            db.dao()
            dbTime = System.currentTimeMillis() - dbStart
        }

        // 2. Benchmark ViewModel State & Reactive Flow Warm-up
        trace("Benchmark_ViewModel_Init") {
            val vmStart = System.currentTimeMillis()
            val notesCount = viewModel.notes.value.size
            val tasksCount = viewModel.academicTasks.value.size
            val profile = viewModel.userProfile.value
            Log.d(TAG, "ViewModel state checked: $notesCount notes, $tasksCount tasks, profile loaded: ${profile != null}")
            vmTime = System.currentTimeMillis() - vmStart
        }

        // 3. Benchmark Jetpack Compose Theme & Token Resolution
        trace("Benchmark_Theme_Resolution") {
            val themeStart = System.currentTimeMillis()
            val colorScheme = getCustomColorScheme(AppColorPalette.CLASSIC_BLUE, isDark = false)
            val typography = getCustomTypography(AppFontStyle.DEFAULT)
            Log.d(TAG, "Theme resolved with primary color: ${colorScheme.primary} and ${typography.bodyLarge.fontSize}")
            themeTime = System.currentTimeMillis() - themeStart
        }

        val totalTime = System.currentTimeMillis() - startTime

        val warning = when {
            dbTime > 80 -> "Database cold-start initialization exceeded 80ms target ($dbTime ms)"
            vmTime > 50 -> "ViewModel flow state-in initialization exceeded 50ms target ($vmTime ms)"
            themeTime > 30 -> "Theme token resolution exceeded 30ms target ($themeTime ms)"
            else -> null
        }

        val report = StartupBenchmarkReport(
            databaseInitMs = dbTime,
            viewModelInitMs = vmTime,
            themeResolutionMs = themeTime,
            totalStartupMs = totalTime,
            isBaselineProfileActive = true,
            bottleneckWarning = warning
        )

        Log.i(
            TAG,
            "Startup Benchmark Complete: Total = ${report.totalStartupMs}ms [DB: ${report.databaseInitMs}ms, VM: ${report.viewModelInitMs}ms, Theme: ${report.themeResolutionMs}ms]. Optimal = ${report.isOptimalStartup}"
        )

        report
    }
}
