package com.example.security

import android.util.Patterns
import java.util.regex.Pattern

sealed class ValidationResult {
    object Success : ValidationResult()
    data class Error(val message: String) : ValidationResult()
}

object InputSanitizer {

    private val PASSWORD_PATTERN = Pattern.compile(
        "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\\S+$).{8,}$"
    )

    fun validateEmail(email: String): ValidationResult {
        val trimmed = email.trim()
        if (trimmed.isEmpty()) {
            return ValidationResult.Error("Email address cannot be empty.")
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(trimmed).matches()) {
            return ValidationResult.Error("Please enter a valid email address (e.g., student@university.ac.za).")
        }
        return ValidationResult.Success
    }

    fun validatePassword(password: String): ValidationResult {
        if (password.isEmpty()) {
            return ValidationResult.Error("Password cannot be empty.")
        }
        if (password.length < 8) {
            return ValidationResult.Error("Password must be at least 8 characters long.")
        }
        if (!password.any { it.isDigit() }) {
            return ValidationResult.Error("Password must contain at least one number.")
        }
        if (!password.any { it.isUpperCase() }) {
            return ValidationResult.Error("Password must contain at least one uppercase letter.")
        }
        if (password.contains(" ")) {
            return ValidationResult.Error("Password cannot contain spaces.")
        }
        return ValidationResult.Success
    }

    fun validateStudentNumber(studentNumber: String): ValidationResult {
        val trimmed = studentNumber.trim()
        if (trimmed.isEmpty()) {
            return ValidationResult.Error("Student number cannot be empty.")
        }
        if (trimmed.length < 4) {
            return ValidationResult.Error("Student number must be at least 4 characters long.")
        }
        return ValidationResult.Success
    }

    fun validateName(name: String): ValidationResult {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            return ValidationResult.Error("Full name cannot be empty.")
        }
        if (trimmed.length < 2) {
            return ValidationResult.Error("Name must be at least 2 characters long.")
        }
        return ValidationResult.Success
    }

    fun sanitizeText(input: String): String {
        return input
            .replace("<script>", "")
            .replace("</script>", "")
            .replace("javascript:", "")
            .replace("'", "''")
            .trim()
    }
}
