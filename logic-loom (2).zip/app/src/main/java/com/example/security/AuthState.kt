package com.example.security

/**
 * Explicit authentication states representing the lifecycle of session resolution.
 * - INITIALIZING: App startup / waiting for Firebase SDK to restore session from keystore/cache.
 * - AUTHENTICATED: Valid user session verified by Firebase Auth.
 * - UNAUTHENTICATED: Session confirmed null or explicitly logged out.
 */
enum class AuthState {
    INITIALIZING,
    AUTHENTICATED,
    UNAUTHENTICATED
}
