package com.example.security

enum class PasswordStrengthLevel {
    WEAK,
    MEDIUM,
    STRONG,
    VERY_STRONG
}

data class PasswordValidationResult(
    val isValid: Boolean,
    val score: Int, // 0 to 100
    val level: PasswordStrengthLevel,
    val hasMinLength: Boolean,
    val hasUppercase: Boolean,
    val hasLowercase: Boolean,
    val hasDigit: Boolean,
    val hasSpecialChar: Boolean,
    val feedbackMessage: String
)

/**
 * Utility helper class to validate password strength (length, special characters, uppercase, numbers)
 * for the sign-up and authentication flows in Logic Loom.
 */
object PasswordStrengthValidator {

    private const val MIN_LENGTH = 8
    private val SPECIAL_CHAR_REGEX = Regex("[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]")

    fun validate(password: String): PasswordValidationResult {
        val hasMinLength = password.length >= MIN_LENGTH
        val hasUppercase = password.any { it.isUpperCase() }
        val hasLowercase = password.any { it.isLowerCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSpecialChar = SPECIAL_CHAR_REGEX.containsMatchIn(password)

        var criteriaMet = 0
        if (hasMinLength) criteriaMet++
        if (hasUppercase) criteriaMet++
        if (hasLowercase) criteriaMet++
        if (hasDigit) criteriaMet++
        if (hasSpecialChar) criteriaMet++

        val score = when {
            password.isEmpty() -> 0
            else -> (criteriaMet * 20).coerceIn(0, 100)
        }

        val level = when {
            score >= 80 && password.length >= 10 -> PasswordStrengthLevel.VERY_STRONG
            score >= 80 -> PasswordStrengthLevel.STRONG
            score >= 60 -> PasswordStrengthLevel.MEDIUM
            else -> PasswordStrengthLevel.WEAK
        }

        val isValid = hasMinLength && hasUppercase && (hasDigit || hasSpecialChar)

        val missingCriteria = mutableListOf<String>()
        if (!hasMinLength) missingCriteria.add("at least $MIN_LENGTH characters")
        if (!hasUppercase) missingCriteria.add("an uppercase letter")
        if (!hasLowercase) missingCriteria.add("a lowercase letter")
        if (!hasDigit) missingCriteria.add("a number")
        if (!hasSpecialChar) missingCriteria.add("a special character")

        val feedbackMessage = when {
            password.isEmpty() -> "Password is required"
            missingCriteria.isEmpty() -> "Strong & secure password"
            else -> "Needs " + missingCriteria.joinToString(", ")
        }

        return PasswordValidationResult(
            isValid = isValid,
            score = score,
            level = level,
            hasMinLength = hasMinLength,
            hasUppercase = hasUppercase,
            hasLowercase = hasLowercase,
            hasDigit = hasDigit,
            hasSpecialChar = hasSpecialChar,
            feedbackMessage = feedbackMessage
        )
    }

    /**
     * Quick helper to verify if a password satisfies minimum security threshold.
     */
    fun isPasswordStrongEnough(password: String): Boolean {
        return validate(password).isValid
    }
}
