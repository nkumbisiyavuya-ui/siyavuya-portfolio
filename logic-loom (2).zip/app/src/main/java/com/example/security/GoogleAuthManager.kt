package com.example.security

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

data class GoogleAuthResult(
    val email: String,
    val displayName: String,
    val idToken: String,
    val firebaseUid: String? = null
)

/**
 * Utility manager that integrates Android Credential Manager API with Google Sign-In
 * and Firebase Auth authentication.
 */
@Singleton
class GoogleAuthManager @Inject constructor() {

    // Web Client ID used for Google Sign-In Credential Manager
    private val defaultWebClientId = "101234567890-defaultclientid.apps.googleusercontent.com"

    suspend fun signInWithGoogle(context: Context, webClientId: String? = null): Result<GoogleAuthResult> {
        val credentialManager = CredentialManager.create(context)
        val clientId = webClientId?.ifEmpty { null } ?: defaultWebClientId

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        return try {
            val response = credentialManager.getCredential(
                context = context,
                request = request
            )

            val credential = response.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                val email = googleIdTokenCredential.id
                val displayName = googleIdTokenCredential.displayName
                    ?: googleIdTokenCredential.givenName
                    ?: "Google Student"

                // Firebase Auth integration
                var firebaseUid: String? = null
                try {
                    val apps = com.google.firebase.FirebaseApp.getApps(context)
                    if (apps.isNotEmpty()) {
                        val firebaseAuth = FirebaseAuth.getInstance()
                        val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                        val authResult = firebaseAuth.signInWithCredential(authCredential).await()
                        firebaseUid = authResult.user?.uid
                    }
                } catch (e: Throwable) {
                    Log.w("GoogleAuthManager", "Firebase Auth sign-in note: ${e.message}")
                }

                Result.success(
                    GoogleAuthResult(
                        email = email,
                        displayName = displayName,
                        idToken = idToken,
                        firebaseUid = firebaseUid
                    )
                )
            } else {
                Result.failure(Exception("Unrecognized credential type received from Credential Manager."))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.d("GoogleAuthManager", "Google Sign-In was cancelled by user.")
            Result.failure(Exception("Google Sign-In was cancelled."))
        } catch (e: androidx.credentials.exceptions.NoCredentialException) {
            Log.i("GoogleAuthManager", "No credentials available for Google Sign-In: ${e.message}")
            Result.failure(Exception("No Google account found on this device. Please sign in with your student email and password, or add a Google account in device Settings."))
        } catch (e: GetCredentialException) {
            val msg = e.message ?: ""
            if (msg.contains("No credential", ignoreCase = true) || msg.contains("16:", ignoreCase = true)) {
                Log.i("GoogleAuthManager", "No matching Google credentials: $msg")
                Result.failure(Exception("No Google account found on this device. Please sign in with your student email and password, or add a Google account in device Settings."))
            } else {
                Log.w("GoogleAuthManager", "Credential Manager warning: ${e.message}")
                Result.failure(Exception(e.localizedMessage ?: "Google sign-in could not be completed."))
            }
        } catch (e: Throwable) {
            Log.w("GoogleAuthManager", "Google Sign-In exception: ${e.message}")
            Result.failure(Exception(e.localizedMessage ?: "Google sign-in encountered an error."))
        }
    }
}
