package com.example.security

import java.util.Locale

sealed class FileValidationResult {
    object Valid : FileValidationResult()
    data class Invalid(val reason: String) : FileValidationResult()
}

object FileValidationUtils {

    private val ALLOWED_EXTENSIONS = setOf(
        "pdf", "doc", "docx", "txt", "rtf", "odt",
        "xls", "xlsx", "csv", "ppt", "pptx",
        "jpg", "jpeg", "png", "gif", "webp", "svg",
        "zip", "rar", "7z"
    )

    private val FORBIDDEN_EXTENSIONS = setOf(
        "apk", "exe", "bat", "cmd", "sh", "bin", "jar",
        "vbs", "js", "mjs", "php", "py", "pl", "cgi",
        "so", "dll", "sys"
    )

    private const val MAX_FILE_SIZE_MB = 50.0

    fun validateFileForUpload(fileName: String, fileSizeMb: Double): FileValidationResult {
        val trimmedName = fileName.trim()
        if (trimmedName.isEmpty()) {
            return FileValidationResult.Invalid("File name cannot be empty.")
        }

        val extension = trimmedName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (extension.isEmpty()) {
            return FileValidationResult.Invalid("File must have a valid extension (e.g. .pdf, .docx).")
        }

        if (FORBIDDEN_EXTENSIONS.contains(extension)) {
            return FileValidationResult.Invalid("Executable or script files (.$extension) are strictly blocked for security reasons.")
        }

        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            return FileValidationResult.Invalid("Unsupported file format (.$extension). Allowed types: Documents (PDF, DOCX, TXT), Spreadsheets, Images, Archives.")
        }

        if (fileSizeMb <= 0) {
            return FileValidationResult.Invalid("Invalid file size.")
        }

        if (fileSizeMb > MAX_FILE_SIZE_MB) {
            return FileValidationResult.Invalid("File size (${"%.1f".format(fileSizeMb)} MB) exceeds the maximum allowed limit of ${MAX_FILE_SIZE_MB.toInt()} MB.")
        }

        return FileValidationResult.Valid
    }
}
