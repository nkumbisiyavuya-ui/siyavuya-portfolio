package com.example.security

import android.os.SystemClock
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthActionCodeException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import kotlinx.coroutines.tasks.await

/**
 * Diagnostic wrapper around FirebaseAuth operations that captures and logs
 * specific error codes, operation timings, and context in Logcat during development.
 */
object FirebaseAuthDiagnosticWrapper {

    const val TAG = "FirebaseAuthDiagnostics"

    // Standardized Error Codes for diagnostic inspection
    object ErrorCodes {
        const val INVALID_EMAIL = "INVALID_EMAIL"
        const val MISSING_EMAIL = "MISSING_EMAIL"
        const val USER_NOT_FOUND = "USER_NOT_FOUND"
        const val OPERATION_NOT_ALLOWED = "OPERATION_NOT_ALLOWED"
        const val TOO_MANY_REQUESTS = "TOO_MANY_REQUESTS"
        const val NETWORK_ERROR = "NETWORK_ERROR"
        const val UNAUTHORIZED_CONTINUE_URI = "UNAUTHORIZED_CONTINUE_URI"
        const val INVALID_CONTINUE_URI = "INVALID_CONTINUE_URI"
        const val FIREBASE_NOT_INITIALIZED = "FIREBASE_NOT_INITIALIZED"
        const val INVALID_API_KEY = "INVALID_API_KEY"
        const val CONFIGURATION_NOT_FOUND = "CONFIGURATION_NOT_FOUND"
        const val UNKNOWN_AUTH_ERROR = "UNKNOWN_AUTH_ERROR"
    }

    /**
     * Executes [FirebaseAuth.sendPasswordResetEmail] with detailed diagnostic logging.
     * Logs request status, specific error code (e.g. INVALID_EMAIL, MISSING_EMAIL),
     * timings, and actionable developer advice to Logcat.
     */
    suspend fun sendPasswordResetEmail(
        firebaseAuth: FirebaseAuth,
        email: String
    ): DiagnosticResult<Unit> {
        val startTime = SystemClock.elapsedRealtime()
        val trimmedEmail = email.trim()

        val projectId = try {
            firebaseAuth.app.options.projectId?.ifEmpty { "unknown-project" } ?: "unknown-project"
        } catch (e: Throwable) {
            "uninitialized"
        }
        val appId = try {
            firebaseAuth.app.options.applicationId.ifEmpty { "unknown-app" }
        } catch (e: Throwable) {
            "uninitialized"
        }

        if (trimmedEmail.isEmpty()) {
            val durationMs = SystemClock.elapsedRealtime() - startTime
            val errorCode = ErrorCodes.MISSING_EMAIL
            val advice = "Email parameter is null, blank, or empty. Ensure input field is populated before invoking password reset."
            val userMessage = "Please enter an email address."

            logDiagnosticFailure(
                operation = "sendPasswordResetEmail",
                targetEmail = trimmedEmail,
                specificErrorCode = errorCode,
                rawErrorCode = "ERROR_MISSING_EMAIL",
                exceptionClass = IllegalArgumentException::class.java.simpleName,
                errorMessage = "The email address parameter cannot be empty.",
                durationMs = durationMs,
                projectId = projectId,
                appId = appId,
                developerAdvice = advice
            )

            return DiagnosticResult.Error(
                errorCode = errorCode,
                rawErrorCode = "ERROR_MISSING_EMAIL",
                userMessage = userMessage,
                developerMessage = "[$errorCode] The email parameter is empty.",
                durationMs = durationMs,
                throwable = IllegalArgumentException("Email cannot be empty")
            )
        }

        logDiagnosticStart(
            operation = "sendPasswordResetEmail",
            targetEmail = trimmedEmail,
            projectId = projectId,
            appId = appId
        )

        return try {
            firebaseAuth.sendPasswordResetEmail(trimmedEmail).await()
            val durationMs = SystemClock.elapsedRealtime() - startTime

            logDiagnosticSuccess(
                operation = "sendPasswordResetEmail",
                targetEmail = trimmedEmail,
                durationMs = durationMs,
                projectId = projectId,
                appId = appId
            )

            DiagnosticResult.Success(
                data = Unit,
                durationMs = durationMs,
                message = "If an account exists for $trimmedEmail, a password reset email has been dispatched."
            )
        } catch (e: Throwable) {
            val durationMs = SystemClock.elapsedRealtime() - startTime
            val (specificCode, rawCode, userMsg, devAdvice) = categorizeError(e, trimmedEmail)

            logDiagnosticFailure(
                operation = "sendPasswordResetEmail",
                targetEmail = trimmedEmail,
                specificErrorCode = specificCode,
                rawErrorCode = rawCode,
                exceptionClass = e.javaClass.simpleName,
                errorMessage = e.message ?: "No error message provided",
                durationMs = durationMs,
                projectId = projectId,
                appId = appId,
                developerAdvice = devAdvice
            )

            DiagnosticResult.Error(
                errorCode = specificCode,
                rawErrorCode = rawCode,
                userMessage = userMsg,
                developerMessage = "[$specificCode] ${e.message}",
                durationMs = durationMs,
                throwable = e
            )
        }
    }

    private fun categorizeError(
        throwable: Throwable,
        email: String
    ): ErrorClassification {
        if (com.example.util.AuthUtils.isApiKeyError(throwable)) {
            val userMsg = if (BuildConfig.DEBUG) {
                "Firebase configuration error: Invalid API key. Please ensure google-services.json contains a valid API key with Identity Toolkit API enabled."
            } else {
                "Authentication service is currently unavailable. Please try again later."
            }
            return ErrorClassification(
                specificCode = ErrorCodes.INVALID_API_KEY,
                rawCode = (throwable as? FirebaseAuthException)?.errorCode ?: "API_KEY_INVALID",
                userMessage = userMsg,
                developerAdvice = "Firebase rejected the API key (API_KEY_INVALID / 400 Bad Request). Verify that google-services.json contains the genuine API key from Firebase Console and Identity Toolkit API is enabled."
            )
        }

        if (com.example.util.AuthUtils.isConfigurationNotFoundError(throwable)) {
            val userMsg = if (BuildConfig.DEBUG) {
                "Firebase configuration error: CONFIGURATION_NOT_FOUND. Authentication is not yet enabled in Firebase Console for project 'logic-loom-f7cad'. Please open Firebase Console -> Build -> Authentication -> Click 'Get started' and enable 'Email/Password' provider."
            } else {
                "Authentication service is currently unavailable. Please try again later."
            }
            return ErrorClassification(
                specificCode = ErrorCodes.CONFIGURATION_NOT_FOUND,
                rawCode = (throwable as? FirebaseAuthException)?.errorCode ?: "CONFIGURATION_NOT_FOUND",
                userMessage = userMsg,
                developerAdvice = "Firebase Identity Toolkit returned CONFIGURATION_NOT_FOUND (400). Authentication has not been initialized in Firebase Console for this project. Visit Firebase Console -> Authentication -> Get started and enable Email/Password."
            )
        }

        return when (throwable) {
            is FirebaseAuthInvalidUserException -> {
                val rawCode = throwable.errorCode
                ErrorClassification(
                    specificCode = ErrorCodes.USER_NOT_FOUND,
                    rawCode = rawCode,
                    userMessage = "No account found with email address '$email'.",
                    developerAdvice = "User does not exist in Firebase Auth for project. Error code: $rawCode"
                )
            }

            is FirebaseAuthInvalidCredentialsException -> {
                val rawCode = throwable.errorCode
                val specificCode = if (email.isBlank()) {
                    ErrorCodes.MISSING_EMAIL
                } else {
                    ErrorCodes.INVALID_EMAIL
                }
                ErrorClassification(
                    specificCode = specificCode,
                    rawCode = rawCode,
                    userMessage = "The email address is invalid or poorly formatted.",
                    developerAdvice = "Email string failed Firebase RFC validation. Check format: $email. Error code: $rawCode"
                )
            }

            is FirebaseAuthActionCodeException -> {
                val rawCode = throwable.errorCode
                ErrorClassification(
                    specificCode = ErrorCodes.UNAUTHORIZED_CONTINUE_URI,
                    rawCode = rawCode,
                    userMessage = "Firebase action URL domain is not authorized.",
                    developerAdvice = "Action code settings rejected. Whitelist domain in Firebase Console > Authentication > Settings > Authorized domains. Error code: $rawCode"
                )
            }

            is FirebaseTooManyRequestsException -> {
                ErrorClassification(
                    specificCode = ErrorCodes.TOO_MANY_REQUESTS,
                    rawCode = "ERROR_TOO_MANY_REQUESTS",
                    userMessage = "Too many password reset requests. Please wait a few moments before trying again.",
                    developerAdvice = "Firebase IP/client rate limit triggered. Throttled due to unusual activity."
                )
            }

            is FirebaseNetworkException -> {
                ErrorClassification(
                    specificCode = ErrorCodes.NETWORK_ERROR,
                    rawCode = "ERROR_NETWORK_REQUEST_FAILED",
                    userMessage = "Network error: Unable to connect to Firebase servers. Check your internet connection.",
                    developerAdvice = "Network request failed. Verify internet connection, DNS, or TLS handshakes to firebase.googleapis.com."
                )
            }

            is FirebaseAuthException -> {
                val rawCode = throwable.errorCode
                val specificCode = when (rawCode) {
                    "ERROR_INVALID_EMAIL", "INVALID_EMAIL" -> ErrorCodes.INVALID_EMAIL
                    "ERROR_MISSING_EMAIL", "MISSING_EMAIL" -> ErrorCodes.MISSING_EMAIL
                    "ERROR_USER_NOT_FOUND", "USER_NOT_FOUND" -> ErrorCodes.USER_NOT_FOUND
                    "ERROR_OPERATION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED" -> ErrorCodes.OPERATION_NOT_ALLOWED
                    "ERROR_TOO_MANY_REQUESTS", "TOO_MANY_REQUESTS" -> ErrorCodes.TOO_MANY_REQUESTS
                    "ERROR_UNAUTHORIZED_CONTINUE_URI", "UNAUTHORIZED_CONTINUE_URI" -> ErrorCodes.UNAUTHORIZED_CONTINUE_URI
                    "ERROR_INVALID_CONTINUE_URI", "INVALID_CONTINUE_URI" -> ErrorCodes.INVALID_CONTINUE_URI
                    else -> ErrorCodes.UNKNOWN_AUTH_ERROR
                }
                val userMsg = when (specificCode) {
                    ErrorCodes.INVALID_EMAIL -> "The email address is invalid."
                    ErrorCodes.MISSING_EMAIL -> "Please enter an email address."
                    ErrorCodes.USER_NOT_FOUND -> "No account found with this email address."
                    ErrorCodes.OPERATION_NOT_ALLOWED -> "Password reset is currently disabled in Firebase Console."
                    ErrorCodes.TOO_MANY_REQUESTS -> "Too many attempts. Please try again later."
                    else -> throwable.localizedMessage ?: "Authentication error ($rawCode)"
                }
                val advice = when (specificCode) {
                    ErrorCodes.OPERATION_NOT_ALLOWED -> "Enable 'Email/Password' provider in Firebase Console > Authentication > Sign-in method."
                    ErrorCodes.INVALID_EMAIL -> "Firebase rejected email syntax. Raw code: $rawCode"
                    ErrorCodes.MISSING_EMAIL -> "Email parameter was not provided to Firebase API."
                    else -> "Firebase authentication exception with code '$rawCode'."
                }
                ErrorClassification(
                    specificCode = specificCode,
                    rawCode = rawCode,
                    userMessage = userMsg,
                    developerAdvice = advice
                )
            }

            is IllegalStateException -> {
                ErrorClassification(
                    specificCode = ErrorCodes.FIREBASE_NOT_INITIALIZED,
                    rawCode = "FIREBASE_NOT_INITIALIZED",
                    userMessage = "Firebase configuration is not initialized.",
                    developerAdvice = "FirebaseApp.initializeApp() has not run or google-services.json is missing in app/."
                )
            }

            is IllegalArgumentException -> {
                val isMissing = throwable.message?.contains("empty", ignoreCase = true) == true ||
                        throwable.message?.contains("null", ignoreCase = true) == true ||
                        email.isBlank()
                val code = if (isMissing) ErrorCodes.MISSING_EMAIL else ErrorCodes.INVALID_EMAIL
                ErrorClassification(
                    specificCode = code,
                    rawCode = if (isMissing) "ERROR_MISSING_EMAIL" else "ERROR_INVALID_EMAIL",
                    userMessage = if (isMissing) "Please enter an email address." else "Invalid email format.",
                    developerAdvice = "IllegalArgumentException caught before or inside Firebase client: ${throwable.message}"
                )
            }

            else -> {
                ErrorClassification(
                    specificCode = ErrorCodes.UNKNOWN_AUTH_ERROR,
                    rawCode = throwable.javaClass.simpleName,
                    userMessage = throwable.localizedMessage ?: "Failed to send password reset email.",
                    developerAdvice = "Unexpected exception type: ${throwable.javaClass.name}"
                )
            }
        }
    }

    private fun logDiagnosticStart(
        operation: String,
        targetEmail: String,
        projectId: String,
        appId: String
    ) {
        Log.d(
            TAG,
            """
            ┌────────────────────────────────────────────────────────────────────────
            │ [FirebaseAuth Diagnostic] STARTING: $operation
            │ Email: $targetEmail
            │ Project ID: $projectId
            │ App ID: $appId
            │ Debug Build: ${BuildConfig.DEBUG}
            └────────────────────────────────────────────────────────────────────────
            """.trimIndent()
        )
    }

    private fun logDiagnosticSuccess(
        operation: String,
        targetEmail: String,
        durationMs: Long,
        projectId: String,
        appId: String
    ) {
        Log.i(
            TAG,
            """
            ┌────────────────────────────────────────────────────────────────────────
            │ [FirebaseAuth Diagnostic] ✅ SUCCESS: $operation
            │ Status: Dispatched successfully to Firebase Authentication
            │ Target Email: $targetEmail
            │ Duration: ${durationMs}ms
            │ Project ID: $projectId
            │ App ID: $appId
            └────────────────────────────────────────────────────────────────────────
            """.trimIndent()
        )
    }

    private fun logDiagnosticFailure(
        operation: String,
        targetEmail: String,
        specificErrorCode: String,
        rawErrorCode: String?,
        exceptionClass: String,
        errorMessage: String,
        durationMs: Long,
        projectId: String,
        appId: String,
        developerAdvice: String
    ) {
        Log.e(
            TAG,
            """
            ┌────────────────────────────────────────────────────────────────────────
            │ [FirebaseAuth Diagnostic] ❌ FAILED: $operation
            │ Specific Error Code : $specificErrorCode
            │ Raw Error Code      : ${rawErrorCode ?: "N/A"}
            │ Target Email        : $targetEmail
            │ Exception Class     : $exceptionClass
            │ Error Message       : $errorMessage
            │ Duration            : ${durationMs}ms
            │ Project ID          : $projectId
            │ App ID              : $appId
            │ Diagnostic Advice   : $developerAdvice
            └────────────────────────────────────────────────────────────────────────
            """.trimIndent()
        )
    }

    private data class ErrorClassification(
        val specificCode: String,
        val rawCode: String?,
        val userMessage: String,
        val developerAdvice: String
    )
}

/**
 * Result wrapper for diagnostic Firebase operations.
 */
sealed class DiagnosticResult<out T> {
    data class Success<T>(
        val data: T,
        val durationMs: Long,
        val message: String
    ) : DiagnosticResult<T>()

    data class Error(
        val errorCode: String,
        val rawErrorCode: String?,
        val userMessage: String,
        val developerMessage: String,
        val durationMs: Long,
        val throwable: Throwable
    ) : DiagnosticResult<Nothing>()
}

/**
 * Extension function for invoking sendPasswordResetEmail with diagnostic logging.
 */
suspend fun FirebaseAuth.sendPasswordResetEmailWithDiagnostics(
    email: String
): DiagnosticResult<Unit> = FirebaseAuthDiagnosticWrapper.sendPasswordResetEmail(this, email)
