package com.example.legal.repository

import com.example.legal.model.LegalDocument
import com.example.legal.model.LegalDocumentSection
import com.example.legal.model.LegalDocumentType
import com.example.legal.model.OfficialSourceLink

/**
 * Single source of truth for Logic Loom legal documents, policy statements, and versioning.
 * Operated by Moraigne.
 * Note: Draft content contains [LEGAL REVIEW REQUIRED] markers for review by qualified legal counsel.
 */
object LegalDocumentRegistry {

    const val CURRENT_LEGAL_VERSION = "1.0"
    const val EFFECTIVE_DATE = "August 13, 2026"
    const val OPERATOR_NAME = "Moraigne"
    const val SUPPORT_EMAIL = "legal@moraigne.com"

    val termsAndConditions: LegalDocument = LegalDocument(
        type = LegalDocumentType.TERMS,
        title = "Terms & Conditions",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Logic Loom is designed and engineered by Moraigne. Defines user agreements, service boundaries, and responsibilities.",
        sections = listOf(
            LegalDocumentSection(
                id = "terms_intro",
                title = "1. Introduction",
                body = "Welcome to Logic Loom. Logic Loom is designed and engineered by Moraigne (\"Moraigne\", \"we\", \"us\", or \"our\"). By creating an account or accessing Logic Loom, you enter into a binding agreement subject to these Terms & Conditions.",
                bulletPoints = listOf(
                    "Logic Loom is designed and engineered by Moraigne.",
                    "Logic Loom is an independent technology platform and is NOT a university, government agency, bursary administration, bank, or official academic authority."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_eligibility",
                title = "2. Eligibility",
                body = "You must be at least 16 years of age (or the minimum legal age of digital consent in your jurisdiction) to register for and use Logic Loom. If you are under 18, you represent that you have obtained parent or legal guardian consent where required by local law.",
                bulletPoints = listOf(
                    "Must meet minimum age requirements for account registration.",
                    "Subject to final legal verification under South African POPIA & legal framework."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_accounts",
                title = "3. Account Security & Responsibilities",
                body = "You are solely responsible for maintaining the confidentiality of your login credentials, PIN security codes, and account access. You agree to notify Moraigne immediately upon discovering any unauthorized access to your account.",
                bulletPoints = listOf(
                    "Maintain accurate account and profile details.",
                    "Keep security PINs and biometric credentials protected on your device.",
                    "Moraigne reserves the right to suspend accounts that violate security or platform integrity."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_services",
                title = "4. Scope of Logic Loom Services",
                body = "Logic Loom provides a suite of local student productivity and organization tools. Features currently available within the application include:",
                bulletPoints = listOf(
                    "Academic Planner & Task Manager",
                    "Calendar Events & Weekly Class Timetable",
                    "Campus Shuttle Schedules & Life Hub Utilities",
                    "Study Notes & Active Recall Flashcard Decks",
                    "Document Vault (PDF & Attachment Storage)",
                    "Student Budget Manager (ZAR) & Financial Goals",
                    "Pomodoro Study Timer & GPA Calculator",
                    "Private Student Diary & To-Do Lists",
                    "Chuma AI - Gemini-Powered Assistant Developed and Engineered by Moraigne"
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_user_responsibilities",
                title = "5. User Conduct & Prohibited Activities",
                body = "Users agree to use Logic Loom only for lawful educational and personal productivity purposes. You strictly agree not to:",
                bulletPoints = listOf(
                    "Attempt unauthorized access to underlying app systems or other user data.",
                    "Upload malicious code, viruses, or harmful payloads.",
                    "Circumvent security PIN locks, biometrics, or authentication protocols.",
                    "Use the AI assistant to generate hate speech, harassment, or illegal content.",
                    "Falsify student identification, academic grades, or official documents."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_ai_limitations",
                title = "6. AI Assistant Limitations",
                body = "Logic Loom incorporates artificial intelligence assistance via Chuma AI powered by Google Gemini API. AI outputs are generated algorithmically and are intended solely as study support tools.",
                bulletPoints = listOf(
                    "AI outputs can contain errors, inaccuracies, or outdated information.",
                    "Chuma AI in Logic Loom is NOT an official academic advisor, university portal, or bursary representative.",
                    "Users must independently verify all exam dates, bursary deadlines, financial calculations, and official announcements."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_intellectual_property",
                title = "7. Intellectual Property & User Content Rights",
                body = "All software code, visual design, branding, trademarks, and logos associated with Logic Loom and Chuma AI are the exclusive property of Moraigne. Users retain ownership of their personal notes, uploaded vault documents, diary entries, and budget records created within the app.",
                bulletPoints = listOf(
                    "Moraigne owns all Logic Loom application software, Chuma AI, and branding rights.",
                    "Users retain ownership of their user-generated study content and documents.",
                    "Logic Loom processes user content solely to deliver localized app functionality."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_availability",
                title = "8. Availability, Maintenance & Outages",
                body = "Moraigne strives to maintain application reliability, but Logic Loom is provided on an \"as is\" and \"as available\" basis without guarantees of 100% uptime or uninterrupted service.",
                bulletPoints = listOf(
                    "Services may experience scheduled maintenance, updates, or temporary outages.",
                    "Moraigne is not liable for data losses caused by device damage, unbacked local storage, or network interruptions."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_termination",
                title = "9. Account Suspension & Termination",
                body = "Moraigne reserves the right to terminate or suspend access to Logic Loom for severe breaches of these Terms, unauthorized security testing, or fraudulent activity.",
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "terms_contact",
                title = "10. Configurable Legal Contact",
                body = "For legal inquiries, official communications, or regulatory notices concerning Logic Loom or Moraigne, please contact:",
                bulletPoints = listOf(
                    "Entity: Moraigne Legal & Compliance Team",
                    "Email: legal@moraigne.com"
                ),
                isLegalReviewRequired = true
            )
        )
    )

    val privacyPolicy: LegalDocument = LegalDocument(
        type = LegalDocumentType.PRIVACY,
        title = "Privacy Policy",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Explains what student data Logic Loom collects, how it is stored locally, why it is used, and how you control it.",
        sections = listOf(
            LegalDocumentSection(
                id = "priv_intro",
                title = "1. Privacy Overview & Data Principles",
                body = "Logic Loom is designed and engineered by Moraigne. We respect your privacy and have built Logic Loom with a privacy-by-design architecture, prioritizing local on-device data storage using encrypted Jetpack DataStore and Room SQLite databases.",
                bulletPoints = listOf(
                    "Logic Loom is designed and engineered by Moraigne.",
                    "Logic Loom collects only data necessary for student productivity features.",
                    "We do NOT sell, rent, or monetize your personal student data to third parties."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "priv_data_collected",
                title = "2. Specific Categories of Collected Data",
                body = "Logic Loom collects and processes the following specific categories of user information:",
                bulletPoints = listOf(
                    "Account Credentials: Full Name, Email Address, Student Number, Hashed Password.",
                    "Student Profile: Institution Name, Course/Degree, Year of Study, Profile Picture Avatar.",
                    "Academic & Schedule Data: Academic tasks, GPA module grades, weekly timetable slots, calendar events.",
                    "Study Content & Vault: Notes, active recall flashcards, private diary entries, uploaded PDF/vault documents.",
                    "Financial & Budget Records: Income items, expense records in ZAR, budget goal targets.",
                    "AI Interaction Data: Prompts submitted to the Chuma AI assistant and generated responses.",
                    "Application Preferences: Selected color theme, dark mode status, security PIN lock settings."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "priv_purposes_table",
                title = "3. Data Purpose, Storage & Retention Matrix",
                body = "Detailed technical purpose and retention breakdown for each collected data type:",
                bulletPoints = listOf(
                    "Information: Account & Profile -> Purpose: User authentication & profile customization -> Storage: Local Room DB & DataStore -> Retention: Retained until account deletion -> Deletion: App Settings Account Purge",
                    "Information: Notes, Vault Docs, Flashcards -> Purpose: Study material management & active recall -> Storage: Local SQLite Room DB -> Retention: Retained until user deletes item -> Deletion: Swipe/Button delete or full purge",
                    "Information: Budget Records (ZAR) -> Purpose: Personal financial tracking & expense goals -> Storage: Local SQLite Room DB -> Retention: Retained until cleared by user -> Deletion: Manual deletion or account reset",
                    "Information: AI Conversation History -> Purpose: Maintaining contextual study assistant chat -> Storage: Local SQLite Room DB -> Retention: Retained locally -> Deletion: Clear Chat History button in AI Assistant"
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "priv_ai_data",
                title = "4. AI Data Processing & Third-Party Sharing",
                body = "When you interact with the Chuma AI Assistant in Logic Loom, your text prompt is transmitted via secure HTTPS REST API calls to Google AI endpoints solely to generate responses.",
                bulletPoints = listOf(
                    "Prompts are transmitted securely to Google Gemini REST API services.",
                    "Passcodes, biometrics, security PINs, and raw vault credentials are NEVER sent to AI services.",
                    "AI conversations are stored locally on your device in Room DB and can be cleared at any time."
                ),
                officialLinks = listOf(
                    OfficialSourceLink("Google AI Privacy Disclosures", "https://ai.google.dev/terms")
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "priv_security",
                title = "5. Sensitive Data Safeguards & Protection",
                body = "Logic Loom implements strict safeguards to protect sensitive student records:",
                bulletPoints = listOf(
                    "Biometric & PIN Lock protection shielding GPA, grades, and financial budget records upon launch.",
                    "No passwords, authentication tokens, or private keys are written to system logs or user errors.",
                    "Database storage operates strictly within app sandboxed storage on Android."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "priv_user_rights",
                title = "6. User Data Ownership & Export Rights",
                body = "You retain full ownership of your notes, documents, and personal logs. You have the right to export your data as a structured JSON backup or permanently purge your account data from the app.",
                isLegalReviewRequired = true
            )
        )
    )

    val aiGuidelines: LegalDocument = LegalDocument(
        type = LegalDocumentType.AI_GUIDELINES,
        title = "Chuma AI Guidelines",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Outlines responsible AI usage, output verification requirements, and academic integrity guidelines.",
        sections = listOf(
            LegalDocumentSection(
                id = "ai_purpose",
                title = "1. Role of Chuma AI in Logic Loom",
                body = "Chuma AI in Logic Loom is designed as a study partner and learning assistant. It helps generate summaries, construct flashcard decks, format study schedules, and explain complex academic concepts.",
                bulletPoints = listOf(
                    "Chuma AI is an assistant — NOT an official academic authority.",
                    "AI recommendations do not replace official university regulations or lecturer instructions."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "ai_verification",
                title = "2. Independent Verification Requirement",
                body = "AI models may produce inaccurate, incomplete, or hallucinated responses. You MUST independently verify all important information with official sources before relying on it.",
                bulletPoints = listOf(
                    "Academic Requirements: Verify assignment deadlines and exam scope with your university portal.",
                    "Bursary & Funding Information: Check official NSFAS, university financial aid, or bursary provider portals.",
                    "Financial & Currency Data: Confirm banking transactions and official exchange rates with accredited banks.",
                    "Campus Transit: Cross-reference shuttle schedules with official university transportation boards."
                ),
                officialLinks = listOf(
                    OfficialSourceLink("NSFAS Official Portal", "https://www.nsfas.org.za"),
                    OfficialSourceLink("SA Higher Education Department", "https://www.dhet.gov.za")
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "ai_academic_integrity",
                title = "3. Academic Integrity & Ethics",
                body = "Users are responsible for complying with their educational institution's academic integrity policies regarding AI assistance.",
                bulletPoints = listOf(
                    "Do NOT present raw AI-generated text as your own original academic coursework.",
                    "Use AI for brainstorming, tutoring, and active recall generation rather than plagiarism."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "ai_disclaimer_notice",
                title = "4. Contextual AI Disclaimers",
                body = "Logic Loom displays contextual notices within the AI assistant: \"Chuma AI can make mistakes. Verify important information with the official university or bursary source.\"",
                isLegalReviewRequired = true
            )
        )
    )

    val acceptableUsePolicy: LegalDocument = LegalDocument(
        type = LegalDocumentType.ACCEPTABLE_USE,
        title = "Acceptable Use Policy",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Defines acceptable and prohibited uses of the Logic Loom platform and software tools.",
        sections = listOf(
            LegalDocumentSection(
                id = "aup_prohibited",
                title = "1. Prohibited Uses",
                body = "Users must not misuse the Logic Loom software, AI API endpoints, or user interfaces. Prohibited conduct includes:",
                bulletPoints = listOf(
                    "Attempting reverse engineering, security probing, or unauthorized database access.",
                    "Distributing malware, spyware, or malicious file attachments through the Vault.",
                    "Automating excessive API requests that interfere with service availability.",
                    "Using the app for fraudulent financial schemes or impersonating university staff.",
                    "Submitting prompts to generate illegal, violent, harassing, or defamatory content."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "aup_enforcement",
                title = "2. Enforcement & Reporting",
                body = "Moraigne reserves the right to restrict access or revoke accounts in cases of clear Acceptable Use violations.",
                isLegalReviewRequired = true
            )
        )
    )

    val userContentRules: LegalDocument = LegalDocument(
        type = LegalDocumentType.USER_CONTENT,
        title = "User Content & Data Rules",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Establishes user content rights, processing limits, and storage boundaries.",
        sections = listOf(
            LegalDocumentSection(
                id = "uc_ownership",
                title = "1. User Ownership Guarantee",
                body = "You retain complete legal ownership over all study notes, document vault uploads, diary entries, and personal budget logs created in Logic Loom.",
                bulletPoints = listOf(
                    "Moraigne claims NO copyright or ownership over your study materials.",
                    "Your content is processed exclusively to deliver local app features on your device."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "uc_responsibility",
                title = "2. User Content Responsibility",
                body = "You represent that you have the right to store any documents or files uploaded to your Document Vault.",
                isLegalReviewRequired = true
            )
        )
    )

    val accountDeletionPolicy: LegalDocument = LegalDocument(
        type = LegalDocumentType.ACCOUNT_DELETION,
        title = "Account & Data Deletion",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Clear procedures for exporting or permanently deleting your Logic Loom account and stored data.",
        sections = listOf(
            LegalDocumentSection(
                id = "del_overview",
                title = "1. Permanent Data Deletion Pathway",
                body = "You can initiate a complete account and data purge directly inside Logic Loom at Settings -> Privacy & Security -> Delete Account & Data.",
                bulletPoints = listOf(
                    "Executing Account Deletion permanently wipes:",
                    "- Student Profile & Account Credentials",
                    "- Academic Planner Tasks & GPA Module Grades",
                    "- Study Notes, Flashcards & Vault Documents",
                    "- Budget Records (ZAR) & Goals",
                    "- Timetable Slots & Calendar Events",
                    "- Chuma AI Conversation History & App Preferences",
                    "This action cannot be undone once confirmed."
                ),
                isLegalReviewRequired = true
            ),
            LegalDocumentSection(
                id = "del_export",
                title = "2. Data Export Prior to Deletion",
                body = "We recommend using the Export Data feature in Privacy Settings to download a local JSON archive of your study notes and records prior to account deletion.",
                isLegalReviewRequired = true
            )
        )
    )

    val legalContact: LegalDocument = LegalDocument(
        type = LegalDocumentType.LEGAL_CONTACT,
        title = "Legal & Compliance Contact",
        version = CURRENT_LEGAL_VERSION,
        effectiveDate = EFFECTIVE_DATE,
        lastUpdated = EFFECTIVE_DATE,
        summary = "Official contact details for Moraigne legal, privacy, and regulatory inquiries.",
        sections = listOf(
            LegalDocumentSection(
                id = "contact_details",
                title = "1. Contact Information",
                body = "For legal notices, privacy regulatory inquiries (POPIA/GDPR), or copyright concerns, contact Moraigne:",
                bulletPoints = listOf(
                    "Company: Moraigne",
                    "Product: Logic Loom",
                    "Attribution: Designed and engineered by Moraigne",
                    "Legal Contact Email: legal@moraigne.com",
                    "Support Email: support@moraigne.com",
                    "Contact: Moraigne Legal & Compliance"
                ),
                isLegalReviewRequired = true
            )
        )
    )

    /**
     * List of all 7 official legal documents in the center.
     */
    val allDocuments: List<LegalDocument> = listOf(
        termsAndConditions,
        privacyPolicy,
        aiGuidelines,
        acceptableUsePolicy,
        userContentRules,
        accountDeletionPolicy,
        legalContact
    )

    fun getDocument(type: LegalDocumentType): LegalDocument {
        return when (type) {
            LegalDocumentType.TERMS -> termsAndConditions
            LegalDocumentType.PRIVACY -> privacyPolicy
            LegalDocumentType.AI_GUIDELINES -> aiGuidelines
            LegalDocumentType.ACCEPTABLE_USE -> acceptableUsePolicy
            LegalDocumentType.USER_CONTENT -> userContentRules
            LegalDocumentType.ACCOUNT_DELETION -> accountDeletionPolicy
            LegalDocumentType.LEGAL_CONTACT -> legalContact
        }
    }
}
