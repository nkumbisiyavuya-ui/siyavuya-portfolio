package com.example.legal.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.legal.model.LegalAcceptance
import com.example.legal.model.LegalConsentState
import com.example.legal.model.LegalDocumentType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val Context.legalDataStore: DataStore<Preferences> by preferencesDataStore(name = "logicloom_legal_acceptance")

/**
 * Manages versioned legal consent records and persistence using DataStore.
 * Ensures user acceptance records include timestamps, document versions, and re-consent checks.
 */
class LegalAcceptanceRepository(private val context: Context) {

    private val dataStore = context.legalDataStore

    companion object {
        // Preference keys
        val TERMS_ACCEPTED_KEY = booleanPreferencesKey("legal_terms_accepted")
        val TERMS_VERSION_KEY = stringPreferencesKey("legal_terms_version")
        val TERMS_ACCEPTED_AT_KEY = stringPreferencesKey("legal_terms_accepted_at")

        val PRIVACY_ACKNOWLEDGED_KEY = booleanPreferencesKey("legal_privacy_acknowledged")
        val PRIVACY_VERSION_KEY = stringPreferencesKey("legal_privacy_version")
        val PRIVACY_ACCEPTED_AT_KEY = stringPreferencesKey("legal_privacy_accepted_at")

        val AI_GUIDELINES_UNDERSTOOD_KEY = booleanPreferencesKey("legal_ai_guidelines_understood")
        val AI_GUIDELINES_VERSION_KEY = stringPreferencesKey("legal_ai_guidelines_version")
        val AI_GUIDELINES_ACCEPTED_AT_KEY = stringPreferencesKey("legal_ai_guidelines_accepted_at")

        val USER_ID_KEY = stringPreferencesKey("legal_accepted_user_id")

        private val isoFormatter = DateTimeFormatter.ISO_INSTANT

        private fun sanitizeUserKey(userId: String): String =
            userId.replace(Regex("[^a-zA-Z0-9_]"), "_").ifBlank { "anonymous" }

        fun userTermsKey(userId: String) = booleanPreferencesKey("legal_${sanitizeUserKey(userId)}_terms_accepted")
        fun userTermsVersionKey(userId: String) = stringPreferencesKey("legal_${sanitizeUserKey(userId)}_terms_version")
        fun userTermsAtKey(userId: String) = stringPreferencesKey("legal_${sanitizeUserKey(userId)}_terms_accepted_at")

        fun userPrivacyKey(userId: String) = booleanPreferencesKey("legal_${sanitizeUserKey(userId)}_privacy_acknowledged")
        fun userPrivacyVersionKey(userId: String) = stringPreferencesKey("legal_${sanitizeUserKey(userId)}_privacy_version")
        fun userPrivacyAtKey(userId: String) = stringPreferencesKey("legal_${sanitizeUserKey(userId)}_privacy_accepted_at")

        fun userAiKey(userId: String) = booleanPreferencesKey("legal_${sanitizeUserKey(userId)}_ai_understood")
        fun userAiVersionKey(userId: String) = stringPreferencesKey("legal_${sanitizeUserKey(userId)}_ai_version")
        fun userAiAtKey(userId: String) = stringPreferencesKey("legal_${sanitizeUserKey(userId)}_ai_accepted_at")
    }

    /**
     * Flow emitting the current legal consent state for the application or a specific user.
     */
    fun consentStateFlowForUser(userId: String?): Flow<LegalConsentState> = dataStore.data.map { prefs ->
        val effectiveUid = userId?.ifBlank { null }
        val currentVer = LegalDocumentRegistry.CURRENT_LEGAL_VERSION

        val (termsAccepted, termsVer, termsAt) = if (effectiveUid != null) {
            val acc = prefs[userTermsKey(effectiveUid)] ?: prefs[TERMS_ACCEPTED_KEY] ?: false
            val ver = prefs[userTermsVersionKey(effectiveUid)] ?: prefs[TERMS_VERSION_KEY] ?: ""
            val at = prefs[userTermsAtKey(effectiveUid)] ?: prefs[TERMS_ACCEPTED_AT_KEY] ?: ""
            Triple(acc, ver, at)
        } else {
            Triple(prefs[TERMS_ACCEPTED_KEY] ?: false, prefs[TERMS_VERSION_KEY] ?: "", prefs[TERMS_ACCEPTED_AT_KEY] ?: "")
        }

        val (privacyAck, privacyVer, privacyAt) = if (effectiveUid != null) {
            val acc = prefs[userPrivacyKey(effectiveUid)] ?: prefs[PRIVACY_ACKNOWLEDGED_KEY] ?: false
            val ver = prefs[userPrivacyVersionKey(effectiveUid)] ?: prefs[PRIVACY_VERSION_KEY] ?: ""
            val at = prefs[userPrivacyAtKey(effectiveUid)] ?: prefs[PRIVACY_ACCEPTED_AT_KEY] ?: ""
            Triple(acc, ver, at)
        } else {
            Triple(prefs[PRIVACY_ACKNOWLEDGED_KEY] ?: false, prefs[PRIVACY_VERSION_KEY] ?: "", prefs[PRIVACY_ACCEPTED_AT_KEY] ?: "")
        }

        val (aiUnderstood, aiVer, aiAt) = if (effectiveUid != null) {
            val acc = prefs[userAiKey(effectiveUid)] ?: prefs[AI_GUIDELINES_UNDERSTOOD_KEY] ?: false
            val ver = prefs[userAiVersionKey(effectiveUid)] ?: prefs[AI_GUIDELINES_VERSION_KEY] ?: ""
            val at = prefs[userAiAtKey(effectiveUid)] ?: prefs[AI_GUIDELINES_ACCEPTED_AT_KEY] ?: ""
            Triple(acc, ver, at)
        } else {
            Triple(prefs[AI_GUIDELINES_UNDERSTOOD_KEY] ?: false, prefs[AI_GUIDELINES_VERSION_KEY] ?: "", prefs[AI_GUIDELINES_ACCEPTED_AT_KEY] ?: "")
        }

        // Detect if user accepted an older version than current registry version
        val needsReconsent = (termsAccepted && termsVer != currentVer) ||
                (privacyAck && privacyVer != currentVer) ||
                (aiUnderstood && aiVer != currentVer)

        LegalConsentState(
            hasAcceptedTerms = termsAccepted && termsVer == currentVer,
            termsAcceptedVersion = termsVer,
            termsAcceptedAt = termsAt,
            hasAcknowledgedPrivacy = privacyAck && privacyVer == currentVer,
            privacyAcceptedVersion = privacyVer,
            privacyAcceptedAt = privacyAt,
            hasUnderstoodAiGuidelines = aiUnderstood && aiVer == currentVer,
            aiGuidelinesAcceptedVersion = aiVer,
            aiGuidelinesAcceptedAt = aiAt,
            needsReconsent = needsReconsent
        )
    }

    /**
     * Flow emitting the current legal consent state for the application.
     */
    val consentStateFlow: Flow<LegalConsentState> = consentStateFlowForUser(null)

    /**
     * Saves user acceptance for required legal documents (Terms, Privacy, AI Guidelines).
     */
    suspend fun recordConsent(
        userId: String = "user_default",
        acceptTerms: Boolean,
        acknowledgePrivacy: Boolean,
        understandAiGuidelines: Boolean
    ) {
        val currentTimestamp = isoFormatter.format(Instant.now())
        val currentVersion = LegalDocumentRegistry.CURRENT_LEGAL_VERSION

        dataStore.edit { prefs ->
            prefs[USER_ID_KEY] = userId

            if (acceptTerms) {
                prefs[TERMS_ACCEPTED_KEY] = true
                prefs[TERMS_VERSION_KEY] = currentVersion
                prefs[TERMS_ACCEPTED_AT_KEY] = currentTimestamp
                if (userId.isNotBlank()) {
                    prefs[userTermsKey(userId)] = true
                    prefs[userTermsVersionKey(userId)] = currentVersion
                    prefs[userTermsAtKey(userId)] = currentTimestamp
                }
            }

            if (acknowledgePrivacy) {
                prefs[PRIVACY_ACKNOWLEDGED_KEY] = true
                prefs[PRIVACY_VERSION_KEY] = currentVersion
                prefs[PRIVACY_ACCEPTED_AT_KEY] = currentTimestamp
                if (userId.isNotBlank()) {
                    prefs[userPrivacyKey(userId)] = true
                    prefs[userPrivacyVersionKey(userId)] = currentVersion
                    prefs[userPrivacyAtKey(userId)] = currentTimestamp
                }
            }

            if (understandAiGuidelines) {
                prefs[AI_GUIDELINES_UNDERSTOOD_KEY] = true
                prefs[AI_GUIDELINES_VERSION_KEY] = currentVersion
                prefs[AI_GUIDELINES_ACCEPTED_AT_KEY] = currentTimestamp
                if (userId.isNotBlank()) {
                    prefs[userAiKey(userId)] = true
                    prefs[userAiVersionKey(userId)] = currentVersion
                    prefs[userAiAtKey(userId)] = currentTimestamp
                }
            }
        }
    }

    /**
     * Retrieves acceptance details for a specific document type.
     */
    suspend fun getAcceptanceRecord(
        type: LegalDocumentType
    ): LegalAcceptance? {
        val currentVersion = LegalDocumentRegistry.CURRENT_LEGAL_VERSION
        var record: LegalAcceptance? = null

        dataStore.edit { prefs ->
            val userId = prefs[USER_ID_KEY] ?: "user_default"
            when (type) {
                LegalDocumentType.TERMS -> {
                    val accepted = prefs[TERMS_ACCEPTED_KEY] ?: false
                    val version = prefs[TERMS_VERSION_KEY] ?: currentVersion
                    val timestamp = prefs[TERMS_ACCEPTED_AT_KEY] ?: ""
                    record = LegalAcceptance(userId, type, version, accepted, timestamp)
                }
                LegalDocumentType.PRIVACY -> {
                    val accepted = prefs[PRIVACY_ACKNOWLEDGED_KEY] ?: false
                    val version = prefs[PRIVACY_VERSION_KEY] ?: currentVersion
                    val timestamp = prefs[PRIVACY_ACCEPTED_AT_KEY] ?: ""
                    record = LegalAcceptance(userId, type, version, accepted, timestamp)
                }
                LegalDocumentType.AI_GUIDELINES -> {
                    val accepted = prefs[AI_GUIDELINES_UNDERSTOOD_KEY] ?: false
                    val version = prefs[AI_GUIDELINES_VERSION_KEY] ?: currentVersion
                    val timestamp = prefs[AI_GUIDELINES_ACCEPTED_AT_KEY] ?: ""
                    record = LegalAcceptance(userId, type, version, accepted, timestamp)
                }
                else -> {
                    record = LegalAcceptance(userId, type, currentVersion, true, isoFormatter.format(Instant.now()))
                }
            }
        }
        return record
    }

    /**
     * Resets all legal acceptance records (e.g. during full account deletion).
     */
    suspend fun clearAllConsentRecords() {
        dataStore.edit { prefs ->
            prefs.clear()
        }
    }
}
