package com.example.legal.model

import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Types of legal documents managed by the Logic Loom Legal & Safety Center.
 */
enum class LegalDocumentType(
    val id: String,
    val title: String,
    val subtitle: String,
    val defaultVersion: String,
    val isConsentRequired: Boolean = true
) {
    TERMS(
        id = "terms",
        title = "Terms & Conditions",
        subtitle = "Operated by Moraigne",
        defaultVersion = "1.0",
        isConsentRequired = true
    ),
    PRIVACY(
        id = "privacy",
        title = "Privacy Policy",
        subtitle = "Data collection, storage & privacy disclosures",
        defaultVersion = "1.0",
        isConsentRequired = true
    ),
    AI_GUIDELINES(
        id = "ai_guidelines",
        title = "Chuma AI Guidelines",
        subtitle = "AI accuracy, limitations & safety boundaries",
        defaultVersion = "1.0",
        isConsentRequired = true
    ),
    ACCEPTABLE_USE(
        id = "acceptable_use",
        title = "Acceptable Use Policy",
        subtitle = "Platform rules & security compliance",
        defaultVersion = "1.0",
        isConsentRequired = false
    ),
    USER_CONTENT(
        id = "user_content",
        title = "User Content & Data Rules",
        subtitle = "Content ownership & processing limits",
        defaultVersion = "1.0",
        isConsentRequired = false
    ),
    ACCOUNT_DELETION(
        id = "account_deletion",
        title = "Account & Data Deletion",
        subtitle = "Data retention & account purge procedures",
        defaultVersion = "1.0",
        isConsentRequired = false
    ),
    LEGAL_CONTACT(
        id = "legal_contact",
        title = "Legal & Compliance Contact",
        subtitle = "Official Moraigne legal contact details",
        defaultVersion = "1.0",
        isConsentRequired = false
    );

    companion object {
        fun fromId(id: String?): LegalDocumentType {
            return entries.find { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) } ?: TERMS
        }
    }
}

/**
 * Section within a legal document with optional bullet points and review tags.
 */
data class LegalDocumentSection(
    val id: String,
    val title: String,
    val body: String,
    val bulletPoints: List<String> = emptyList(),
    val officialLinks: List<OfficialSourceLink> = emptyList(),
    val isLegalReviewRequired: Boolean = true
)

/**
 * Official link reference (e.g. University portal or government bursary source).
 */
data class OfficialSourceLink(
    val label: String,
    val url: String
)

/**
 * Central configuration model for versioned legal documents.
 */
data class LegalDocument(
    val type: LegalDocumentType,
    val title: String,
    val version: String,
    val effectiveDate: String,
    val lastUpdated: String,
    val isCurrent: Boolean = true,
    val summary: String,
    val sections: List<LegalDocumentSection>,
    val contactAddress: String = "Moraigne Legal & Compliance",
    val contactEmail: String = "legal@moraigne.com"
)

/**
 * Structured legal acceptance record for tracking consent history.
 */
data class LegalAcceptance(
    val userId: String,
    val documentType: LegalDocumentType,
    val documentVersion: String,
    val accepted: Boolean,
    val acceptedAt: String, // ISO timestamp e.g. 2026-08-13T04:17:41Z
    val appVersion: String = "1.0.0"
)

/**
 * Summary of user's overall legal consent state.
 */
data class LegalConsentState(
    val hasAcceptedTerms: Boolean = false,
    val termsAcceptedVersion: String = "",
    val termsAcceptedAt: String = "",
    val hasAcknowledgedPrivacy: Boolean = false,
    val privacyAcceptedVersion: String = "",
    val privacyAcceptedAt: String = "",
    val hasUnderstoodAiGuidelines: Boolean = false,
    val aiGuidelinesAcceptedVersion: String = "",
    val aiGuidelinesAcceptedAt: String = "",
    val needsReconsent: Boolean = false
) {
    val isFullyConsented: Boolean
        get() = hasAcceptedTerms && hasAcknowledgedPrivacy && hasUnderstoodAiGuidelines && !needsReconsent
}
