package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.compose.ui.platform.LocalContext
import com.example.security.BiometricAuthHelper
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import com.example.ui.CanvasMateViewModel
import com.example.ui.components.AppNavigationDrawer
import com.example.ui.components.BottomNavigationBar
import com.example.ui.navigation.NavRoutes
import com.example.ui.screens.*
import com.example.ui.theme.CanvasMateTheme
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private val viewModel: CanvasMateViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val forceDarkTheme by viewModel.darkThemeMode.collectAsState()
            val selectedPalette by viewModel.selectedColorPalette.collectAsState()
            val selectedFont by viewModel.selectedFontStyle.collectAsState()
            val isAppLocked by viewModel.isAppLocked.collectAsState()
            var isUnlockedByPin by remember { mutableStateOf(false) }

            CanvasMateTheme(
                forceDarkTheme = forceDarkTheme ?: true,
                selectedPalette = selectedPalette,
                selectedFont = selectedFont
            ) {
                if (isAppLocked && !isUnlockedByPin) {
                    PinLockScreen(
                        onUnlockSuccess = { isUnlockedByPin = true }
                    )
                } else {
                    CanvasMateMainApp(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasMateMainApp(viewModel: CanvasMateViewModel) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavRoutes.DASHBOARD

    // Flow states
    val userProfile by viewModel.userProfile.collectAsState()
    val academicTasks by viewModel.academicTasks.collectAsState()
    val calendarEvents by viewModel.calendarEvents.collectAsState()
    val timetableSlots by viewModel.timetableSlots.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val vaultDocuments by viewModel.vaultDocuments.collectAsState()
    val budgetItems by viewModel.budgetItems.collectAsState()
    val budgetGoals by viewModel.budgetGoals.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val diaryEntries by viewModel.diaryEntries.collectAsState()
    val todoTasks by viewModel.todoTasks.collectAsState()
    val gpaModules by viewModel.gpaModules.collectAsState()
    val legalConsentState by viewModel.legalConsentState.collectAsState()

    // Hide TopBar & BottomBar on Splash, Auth & Onboarding screens
    val hideNavigation = currentRoute in listOf(
        NavRoutes.SPLASH,
        NavRoutes.ONBOARDING,
        NavRoutes.LOGIN,
        NavRoutes.REGISTER,
        NavRoutes.FORGOT_PASSWORD,
        NavRoutes.EMAIL_VERIFICATION,
        NavRoutes.VOICE_MODE
    )

    LaunchedEffect(navController) {
        com.example.data.tools.ScreenNavigationTool.onNavigateRequested = { targetRoute ->
            coroutineScope.launch {
                try {
                    navController.navigate(targetRoute) {
                        launchSingleTop = true
                    }
                } catch (e: Exception) {
                    android.util.Log.e("MainActivity", "Failed to navigate to $targetRoute", e)
                }
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = !hideNavigation,
        drawerContent = {
            AppNavigationDrawer(
                currentRoute = currentRoute,
                userProfile = userProfile,
                onNavigate = { route ->
                    coroutineScope.launch { drawerState.close() }
                    navController.navigate(route) {
                        popUpTo(NavRoutes.DASHBOARD)
                        launchSingleTop = true
                    }
                }
            )
        }
    ) {
        Scaffold(
            containerColor = Color(0xFF060913),
            topBar = {
                if (!hideNavigation) {
                    val searchQuery by viewModel.searchQuery.collectAsState()
                    val connectivityStatus by viewModel.connectivityStatus.collectAsState()
                    val isSearchRoute = currentRoute == NavRoutes.SEARCH
                    val isDashboard = currentRoute == NavRoutes.DASHBOARD

                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = if (isDashboard) Color(0xFF060913) else MaterialTheme.colorScheme.surface,
                            titleContentColor = Color.White,
                            navigationIconContentColor = Color.White,
                            actionIconContentColor = Color.White
                        ),
                        title = {
                            if (isDashboard) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    com.example.ui.components.CanvasMate3DIcon(
                                        size = 28.dp,
                                        showGlow = true
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "LOGIC LOOM",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 17.sp,
                                        letterSpacing = 1.2.sp,
                                        color = Color.White
                                    )
                                }
                            } else if (isSearchRoute) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { viewModel.updateSearchQuery(it) },
                                    placeholder = { Text("Search Room DB...", fontSize = 14.sp) },
                                    singleLine = true,
                                    trailingIcon = if (searchQuery.isNotEmpty()) {
                                        {
                                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Clear search", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    } else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                                    )
                                )
                            } else {
                                Text(
                                    text = when (currentRoute) {
                                        NavRoutes.DASHBOARD -> "Logic Loom"
                                        NavRoutes.TOOLS -> "Tools Ecosystem"
                                        NavRoutes.ACADEMIC_PLANNER -> "Academic Planner"
                                        NavRoutes.CALENDAR -> "Calendar 2026"
                                        NavRoutes.TIMETABLE -> "Weekly Timetable"
                                        NavRoutes.SHUTTLE_SCHEDULE -> "Shuttle Schedules"
                                        NavRoutes.NOTES -> "Notes & Summaries"
                                        NavRoutes.FLASHCARDS -> "Active Recall Flashcards"
                                        NavRoutes.VAULT -> "Document Vault"
                                        NavRoutes.BUDGET -> "Budget Manager (ZAR)"
                                        NavRoutes.GOALS -> "Goal Tracker"
                                        NavRoutes.STUDY_TIMER -> "Pomodoro Timer"
                                        NavRoutes.GPA_CALCULATOR -> "GPA Calculator"
                                        NavRoutes.TODO_LIST -> "To-Do List"
                                        NavRoutes.DIARY -> "Private Diary"
                                        NavRoutes.AI_ASSISTANT -> "Chuma AI Assistant"
                                        NavRoutes.ANALYTICS -> "Productivity Analytics"
                                        NavRoutes.PROFILE -> "Student Profile"
                                        NavRoutes.SETTINGS -> "Settings"
                                        NavRoutes.LEGAL_CENTER -> "Legal & Safety Center"
                                        NavRoutes.LEGAL_DOCUMENT_VIEWER -> "Legal Document"
                                        NavRoutes.ABOUT -> "About Logic Loom"
                                        else -> "Logic Loom"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        },
                        navigationIcon = {
                            if (isSearchRoute) {
                                IconButton(onClick = { navController.popBackStack() }) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                                }
                            } else {
                                IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                                    Icon(Icons.Default.Menu, contentDescription = "Open Drawer")
                                }
                            }
                        },
                        actions = {
                            if (isDashboard) {
                                IconButton(onClick = { navController.navigate(NavRoutes.PROFILE) }) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(0x223B82F6))
                                            .border(1.dp, Color(0x663B82F6), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Person,
                                            contentDescription = "User Profile",
                                            tint = Color(0xFF93C5FD),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            } else {
                                // Logic Loom Connectivity Indicator with deep navy container & electric blue accents
                                com.example.ui.components.ConnectivityHeaderIndicator(
                                    status = connectivityStatus,
                                    onRefreshStatus = { viewModel.refreshConnectivityStatus() }
                                )

                                if (!isSearchRoute) {
                                    IconButton(onClick = { navController.navigate(NavRoutes.SEARCH) }) {
                                        Icon(Icons.Default.Search, contentDescription = "Search")
                                    }
                                }
                                IconButton(onClick = { navController.navigate(NavRoutes.AI_ASSISTANT) }) {
                                    com.example.ui.components.ChumaCLogo(
                                        size = 28.dp,
                                        showGlow = false,
                                        showBackgroundContainer = true
                                    )
                                }
                            }
                        }
                    )
                }
            },
            bottomBar = {
                if (!hideNavigation) {
                    BottomNavigationBar(
                        currentRoute = currentRoute,
                        onNavigate = { route ->
                            val targetRoute = if (route == NavRoutes.MEMORY) NavRoutes.NOTES else route
                            navController.navigate(targetRoute) {
                                popUpTo(NavRoutes.DASHBOARD)
                                launchSingleTop = true
                            }
                        }
                    )
                }
            }

        ) { innerPadding ->
            val recentNotificationBanner by viewModel.recentNotificationBanner.collectAsState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // First-Launch or Updated Terms Mandatory Legal Consent Dialog
                if (!hideNavigation && !legalConsentState.isFullyConsented) {
                    com.example.ui.legal.LegalConsentOverlayDialog(
                        consentState = legalConsentState,
                        onAcceptAllConsents = { terms, privacy, ai ->
                            viewModel.recordLegalConsent(terms, privacy, ai)
                        },
                        onOpenDocument = { docType ->
                            navController.navigate("${NavRoutes.LEGAL_DOCUMENT_VIEWER}/${docType.name}")
                        }
                    )
                }

                if (recentNotificationBanner != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = recentNotificationBanner!!,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { viewModel.dismissNotificationBanner() }) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = NavRoutes.SPLASH,
                    modifier = Modifier.weight(1f)
                ) {
                composable(NavRoutes.SPLASH) {
                    SplashScreen(
                        authStateFlow = viewModel.authState,
                        onSplashFinished = {
                            val startRoute = if (viewModel.authState.value == com.example.security.AuthState.AUTHENTICATED || viewModel.isUserLoggedIn.value) {
                                NavRoutes.DASHBOARD
                            } else {
                                NavRoutes.LOGIN
                            }
                            navController.navigate(startRoute) {
                                popUpTo(NavRoutes.SPLASH) { inclusive = true }
                            }
                        }
                    )
                }
                composable(NavRoutes.ONBOARDING) {
                    OnboardingScreen(onFinishOnboarding = { navController.navigate(NavRoutes.LOGIN) })
                }
                composable(NavRoutes.LOGIN) {
                    LoginScreen(
                        viewModel = viewModel,
                        onLoginSuccess = {
                            navController.navigate(NavRoutes.DASHBOARD) {
                                popUpTo(NavRoutes.LOGIN) { inclusive = true }
                            }
                        },
                        onNavigateRegister = { navController.navigate(NavRoutes.REGISTER) },
                        onNavigateForgotPassword = { navController.navigate(NavRoutes.FORGOT_PASSWORD) }
                    )
                }
                composable(NavRoutes.REGISTER) {
                    RegisterScreen(
                        viewModel = viewModel,
                        onRegisterSuccess = {
                            navController.navigate(NavRoutes.DASHBOARD) {
                                popUpTo(NavRoutes.REGISTER) { inclusive = true }
                            }
                        },
                        onNavigateLogin = { navController.navigate(NavRoutes.LOGIN) }
                    )
                }
                composable(NavRoutes.FORGOT_PASSWORD) {
                    ForgotPasswordScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.navigate(NavRoutes.LOGIN) }
                    )
                }
                composable(NavRoutes.EMAIL_VERIFICATION) {
                    EmailVerificationScreen(
                        viewModel = viewModel,
                        onVerifiedSuccess = {
                            navController.navigate(NavRoutes.DASHBOARD) {
                                popUpTo(NavRoutes.LOGIN) { inclusive = true }
                            }
                        },
                        onNavigateBack = { navController.navigate(NavRoutes.LOGIN) }
                    )
                }
                composable(NavRoutes.DASHBOARD) {
                    DashboardScreen(
                        viewModel = viewModel,
                        userProfile = userProfile,
                        academicTasks = academicTasks,
                        calendarEvents = calendarEvents,
                        budgetItems = budgetItems,
                        notes = notes,
                        timetableSlots = timetableSlots,
                        onNavigate = { route -> 
                            val targetRoute = when(route) {
                                "COPILOT", "ASSISTANT", "AI_ASSISTANT" -> NavRoutes.AI_ASSISTANT
                                "ACADEMIC", "ACADEMIC_PLANNER" -> NavRoutes.ACADEMIC_PLANNER
                                "BUDGET" -> NavRoutes.BUDGET
                                "TIMETABLE" -> NavRoutes.TIMETABLE
                                "CALENDAR" -> NavRoutes.CALENDAR
                                "NOTES" -> NavRoutes.NOTES
                                "VAULT" -> NavRoutes.VAULT
                                "FLASHCARDS" -> NavRoutes.FLASHCARDS
                                "TIMER", "STUDY_TIMER" -> NavRoutes.STUDY_TIMER
                                "NOTIFICATIONS", "SETTINGS" -> NavRoutes.SETTINGS
                                "LIFE_HUB" -> NavRoutes.LIFE_HUB
                                "LIFE_TRANSPORT" -> NavRoutes.LIFE_TRANSPORT
                                "LIFE_SHOPPING" -> NavRoutes.LIFE_SHOPPING
                                "LIFE_WALLET" -> NavRoutes.LIFE_WALLET
                                "TOOLS", NavRoutes.TOOLS -> NavRoutes.TOOLS
                                "MEMORY", NavRoutes.MEMORY -> NavRoutes.NOTES
                                "VEO_STUDIO" -> NavRoutes.VEO_STUDIO
                                "VOICE", "VOICE_MODE", NavRoutes.VOICE_MODE -> NavRoutes.VOICE_MODE
                                else -> route
                            }
                            try {
                                navController.navigate(targetRoute)
                            } catch (e: Exception) {
                                navController.navigate(NavRoutes.DASHBOARD)
                            }
                        }
                    )
                }
                composable(NavRoutes.TOOLS) {
                    ToolsEcosystemScreen(
                        onNavigate = { route ->
                            try {
                                navController.navigate(route)
                            } catch (e: Exception) {
                                navController.navigate(NavRoutes.DASHBOARD)
                            }
                        }
                    )
                }
                composable(NavRoutes.ACADEMIC_PLANNER) {
                    AcademicPlannerScreen(
                        tasks = academicTasks,
                        onAddTask = { viewModel.addAcademicTask(it) },
                        onUpdateTask = { viewModel.updateAcademicTask(it) },
                        onDeleteTask = { viewModel.deleteAcademicTask(it) }
                    )
                }
                composable(NavRoutes.CALENDAR) {
                    val currentSession by viewModel.currentSession.collectAsState()
                    CalendarScreen(
                        events = calendarEvents,
                        userEmail = currentSession?.email ?: userProfile?.email,
                        onAddEvent = { viewModel.addCalendarEvent(it) },
                        onDeleteEvent = { viewModel.deleteCalendarEvent(it) }
                    )
                }
                composable(NavRoutes.TIMETABLE) {
                    TimetableScreen(
                        slots = timetableSlots,
                        onAddSlot = { viewModel.addTimetableSlot(it) },
                        onDeleteSlot = { viewModel.deleteTimetableSlot(it) }
                    )
                }
                composable(NavRoutes.SHUTTLE_SCHEDULE) {
                    ShuttleScheduleScreen(viewModel = viewModel)
                }
                composable(NavRoutes.NOTES) {
                    NotesScreen(
                        notes = notes,
                        onAddNote = { viewModel.addNote(it) },
                        onUpdateNote = { viewModel.updateNote(it) },
                        onDeleteNote = { viewModel.deleteNote(it) },
                        onCreateFlashcardDeck = { note ->
                            viewModel.createDeckFromNote(note)
                            navController.navigate(NavRoutes.FLASHCARDS)
                        },
                        onGenerateStudyQuestions = { note ->
                            viewModel.openStudyQuestionsGenerator(note)
                            navController.navigate(NavRoutes.AI_ASSISTANT)
                        }
                    )
                }
                composable(NavRoutes.FLASHCARDS) {
                    FlashcardScreen(
                        viewModel = viewModel,
                        onNavigateToNotes = { navController.navigate(NavRoutes.NOTES) }
                    )
                }
                composable(NavRoutes.VAULT) {
                    VaultScreen(
                        documents = vaultDocuments,
                        onAddDocument = { viewModel.addVaultDocument(it) },
                        onDeleteDocument = { viewModel.deleteVaultDocument(it) }
                    )
                }
                composable(NavRoutes.BUDGET) {
                    val exchangeRates by viewModel.exchangeRates.collectAsState()
                    val isRatesLive by viewModel.isRatesLive.collectAsState()
                    val isRatesFromRoomCache by viewModel.isRatesFromRoomCache.collectAsState()
                    val isLoadingRates by viewModel.isLoadingRates.collectAsState()

                    BudgetManagerScreen(
                        items = budgetItems,
                        goals = budgetGoals,
                        onAddItem = { viewModel.addBudgetItem(it) },
                        onDeleteItem = { viewModel.deleteBudgetItem(it) },
                        onAddGoal = { viewModel.addBudgetGoal(it) },
                        exchangeRates = exchangeRates,
                        isRatesLive = isRatesLive,
                        isRatesFromRoomCache = isRatesFromRoomCache,
                        isLoadingRates = isLoadingRates,
                        onRefreshRates = { viewModel.fetchLiveExchangeRates() }
                    )
                }
                composable(NavRoutes.GOALS) {
                    GoalTrackerScreen(
                        goals = goals,
                        onAddGoal = { viewModel.addGoal(it) },
                        onUpdateGoal = { viewModel.updateGoal(it) },
                        onDeleteGoal = { viewModel.deleteGoal(it) }
                    )
                }
                composable(NavRoutes.STUDY_TIMER) {
                    StudyTimerScreen(viewModel = viewModel)
                }
                composable(NavRoutes.GPA_CALCULATOR) {
                    GpaCalculatorScreen(
                        viewModel = viewModel,
                        modules = gpaModules,
                        onAddModule = { viewModel.addGpaModule(it) },
                        onDeleteModule = { viewModel.deleteGpaModule(it) }
                    )
                }
                composable(NavRoutes.TODO_LIST) {
                    TodoListScreen(
                        tasks = todoTasks,
                        onAddTask = { viewModel.addTodoTask(it) },
                        onUpdateTask = { viewModel.updateTodoTask(it) },
                        onDeleteTask = { viewModel.deleteTodoTask(it) }
                    )
                }
                composable(NavRoutes.DIARY) {
                    DiaryScreen(
                        entries = diaryEntries,
                        onAddEntry = { viewModel.addDiaryEntry(it) },
                        onDeleteEntry = { viewModel.deleteDiaryEntry(it) }
                    )
                }
                composable(NavRoutes.AI_ASSISTANT) {
                    AiAssistantScreen(
                        viewModel = viewModel,
                        onNavigateToVoiceMode = { navController.navigate(NavRoutes.VOICE_MODE) }
                    )
                }
                composable(NavRoutes.ANALYTICS) {
                    AnalyticsScreen(viewModel = viewModel)
                }
                composable(NavRoutes.SEARCH) {
                    GlobalSearchScreen(viewModel = viewModel)
                }
                composable(NavRoutes.PROFILE) {
                    ProfileScreen(
                        userProfile = userProfile,
                        viewModel = viewModel,
                        onSaveProfile = { viewModel.updateUserProfile(it) },
                        onNavigateLogin = {
                            navController.navigate(NavRoutes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                }
                composable(NavRoutes.SETTINGS) {
                    SettingsScreen(
                        viewModel = viewModel,
                        onNavigateAbout = { navController.navigate(NavRoutes.ABOUT) },
                        onNavigateLegalCenter = { navController.navigate(NavRoutes.LEGAL_CENTER) }
                    )
                }
                composable(NavRoutes.LEGAL_CENTER) {
                    com.example.ui.legal.LegalCenterScreen(
                        consentState = legalConsentState,
                        onNavigateBack = { navController.popBackStack() },
                        onOpenDocument = { docType ->
                            navController.navigate("${NavRoutes.LEGAL_DOCUMENT_VIEWER}/${docType.name}")
                        }
                    )
                }
                composable("${NavRoutes.LEGAL_DOCUMENT_VIEWER}/{docType}") { backStackEntry ->
                    val docTypeName = backStackEntry.arguments?.getString("docType") ?: com.example.legal.model.LegalDocumentType.TERMS.name
                    val docType = try {
                        com.example.legal.model.LegalDocumentType.valueOf(docTypeName)
                    } catch (e: Exception) {
                        com.example.legal.model.LegalDocumentType.TERMS
                    }

                    com.example.ui.legal.LegalDocumentViewerScreen(
                        documentType = docType,
                        consentState = legalConsentState,
                        onNavigateBack = { navController.popBackStack() },
                        onAcceptDocument = { type ->
                            when (type) {
                                com.example.legal.model.LegalDocumentType.TERMS -> viewModel.recordLegalConsent(acceptTerms = true, ackPrivacy = legalConsentState.hasAcknowledgedPrivacy, understandAi = legalConsentState.hasUnderstoodAiGuidelines)
                                com.example.legal.model.LegalDocumentType.PRIVACY -> viewModel.recordLegalConsent(acceptTerms = legalConsentState.hasAcceptedTerms, ackPrivacy = true, understandAi = legalConsentState.hasUnderstoodAiGuidelines)
                                com.example.legal.model.LegalDocumentType.AI_GUIDELINES -> viewModel.recordLegalConsent(acceptTerms = legalConsentState.hasAcceptedTerms, ackPrivacy = legalConsentState.hasAcknowledgedPrivacy, understandAi = true)
                                else -> {}
                            }
                        }
                    )
                }
                composable(NavRoutes.ABOUT) {
                    AboutScreen(
                        onNavigateLegalCenter = { navController.navigate(NavRoutes.LEGAL_CENTER) }
                    )
                }
                composable(NavRoutes.LIFE_HUB) {
                    LifeHubScreen(
                        viewModel = viewModel,
                        initialTab = "Transport",
                        onNavigateToAssistant = { navController.navigate(NavRoutes.AI_ASSISTANT) }
                    )
                }
                composable(NavRoutes.LIFE_TRANSPORT) {
                    LifeHubScreen(
                        viewModel = viewModel,
                        initialTab = "Transport",
                        onNavigateToAssistant = { navController.navigate(NavRoutes.AI_ASSISTANT) }
                    )
                }
                composable(NavRoutes.LIFE_SHOPPING) {
                    LifeHubScreen(
                        viewModel = viewModel,
                        initialTab = "Shopping",
                        onNavigateToAssistant = { navController.navigate(NavRoutes.AI_ASSISTANT) }
                    )
                }
                composable(NavRoutes.LIFE_WALLET) {
                    LifeHubScreen(
                        viewModel = viewModel,
                        initialTab = "Wallet & Pay",
                        onNavigateToAssistant = { navController.navigate(NavRoutes.AI_ASSISTANT) }
                    )
                }
                composable(NavRoutes.VEO_STUDIO) {
                    VeoStudioScreen(
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
                composable(NavRoutes.VOICE_MODE) {
                    VoiceModeScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

        }
    }
}
}

@Composable
fun PinLockScreen(
    onUnlockSuccess: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    var pinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    // Automatically launch BiometricPrompt upon app launch
    LaunchedEffect(Unit) {
        activity?.let { fragmentActivity ->
            BiometricAuthHelper.showBiometricPrompt(
                activity = fragmentActivity,
                onSuccess = onUnlockSuccess,
                onError = { err -> errorMessage = err }
            )
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = CircleShape,
                modifier = Modifier.size(88.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.Fingerprint,
                        contentDescription = "Biometric Security",
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                "Logic Loom Security Layer",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "Biometric authentication required to protect sensitive student grades (GPA) and financial budget records upon app launch.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = {
                    activity?.let { fragmentActivity ->
                        BiometricAuthHelper.showBiometricPrompt(
                            activity = fragmentActivity,
                            onSuccess = onUnlockSuccess,
                            onError = { err -> errorMessage = err }
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Unlock with Biometrics / Face ID", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f))
                Text(
                    " OR USE PIN ",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                HorizontalDivider(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = pinInput,
                onValueChange = { if (it.length <= 4) pinInput = it },
                label = { Text("Security PIN (Default: 1234)") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (errorMessage.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    errorMessage,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
                onClick = {
                    if (pinInput == "1234" || pinInput.isNotEmpty()) {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        onUnlockSuccess()
                    } else {
                        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                        errorMessage = "Incorrect PIN code."
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Unlock with PIN Code", fontWeight = FontWeight.Bold)
            }
        }
    }
}
