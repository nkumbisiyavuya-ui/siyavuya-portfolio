package com.example

import android.app.Application
import com.example.data.local.CanvasMateDao
import com.example.data.local.CanvasMateDatabase
import com.example.data.repository.CanvasMateRepository
import com.example.di.AppContainer
import com.example.di.DefaultAppContainer

class CanvasMateApplication : Application() {

    lateinit var container: AppContainer
        private set

    val database: CanvasMateDatabase
        get() = container.database

    val dao: CanvasMateDao
        get() = container.dao

    val repository: CanvasMateRepository
        get() = container.repository

    val authRepository: com.example.data.repository.AuthRepository
        get() = container.authRepository

    override fun onCreate() {
        super.onCreate()
        instance = this
        container = DefaultAppContainer(this)

        try {
            // One authoritative Firebase initialization path powered by google-services.json
            val apps = com.google.firebase.FirebaseApp.getApps(this)
            if (apps.isEmpty()) {
                com.google.firebase.FirebaseApp.initializeApp(this)
            }
            val activeApp = com.google.firebase.FirebaseApp.getInstance()
            val rawKey = activeApp.options.apiKey
            val maskedKey = com.example.util.AuthUtils.maskApiKey(rawKey)
            android.util.Log.i(
                "CanvasMateApplication",
                "Authoritative Firebase initialized: ProjectId=${activeApp.options.projectId}, ApplicationId=${activeApp.options.applicationId}, ApiKey=$maskedKey"
            )
            if (rawKey.contains("LogicLoomAuthAppKey") || rawKey.contains("DummyKey") || rawKey.isEmpty()) {
                android.util.Log.w(
                    "CanvasMateApplication",
                    "[Firebase Config Warning] The active API key is a placeholder ($maskedKey). Ensure google-services.json is replaced with the authentic configuration from Firebase Console."
                )
            }
        } catch (e: Throwable) {
            android.util.Log.e("CanvasMateApplication", "Authoritative Firebase initialization error: ${e.message}", e)
        }
    }

    companion object {
        lateinit var instance: CanvasMateApplication
            private set

        val appContext: android.content.Context
            get() = if (::instance.isInitialized) instance.applicationContext else null ?: error("CanvasMateApplication not initialized")

        val safeAppContext: android.content.Context?
            get() = if (::instance.isInitialized) instance.applicationContext else null
    }
}
