package com.example.data.voice

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Conversational Voice Session Coordinator for Chuma AI.
 * Handles the full real-time speech loop:
 * - Speech-to-text with live streaming transcription
 * - Turn detection & auto silence completion
 * - Streaming text chunking and low-latency Neural TTS synthesis
 * - Immediate conversational barge-in / interruption
 * - Audio-reactive RMS energy for waveform animations
 * - Voice profile settings (Female, Male, Horizon) with neural voice IDs
 * - Automatic fallback to Android system TTS if neural proxy is unavailable
 * - Integration with Chuma AI reasoning and persistent transcript history
 */
class VoiceSessionManager(
    private val context: Context,
    private val coroutineScope: CoroutineScope,
    private val speechProvider: SpeechRecognitionProvider = AndroidSpeechRecognitionProvider(context),
    val ttsProvider: TextToSpeechProvider = CompositeTextToSpeechProvider(context),
    private val onSendPromptToAi: (prompt: String, onResponse: (String) -> Unit) -> Unit = { _, _ -> },
    private val onStreamPromptToAi: ((prompt: String, onChunk: (String) -> Unit, onResponse: (String) -> Unit) -> Unit)? = null
) {

    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _currentLiveTranscript = MutableStateFlow("")
    val currentLiveTranscript: StateFlow<String> = _currentLiveTranscript.asStateFlow()

    private val _currentAiSpeech = MutableStateFlow("")
    val currentAiSpeech: StateFlow<String> = _currentAiSpeech.asStateFlow()

    private val _soundLevelRms = MutableStateFlow(0f)
    val soundLevelRms: StateFlow<Float> = _soundLevelRms.asStateFlow()

    private val _voiceSettings = MutableStateFlow(VoiceSettings())
    val voiceSettings: StateFlow<VoiceSettings> = _voiceSettings.asStateFlow()

    private val _transcripts = MutableStateFlow<List<VoiceTranscriptItem>>(emptyList())
    val transcripts: StateFlow<List<VoiceTranscriptItem>> = _transcripts.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    val isUsingFallbackTts: StateFlow<Boolean> = if (ttsProvider is CompositeTextToSpeechProvider) {
        ttsProvider.isUsingFallback
    } else {
        MutableStateFlow(false).asStateFlow()
    }

    val ttsStatusNotice: StateFlow<String?> = if (ttsProvider is CompositeTextToSpeechProvider) {
        ttsProvider.statusNotice
    } else {
        MutableStateFlow(null).asStateFlow()
    }

    private var silenceJob: Job? = null
    private var lastSpokenTime: Long = 0L

    fun getSelectedProfile(): VoiceProfile {
        return CHUMA_VOICE_PROFILES.firstOrNull { it.id == _voiceSettings.value.selectedVoiceId }
            ?: CHUMA_VOICE_PROFILES[0]
    }

    fun updateSettings(newSettings: VoiceSettings) {
        _voiceSettings.value = newSettings
    }

    fun setVoiceProfile(profileId: String) {
        _voiceSettings.value = _voiceSettings.value.copy(selectedVoiceId = profileId)
    }

    fun setVoiceVolume(volume: Float) {
        _voiceSettings.value = _voiceSettings.value.copy(volume = volume.coerceIn(0f, 1f))
    }

    fun setSpeakingSpeed(speed: Float) {
        _voiceSettings.value = _voiceSettings.value.copy(speechRate = speed.coerceIn(0.6f, 2.0f))
    }

    fun setAutoPlay(enabled: Boolean) {
        _voiceSettings.value = _voiceSettings.value.copy(autoPlayResponses = enabled)
    }

    fun setLiveTranscription(enabled: Boolean) {
        _voiceSettings.value = _voiceSettings.value.copy(liveTranscriptionEnabled = enabled)
    }

    /**
     * Starts listening for user speech input.
     * If Chuma is currently speaking, barge-in is automatically triggered first.
     */
    fun startListening() {
        if (_voiceState.value == VoiceState.SPEAKING) {
            bargeIn()
        }

        _errorMessage.value = null
        _voiceState.value = VoiceState.LISTENING
        _currentLiveTranscript.value = ""

        speechProvider.startListening(
            onPartial = { partialText ->
                _voiceState.value = VoiceState.LISTENING
                if (_voiceSettings.value.liveTranscriptionEnabled) {
                    _currentLiveTranscript.value = partialText
                }
                lastSpokenTime = System.currentTimeMillis()
                scheduleSilenceDetection(partialText)
            },
            onFinal = { finalText ->
                silenceJob?.cancel()
                if (finalText.isNotBlank()) {
                    processUserTurn(finalText)
                } else {
                    _voiceState.value = VoiceState.IDLE
                }
            },
            onError = { err ->
                silenceJob?.cancel()
                // Ignore speech timeout errors when idle or returning to ready
                if (_voiceState.value == VoiceState.LISTENING) {
                    _errorMessage.value = err
                    _voiceState.value = VoiceState.ERROR
                }
            },
            onRmsChanged = { rms ->
                if (_voiceState.value == VoiceState.LISTENING) {
                    _soundLevelRms.value = rms
                }
            },
            onEndOfSpeech = {
                _soundLevelRms.value = 0f
            }
        )
    }

    /**
     * Stop listening manually (e.g. user taps mic button during recording).
     */
    fun stopListeningManually() {
        silenceJob?.cancel()
        speechProvider.stopListening()
        val text = _currentLiveTranscript.value.trim()
        if (text.isNotBlank()) {
            processUserTurn(text)
        } else {
            _voiceState.value = VoiceState.IDLE
        }
    }

    /**
     * Conversational Turn Detection:
     * Detects when user has naturally paused or finished speaking (~1.6 seconds of silence).
     */
    private fun scheduleSilenceDetection(accumulatedText: String) {
        silenceJob?.cancel()
        silenceJob = coroutineScope.launch {
            delay(1600L)
            if (_voiceState.value == VoiceState.LISTENING && accumulatedText.isNotBlank()) {
                speechProvider.stopListening()
                processUserTurn(accumulatedText)
            }
        }
    }

    /**
     * Submits completed user utterance to Chuma AI reasoning engine.
     * If streaming is supported, buffers and sends sentence chunks to TTS as they arrive.
     */
    private fun processUserTurn(userQuery: String) {
        silenceJob?.cancel()
        _soundLevelRms.value = 0f
        _currentLiveTranscript.value = userQuery

        // Add to transcript record
        val userItem = VoiceTranscriptItem(sender = "User", text = userQuery)
        _transcripts.value = _transcripts.value + userItem

        _voiceState.value = VoiceState.THINKING

        if (onStreamPromptToAi != null) {
            val chunker = StreamingTextChunker()
            val hasEmittedChunk = AtomicBoolean(false)
            val accumulatedSpeech = StringBuilder()

            onStreamPromptToAi.invoke(
                userQuery,
                { token ->
                    accumulatedSpeech.append(token)
                    _currentAiSpeech.value = accumulatedSpeech.toString()

                    val readyChunks = chunker.processToken(token)
                    for (readyChunk in readyChunks) {
                        hasEmittedChunk.set(true)
                        _voiceState.value = VoiceState.SPEAKING
                        ttsProvider.speakChunk(
                            chunk = readyChunk,
                            isLastChunk = false,
                            profile = getSelectedProfile(),
                            volume = _voiceSettings.value.volume,
                            speed = _voiceSettings.value.speechRate,
                            onStart = {
                                _voiceState.value = VoiceState.SPEAKING
                            },
                            onDone = {
                                // Handled sequentially by SequentialAudioPlayer
                            },
                            onError = { err ->
                                _errorMessage.value = err
                            }
                        )
                    }
                },
                { fullResponse ->
                    coroutineScope.launch {
                        val finalText = if (fullResponse.isNotBlank()) fullResponse else accumulatedSpeech.toString()
                        val aiItem = VoiceTranscriptItem(sender = "Chuma", text = finalText)
                        _transcripts.value = _transcripts.value + aiItem
                        _currentAiSpeech.value = finalText

                        val tailChunk = chunker.flush()
                        if (tailChunk != null && hasEmittedChunk.get()) {
                            ttsProvider.speakChunk(
                                chunk = tailChunk,
                                isLastChunk = true,
                                profile = getSelectedProfile(),
                                volume = _voiceSettings.value.volume,
                                speed = _voiceSettings.value.speechRate,
                                onStart = {
                                    _voiceState.value = VoiceState.SPEAKING
                                },
                                onDone = {
                                    onPlaybackFinished()
                                },
                                onError = { err ->
                                    _errorMessage.value = err
                                }
                            )
                        } else if (!hasEmittedChunk.get()) {
                            // Model responded as single output or chunker didn't split
                            handleAiResponse(finalText)
                        }
                    }
                }
            )
        } else {
            // Standard non-streaming path
            onSendPromptToAi(userQuery) { aiResponse ->
                coroutineScope.launch {
                    handleAiResponse(aiResponse)
                }
            }
        }
    }

    /**
     * Receives Chuma AI's synthesized response and begins TTS audio playback.
     */
    private fun handleAiResponse(aiResponse: String) {
        // Record in voice transcript if not already recorded
        val lastItem = _transcripts.value.lastOrNull()
        if (lastItem == null || lastItem.sender != "Chuma" || lastItem.text != aiResponse) {
            val aiItem = VoiceTranscriptItem(sender = "Chuma", text = aiResponse)
            _transcripts.value = _transcripts.value + aiItem
        }

        _currentAiSpeech.value = aiResponse

        if (!_voiceSettings.value.autoPlayResponses) {
            _voiceState.value = VoiceState.IDLE
            return
        }

        _voiceState.value = VoiceState.SPEAKING

        val profile = getSelectedProfile()
        ttsProvider.speak(
            text = aiResponse,
            profile = profile,
            volume = _voiceSettings.value.volume,
            speed = _voiceSettings.value.speechRate,
            onStart = {
                _voiceState.value = VoiceState.SPEAKING
            },
            onDone = {
                onPlaybackFinished()
            },
            onError = { err ->
                _voiceState.value = VoiceState.ERROR
                _errorMessage.value = err
            }
        )
    }

    private fun onPlaybackFinished() {
        _voiceState.value = VoiceState.IDLE
        _currentAiSpeech.value = ""
        // Continuous conversation loop: Automatically listen for next turn after slight breath pause
        coroutineScope.launch {
            delay(300L)
            if (_voiceState.value == VoiceState.IDLE) {
                startListening()
            }
        }
    }

    /**
     * BARGE-IN / INTERRUPTION:
     * Immediately stops TTS playback, cancels audio stream,
     * clears queued audio chunks, preserves context, and returns to listening.
     */
    fun bargeIn() {
        silenceJob?.cancel()
        ttsProvider.stop()
        _voiceState.value = VoiceState.INTERRUPTED
        coroutineScope.launch {
            delay(150L)
            startListening()
        }
    }

    /**
     * Stop all audio and speech engines and return to idle.
     */
    fun pauseOrStopAll() {
        silenceJob?.cancel()
        ttsProvider.stop()
        speechProvider.stopListening()
        _soundLevelRms.value = 0f
        _voiceState.value = VoiceState.IDLE
    }

    fun clearTranscripts() {
        _transcripts.value = emptyList()
        _currentLiveTranscript.value = ""
        _currentAiSpeech.value = ""
    }

    fun destroy() {
        pauseOrStopAll()
        speechProvider.destroy()
        ttsProvider.destroy()
    }
}
