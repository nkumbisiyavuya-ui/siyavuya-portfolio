package com.example.data.repository

import com.example.data.local.Task
import kotlinx.coroutines.flow.Flow

interface TaskRepository {
    val allTasks: Flow<List<Task>>
    val firestoreTasks: Flow<List<Task>>

    fun getTaskById(id: Long): Flow<Task?>
    fun getTasksByCourseCode(courseCode: String): Flow<List<Task>>
    fun getTasksByAcademicPeriod(academicPeriod: String): Flow<List<Task>>

    suspend fun insertTask(task: Task): Long
    suspend fun insertTasks(tasks: List<Task>): List<Long>
    suspend fun updateTask(task: Task)
    suspend fun deleteTask(task: Task)
    suspend fun deleteTaskById(id: Long)

    // Firestore Integration Methods
    suspend fun saveTaskToFirestore(task: Task): Result<Unit>
    suspend fun deleteTaskFromFirestore(taskId: String): Result<Unit>
    suspend fun syncTasksWithFirestore(): Result<Unit>
}
