package com.example.data.ai.orchestrator

/**
 * Capabilities required by or available to the Chuma AI Orchestrator.
 */
enum class ChumaCapability(val displayName: String) {
    GEMINI("Gemini Neural Intelligence"),
    WEB_SEARCH("Live Web Search"),
    FILE_RETRIEVAL("Vault & File Retrieval"),
    FILE_ANALYSIS("Document & File Analysis"),
    MEMORY("Context & Memory"),
    CALCULATOR("Deterministic Mathematical Engine"),
    WEATHER("Live Weather Telemetry"),
    MAPS("Campus & Geolocation Navigation"),
    CODE_ANALYSIS("Code Synthesis & Debugging"),
    OTHER_TOOLS("Device & Academic Tools")
}
