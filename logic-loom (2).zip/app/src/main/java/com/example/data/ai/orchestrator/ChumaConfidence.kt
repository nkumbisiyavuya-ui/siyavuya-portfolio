package com.example.data.ai.orchestrator

/**
 * Lightweight confidence level for Chuma AI orchestration.
 * Avoids fabricated numerical percentages.
 */
enum class ChumaConfidence {
    HIGH,
    MEDIUM,
    LOW,
    UNKNOWN
}
