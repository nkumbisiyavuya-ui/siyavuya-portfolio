package com.example.data.voice

import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger

/**
 * Production-ready Neural Text-To-Speech Provider.
 *
 * Implements low-latency streaming chunk synthesis and sequential audio playback.
 * Securely communicates with an authenticated backend proxy without embedding
 * provider API keys (such as ElevenLabs credentials) into the client application.
 */
class NeuralTextToSpeechProvider(
    private val context: Context,
    private val backendClient: NeuralTtsBackendClient = HttpNeuralTtsBackendClient(),
    private val audioPlayer: SequentialAudioPlayer = SequentialAudioPlayer(context),
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) : TextToSpeechProvider {

    companion object {
        private const val TAG = "NeuralTtsProvider"
    }

    override val providerName: String = "ElevenLabs Neural TTS"

    override val isReady: Boolean
        get() = backendClient.isConfigured()

    private var activeSynthesisJob: Job? = null

    override fun speak(
        text: String,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        val startTime = System.currentTimeMillis()
        val cleaned = StreamingTextChunker.cleanForSpeech(text)
        if (cleaned.isBlank()) {
            onDone()
            return
        }

        activeSynthesisJob?.cancel()
        val generationId = audioPlayer.startNewGeneration()

        activeSynthesisJob = coroutineScope.launch {
            try {
                val chunks = StreamingTextChunker.chunkCompleteText(cleaned)
                Log.d(TAG, "VOICE_TTS_REQUEST: Speaking text (${cleaned.length} chars) split into ${chunks.size} chunks. Voice: ${profile.name} (gen: $generationId)")

                val totalChunks = chunks.size
                val completedChunks = AtomicInteger(0)
                var hasStartedPlayback = false

                for ((index, chunk) in chunks.withIndex()) {
                    ensureActive()
                    if (generationId != audioPlayer.activeGenerationId) {
                        Log.d(TAG, "VOICE_TTS_CANCELLED: Generation $generationId was superseded by ${audioPlayer.activeGenerationId}")
                        return@launch
                    }

                    val isLast = index == totalChunks - 1
                    val voiceId = resolveNeuralVoiceId(profile)

                    val result = backendClient.synthesize(
                        NeuralTtsSynthesizeRequest(
                            text = chunk,
                            voiceId = voiceId,
                            speed = speed,
                            volume = volume,
                            modelId = profile.neuralModelId,
                            generationId = generationId
                        ),
                        isCancelled = { generationId != audioPlayer.activeGenerationId }
                    )

                    ensureActive()
                    if (generationId != audioPlayer.activeGenerationId) {
                        Log.d(TAG, "VOICE_TTS_CANCELLED: Dropping late synthesis result for gen: $generationId")
                        return@launch
                    }

                    if (!result.isSuccess || result.audioBytes == null) {
                        Log.w(TAG, "VOICE_TTS_ERROR: Chunk synthesis failed: ${result.errorMessage}")
                        withContext(Dispatchers.Main) {
                            onError(result.errorMessage ?: "Neural synthesis failed")
                        }
                        return@launch
                    }

                    // Enqueue chunk into sequential playback layer
                    audioPlayer.enqueueChunk(
                        audioBytes = result.audioBytes,
                        volume = volume,
                        speed = speed,
                        isLastChunk = isLast,
                        generationId = generationId,
                        onStart = {
                            if (!hasStartedPlayback) {
                                hasStartedPlayback = true
                                val firstAudioLatency = System.currentTimeMillis() - startTime
                                Log.d(TAG, "VOICE_TTS_FIRST_AUDIO: Latency to first audio playback: ${firstAudioLatency}ms")
                                onStart()
                            }
                        },
                        onDone = {
                            val doneCount = completedChunks.incrementAndGet()
                            if (doneCount >= totalChunks) {
                                Log.d(TAG, "VOICE_TTS_COMPLETED: Finished speaking all $totalChunks chunks in ${System.currentTimeMillis() - startTime}ms")
                                onDone()
                            }
                        },
                        onError = { playErr ->
                            Log.w(TAG, "VOICE_TTS_ERROR: Audio playback error: $playErr")
                            onError(playErr)
                        }
                    )
                }
            } catch (e: CancellationException) {
                Log.d(TAG, "VOICE_TTS_CANCELLED: Synthesis was cancelled by barge-in")
            } catch (e: Exception) {
                Log.e(TAG, "VOICE_TTS_ERROR: Unexpected error during speak pipeline", e)
                withContext(Dispatchers.Main) {
                    onError(e.localizedMessage ?: "Neural TTS error")
                }
            }
        }
    }

    override fun speakChunk(
        chunk: String,
        isLastChunk: Boolean,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        val startTime = System.currentTimeMillis()
        val cleaned = StreamingTextChunker.cleanForSpeech(chunk)
        if (cleaned.isBlank()) {
            if (isLastChunk) onDone()
            return
        }

        val generationId = audioPlayer.activeGenerationId
        coroutineScope.launch {
            try {
                ensureActive()
                if (generationId != audioPlayer.activeGenerationId) {
                    Log.d(TAG, "VOICE_TTS_CANCELLED: Dropping streaming chunk from superseded generationId $generationId")
                    return@launch
                }

                val voiceId = resolveNeuralVoiceId(profile)
                Log.d(TAG, "VOICE_TTS_REQUEST: Synthesizing streaming chunk (${cleaned.length} chars, isLast=$isLastChunk, gen=$generationId)")

                val result = backendClient.synthesize(
                    NeuralTtsSynthesizeRequest(
                        text = cleaned,
                        voiceId = voiceId,
                        speed = speed,
                        volume = volume,
                        modelId = profile.neuralModelId,
                        generationId = generationId
                    ),
                    isCancelled = { generationId != audioPlayer.activeGenerationId }
                )

                ensureActive()
                if (generationId != audioPlayer.activeGenerationId) {
                    Log.d(TAG, "VOICE_TTS_CANCELLED: Dropping late streaming chunk result from gen $generationId")
                    return@launch
                }

                if (!result.isSuccess || result.audioBytes == null) {
                    withContext(Dispatchers.Main) {
                        onError(result.errorMessage ?: "Failed to synthesize neural audio chunk")
                    }
                    return@launch
                }

                audioPlayer.enqueueChunk(
                    audioBytes = result.audioBytes,
                    volume = volume,
                    speed = speed,
                    isLastChunk = isLastChunk,
                    generationId = generationId,
                    onStart = {
                        Log.d(TAG, "VOICE_TTS_FIRST_AUDIO: Playing streaming chunk in ${System.currentTimeMillis() - startTime}ms")
                        onStart()
                    },
                    onDone = {
                        if (isLastChunk) {
                            Log.d(TAG, "VOICE_TTS_COMPLETED: Streaming turn completed")
                            onDone()
                        }
                    },
                    onError = onError
                )
            } catch (e: CancellationException) {
                Log.d(TAG, "VOICE_TTS_CANCELLED: Streaming chunk synthesis cancelled")
            } catch (e: Exception) {
                Log.e(TAG, "VOICE_TTS_ERROR: Failed to process streaming chunk", e)
                withContext(Dispatchers.Main) {
                    onError(e.localizedMessage ?: "Streaming chunk error")
                }
            }
        }
    }

    override fun stop() {
        val startCancel = System.currentTimeMillis()
        audioPlayer.startNewGeneration()
        activeSynthesisJob?.cancel()
        audioPlayer.stop()
        Log.d(TAG, "VOICE_TTS_CANCELLED: Neural TTS stop & barge-in executed in ${System.currentTimeMillis() - startCancel}ms")
    }

    override fun destroy() {
        stop()
        coroutineScope.cancel()
        audioPlayer.destroy()
    }

    private fun resolveNeuralVoiceId(profile: VoiceProfile): String {
        return profile.neuralVoiceId
            ?: when (profile.id) {
                "female" -> NeuralTtsConfiguration.current.femaleVoiceId
                "male" -> NeuralTtsConfiguration.current.maleVoiceId
                else -> NeuralTtsConfiguration.current.horizonVoiceId
            }
    }
}
