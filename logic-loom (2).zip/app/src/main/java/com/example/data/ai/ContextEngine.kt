package com.example.data.ai

import com.example.data.local.*

object ContextEngine {

    fun buildMinimalContextString(
        intent: ParsedIntent,
        context: CanvasMateContext,
        privacyLevel: AiPrivacyLevel = AiPrivacyLevel.STANDARD
    ): String {
        val sanitizedUser = AiContextSanitizer.sanitizeUserProfile(context.userProfile, privacyLevel)
        val name = sanitizedUser?.fullName?.takeIf { it.isNotBlank() } ?: "Student"
        val uni = sanitizedUser?.university?.takeIf { it.isNotBlank() }
        val course = sanitizedUser?.course?.takeIf { it.isNotBlank() }

        val sb = StringBuilder()
        val deviceDateTime = com.example.data.tools.TimeTool.getDeviceDateTimeInfo()
        sb.append("Current Device Date/Time: ${deviceDateTime.dayOfWeek}, ${deviceDateTime.formattedDate} at ${deviceDateTime.formattedTime} (${deviceDateTime.timezoneId})\n")
        sb.append("User Name: ${AiContextSanitizer.sanitizeText(name, privacyLevel)}\n")
        if (!uni.isNullOrBlank()) {
            sb.append("University: ${AiContextSanitizer.sanitizeText(uni, privacyLevel)}\n")
        }
        if (!course.isNullOrBlank()) {
            sb.append("Course: ${AiContextSanitizer.sanitizeText(course, privacyLevel)}\n")
        }

        when (intent.category) {
            MajorIntentCategory.TASKS -> {
                sb.append("\nTasks Context:\n")
                context.academicTasks.take(5).forEach {
                    val cleanTitle = AiContextSanitizer.sanitizeText(it.title, privacyLevel)
                    sb.append("- Academic Task: $cleanTitle (${it.module}), Due: ${it.dueDate}\n")
                }
                context.todoTasks.take(5).forEach {
                    val cleanTitle = AiContextSanitizer.sanitizeText(it.title, privacyLevel)
                    sb.append("- Todo: $cleanTitle (Priority: ${it.priority}), Completed: ${it.isCompleted}\n")
                }
            }
            MajorIntentCategory.FINANCE -> {
                sb.append("\nFinance Context:\n")
                val totalIncome = context.budgetItems.filter { it.type.lowercase() == "income" }.sumOf { it.amount }
                val totalExpense = context.budgetItems.filter { it.type.lowercase() == "expense" }.sumOf { it.amount }
                sb.append("Total Income: R$totalIncome, Total Expenses: R$totalExpense, Net Balance: R${(totalIncome - totalExpense).coerceAtLeast(0.0)}\n")
            }
            MajorIntentCategory.CALENDAR -> {
                sb.append("\nTimetable & Calendar Context:\n")
                context.timetableSlots.take(5).forEach {
                    val cleanVenue = AiContextSanitizer.sanitizeText(it.venue, privacyLevel)
                    sb.append("- Class: ${it.module} at ${it.startTime}-${it.endTime} ($cleanVenue)\n")
                }
                context.calendarEvents.take(5).forEach {
                    val cleanTitle = AiContextSanitizer.sanitizeText(it.title, privacyLevel)
                    sb.append("- Event: $cleanTitle on ${it.date} at ${it.time}\n")
                }
            }
            MajorIntentCategory.DOCUMENTS -> {
                sb.append("\nDocuments Context:\n")
                context.vaultDocuments
                    .filter { AiContextSanitizer.isVaultDocumentAllowedForAi(it.title, it.category) }
                    .take(5)
                    .forEach {
                        val cleanTitle = AiContextSanitizer.sanitizeText(it.title, privacyLevel)
                        sb.append("- Document: $cleanTitle (${it.category})\n")
                    }
                context.notes.take(5).forEach {
                    val cleanTitle = AiContextSanitizer.sanitizeText(it.title, privacyLevel)
                    sb.append("- Study Note: $cleanTitle (Folder: ${it.folder})\n")
                }
            }
            else -> {
                sb.append("\nGeneral Context:\n")
                if (context.academicTasks.isNotEmpty()) sb.append("Pending Tasks: ${context.academicTasks.size}\n")
                if (context.timetableSlots.isNotEmpty()) sb.append("Classes Logged: ${context.timetableSlots.size}\n")
            }
        }

        return AiContextSanitizer.sanitizeText(sb.toString(), privacyLevel)
    }
}

