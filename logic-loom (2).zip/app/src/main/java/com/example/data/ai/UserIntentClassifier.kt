package com.example.data.ai

import java.util.Locale

/**
 * Three distinct user intent modes as defined by Chuma AI governance principles.
 */
enum class UserIntentMode {
    /** The user is asking for facts, data, explanations, or current conditions. */
    INFORMATION_QUERY,

    /** The user is asking how to do something or for instructions/steps. */
    INSTRUCTION_REQUEST,

    /** The user is explicitly requesting the assistant to perform an action or tool operation. */
    ACTION_REQUEST
}

data class ClassifiedIntent(
    val mode: UserIntentMode,
    val actionType: String? = null,
    val isExplicitAction: Boolean = false,
    val confidence: Float = 1.0f
)

object UserIntentClassifier {

    private val INSTRUCTION_PREFIXES = listOf(
        "how do i", "how can i", "how to", "how do we", "how does one",
        "how should i", "tell me how to", "show me how to", "explain how to",
        "guide me to", "what are the steps to", "how do you", "instructions for",
        "tutorial for", "teach me how to"
    )

    private val ACTION_INDICATORS = listOf(
        "set an alarm", "set alarm", "wake me up", "alarm for", "alarm at",
        "create a task", "create task", "add task", "new task", "make a task",
        "remind me", "set reminder", "create reminder", "set a reminder",
        "add expense", "log expense", "record expense", "add spending",
        "open settings", "open timetable", "open notes", "open vault",
        "open budget", "open calendar", "open gpa", "open screen", "go to settings",
        "delete task", "remove task", "complete task", "mark task",
        "navigate to", "directions to", "take me to",
        "delete all", "wipe my", "clear all", "reset account",
        "create study plan", "generate study plan"
    )

    fun classify(prompt: String): ClassifiedIntent {
        val lower = prompt.trim().lowercase(Locale.ROOT)

        // 1. Check for instruction queries first (e.g. "How do I set an alarm?")
        if (INSTRUCTION_PREFIXES.any { lower.startsWith(it) }) {
            return ClassifiedIntent(
                mode = UserIntentMode.INSTRUCTION_REQUEST,
                isExplicitAction = false
            )
        }

        // 2. Check for explicit action requests (e.g. "Set an alarm for 7 AM")
        for (action in ACTION_INDICATORS) {
            if (lower.startsWith(action) || lower.contains("please $action") || lower.contains("can you $action")) {
                val actionType = when {
                    action.contains("alarm") -> "set_alarm"
                    action.contains("reminder") || action.contains("remind me") -> "create_reminder"
                    action.contains("task") && action.contains("delete") -> "delete_task"
                    action.contains("task") && action.contains("complete") -> "complete_task"
                    action.contains("task") -> "create_task"
                    action.contains("expense") -> "add_expense"
                    action.contains("open") || action.contains("go to") -> "open_screen"
                    action.contains("navigate") || action.contains("directions") -> "navigate"
                    action.contains("study plan") -> "create_study_plan"
                    action.contains("delete") || action.contains("wipe") || action.contains("reset") -> "destructive_action"
                    else -> "general_action"
                }
                return ClassifiedIntent(
                    mode = UserIntentMode.ACTION_REQUEST,
                    actionType = actionType,
                    isExplicitAction = true
                )
            }
        }

        // 3. Fallback to information query (e.g. "What time does the sun set today?")
        return ClassifiedIntent(
            mode = UserIntentMode.INFORMATION_QUERY,
            isExplicitAction = false
        )
    }

    /**
     * Generates a helpful instruction response when the user asks "How do I..."
     */
    fun getInstructionGuidance(prompt: String): String {
        val lower = prompt.trim().lowercase(Locale.ROOT)
        return when {
            lower.contains("alarm") -> {
                "To set an alarm, you can ask me directly with a command like:\n" +
                        "• *\"Set an alarm for 7 AM tomorrow\"*\n" +
                        "• *\"Alarm at 6:30\"*\n\n" +
                        "You can also use your device's Clock app to customize ringtones, snooze intervals, and recurring vibration patterns."
            }
            lower.contains("reminder") || lower.contains("remind") -> {
                "To create a reminder, ask me directly:\n" +
                        "• *\"Remind me tomorrow at 9 to submit CS assignment\"*\n" +
                        "• *\"Set a reminder at 14:00\"*\n\n" +
                        "Reminders are integrated into your smart study timetable and notification alerts."
            }
            lower.contains("task") || lower.contains("assignment") -> {
                "To create a task in Logic Loom:\n" +
                        "• Ask me: *\"Create a task for Mathematics due Friday\"*\n" +
                        "• Or tap the **Academic Planner** tab in the navigation bar and tap **+ Add Task**."
            }
            lower.contains("expense") || lower.contains("budget") -> {
                "To track an expense:\n" +
                        "• Tell me: *\"Add expense of R45 for lunch\"*\n" +
                        "• Or open the **Budget** tab to view your spending breakdown and category limits."
            }
            lower.contains("gpa") -> {
                "To calculate your GPA, open the **GPA Calculator** screen or tell me your module grades and credits (e.g. *\"Calculate grade with current 65% targeting 75%\"*)."
            }
            lower.contains("screen") || lower.contains("navigate") || lower.contains("open") -> {
                "You can tell me to open any screen in Logic Loom, such as *\"Open Settings\"*, *\"Open Timetable\"*, or *\"Open Notes\"*."
            }
            else -> {
                "In Logic Loom, you can ask me to perform actions directly (e.g., *\"Set an alarm for 7 AM\"*, *\"Create a task\"*, *\"Open Settings\"*) or ask questions about your studies, schedules, and campus life."
            }
        }
    }
}
