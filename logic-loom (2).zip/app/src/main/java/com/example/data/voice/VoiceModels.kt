package com.example.data.voice

/**
 * Visual and conversational states for Chuma AI Voice Mode V1.
 */
enum class VoiceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    INTERRUPTED,
    ERROR
}

/**
 * Configurable voice agent profiles for Chuma AI.
 * All profiles share the exact same underlying Chuma AI brain, knowledge, and tools,
 * while providing distinct conversational presentation, pitch, cadence, and neural voice IDs.
 */
data class VoiceProfile(
    val id: String,
    val name: String,
    val genderLabel: String,
    val personality: String,
    val pitch: Float,
    val rate: Float,
    val preferredVoiceTag: String? = null,
    val neuralVoiceId: String? = null,
    val neuralModelId: String? = null
)

val CHUMA_VOICE_PROFILES = listOf(
    VoiceProfile(
        id = "female",
        name = "Chuma — Female",
        genderLabel = "Female",
        personality = "Warm, intelligent, natural, articulate, professional",
        pitch = 1.15f,
        rate = 1.0f,
        preferredVoiceTag = "en-us-x-sfg#female_1",
        neuralVoiceId = "Sy7d8PNbkbjIJxf1li2K",
        neuralModelId = "eleven_turbo_v2_5"
    ),
    VoiceProfile(
        id = "male",
        name = "Chuma — Male",
        genderLabel = "Male",
        personality = "Confident, calm, intelligent, direct, conversational",
        pitch = 0.88f,
        rate = 0.98f,
        preferredVoiceTag = "en-us-x-sfg#male_1",
        neuralVoiceId = "xvDjI8KMgjF1nCoPoNKX",
        neuralModelId = "eleven_turbo_v2_5"
    ),
    VoiceProfile(
        id = "horizon",
        name = "Chuma — Horizon",
        genderLabel = "Neural / Adaptive",
        personality = "Dynamic, futuristic, adaptive, articulate (Configurable)",
        pitch = 1.02f,
        rate = 1.05f,
        preferredVoiceTag = "en-za-x-sfg#neutral_1",
        neuralVoiceId = "fFAtoTPtP0TtMyhbR3L9",
        neuralModelId = "eleven_turbo_v2_5"
    )
)

/**
 * Configuration for the Neural TTS backend proxy.
 *
 * SECURITY: Long-lived provider API keys (such as ElevenLabs API keys) MUST NOT be stored
 * in the client APK. Requests are routed through a secure authenticated backend proxy
 * (or Firebase Cloud Function / server endpoint).
 *
 * If backendProxyUrl is null or unavailable, the system automatically falls back to AndroidTextToSpeechProvider.
 */
data class NeuralTtsConfiguration(
    val backendProxyUrl: String? = null,
    val femaleVoiceId: String = "Sy7d8PNbkbjIJxf1li2K",
    val maleVoiceId: String = "xvDjI8KMgjF1nCoPoNKX",
    val horizonVoiceId: String = "fFAtoTPtP0TtMyhbR3L9",
    val defaultModelId: String = "eleven_turbo_v2_5",
    val timeoutMs: Long = 8000L,
    val isEnabled: Boolean = true
) {
    companion object {
        @Volatile
        var current: NeuralTtsConfiguration = NeuralTtsConfiguration()
    }
}

/**
 * User-configurable voice settings.
 */
data class VoiceSettings(
    val selectedVoiceId: String = "female",
    val volume: Float = 0.9f,           // 0.0 to 1.0
    val speechRate: Float = 1.0f,       // 0.75x to 1.5x
    val autoPlayResponses: Boolean = true,
    val liveTranscriptionEnabled: Boolean = true
)

/**
 * Clean transcript record for voice conversations.
 */
data class VoiceTranscriptItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "User" or "Chuma"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPartial: Boolean = false
)
