package com.example.data.ai

import com.example.data.local.*

data class ToolExecutionResult(
    val success: Boolean,
    val message: String,
    val cardTag: String? = null
)

object ToolEngine {

    fun executeCreateTask(title: String, dueDate: String = "Tomorrow", module: String = "General"): ToolExecutionResult {
        val cleanTitle = title.ifBlank { "Study Session" }
        return ToolExecutionResult(
            success = true,
            message = "Created task: '$cleanTitle' for module $module (due $dueDate).",
            cardTag = "[CARD_TASK:Title=$cleanTitle|Status=Created]"
        )
    }

    fun executeCreateReminder(title: String, time: String = "08:00", leadMinutes: Int = 15): ToolExecutionResult {
        val cleanTitle = title.ifBlank { "Assignment Deadline" }
        return ToolExecutionResult(
            success = true,
            message = "Configured reminder '$cleanTitle' for $time ($leadMinutes min lead time).",
            cardTag = "[CARD_TASK:Title=$cleanTitle|Status=ReminderSet]"
        )
    }

    fun executeAddExpense(description: String, amount: Double, category: String = "Food"): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Logged expense: R${"%.2f".format(amount)} for '$description' ($category).",
            cardTag = "[CARD_BUDGET:Amount=R${"%.2f".format(amount)}|Category=$category]"
        )
    }

    fun executeCreateStudyPlan(coursesStr: String, preferredTimesStr: String): ToolExecutionResult {
        val plan = CanvasMateAiOrchestrator.generateCustomStudyPlan(coursesStr, preferredTimesStr)
        return ToolExecutionResult(
            success = true,
            message = plan,
            cardTag = "[CARD_STUDY_PLAN:Status=Generated]"
        )
    }

    fun executeGetTasksSummary(module: String = "All"): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Retrieved tasks summary for module '$module'. All active tasks are up to date.",
            cardTag = "[CARD_TASK:Status=SummaryLoaded]"
        )
    }

    fun executeDeleteTask(taskId: String): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Task '$taskId' deleted successfully.",
            cardTag = "[CARD_TASK:TaskId=$taskId|Status=Deleted]"
        )
    }

    fun executeCompleteTask(taskId: String): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Task '$taskId' marked as complete.",
            cardTag = "[CARD_TASK:TaskId=$taskId|Status=Completed]"
        )
    }

    fun executeGetCalendarEvents(): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Calendar schedule retrieved: Next lecture is at 10:00 AM (CS201), followed by Tutorial at 14:00 PM.",
            cardTag = "[CARD_CALENDAR:Status=EventsLoaded]"
        )
    }

    fun executeGetNextClass(): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Next class: CS201 Data Structures at 10:00 AM in Science Building Room 102.",
            cardTag = "[CARD_CALENDAR:Status=NextClassLoaded]"
        )
    }

    fun executeGetBalanceSummary(): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Financial Summary: Available Balance: R1,250.00 | Total Income: R3,000.00 | Expenses: R1,750.00.",
            cardTag = "[CARD_BUDGET:Balance=R1250.00]"
        )
    }

    fun executeAnalyzeSpending(category: String = "All"): ToolExecutionResult {
        return ToolExecutionResult(
            success = true,
            message = "Spending analysis for $category: Top expenses are Food (45%) and Books/Stationery (30%). Budget is within healthy limits.",
            cardTag = "[CARD_BUDGET:Category=$category|Status=Analyzed]"
        )
    }

    fun executeSearchCampusBuildings(query: String): ToolExecutionResult {
        val buildings = com.example.data.location.LocationService.searchCampusBuildings(query)
        val msg = if (buildings.isNotEmpty()) {
            "Found ${buildings.size} campus building(s):\n" + buildings.joinToString("\n") {
                "• ${it.name} (${it.code}) - ${it.campusArea}: ${it.description} [${it.openingHours}]"
            }
        } else {
            "No campus buildings found matching '$query'."
        }
        return ToolExecutionResult(
            success = true,
            message = msg,
            cardTag = "[CARD_CAMPUS:Query=$query|Count=${buildings.size}]"
        )
    }

    fun executeSearchPlaces(query: String, requirePermission: Boolean = false): ToolExecutionResult {
        val places = com.example.data.location.LocationService.searchPlaces(query, requirePermission = requirePermission)
        val msg = if (places.isNotEmpty()) {
            "Found ${places.size} place(s) near campus:\n" + places.joinToString("\n") {
                "• ${it.name} (${it.category}) - ${it.distanceKm}km away at ${it.address}. Status: ${it.openingStatus}. Rating: ⭐${it.rating}"
            }
        } else if (requirePermission && !com.example.data.location.LocationService.canUseLocation()) {
            "Location permission is required for exact place search but is currently disabled. Please grant location permission or enable manual location override."
        } else {
            "No places found matching '$query'."
        }
        return ToolExecutionResult(
            success = true,
            message = msg,
            cardTag = "[CARD_PLACE:Query=$query|Count=${places.size}]"
        )
    }

    suspend fun executeSearchWeb(query: String): ToolExecutionResult {
        val res = com.example.data.tools.WebSearchTool.searchWeb(query)
        return ToolExecutionResult(
            success = res.success,
            message = res.formattedAnswer,
            cardTag = if (res.success) "[CARD_SEARCH:Query=$query|Results=${res.results.size}]" else null
        )
    }

    suspend fun executeGetWeather(location: String): ToolExecutionResult {
        val res = com.example.data.tools.WeatherTool.getWeather(location)
        return ToolExecutionResult(
            success = res.success,
            message = res.formattedSummary,
            cardTag = if (res.success) "[CARD_WEATHER:Location=${res.locationName}|Temp=${res.temperatureCelsius}°C]" else null
        )
    }

    fun executeCalculate(expression: String): ToolExecutionResult {
        val res = com.example.data.tools.CalculatorTool.calculate(expression)
        return ToolExecutionResult(
            success = res.success,
            message = if (res.success) "🔢 **Calculation**: ${res.explanation}" else res.explanation,
            cardTag = if (res.success) "[CARD_CALC:Result=${res.formattedResult}]" else null
        )
    }

    fun executeGetCurrentTime(location: String): ToolExecutionResult {
        val calendarCheck = com.example.data.tools.TimeTool.resolveCalendarEventDate(location)
        if (calendarCheck != null) {
            return ToolExecutionResult(
                success = true,
                message = calendarCheck,
                cardTag = "[CARD_TIME:HolidayCheck]"
            )
        }
        val res = com.example.data.tools.TimeTool.getCurrentTime(location)
        return ToolExecutionResult(
            success = res.success,
            message = res.fullReport,
            cardTag = if (res.success) "[CARD_TIME:Zone=${res.timezoneId}|Time=${res.formattedTime}]" else null
        )
    }

    suspend fun executeGetExchangeRate(amount: Double, base: String = "ZAR", target: String = "USD"): ToolExecutionResult {
        val res = com.example.data.tools.CurrencyTool.convertCurrency(amount, base, target)
        return ToolExecutionResult(
            success = res.success,
            message = res.formattedSummary,
            cardTag = if (res.success) "[CARD_CURRENCY:Base=$base|Target=$target|Rate=${res.rate}]" else null
        )
    }

    fun executeGetPlaceDetails(placeName: String): ToolExecutionResult {
        val res = com.example.data.tools.PlaceSearchTool.getPlaceDetails(placeName)
        return ToolExecutionResult(
            success = res.success,
            message = res.formattedSummary,
            cardTag = if (res.success) "[CARD_PLACE_DETAILS:Place=$placeName]" else null
        )
    }

    fun executeSetAlarm(prompt: String): ToolExecutionResult {
        val parsed = com.example.data.tools.AlarmTool.parseAlarmRequest(prompt)
        if (parsed == null) {
            return ToolExecutionResult(
                success = false,
                message = "I couldn't identify the requested time for the alarm. Please specify a time like 'Set an alarm for 7 AM' or 'Alarm at 6:30'."
            )
        }
        val (hour, minute) = parsed
        val isTomorrow = com.example.data.tools.AlarmTool.isTomorrowRequested(prompt)
        val result = com.example.data.tools.AlarmTool.setAlarm(
            hour = hour,
            minute = minute,
            label = "Logic Loom Alarm",
            isTomorrow = isTomorrow
        )
        return ToolExecutionResult(
            success = result.success,
            message = result.message,
            cardTag = if (result.success) "[CARD_ALARM:Time=${hour}:${minute}]" else null
        )
    }

    fun executeOpenScreen(screenName: String): ToolExecutionResult {
        val result = com.example.data.tools.ScreenNavigationTool.openScreen(screenName)
        return ToolExecutionResult(
            success = result.success,
            message = result.message,
            cardTag = if (result.success && result.targetRoute != null) "[CARD_NAV:Route=${result.targetRoute}]" else null
        )
    }

    fun executeNavigateToLocation(destination: String): ToolExecutionResult {
        val cleanDest = destination.trim()
        if (cleanDest.isBlank()) {
            return ToolExecutionResult(
                success = false,
                message = "Please specify a destination to navigate to (e.g. 'Navigate to CPUT Bellville' or 'Directions to Library')."
            )
        }
        val locationService = com.example.data.location.LocationService()
        val campusBuildings = locationService.searchCampusBuildings(cleanDest)
        val campusMatch = campusBuildings.firstOrNull()

        val context = com.example.CanvasMateApplication.safeAppContext
        val geoUri = if (campusMatch != null) {
            "geo:0,0?q=" + android.net.Uri.encode("${campusMatch.name}, ${campusMatch.campusArea}")
        } else {
            "geo:0,0?q=" + android.net.Uri.encode(cleanDest)
        }

        var intentLaunched = false
        if (context != null) {
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(geoUri)).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                    intentLaunched = true
                }
            } catch (e: Exception) {
                // Ignore intent launch failure, provide directions text
            }
        }

        val details = if (campusMatch != null) {
            "• Destination: ${campusMatch.name} (${campusMatch.code})\n• Campus Area: ${campusMatch.campusArea}\n• Hours: ${campusMatch.openingHours}\n• Details: ${campusMatch.description}"
        } else {
            "• Destination: $cleanDest\n• Map query prepared: $geoUri"
        }

        val message = if (intentLaunched) {
            "Done — opening navigation directions to '$cleanDest':\n$details"
        } else {
            "Navigation route for '$cleanDest':\n$details\nTap the map card below to view in your maps app."
        }

        return ToolExecutionResult(
            success = true,
            message = message,
            cardTag = "[CARD_LOCATION:Query=$cleanDest]"
        )
    }
}

