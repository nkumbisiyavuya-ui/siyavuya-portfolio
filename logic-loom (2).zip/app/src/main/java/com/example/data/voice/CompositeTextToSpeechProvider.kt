package com.example.data.voice

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Composite TTS Coordinator managing PRIMARY (Neural TTS) and FALLBACK (Android System TTS).
 *
 * Fault-Tolerant Selection Policy:
 * 1. PRIMARY: NeuralTextToSpeechProvider (secure ElevenLabs proxy)
 * 2. FALLBACK: AndroidTextToSpeechProvider (local device voice engine)
 *
 * If the neural backend proxy is unconfigured, unreachable, throws an HTTP error (401/429/500),
 * times out, or encounters audio decoding errors, the system automatically falls back to
 * AndroidTextToSpeechProvider without interrupting the conversation or crashing Voice Mode.
 *
 * The active state is reported via [isUsingFallback] and [statusNotice] ("Using device voice").
 */
class CompositeTextToSpeechProvider(
    private val context: Context,
    val primaryProvider: TextToSpeechProvider = NeuralTextToSpeechProvider(context),
    val fallbackProvider: TextToSpeechProvider = AndroidTextToSpeechProvider(context)
) : TextToSpeechProvider {

    companion object {
        private const val TAG = "CompositeTtsProvider"
    }

    override val providerName: String
        get() = if (_isUsingFallback.value) fallbackProvider.providerName else primaryProvider.providerName

    override val isReady: Boolean
        get() = primaryProvider.isReady || fallbackProvider.isReady

    private val _isUsingFallback = MutableStateFlow(false)
    val isUsingFallback: StateFlow<Boolean> = _isUsingFallback.asStateFlow()

    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice.asStateFlow()

    override fun speak(
        text: String,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (!primaryProvider.isReady) {
            executeFallback(
                reason = "Neural TTS backend proxy not configured",
                text = text,
                profile = profile,
                volume = volume,
                speed = speed,
                utteranceId = utteranceId,
                onStart = onStart,
                onDone = onDone,
                onError = onError
            )
            return
        }

        // Attempt Primary Neural TTS
        primaryProvider.speak(
            text = text,
            profile = profile,
            volume = volume,
            speed = speed,
            utteranceId = utteranceId,
            onStart = {
                _isUsingFallback.value = false
                _statusNotice.value = null
                onStart()
            },
            onDone = onDone,
            onError = { neuralError ->
                executeFallback(
                    reason = neuralError,
                    text = text,
                    profile = profile,
                    volume = volume,
                    speed = speed,
                    utteranceId = utteranceId,
                    onStart = onStart,
                    onDone = onDone,
                    onError = onError
                )
            }
        )
    }

    override fun speakChunk(
        chunk: String,
        isLastChunk: Boolean,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (!primaryProvider.isReady || _isUsingFallback.value) {
            executeFallbackChunk(
                reason = if (_isUsingFallback.value) "Active fallback mode" else "Neural TTS not configured",
                chunk = chunk,
                isLastChunk = isLastChunk,
                profile = profile,
                volume = volume,
                speed = speed,
                utteranceId = utteranceId,
                onStart = onStart,
                onDone = onDone,
                onError = onError
            )
            return
        }

        primaryProvider.speakChunk(
            chunk = chunk,
            isLastChunk = isLastChunk,
            profile = profile,
            volume = volume,
            speed = speed,
            utteranceId = utteranceId,
            onStart = {
                _isUsingFallback.value = false
                _statusNotice.value = null
                onStart()
            },
            onDone = onDone,
            onError = { chunkError ->
                executeFallbackChunk(
                    reason = chunkError,
                    chunk = chunk,
                    isLastChunk = isLastChunk,
                    profile = profile,
                    volume = volume,
                    speed = speed,
                    utteranceId = utteranceId,
                    onStart = onStart,
                    onDone = onDone,
                    onError = onError
                )
            }
        )
    }

    private fun executeFallback(
        reason: String,
        text: String,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        Log.w(TAG, "VOICE_TTS_FALLBACK: Switching to Android system TTS. Reason: $reason")
        _isUsingFallback.value = true
        _statusNotice.value = "Using device voice"

        fallbackProvider.speak(
            text = text,
            profile = profile,
            volume = volume,
            speed = speed,
            utteranceId = utteranceId,
            onStart = onStart,
            onDone = onDone,
            onError = onError
        )
    }

    private fun executeFallbackChunk(
        reason: String,
        chunk: String,
        isLastChunk: Boolean,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        Log.w(TAG, "VOICE_TTS_FALLBACK: Chunk fallback to Android system TTS. Reason: $reason")
        _isUsingFallback.value = true
        _statusNotice.value = "Using device voice"

        fallbackProvider.speakChunk(
            chunk = chunk,
            isLastChunk = isLastChunk,
            profile = profile,
            volume = volume,
            speed = speed,
            utteranceId = utteranceId,
            onStart = onStart,
            onDone = onDone,
            onError = onError
        )
    }

    override fun stop() {
        primaryProvider.stop()
        fallbackProvider.stop()
    }

    override fun destroy() {
        primaryProvider.destroy()
        fallbackProvider.destroy()
    }
}
