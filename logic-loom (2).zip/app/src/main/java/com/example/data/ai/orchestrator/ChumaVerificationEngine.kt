package com.example.data.ai.orchestrator

import com.example.data.ai.orchestrator.tools.ToolResult

/**
 * Result of verification checks performed on synthesized responses.
 */
data class VerificationResult(
    val isValid: Boolean,
    val verifiedOutput: String,
    val notes: String? = null,
    val issuesFound: List<String> = emptyList()
)

/**
 * Lightweight verification engine ensuring responses are honest, grounded,
 * consistent, and free of hallucinated actions or fabricated citations.
 */
object ChumaVerificationEngine {

    /**
     * Verifies the response against intent, executed tools, and sources.
     */
    fun verify(
        rawOutput: String,
        intent: ChumaIntent,
        executedTools: List<Pair<String, ToolResult>>,
        sources: List<String>,
        isSearchAvailable: Boolean
    ): VerificationResult {
        var output = rawOutput.trim()
        val issues = mutableListOf<String>()

        // 1. Check for empty or whitespace output
        if (output.isBlank()) {
            return VerificationResult(
                isValid = false,
                verifiedOutput = "Chuma could not generate a response for this query. Please rephrase or try again.",
                notes = "Empty output detected",
                issuesFound = listOf("EMPTY_RESPONSE")
            )
        }

        // 2. Prevent hallucinated tool actions when tools were not executed
        // e.g., claiming to have booked a ride or transferred funds
        if (output.contains("booked your uber", ignoreCase = true) || output.contains("dispatched a bolt", ignoreCase = true)) {
            issues.add("UNVERIFIED_RIDE_DISPATCH")
            output = "Logic Loom provides local campus schedule assistance, but external ride dispatch (Uber/Bolt) is not directly supported. Please book directly in the respective app."
        }

        if (output.contains("transferred the money", ignoreCase = true) || output.contains("payment has been processed", ignoreCase = true)) {
            issues.add("UNVERIFIED_PAYMENT")
            output = "Direct bank fund transfers are unavailable in this environment. Your budget entries can be logged locally, but no real money was transferred."
        }

        // 3. Search-dependent verification
        if (intent.isSearchRequired) {
            if (!isSearchAvailable) {
                // Cannot claim live search occurred if search capability is offline
                if (output.contains("I searched the web", ignoreCase = true) || output.contains("According to the latest search", ignoreCase = true)) {
                    issues.add("FABRICATED_SEARCH_CLAIM")
                    output = "Web search is currently unavailable. " + output.replace(Regex("(?i)I searched the web and found that|According to the latest search results,?"), "")
                }
            } else if (sources.isEmpty() && output.contains("[http", ignoreCase = true)) {
                // Strip fake hallucinated citations
                issues.add("FABRICATED_CITATION_DETECTED")
                output = output.replace(Regex("\\[https?://[^\\]]+\\]"), "")
            }
        }

        // 4. Failed tool execution check
        val failedTool = executedTools.firstOrNull { !it.second.success }
        if (failedTool != null && output.isBlank()) {
            issues.add("TOOL_FAILURE")
            output = "Unable to complete ${failedTool.first}: ${failedTool.second.error ?: "Operation encountered an issue."}"
        }

        // 5. Check whether the response is responsive to the prompt intent
        if (intent.taskType == ChumaTaskType.MATHEMATICS && executedTools.any { it.first == "calculator" && it.second.success }) {
            val calcResult = executedTools.first { it.first == "calculator" }.second
            if (!output.contains(calcResult.output) && calcResult.formattedMessage.isNotBlank()) {
                output = calcResult.formattedMessage
            }
        }

        // 6. Clean unnecessary conversational fluff if starting with repetitive filler
        output = removeConversationalFluff(output)

        val isValid = issues.isEmpty()
        return VerificationResult(
            isValid = isValid,
            verifiedOutput = output,
            notes = if (issues.isNotEmpty()) "Adjusted: ${issues.joinToString(", ")}" else "Passed all verification checks",
            issuesFound = issues
        )
    }

    private fun removeConversationalFluff(text: String): String {
        return text
            .replace(Regex("^(Sure thing!|Sure!|Absolutely!|Certainly!|Here is what you asked for:?|Here is the answer:?)\\s*", RegexOption.IGNORE_CASE), "")
            .trim()
    }
}
