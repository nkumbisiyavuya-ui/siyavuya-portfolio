package com.example.data.ai.orchestrator.memory

import com.example.data.ai.CanvasMateContext

/**
 * Abstraction for retrieving relevant user, project, or persistent memory.
 * Does NOT create fake memory or mock databases.
 */
interface MemoryProvider {
    suspend fun retrieveRelevantMemory(
        prompt: String,
        conversationId: String,
        context: CanvasMateContext?
    ): String?
}

/**
 * Default implementation extracting strictly available context from the active workspace snapshot
 * without fabricating memories.
 */
class DefaultMemoryProvider : MemoryProvider {
    override suspend fun retrieveRelevantMemory(
        prompt: String,
        conversationId: String,
        context: CanvasMateContext?
    ): String? {
        if (context == null) return null

        val relevantSnippets = mutableListOf<String>()

        // 1. Check if user is asking about their own profile / courses / modules
        val lower = prompt.lowercase()
        if (lower.contains("my course") || lower.contains("my module") || lower.contains("my gpa") || lower.contains("my grade")) {
            if (context.gpaModules.isNotEmpty()) {
                val modulesSummary = context.gpaModules.joinToString(", ") { "${it.moduleCode} (${it.mark}%)" }
                relevantSnippets.add("Enrolled Modules: $modulesSummary")
            }
            context.userProfile?.let { prof ->
                if (prof.university.isNotBlank()) {
                    relevantSnippets.add("University: ${prof.university} (${prof.course})")
                }
            }
        }

        // 2. Check if user is asking about tasks or reminders
        if (lower.contains("my task") || lower.contains("due") || lower.contains("deadline") || lower.contains("homework")) {
            val pendingTasks = context.academicTasks.filter { it.status != "Completed" }
            if (pendingTasks.isNotEmpty()) {
                val taskSummary = pendingTasks.take(5).joinToString("; ") { "${it.title} (due: ${it.dueDate})" }
                relevantSnippets.add("Pending Academic Tasks: $taskSummary")
            }
        }

        return if (relevantSnippets.isNotEmpty()) {
            relevantSnippets.joinToString("\n")
        } else {
            null
        }
    }
}
