package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for Academic Schedules.
 */
@Dao
interface AcademicScheduleDao {

    @Query("SELECT * FROM academic_schedules ORDER BY dayOfWeek ASC, startTime ASC")
    fun getAllSchedulesFlow(): Flow<List<AcademicSchedule>>

    @Query("SELECT * FROM academic_schedules ORDER BY dayOfWeek ASC, startTime ASC")
    suspend fun getAllSchedules(): List<AcademicSchedule>

    @Query("SELECT * FROM academic_schedules WHERE dayOfWeek = :day ORDER BY startTime ASC")
    fun getSchedulesForDayFlow(day: String): Flow<List<AcademicSchedule>>

    @Query("SELECT * FROM academic_schedules WHERE courseCode = :courseCode ORDER BY startTime ASC")
    fun getSchedulesForCourseFlow(courseCode: String): Flow<List<AcademicSchedule>>

    @Query("SELECT * FROM academic_schedules WHERE id = :id LIMIT 1")
    suspend fun getScheduleById(id: Long): AcademicSchedule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: AcademicSchedule): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedules(schedules: List<AcademicSchedule>)

    @Update
    suspend fun updateSchedule(schedule: AcademicSchedule)

    @Delete
    suspend fun deleteSchedule(schedule: AcademicSchedule)

    @Query("DELETE FROM academic_schedules WHERE id = :id")
    suspend fun deleteScheduleById(id: Long)

    @Query("DELETE FROM academic_schedules")
    suspend fun clearAllSchedules()
}
