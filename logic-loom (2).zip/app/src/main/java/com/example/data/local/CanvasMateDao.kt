package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CanvasMateDao {
    // User Profile
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getUserProfileDirect(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUserProfile(profile: UserProfile)

    @Update
    suspend fun updateUserProfile(profile: UserProfile)

    @Delete
    suspend fun deleteUserProfile(profile: UserProfile)

    // Academic Tasks
    @Query("SELECT * FROM academic_tasks ORDER BY dueDate ASC")
    fun getAllAcademicTasks(): Flow<List<AcademicTask>>

    @Query("SELECT * FROM academic_tasks WHERE id = :id LIMIT 1")
    fun getAcademicTaskById(id: Long): Flow<AcademicTask?>

    @Query("SELECT * FROM academic_tasks WHERE status = :status ORDER BY dueDate ASC")
    fun getAcademicTasksByStatus(status: String): Flow<List<AcademicTask>>

    @Query("SELECT * FROM academic_tasks WHERE module = :module ORDER BY dueDate ASC")
    fun getAcademicTasksByModule(module: String): Flow<List<AcademicTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAcademicTask(task: AcademicTask): Long

    @Update
    suspend fun updateAcademicTask(task: AcademicTask)

    @Query("DELETE FROM academic_tasks WHERE id = :id")
    suspend fun deleteAcademicTask(id: Long)

    @Delete
    suspend fun deleteAcademicTask(task: AcademicTask)

    // GPA Modules
    @Query("SELECT * FROM gpa_modules ORDER BY id ASC")
    fun getAllGpaModules(): Flow<List<GpaModule>>

    @Query("SELECT * FROM gpa_modules WHERE id = :id LIMIT 1")
    fun getGpaModuleById(id: Long): Flow<GpaModule?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGpaModule(module: GpaModule): Long

    @Update
    suspend fun updateGpaModule(module: GpaModule)

    @Query("DELETE FROM gpa_modules WHERE id = :id")
    suspend fun deleteGpaModule(id: Long)

    @Delete
    suspend fun deleteGpaModule(module: GpaModule)

    // Budget Items
    @Query("SELECT * FROM budget_items ORDER BY id DESC")
    fun getAllBudgetItems(): Flow<List<BudgetItem>>

    @Query("SELECT * FROM budget_items WHERE id = :id LIMIT 1")
    fun getBudgetItemById(id: Long): Flow<BudgetItem?>

    @Query("SELECT * FROM budget_items WHERE type = :type ORDER BY id DESC")
    fun getBudgetItemsByType(type: String): Flow<List<BudgetItem>>

    @Query("SELECT * FROM budget_items WHERE category = :category ORDER BY id DESC")
    fun getBudgetItemsByCategory(category: String): Flow<List<BudgetItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudgetItem(item: BudgetItem): Long

    @Update
    suspend fun updateBudgetItem(item: BudgetItem)

    @Query("DELETE FROM budget_items WHERE id = :id")
    suspend fun deleteBudgetItem(id: Long)

    @Delete
    suspend fun deleteBudgetItem(item: BudgetItem)

    // Budget Goals
    @Query("SELECT * FROM budget_goals")
    fun getAllBudgetGoals(): Flow<List<BudgetGoal>>

    @Query("SELECT * FROM budget_goals WHERE id = :id LIMIT 1")
    fun getBudgetGoalById(id: Long): Flow<BudgetGoal?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudgetGoal(goal: BudgetGoal): Long

    @Update
    suspend fun updateBudgetGoal(goal: BudgetGoal)

    @Query("DELETE FROM budget_goals WHERE id = :id")
    suspend fun deleteBudgetGoal(id: Long)

    @Delete
    suspend fun deleteBudgetGoal(goal: BudgetGoal)

    // Calendar Events
    @Query("SELECT * FROM calendar_events ORDER BY date ASC, time ASC")
    fun getAllCalendarEvents(): Flow<List<CalendarEvent>>

    @Query("SELECT * FROM calendar_events WHERE id = :id LIMIT 1")
    fun getCalendarEventById(id: Long): Flow<CalendarEvent?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarEvent(event: CalendarEvent): Long

    @Update
    suspend fun updateCalendarEvent(event: CalendarEvent)

    @Query("DELETE FROM calendar_events WHERE id = :id")
    suspend fun deleteCalendarEvent(id: Long)

    @Delete
    suspend fun deleteCalendarEvent(event: CalendarEvent)

    // Timetable Slots
    @Query("SELECT * FROM timetable_slots ORDER BY startTime ASC")
    fun getAllTimetableSlots(): Flow<List<TimetableSlot>>

    @Query("SELECT * FROM timetable_slots WHERE id = :id LIMIT 1")
    fun getTimetableSlotById(id: Long): Flow<TimetableSlot?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetableSlot(slot: TimetableSlot): Long

    @Update
    suspend fun updateTimetableSlot(slot: TimetableSlot)

    @Query("DELETE FROM timetable_slots WHERE id = :id")
    suspend fun deleteTimetableSlot(id: Long)

    @Delete
    suspend fun deleteTimetableSlot(slot: TimetableSlot)

    // Note Items
    @Query("SELECT * FROM note_items ORDER BY isPinned DESC, id DESC")
    fun getAllNotes(): Flow<List<NoteItem>>

    @Query("SELECT * FROM note_items WHERE id = :id LIMIT 1")
    fun getNoteById(id: Long): Flow<NoteItem?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteItem): Long

    @Update
    suspend fun updateNote(note: NoteItem)

    @Query("DELETE FROM note_items WHERE id = :id")
    suspend fun deleteNote(id: Long)

    @Delete
    suspend fun deleteNote(note: NoteItem)

    // Vault Documents
    @Query("SELECT * FROM vault_documents ORDER BY id DESC")
    fun getAllVaultDocuments(): Flow<List<VaultDocument>>

    @Query("SELECT * FROM vault_documents WHERE id = :id LIMIT 1")
    fun getVaultDocumentById(id: Long): Flow<VaultDocument?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultDocument(doc: VaultDocument): Long

    @Update
    suspend fun updateVaultDocument(doc: VaultDocument)

    @Query("DELETE FROM vault_documents WHERE id = :id")
    suspend fun deleteVaultDocument(id: Long)

    @Delete
    suspend fun deleteVaultDocument(doc: VaultDocument)

    // Goal Items
    @Query("SELECT * FROM goal_items ORDER BY id DESC")
    fun getAllGoals(): Flow<List<GoalItem>>

    @Query("SELECT * FROM goal_items WHERE id = :id LIMIT 1")
    fun getGoalById(id: Long): Flow<GoalItem?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalItem): Long

    @Update
    suspend fun updateGoal(goal: GoalItem)

    @Query("DELETE FROM goal_items WHERE id = :id")
    suspend fun deleteGoal(id: Long)

    @Delete
    suspend fun deleteGoal(goal: GoalItem)

    // Diary Entries
    @Query("SELECT * FROM diary_entries ORDER BY id DESC")
    fun getAllDiaryEntries(): Flow<List<DiaryEntry>>

    @Query("SELECT * FROM diary_entries WHERE id = :id LIMIT 1")
    fun getDiaryEntryById(id: Long): Flow<DiaryEntry?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiaryEntry(entry: DiaryEntry): Long

    @Update
    suspend fun updateDiaryEntry(entry: DiaryEntry)

    @Query("DELETE FROM diary_entries WHERE id = :id")
    suspend fun deleteDiaryEntry(id: Long)

    @Delete
    suspend fun deleteDiaryEntry(entry: DiaryEntry)

    // Todo Tasks
    @Query("SELECT * FROM todo_tasks ORDER BY isCompleted ASC, priority DESC, id DESC")
    fun getAllTodoTasks(): Flow<List<TodoTask>>

    @Query("SELECT * FROM todo_tasks WHERE id = :id LIMIT 1")
    fun getTodoTaskById(id: Long): Flow<TodoTask?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodoTask(task: TodoTask): Long

    @Update
    suspend fun updateTodoTask(task: TodoTask)

    @Query("DELETE FROM todo_tasks WHERE id = :id")
    suspend fun deleteTodoTask(id: Long)

    @Delete
    suspend fun deleteTodoTask(task: TodoTask)

    // Shuttle Schedules
    @Query("SELECT * FROM shuttle_schedules ORDER BY departureTime ASC")
    fun getAllShuttleSchedules(): Flow<List<ShuttleSchedule>>

    @Query("SELECT * FROM shuttle_schedules WHERE id = :id LIMIT 1")
    fun getShuttleScheduleById(id: Long): Flow<ShuttleSchedule?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShuttleSchedule(shuttle: ShuttleSchedule): Long

    @Update
    suspend fun updateShuttleSchedule(shuttle: ShuttleSchedule)

    @Query("DELETE FROM shuttle_schedules WHERE id = :id")
    suspend fun deleteShuttleSchedule(id: Long)

    @Delete
    suspend fun deleteShuttleSchedule(shuttle: ShuttleSchedule)

    // ZAR Exchange Rates Caching
    @Query("SELECT * FROM zar_exchange_rates")
    fun getAllExchangeRates(): Flow<List<ExchangeRateEntity>>

    @Query("SELECT * FROM zar_exchange_rates")
    suspend fun getAllExchangeRatesDirect(): List<ExchangeRateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExchangeRates(rates: List<ExchangeRateEntity>)

    @Query("DELETE FROM zar_exchange_rates")
    suspend fun clearExchangeRates()

    // Global Search Room Queries
    @Query("SELECT * FROM note_items WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR folder LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' ORDER BY isPinned DESC, id DESC")
    fun searchNotes(query: String): Flow<List<NoteItem>>

    @Query("SELECT * FROM academic_tasks WHERE title LIKE '%' || :query || '%' OR module LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' OR taskType LIKE '%' || :query || '%' ORDER BY dueDate ASC")
    fun searchAcademicTasks(query: String): Flow<List<AcademicTask>>

    @Query("SELECT * FROM budget_items WHERE title LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' OR type LIKE '%' || :query || '%' ORDER BY id DESC")
    fun searchBudgetItems(query: String): Flow<List<BudgetItem>>

    @Query("SELECT * FROM vault_documents WHERE title LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' OR fileType LIKE '%' || :query || '%' ORDER BY id DESC")
    fun searchVaultDocuments(query: String): Flow<List<VaultDocument>>

    // Flashcard Decks & Cards
    @Query("SELECT * FROM flashcard_decks ORDER BY id DESC")
    fun getAllFlashcardDecks(): Flow<List<FlashcardDeck>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcardDeck(deck: FlashcardDeck): Long

    @Query("DELETE FROM flashcard_decks WHERE id = :deckId")
    suspend fun deleteFlashcardDeck(deckId: Long)

    @Query("SELECT * FROM flashcards WHERE deckId = :deckId ORDER BY id ASC")
    fun getFlashcardsForDeck(deckId: Long): Flow<List<Flashcard>>

    @Query("SELECT * FROM flashcards ORDER BY id ASC")
    fun getAllFlashcards(): Flow<List<Flashcard>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcard(card: Flashcard): Long

    @Update
    suspend fun updateFlashcard(card: Flashcard)

    @Query("DELETE FROM flashcards WHERE id = :cardId")
    suspend fun deleteFlashcard(cardId: Long)

    // Shopping Items
    @Query("SELECT * FROM shopping_items ORDER BY isPurchased ASC, isUrgent DESC, id DESC")
    fun getAllShoppingItems(): Flow<List<ShoppingItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingItem(item: ShoppingItem): Long

    @Update
    suspend fun updateShoppingItem(item: ShoppingItem)

    @Query("DELETE FROM shopping_items WHERE id = :id")
    suspend fun deleteShoppingItem(id: Long)

    // Transport Requests
    @Query("SELECT * FROM transport_requests ORDER BY id DESC")
    fun getAllTransportRequests(): Flow<List<TransportRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransportRequest(request: TransportRequest): Long

    @Update
    suspend fun updateTransportRequest(request: TransportRequest)

    @Query("DELETE FROM transport_requests WHERE id = :id")
    suspend fun deleteTransportRequest(id: Long)

    // Food Orders
    @Query("SELECT * FROM food_orders ORDER BY id DESC")
    fun getAllFoodOrders(): Flow<List<FoodOrder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFoodOrder(order: FoodOrder): Long

    @Update
    suspend fun updateFoodOrder(order: FoodOrder)

    @Query("DELETE FROM food_orders WHERE id = :id")
    suspend fun deleteFoodOrder(id: Long)

    // Payment Methods
    @Query("SELECT * FROM payment_methods ORDER BY isDefault DESC, id ASC")
    fun getAllPaymentMethods(): Flow<List<PaymentMethodEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentMethod(method: PaymentMethodEntity): Long

    @Query("DELETE FROM payment_methods WHERE id = :id")
    suspend fun deletePaymentMethod(id: Long)

    // Tasks (South African Academic Tasks)
    @Query("SELECT * FROM tasks ORDER BY dueDate ASC")
    fun getAllTasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    fun getTaskById(id: Long): Flow<Task?>

    @Query("SELECT * FROM tasks WHERE courseCode = :courseCode ORDER BY dueDate ASC")
    fun getTasksByCourseCode(courseCode: String): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE academicPeriod = :academicPeriod ORDER BY dueDate ASC")
    fun getTasksByAcademicPeriod(academicPeriod: String): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task): Long

    @Update
    suspend fun updateTask(task: Task)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTask(id: Long)

    @Delete
    suspend fun deleteTask(task: Task)

    // Courses (South African Academic Courses)
    @Query("SELECT * FROM courses ORDER BY courseCode ASC")
    fun getAllCourses(): Flow<List<Course>>

    @Query("SELECT * FROM courses WHERE id = :id LIMIT 1")
    fun getCourseById(id: Long): Flow<Course?>

    @Query("SELECT * FROM courses WHERE courseCode = :courseCode LIMIT 1")
    fun getCourseByCode(courseCode: String): Flow<Course?>

    @Query("SELECT * FROM courses WHERE academicPeriod = :academicPeriod ORDER BY courseCode ASC")
    fun getCoursesByAcademicPeriod(academicPeriod: String): Flow<List<Course>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: Course): Long

    @Update
    suspend fun updateCourse(course: Course)

    @Query("DELETE FROM courses WHERE id = :id")
    suspend fun deleteCourse(id: Long)

    @Delete
    suspend fun deleteCourse(course: Course)

    // Reminders
    @Query("SELECT * FROM reminders WHERE isDismissed = 0 ORDER BY reminderDateTime ASC")
    fun getAllActiveReminders(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders ORDER BY reminderDateTime ASC")
    fun getAllReminders(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    fun getReminderById(id: Long): Flow<Reminder?>

    @Query("SELECT * FROM reminders WHERE courseCode = :courseCode ORDER BY reminderDateTime ASC")
    fun getRemindersByCourseCode(courseCode: String): Flow<List<Reminder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: Reminder): Long

    @Update
    suspend fun updateReminder(reminder: Reminder)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminder(id: Long)

    @Delete
    suspend fun deleteReminder(reminder: Reminder)

    // Data Integrity: Purge legacy sample data
    @Query("DELETE FROM shopping_items WHERE itemTitle IN ('Full Cream Milk (2L)', 'Whole Wheat Bread', 'A4 Exam Pad (100 pgs)', 'Nescafé Classic Coffee')")
    suspend fun purgeSampleShoppingItems()

    @Query("DELETE FROM academic_tasks WHERE title IN ('CSC3002F Distributed Systems Project', 'MTH3012S Complex Analysis Test 2', 'INF3003W Database Architecture Seminar')")
    suspend fun purgeSampleTasks()

    @Query("DELETE FROM transport_requests WHERE origin IN ('Tugwell Residence', 'Main Campus')")
    suspend fun purgeSampleTransportRequests()

    @Query("DELETE FROM shuttle_schedules WHERE routeName LIKE '%Jammie Shuttle - Tugwell%'")
    suspend fun purgeSampleShuttles()

    @Query("DELETE FROM gpa_modules WHERE moduleCode IN ('CSC3002F', 'MTH3012S', 'INF3003W', 'STA2004F')")
    suspend fun purgeSampleGpaModules()

    @Query("DELETE FROM timetable_slots WHERE module IN ('CSC3002F', 'MTH3012S', 'INF3003W', 'CSC3002F Practical', 'MTH3012S Tutorial')")
    suspend fun purgeSampleTimetableSlots()

    @Query("DELETE FROM calendar_events WHERE title IN ('CSC3002F Lecture - Raft Protocol', 'CSC3002F Project Milestone 1', 'DevX Labs Hackathon 2026', 'MTH3012S Term Test 2', 'Campus Tech Social Meetup')")
    suspend fun purgeSampleCalendarEvents()

    @Query("DELETE FROM budget_goals WHERE title IN ('Laptop Replacement Fund', 'December Vacation Trip')")
    suspend fun purgeSampleBudgetGoals()

    @Query("DELETE FROM budget_items WHERE title IN ('Monthly Allowance', 'Monthly Grocery Run', 'Part-time Tutoring', 'Mobile Data & WiFi bundle')")
    suspend fun purgeSampleBudgetItems()
}



