package com.example.data.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Structured result model for web search responses.
 */
data class WebSearchResult(
    val title: String,
    val url: String,
    val domain: String,
    val snippet: String,
    val publishedDate: String? = null,
    val retrievalTimestamp: Long = System.currentTimeMillis()
)

data class WebSearchResponse(
    val success: Boolean,
    val query: String,
    val results: List<WebSearchResult>,
    val formattedAnswer: String,
    val errorMessage: String? = null
)

/**
 * WebSearchTool executes real, live web searches, retrieves genuine search snippets,
 * formats verified citations, and avoids fake hallucinations.
 */
object WebSearchTool {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /**
     * Executes a live web search for the query with structured snippets and verifiable URLs.
     */
    suspend fun searchWeb(rawQuery: String): WebSearchResponse = withContext(Dispatchers.IO) {
        val query = cleanSearchQuery(rawQuery)
        if (query.isBlank()) {
            return@withContext WebSearchResponse(
                success = false,
                query = rawQuery,
                results = emptyList(),
                formattedAnswer = "Please provide a specific search query.",
                errorMessage = "Empty query"
            )
        }

        try {
            // 1. Check if direct DuckDuckGo Instant Answer API / Wikipedia API returns structured knowledge
            val encoded = URLEncoder.encode(query, "UTF-8")
            val ddgUrl = "https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1"
            val request = Request.Builder()
                .url(ddgUrl)
                .header("User-Agent", "LogicLoom-Chuma/1.0")
                .get()
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            val results = mutableListOf<WebSearchResult>()
            if (response.isSuccessful && body.isNotBlank()) {
                val json = JSONObject(body)
                val abstractText = json.optString("AbstractText", "")
                val abstractSource = json.optString("AbstractSource", "")
                val abstractUrl = json.optString("AbstractURL", "")
                val heading = json.optString("Heading", query)

                if (abstractText.isNotBlank() && abstractUrl.isNotBlank()) {
                    val domain = extractDomain(abstractUrl)
                    results.add(
                        WebSearchResult(
                            title = heading.ifBlank { query },
                            url = abstractUrl,
                            domain = if (abstractSource.isNotBlank()) abstractSource else domain,
                            snippet = abstractText.take(300),
                            publishedDate = null,
                            retrievalTimestamp = System.currentTimeMillis()
                        )
                    )
                }

                // Check RelatedTopics
                val related = json.optJSONArray("RelatedTopics")
                if (related != null) {
                    for (i in 0 until minOf(related.length(), 4)) {
                        val item = related.optJSONObject(i) ?: continue
                        val text = item.optString("Text", "")
                        val firstUrl = item.optString("FirstURL", "")
                        if (text.isNotBlank() && firstUrl.isNotBlank()) {
                            val domain = extractDomain(firstUrl)
                            val title = text.substringBefore(" - ").take(80)
                            results.add(
                                WebSearchResult(
                                    title = title,
                                    url = firstUrl,
                                    domain = domain,
                                    snippet = text.take(250),
                                    publishedDate = null,
                                    retrievalTimestamp = System.currentTimeMillis()
                                )
                            )
                        }
                    }
                }
            }

            // 2. If DDG instant answer was empty, query Wikipedia REST API for structured factual articles
            if (results.isEmpty()) {
                val wikiUrl = "https://en.wikipedia.org/api/rest_v1/page/summary/$encoded"
                val wikiReq = Request.Builder()
                    .url(wikiUrl)
                    .header("User-Agent", "LogicLoom-Chuma/1.0")
                    .get()
                    .build()
                val wikiResp = httpClient.newCall(wikiReq).execute()
                val wikiBody = wikiResp.body?.string() ?: ""
                if (wikiResp.isSuccessful && wikiBody.isNotBlank()) {
                    val wikiJson = JSONObject(wikiBody)
                    val extract = wikiJson.optString("extract", "")
                    val title = wikiJson.optString("title", query)
                    val pageUrl = wikiJson.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page", "https://en.wikipedia.org/wiki/$encoded")
                        ?: "https://en.wikipedia.org/wiki/$encoded"

                    if (extract.isNotBlank()) {
                        results.add(
                            WebSearchResult(
                                title = title,
                                url = pageUrl,
                                domain = "wikipedia.org",
                                snippet = extract.take(350),
                                publishedDate = null,
                                retrievalTimestamp = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }

            if (results.isNotEmpty()) {
                val formatted = buildStructuredSearchReport(query, results)
                return@withContext WebSearchResponse(
                    success = true,
                    query = query,
                    results = results,
                    formattedAnswer = formatted
                )
            } else {
                // If live search returned no direct index match
                return@withContext WebSearchResponse(
                    success = false,
                    query = query,
                    results = emptyList(),
                    formattedAnswer = "I couldn't find live verified search results for '$query'. Please try refining your search terms.",
                    errorMessage = "No search results returned"
                )
            }
        } catch (e: Exception) {
            return@withContext WebSearchResponse(
                success = false,
                query = query,
                results = emptyList(),
                formattedAnswer = "I can't access live web information right now. Please check your network connection and try again.",
                errorMessage = e.message
            )
        }
    }

    /**
     * Builds transparent search summary report with genuine citations.
     */
    fun buildStructuredSearchReport(query: String, results: List<WebSearchResult>): String {
        val topResult = results.first()
        val formattedDate = SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date())

        val citations = results.distinctBy { it.url }.joinToString("\n") { r ->
            "• [${r.title}](${r.url}) — *${r.domain}*"
        }

        return """
            🌐 **Search Results for "${query}"**
            
            ${topResult.snippet}
            
            **Sources & Citations** (Retrieved: $formattedDate):
            $citations
        """.trimIndent()
    }

    private fun cleanSearchQuery(raw: String): String {
        return raw
            .replace("search the web for", "", ignoreCase = true)
            .replace("search the internet for", "", ignoreCase = true)
            .replace("search for", "", ignoreCase = true)
            .replace("search web for", "", ignoreCase = true)
            .replace("search", "", ignoreCase = true)
            .replace("google", "", ignoreCase = true)
            .replace("find information about", "", ignoreCase = true)
            .replace("find info on", "", ignoreCase = true)
            .replace("what is the latest news about", "", ignoreCase = true)
            .replace("latest news about", "", ignoreCase = true)
            .replace("?", "")
            .trim()
    }

    private fun extractDomain(url: String): String {
        return try {
            val uri = java.net.URI(url)
            val host = uri.host ?: ""
            host.removePrefix("www.")
        } catch (e: Exception) {
            "web-source"
        }
    }
}
