package com.example.data.ai

import com.example.data.local.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

object CanvasMateAiOrchestrator {

    private val orchestrator = AiOrchestrator()
    private val chumaOrchestrator = com.example.data.ai.orchestrator.ChumaOrchestrator()

    /**
     * Master entry point for Chuma v1 Central Intelligence Orchestration.
     */
    suspend fun processUserPrompt(
        prompt: String,
        sourceMode: String,
        context: CanvasMateContext,
        history: List<Pair<String, String>> = emptyList(),
        onChunk: ((String) -> Unit)? = null
    ): String {
        val executionContext = com.example.data.ai.orchestrator.ChumaExecutionContext(
            userRequest = prompt,
            conversationHistory = history,
            canvasContext = context,
            onChunk = onChunk
        )
        return chumaOrchestrator.process(prompt, executionContext).output
    }

    private fun isAcademicCalculatorQuery(lower: String): Boolean {
        return (lower.contains("pass") || lower.contains("mark") || lower.contains("exam") || lower.contains("needed") || lower.contains("calculate") || lower.contains("grade") || lower.contains("%") || lower.contains("average")) &&
                (lower.contains("test") || lower.contains("assignment") || lower.contains("coursework") || lower.contains("need") || lower.contains("what if") || lower.contains("final"))
    }

    private fun processAcademicCalculator(prompt: String, context: CanvasMateContext): String {
        val numbers = Regex("(\\d+(?:\\.\\d+)?)%?").findAll(prompt).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()

        if (numbers.size >= 3) {
            val assignmentWeight = numbers.getOrNull(0) ?: 30.0
            val assignmentMark = numbers.getOrNull(1) ?: 60.0
            val testWeight = numbers.getOrNull(2) ?: 20.0
            val testMark = numbers.getOrNull(3) ?: 50.0
            val examWeight = numbers.getOrNull(4) ?: (100.0 - assignmentWeight - testWeight).coerceAtLeast(10.0)
            val targetPass = if (prompt.contains("70")) 70.0 else 50.0

            val currentContrib1 = (assignmentMark * (assignmentWeight / 100.0))
            val currentContrib2 = (testMark * (testWeight / 100.0))
            val currentTotalCoursework = currentContrib1 + currentContrib2
            val remainingNeeded = (targetPass - currentTotalCoursework).coerceAtLeast(0.0)
            val requiredExamMark = (remainingNeeded / (examWeight / 100.0)).coerceIn(0.0, 100.0)

            return """
🎓 **Academic Calculator & Grade Scenario**

📌 **Assessment Breakdown**:
• Assessment 1 (${assignmentWeight.roundToInt()}% Weight): **${assignmentMark.roundToInt()}%** ➔ Contributes **${"%.1f".format(currentContrib1)}%**
• Assessment 2 (${testWeight.roundToInt()}% Weight): **${testMark.roundToInt()}%** ➔ Contributes **${"%.1f".format(currentContrib2)}%**
• **Current Weighted Coursework Total**: **${"%.1f".format(currentTotalCoursework)}%** (out of ${(assignmentWeight + testWeight).roundToInt()}%)

🎯 **Target Overall Final Mark**: **${targetPass.roundToInt()}%**
📐 **Remaining Exam Weight**: **${examWeight.roundToInt()}%**

💡 **Result Calculation**:
To achieve your target of **${targetPass.roundToInt()}%**, you need to score approximately **${"%.1f".format(requiredExamMark)}%** (approx. **${requiredExamMark.roundToInt()}%**) in your final exam (${examWeight.roundToInt()}% weight).

[CARD_ACADEMIC:Score=${"%.1f".format(currentTotalCoursework)}|Required=${requiredExamMark.roundToInt()}|Target=${targetPass.roundToInt()}]
            """.trimIndent()
        }

        val modules = context.gpaModules
        if (modules.isNotEmpty()) {
            val totalCredits = modules.sumOf { it.credits }
            val weightedScore = modules.sumOf { it.mark * it.credits }
            val avg = if (totalCredits > 0) weightedScore / totalCredits else 0.0

            return """
🎓 **Logic Loom GPA & Module Summary**

📍 **Registered Modules**: ${modules.size}
📊 **Cumulative GPA / Average**: **${"%.1f".format(avg)}%**

Module Breakdown:
${modules.joinToString("\n") { "• **${it.moduleCode}** (${it.credits} Credits): **${it.mark}%**" }}

💡 *Tip*: Tell me your assignment and test marks to calculate exact required exam scores!
            """.trimIndent()
        }

        return """
🎓 **Academic Calculator Helper**

To compute your required exam mark, tell me:
1. Your assignment mark & weight (e.g., "62% on 30% assignment")
2. Your test mark & weight (e.g., "48% on 20% test")
3. Your exam weight (e.g., "50% exam")

Example: *"My assignment is 30% and I got 62%. My test is 20% and I got 48%. What do I need in the 50% exam to pass with 50%?"*
        """.trimIndent()
    }

    private fun processWeatherIntelligence(prompt: String, context: CanvasMateContext): String {
        val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        val dateStr = dateFormat.format(Date())
        val area = context.userLocationArea

        val isColdOrRainy = prompt.contains("jacket") || prompt.contains("cold") || prompt.contains("umbrella")
        val temp = if (isColdOrRainy) 16 else 21
        val condition = if (isColdOrRainy) "Cool with afternoon showers" else "Partly sunny with mild coastal breeze"
        val rainChance = if (isColdOrRainy) 65 else 15

        val clothingAdvice = if (rainChance > 50) {
            "🌧️ **Rain Expected Later**: Long pants, a warm top, and a waterproof jacket or coat. **Definitely bring an umbrella** for walking between lectures!"
        } else if (temp < 18) {
            "🧥 **Cool Conditions**: A long-sleeve top and a light jacket or hoodie will keep you comfortable on campus."
        } else {
            "👕 **Mild & Pleasant**: Jeans/trousers with a T-shirt or light shirt. A light jacket is recommended if staying out past sunset."
        }

        return """
🌤️ **Logic Loom Weather & Campus Advice**
📅 **Date**: $dateStr
📍 **Area**: $area

• **Temperature**: ${temp}°C (High ${temp + 3}°C / Low ${temp - 6}°C)
• **Conditions**: $condition
• **Rain Probability**: $rainChance%
• **Wind Speed**: 18 km/h South-Westerly

👗 **Personal Clothing & Campus Advice**:
$clothingAdvice

[CARD_WEATHER:Temp=${temp}°C|Rain=$rainChance%|Condition=$condition]
        """.trimIndent()
    }

    private fun isNearbyLocationQuery(lower: String): Boolean {
        return lower.contains("nearest") || lower.contains("near me") || lower.contains("pharmacy") ||
                lower.contains("library") || lower.contains("coffee") || lower.contains("supermarket") ||
                lower.contains("atm") || lower.contains("study spot") || lower.contains("food near") ||
                lower.contains("print") || lower.contains("where is")
    }

    private fun processNearbyPlacesQuery(prompt: String, context: CanvasMateContext): String {
        val lower = prompt.lowercase()
        val area = context.userLocationArea

        return when {
            lower.contains("library") || lower.contains("study") -> """
📚 **Nearest Study & Library Spots**
📍 Near $area

1. **Central Campus Library**
   📍 0.8 km away • 🟢 Open until 22:00
   ⭐ 4.8/5 • Silent study zones, Wi-Fi, computer labs & power outlets.

2. **Jagger Knowledge Commons**
   📍 1.1 km away • 🟢 Open 24 Hours
   ⭐ 4.7/5 • Group study rooms & high-speed printing stations.

[CARD_LOCATION:Name=Central Campus Library|Dist=0.8 km|Status=Open until 22:00]
            """.trimIndent()

            lower.contains("pharmacy") || lower.contains("health") || lower.contains("doctor") -> """
💊 **Nearest Health & Pharmacy Services**
📍 Near $area

1. **Student Health Campus Pharmacy**
   📍 0.4 km away • 🟢 Open until 17:00
   ⭐ 4.6/5 • Prescription medicines, first aid & student medical aid support.

2. **Dis-Chem Pharmacies (Main Road)**
   📍 1.5 km away • 🟢 Open until 19:00
   ⭐ 4.5/5 • Full retail clinic, supplements & toiletries.

[CARD_LOCATION:Name=Student Health Campus Pharmacy|Dist=0.4 km|Status=Open until 17:00]
            """.trimIndent()

            lower.contains("coffee") || lower.contains("café") || lower.contains("cafe") -> """
☕ **Nearest Campus Coffee & Snack Spots**
📍 Near $area

1. **Faculty Quad Espresso Bar**
   📍 0.3 km away • 🟢 Open until 16:30
   ⭐ 4.8/5 • Artisan coffee, muffins, sandwiches under R50.

2. **Student Union Plaza Café**
   📍 0.6 km away • 🟢 Open until 18:00
   ⭐ 4.4/5 • Fresh juices, healthy wraps & outdoor seating.

[CARD_LOCATION:Name=Faculty Quad Espresso Bar|Dist=0.3 km|Status=Open until 16:30]
            """.trimIndent()

            else -> """
📍 **Nearby Campus Services & Places**
📍 Near $area

1. **Campus Student Centre & Food Court**
   📍 0.5 km away • 🟢 Open until 18:00
   ⭐ 4.6/5 • ATMs, printing shops, food outlets & grocery store.

2. **Main Administration & Student Helpdesk**
   📍 0.7 km away • 🟢 Open until 16:00
   ⭐ 4.3/5 • Card queries, transcript prints & financial aid assistance.

[CARD_LOCATION:Name=Campus Student Centre|Dist=0.5 km|Status=Open until 18:00]
            """.trimIndent()
        }
    }

    fun generateCustomStudyPlan(coursesStr: String, preferredTimesStr: String): String {
        val courseList = coursesStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val firstCourse = courseList.getOrNull(0) ?: "CSC3002F"
        val secondCourse = courseList.getOrNull(1) ?: "MTH3012S"
        val thirdCourse = courseList.getOrNull(2) ?: "EEE3096S"

        return """
📅 **Personalized Study Plan (August 2026)**

🎯 **Prioritized Focus Hierarchy**:
1. 🔴 HIGH PRIORITY: $firstCourse (Upcoming Deadline & Exam)
2. 🟡 MEDIUM PRIORITY: $secondCourse (Assignments & Core Problem Sets)
3. 🟢 ROUTINE REVISION: $thirdCourse (Lecture Summary & Concept Review)

⏰ **Preferred Study Windows**: $preferredTimesStr

📆 **Suggested Module Study Sessions**:
• [Session 1] Mon 08:00 - $firstCourse Intensive Problem Solving & Lab Work
• [Session 2] Tue 18:00 - $secondCourse Theorem Proofs & Tutorial Exercises
• [Session 3] Wed 08:00 - $firstCourse Assignment Project Development
• [Session 4] Thu 18:00 - $secondCourse Exam Past Paper Practice under timed conditions
• [Session 5] Fri 08:00 - $thirdCourse Lecture Notes Consolidation & Flashcard Drill

✅ **Actionable Study Tasks**:
• [Task 1] High Priority: Complete $firstCourse project implementation & test cases
• [Task 2] High Priority: Solve 2025 $firstCourse past exam paper questions 1-4
• [Task 3] Medium Priority: Work through $secondCourse tutorial problem set
• [Task 4] Medium Priority: Revise $secondCourse key proofs and formula sheet
• [Task 5] Routine Priority: Summarize $thirdCourse week 4 lecture slides
        """.trimIndent()
    }

    private suspend fun buildGroundedGeminiResponse(
        prompt: String,
        sourceMode: String,
        context: CanvasMateContext,
        minimalContext: String
    ): String {
        val user = context.userProfile
        val name = user?.fullName ?: "Student"

        val systemContextPrompt = """
            You are Chuma AI, an advanced, highly intelligent, and versatile AI assistant built into CanvasMate, developed and engineered by Moraigne.
            You provide clear, accurate, thoughtful, and comprehensive answers to any question.

            CONTEXT SUMMARY:
            $minimalContext
            Current Date: ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}

            INSTRUCTIONS:
            - Be helpful, direct, articulate, and intelligent.
            - Answer general knowledge, science, history, geography, lifestyle, code, and academic questions with precision and thoroughness.
            - Never start with generic filler or say "As an AI model".
        """.trimIndent()

        val fullPrompt = "$systemContextPrompt\n\nUSER PROMPT: $prompt"
        return GeminiClient.askGemini(fullPrompt, taskType = sourceMode)
    }
}
