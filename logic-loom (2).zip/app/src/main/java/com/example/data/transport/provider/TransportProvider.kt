package com.example.data.transport.provider

import com.example.data.transport.model.TransitStation
import com.example.data.transport.model.TransportMode
import com.example.data.transport.model.TransportOption
import com.example.data.transport.model.TransportSearchQuery

/**
 * Interface contract for all public and private transport information providers.
 * Implementations provide honest, sourced data and never pretend to execute rides/transactions.
 */
interface TransportProvider {
    val providerId: String
    val providerName: String
    val supportedModes: Set<TransportMode>
    val officialSourceInfo: String

    suspend fun getStations(): List<TransitStation>

    suspend fun searchRoutes(query: TransportSearchQuery): List<TransportOption>

    suspend fun findNearestStation(lat: Double, lng: Double): TransitStation?
}
