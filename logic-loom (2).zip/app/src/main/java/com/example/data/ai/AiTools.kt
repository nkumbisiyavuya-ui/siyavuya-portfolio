package com.example.data.ai

import org.json.JSONArray
import org.json.JSONObject

/**
 * Parameter definition for AI Tool inputs.
 */
data class AiToolParameter(
    val name: String,
    val type: String, // "STRING", "NUMBER", "INTEGER", "BOOLEAN"
    val description: String,
    val isRequired: Boolean = false
)

/**
 * Definition of an AI Tool for Gemini function calling and system action execution.
 */
data class AiTool(
    val name: String,
    val description: String,
    val parameters: List<AiToolParameter> = emptyList(),
    val handler: suspend (Map<String, Any?>) -> ToolExecutionResult
) {
    /**
     * Converts tool definition into Gemini API Function Declaration JSON object.
     */
    fun toGeminiFunctionDeclaration(): JSONObject {
        val funcObj = JSONObject()
        funcObj.put("name", name)
        funcObj.put("description", description)

        if (parameters.isNotEmpty()) {
            val propertiesObj = JSONObject()
            val requiredArray = JSONArray()

            parameters.forEach { param ->
                val paramObj = JSONObject()
                paramObj.put("type", param.type)
                paramObj.put("description", param.description)
                propertiesObj.put(param.name, paramObj)

                if (param.isRequired) {
                    requiredArray.put(param.name)
                }
            }

            val parametersObj = JSONObject()
            parametersObj.put("type", "OBJECT")
            parametersObj.put("properties", propertiesObj)
            if (requiredArray.length() > 0) {
                parametersObj.put("required", requiredArray)
            }
            funcObj.put("parameters", parametersObj)
        }

        return funcObj
    }
}

/**
 * Registry and Manager for AI Tools in Logic Loom.
 */
object AiToolRegistry {

    private val toolsMap = mutableMapOf<String, AiTool>()

    init {
        registerDefaultTools()
    }

    private fun registerDefaultTools() {
        // 1. Create Task Tool
        registerTool(
            AiTool(
                name = "create_task",
                description = "Creates a new task or assignment in Logic Loom",
                parameters = listOf(
                    AiToolParameter("title", "STRING", "Title of the task", isRequired = true),
                    AiToolParameter("dueDate", "STRING", "Due date (e.g. 'Tomorrow', '2026-08-15')"),
                    AiToolParameter("module", "STRING", "Module or course code (e.g. 'CS101', 'General')")
                )
            ) { args ->
                val title = args["title"]?.toString() ?: "New Task"
                val dueDate = args["dueDate"]?.toString() ?: "Tomorrow"
                val module = args["module"]?.toString() ?: "General"
                ToolEngine.executeCreateTask(title, dueDate, module)
            }
        )

        // 2. Create Reminder Tool
        registerTool(
            AiTool(
                name = "create_reminder",
                description = "Sets a reminder for a specific time and lead interval",
                parameters = listOf(
                    AiToolParameter("title", "STRING", "Reminder subject or task", isRequired = true),
                    AiToolParameter("time", "STRING", "Time of reminder in HH:mm format"),
                    AiToolParameter("leadMinutes", "INTEGER", "Lead minutes before deadline")
                )
            ) { args ->
                val title = args["title"]?.toString() ?: "Reminder"
                val time = args["time"]?.toString() ?: "08:00"
                val leadMinutes = (args["leadMinutes"] as? Number)?.toInt() ?: 15
                ToolEngine.executeCreateReminder(title, time, leadMinutes)
            }
        )

        // 3. Add Expense Tool
        registerTool(
            AiTool(
                name = "add_expense",
                description = "Logs a financial expense into the student budget tracker",
                parameters = listOf(
                    AiToolParameter("description", "STRING", "Expense item or description", isRequired = true),
                    AiToolParameter("amount", "NUMBER", "Monetary amount spent in ZAR", isRequired = true),
                    AiToolParameter("category", "STRING", "Category (Food, Books, Transport, Rent, Entertainment)")
                )
            ) { args ->
                val description = args["description"]?.toString() ?: "Expense"
                val amount = (args["amount"] as? Number)?.toDouble() ?: 0.0
                val category = args["category"]?.toString() ?: "General"
                ToolEngine.executeAddExpense(description, amount, category)
            }
        )

        // 4. Create Study Plan Tool
        registerTool(
            AiTool(
                name = "create_study_plan",
                description = "Generates a personalized study schedule and plan for courses",
                parameters = listOf(
                    AiToolParameter("courses", "STRING", "Comma-separated list of course codes", isRequired = true),
                    AiToolParameter("preferredTimes", "STRING", "Preferred study times (e.g. 'Evenings', 'Mornings')")
                )
            ) { args ->
                val courses = args["courses"]?.toString() ?: "General Modules"
                val preferredTimes = args["preferredTimes"]?.toString() ?: "Evenings"
                ToolEngine.executeCreateStudyPlan(courses, preferredTimes)
            }
        )

        // 5. Delete Task Tool
        registerTool(
            AiTool(
                name = "delete_task",
                description = "Deletes an existing task from Logic Loom by task ID",
                parameters = listOf(
                    AiToolParameter("taskId", "STRING", "ID of the task to delete", isRequired = true)
                )
            ) { args ->
                val taskId = args["taskId"]?.toString() ?: ""
                ToolEngine.executeDeleteTask(taskId)
            }
        )

        // 6. Complete Task Tool
        registerTool(
            AiTool(
                name = "complete_task",
                description = "Marks an existing task as completed in Logic Loom",
                parameters = listOf(
                    AiToolParameter("taskId", "STRING", "ID of the task to complete", isRequired = true)
                )
            ) { args ->
                val taskId = args["taskId"]?.toString() ?: ""
                ToolEngine.executeCompleteTask(taskId)
            }
        )

        // 7. Get Tasks Summary Tool
        registerTool(
            AiTool(
                name = "get_tasks_summary",
                description = "Retrieves a summary of active tasks and assignments filtered by module",
                parameters = listOf(
                    AiToolParameter("module", "STRING", "Module code to filter by (e.g. 'CS101', 'All')")
                )
            ) { args ->
                val module = args["module"]?.toString() ?: "All"
                ToolEngine.executeGetTasksSummary(module)
            }
        )

        // 8. Get Calendar Events Tool
        registerTool(
            AiTool(
                name = "get_calendar_events",
                description = "Retrieves today's calendar schedule, classes, and upcoming deadlines",
                parameters = emptyList()
            ) { _ ->
                ToolEngine.executeGetCalendarEvents()
            }
        )

        // 9. Get Next Class Tool
        registerTool(
            AiTool(
                name = "get_next_class",
                description = "Retrieves details and location of the user's next upcoming class lecture",
                parameters = emptyList()
            ) { _ ->
                ToolEngine.executeGetNextClass()
            }
        )

        // 10. Get Balance Summary Tool
        registerTool(
            AiTool(
                name = "get_balance_summary",
                description = "Retrieves student financial summary including available balance, total income, and total expenses",
                parameters = emptyList()
            ) { _ ->
                ToolEngine.executeGetBalanceSummary()
            }
        )

        // 11. Analyze Spending Tool
        registerTool(
            AiTool(
                name = "analyze_spending",
                description = "Analyzes student spending habits and category breakdowns",
                parameters = listOf(
                    AiToolParameter("category", "STRING", "Specific category to analyze (Food, Books, Transport, Rent, Entertainment, All)")
                )
            ) { args ->
                val category = args["category"]?.toString() ?: "All"
                ToolEngine.executeAnalyzeSpending(category)
            }
        )

        // 12. Calculate Grade Tool
        registerTool(
            AiTool(
                name = "calculate_grade",
                description = "Calculates required final exam score to achieve a target course mark",
                parameters = listOf(
                    AiToolParameter("currentGrade", "NUMBER", "Current percentage score (e.g. 65.0)", isRequired = true),
                    AiToolParameter("targetGrade", "NUMBER", "Target final percentage score (e.g. 75.0)", isRequired = true),
                    AiToolParameter("examWeight", "NUMBER", "Weight percentage of final exam (e.g. 40.0)", isRequired = true)
                )
            ) { args ->
                val current = (args["currentGrade"] as? Number)?.toDouble() ?: 50.0
                val target = (args["targetGrade"] as? Number)?.toDouble() ?: 60.0
                val weight = (args["examWeight"] as? Number)?.toDouble() ?: 40.0
                val needed = (target - (current * (1.0 - weight / 100.0))) / (weight / 100.0)
                val msg = if (needed <= 100.0 && needed >= 0) {
                    "To achieve a target final grade of %.1f%%, you need to score %.1f%% on your final exam (weight: %.0f%%).".format(target, needed, weight)
                } else if (needed < 0) {
                    "You have already guaranteed your target grade of %.1f%% based on your current score of %.1f%%!".format(target, current)
                } else {
                    "Achieving %.1f%% requires scoring %.1f%% on the final exam, which exceeds 100%%. Aim for a revised target.".format(target, needed)
                }
                ToolExecutionResult(
                    success = true,
                    message = msg,
                    cardTag = "[CARD_GRADE:Needed=%.1f%%]".format(needed)
                )
            }
        )

        // 13. Search Campus Buildings Tool
        registerTool(
            AiTool(
                name = "search_campus_buildings",
                description = "Searches for campus buildings, faculty halls, libraries, and lecture venues",
                parameters = listOf(
                    AiToolParameter("query", "STRING", "Building name, venue code, or keyword", isRequired = true)
                )
            ) { args ->
                val query = args["query"]?.toString() ?: ""
                ToolEngine.executeSearchCampusBuildings(query)
            }
        )

        // 14. Search Nearby Places Tool
        registerTool(
            AiTool(
                name = "search_nearby_places",
                description = "Searches for places near campus such as cafes, study spots, pharmacies, and transit stops",
                parameters = listOf(
                    AiToolParameter("query", "STRING", "Type of place or search term (e.g. 'coffee', 'library', 'pharmacy', 'shuttle')", isRequired = true),
                    AiToolParameter("requirePermission", "BOOLEAN", "Set true if exact location permission is strictly required")
                )
            ) { args ->
                val query = args["query"]?.toString() ?: ""
                val requirePerm = args["requirePermission"] as? Boolean ?: false
                ToolEngine.executeSearchPlaces(query, requirePerm)
            }
        )

        // 15. Web Search Tool
        registerTool(
            AiTool(
                name = "search_web",
                description = "Searches the web for current information, news, universities, or external facts",
                parameters = listOf(
                    AiToolParameter("query", "STRING", "Search terms or question to search the internet for", isRequired = true)
                )
            ) { args ->
                val query = args["query"]?.toString() ?: ""
                ToolEngine.executeSearchWeb(query)
            }
        )

        // 16. Weather Tool
        registerTool(
            AiTool(
                name = "get_weather",
                description = "Retrieves live real-time weather information for a specified city or location",
                parameters = listOf(
                    AiToolParameter("location", "STRING", "City name or location (e.g. 'Cape Town', 'Johannesburg', 'London')", isRequired = true)
                )
            ) { args ->
                val location = args["location"]?.toString() ?: "Cape Town"
                ToolEngine.executeGetWeather(location)
            }
        )

        // 17. Arithmetic Calculator Tool
        registerTool(
            AiTool(
                name = "calculate",
                description = "Deterministically evaluates mathematical arithmetic expressions (e.g. 928 * 37, 15% of 2500)",
                parameters = listOf(
                    AiToolParameter("expression", "STRING", "Mathematical expression to evaluate", isRequired = true)
                )
            ) { args ->
                val expression = args["expression"]?.toString() ?: "0"
                ToolEngine.executeCalculate(expression)
            }
        )

        // 18. Current Time and Date Tool
        registerTool(
            AiTool(
                name = "get_current_time",
                description = "Retrieves the accurate current time, date, day of week, and timezone for any city or region",
                parameters = listOf(
                    AiToolParameter("location", "STRING", "City name or timezone (e.g. 'Tokyo', 'Cape Town', 'London', 'New York')", isRequired = true)
                )
            ) { args ->
                val location = args["location"]?.toString() ?: "Cape Town"
                ToolEngine.executeGetCurrentTime(location)
            }
        )

        // 19. Currency Exchange Rate Tool
        registerTool(
            AiTool(
                name = "get_exchange_rate",
                description = "Retrieves real-time currency conversion rates (e.g. ZAR to USD)",
                parameters = listOf(
                    AiToolParameter("amount", "NUMBER", "Monetary amount to convert", isRequired = true),
                    AiToolParameter("baseCurrency", "STRING", "Source currency code (e.g. 'ZAR', 'USD')"),
                    AiToolParameter("targetCurrency", "STRING", "Target currency code (e.g. 'USD', 'ZAR')")
                )
            ) { args ->
                val amount = (args["amount"] as? Number)?.toDouble() ?: 1000.0
                val base = args["baseCurrency"]?.toString() ?: "ZAR"
                val target = args["targetCurrency"]?.toString() ?: "USD"
                ToolEngine.executeGetExchangeRate(amount, base, target)
            }
        )

        // 20. Place Details Tool
        registerTool(
            AiTool(
                name = "get_place_details",
                description = "Retrieves detailed information and opening status for a campus or nearby facility",
                parameters = listOf(
                    AiToolParameter("placeName", "STRING", "Name of the place or facility", isRequired = true)
                )
            ) { args ->
                val placeName = args["placeName"]?.toString() ?: ""
                ToolEngine.executeGetPlaceDetails(placeName)
            }
        )

        // 21. Set Alarm Tool
        registerTool(
            AiTool(
                name = "set_alarm",
                description = "Sets an alarm using the Android Clock system (e.g. 7 AM, 06:30, 8 PM)",
                parameters = listOf(
                    AiToolParameter("time", "STRING", "Time string for alarm (e.g. '7 AM', '06:30', '8 PM')", isRequired = true),
                    AiToolParameter("label", "STRING", "Alarm label or reason")
                )
            ) { args ->
                val time = args["time"]?.toString() ?: "07:00"
                val label = args["label"]?.toString() ?: "Logic Loom Alarm"
                ToolEngine.executeSetAlarm("Set an alarm for $time ($label)")
            }
        )

        // 22. Open Screen Tool
        registerTool(
            AiTool(
                name = "open_screen",
                description = "Navigates directly to a supported screen within Logic Loom (Settings, Timetable, Notes, Vault, Budget, Calendar, GPA)",
                parameters = listOf(
                    AiToolParameter("screenName", "STRING", "Name of screen to open (e.g. 'Settings', 'Timetable', 'Notes')", isRequired = true)
                )
            ) { args ->
                val screenName = args["screenName"]?.toString() ?: "Dashboard"
                ToolEngine.executeOpenScreen(screenName)
            }
        )

        // 23. Navigate To Location Tool
        registerTool(
            AiTool(
                name = "navigate_to_location",
                description = "Provides walking or driving navigation directions to a campus building or local destination",
                parameters = listOf(
                    AiToolParameter("destination", "STRING", "Campus building or address to navigate to", isRequired = true)
                )
            ) { args ->
                val destination = args["destination"]?.toString() ?: ""
                ToolEngine.executeNavigateToLocation(destination)
            }
        )
    }


    fun registerTool(tool: AiTool) {
        toolsMap[tool.name] = tool
    }

    fun getTool(name: String): AiTool? = toolsMap[name]

    fun getAllTools(): List<AiTool> = toolsMap.values.toList()

    fun getGeminiToolsJsonArray(): JSONArray {
        val functionDeclarations = JSONArray()
        toolsMap.values.forEach { tool ->
            functionDeclarations.put(tool.toGeminiFunctionDeclaration())
        }
        val toolsArray = JSONArray()
        val toolsObj = JSONObject()
        toolsObj.put("functionDeclarations", functionDeclarations)
        toolsArray.put(toolsObj)
        return toolsArray
    }

    suspend fun executeTool(name: String, args: Map<String, Any?>): ToolExecutionResult {
        val tool = toolsMap[name]
            ?: return ToolExecutionResult(
                success = false,
                message = "Tool '$name' is not registered in AiToolRegistry."
            )
        return try {
            tool.handler(args)
        } catch (e: Exception) {
            ToolExecutionResult(
                success = false,
                message = "Error executing tool '$name': ${e.localizedMessage}"
            )
        }
    }
}
