package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val fullName: String = "",
    val studentNumber: String = "",
    val university: String = "",
    val faculty: String = "",
    val course: String = "",
    val yearOfStudy: String = "",
    val email: String = "",
    val phone: String = "",
    val profilePictureUri: String? = null,
    val pin: String = "1234",
    val isPinEnabled: Boolean = false,
    val isLoggedIn: Boolean = false,
    val hasCompletedOnboarding: Boolean = false
)

@Entity(tableName = "academic_tasks")
data class AcademicTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val module: String,
    val description: String = "",
    val dueDate: String, // e.g. "2026-08-15"
    val priority: String = "Medium", // High, Medium, Low
    val taskType: String = "Assignment", // Assignment, Project, Presentation, Practical, Test, Exam
    val status: String = "Pending", // Pending, In Progress, Completed
    val progress: Int = 0, // 0 to 100
    val reminderTime: String = "1 Day Before",
    val checklistJson: String = "", // e.g. "Draft outline|Research papers|Proofread"
    val attachmentName: String = ""
)

@Entity(tableName = "calendar_events")
data class CalendarEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val date: String, // "2026-08-10"
    val time: String = "09:00",
    val category: String = "Lecture", // Assignment Deadline, Exam Date, Lecture, Event, Birthday, Meeting, Study Session
    val location: String = "",
    val description: String = "",
    val colorHex: String = "#2563EB"
)

@Entity(tableName = "timetable_slots")
data class TimetableSlot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayOfWeek: String, // Monday, Tuesday, Wednesday, Thursday, Friday
    val startTime: String, // "08:00"
    val endTime: String, // "09:45"
    val module: String,
    val venue: String,
    val lecturer: String = "",
    val notes: String = ""
)

@Entity(tableName = "note_items")
data class NoteItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val folder: String = "General",
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val tags: String = "",
    val updatedAt: String = "2026-08-05",
    val hasVoiceNote: Boolean = false,
    val voiceNoteDurationSec: Int = 0,
    val codeBlock: String = ""
)

@Entity(tableName = "vault_documents")
data class VaultDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "PDFs", // Assignments, Past Papers, Lecture Notes, PDFs, CV, Certificates, Personal Documents
    val fileSizeMb: Double = 1.5,
    val uploadDate: String = "2026-08-05",
    val fileType: String = "PDF"
)

@Entity(tableName = "budget_items")
data class BudgetItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double = 0.0, // Defaults to R0.00
    val type: String, // "Income" or "Expense"
    val category: String, // Income: Allowance, Salary, Bursary, Scholarship, Parents, Other. Expense: Food, Transport, Accommodation, Entertainment, Books, Shopping, Electricity, Data, Internet, Medical, Savings, Other
    val date: String = "2026-08-05"
)

@Entity(tableName = "budget_goals")
data class BudgetGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetAmount: Double = 0.0, // Default R0.00
    val currentAmount: Double = 0.0, // Default R0.00
    val deadline: String = "2026-11-30"
)

@Entity(tableName = "goal_items")
data class GoalItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "Academic", // Academic, Financial, Health, Personal, Career
    val targetDate: String = "2026-12-15",
    val progress: Int = 0, // 0 to 100
    val milestonesJson: String = "" // "Submit draft|Get supervisor review|Finalize"
)

@Entity(tableName = "diary_entries")
data class DiaryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val date: String = "2026-08-05",
    val mood: String = "Productive", // Happy, Stressed, Productive, Relaxed, Focused
    val moodEmoji: String = "😊",
    val content: String,
    val photoName: String = ""
)

@Entity(tableName = "todo_tasks")
data class TodoTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val priority: String = "Medium", // High, Medium, Low
    val isCompleted: Boolean = false,
    val isRecurring: Boolean = false,
    val recurring: String = "None",
    val dueDate: String = "2026-08-05"
)

@Entity(tableName = "gpa_modules")
data class GpaModule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleCode: String,
    val credits: Int = 18,
    val mark: Double = 75.0
)

@Entity(tableName = "shuttle_schedules")
data class ShuttleSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routeName: String, // e.g. "Jammie Shuttle - Tugwell to Upper Campus"
    val stopLocation: String = "Tugwell Bus Stop",
    val departureTime: String = "07:30",
    val arrivalTime: String = "07:45",
    val daysOfWeek: String = "Mon - Fri",
    val frequencyMinutes: Int = 15,
    val isFavorite: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "zar_exchange_rates")
data class ExchangeRateEntity(
    @PrimaryKey val currencyCode: String, // e.g. "USD", "EUR", "GBP"
    val rateAgainstZar: Double,          // rate value relative to 1 ZAR
    val lastUpdatedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "flashcard_decks")
data class FlashcardDeck(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String = "General",
    val description: String = "",
    val noteId: Long? = null,
    val createdAt: String = "2026-08-07"
)

@Entity(tableName = "flashcards")
data class Flashcard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val question: String,
    val answer: String,
    val isMastered: Boolean = false,
    val timesReviewed: Int = 0
)

@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemTitle: String,
    val category: String = "Groceries", // Groceries, Toiletries, Electronics, School Supplies
    val estimatedPriceZar: Double = 0.0,
    val isPurchased: Boolean = false,
    val isUrgent: Boolean = false
)

@Entity(tableName = "transport_requests")
data class TransportRequest(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val origin: String,
    val destination: String,
    val transportMethod: String = "Uber", // Uber, Jammie Shuttle, Public Bus, Taxi, Train, Walking, Cycling
    val estimatedCostZar: Double = 0.0,
    val estimatedDurationMins: Int = 15,
    val distanceKm: Double = 5.2,
    val timestamp: String = "2026-08-07 10:30",
    val status: String = "Draft" // Draft, Requested, Completed
)

@Entity(tableName = "food_orders")
data class FoodOrder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val restaurantName: String,
    val category: String = "Burgers", // Burgers, Pizza, Chicken, Asian, Healthy, Coffee, Fast Food, Drinks
    val itemsSummary: String,
    val totalCostZar: Double = 0.0,
    val status: String = "Delivered", // Draft, Placed, Preparing, Delivered
    val timestamp: String = "2026-08-07 12:15"
)

@Entity(tableName = "payment_methods")
data class PaymentMethodEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // Google Pay, Capitec Tokenized Card, Student Virtual Wallet
    val type: String = "GOOGLE_PAY", // GOOGLE_PAY, CARD_TOKEN
    val last4: String = "4242",
    val isDefault: Boolean = false
)

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val courseCode: String, // e.g. "CSC3002F", "MAM1000W"
    val academicPeriod: String = "Semester 1", // e.g. "Semester 1", "Semester 2", "Term 1", "Term 2", "Year Block"
    val description: String = "",
    val dueDate: String, // e.g. "2026-08-20"
    val dueTime: String = "23:59",
    val priority: String = "Medium", // High, Medium, Low
    val weightPercentage: Double = 10.0, // Weight in SA academic assessment breakdown
    val status: String = "Pending", // Pending, In Progress, Completed
    val isCompleted: Boolean = false
)

@Entity(tableName = "courses")
data class Course(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseCode: String, // e.g. "CSC3002F"
    val courseName: String, // e.g. "Computer Science 3002"
    val academicPeriod: String = "Semester 1", // e.g. "Semester 1", "Semester 2", "Year Block"
    val nqfLevel: Int = 7, // SA NQF Level (5, 6, 7, 8)
    val saqaCredits: Int = 18, // SAQA credit rating
    val lecturerName: String = "",
    val department: String = "Computer Science",
    val venue: String = "Upper Campus CS101",
    val colorHex: String = "#2563EB"
)

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val courseCode: String = "", // e.g. "CSC3002F"
    val academicPeriod: String = "Semester 1", // e.g. "Semester 1", "Semester 2"
    val reminderDateTime: String, // "2026-08-15 08:00"
    val reminderType: String = "Assignment Due", // Assignment Due, Lecture Alert, Exam Prep, Study Session
    val notes: String = "",
    val isDismissed: Boolean = false,
    val isNotificationEnabled: Boolean = true
)

@Entity(tableName = "academic_schedules")
data class AcademicSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val scheduleName: String, // e.g. "Semester 1 2026 Timetable"
    val academicYear: String = "2026",
    val academicPeriod: String = "Semester 1", // Semester 1, Semester 2, Term 1, Term 2, Year Block
    val courseCode: String, // e.g. "CSC3002F"
    val courseName: String = "",
    val dayOfWeek: String, // Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
    val startTime: String, // e.g. "08:00"
    val endTime: String, // e.g. "09:45"
    val venue: String = "",
    val sessionType: String = "Lecture", // Lecture, Practical, Tutorial, Seminar, Workshop
    val lecturer: String = "",
    val isActive: Boolean = true,
    val colorHex: String = "#2563EB"
)





