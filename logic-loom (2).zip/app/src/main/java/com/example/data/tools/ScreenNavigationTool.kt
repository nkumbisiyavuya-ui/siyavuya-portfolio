package com.example.data.tools

import com.example.ui.navigation.NavRoutes

data class ScreenNavigationResult(
    val success: Boolean,
    val targetRoute: String?,
    val displayName: String,
    val message: String
)

object ScreenNavigationTool {

    // Callback listener subscribed by ViewModel or UI orchestrator
    var onNavigateRequested: ((String) -> Unit)? = null

    private val routeMap = mapOf(
        "settings" to Pair(NavRoutes.SETTINGS, "Settings"),
        "setting" to Pair(NavRoutes.SETTINGS, "Settings"),
        "timetable" to Pair(NavRoutes.TIMETABLE, "Timetable"),
        "schedule" to Pair(NavRoutes.TIMETABLE, "Timetable"),
        "calendar" to Pair(NavRoutes.CALENDAR, "Calendar"),
        "notes" to Pair(NavRoutes.NOTES, "Notes"),
        "note" to Pair(NavRoutes.NOTES, "Notes"),
        "vault" to Pair(NavRoutes.VAULT, "Vault"),
        "documents" to Pair(NavRoutes.VAULT, "Vault"),
        "budget" to Pair(NavRoutes.BUDGET, "Budget"),
        "finance" to Pair(NavRoutes.BUDGET, "Budget"),
        "planner" to Pair(NavRoutes.ACADEMIC_PLANNER, "Academic Planner"),
        "academic planner" to Pair(NavRoutes.ACADEMIC_PLANNER, "Academic Planner"),
        "todo" to Pair(NavRoutes.TODO_LIST, "To-Do List"),
        "tasks" to Pair(NavRoutes.TODO_LIST, "To-Do List"),
        "flashcards" to Pair(NavRoutes.FLASHCARDS, "Flashcards"),
        "gpa" to Pair(NavRoutes.GPA_CALCULATOR, "GPA Calculator"),
        "gpa calculator" to Pair(NavRoutes.GPA_CALCULATOR, "GPA Calculator"),
        "shuttle" to Pair(NavRoutes.SHUTTLE_SCHEDULE, "Shuttle Schedule"),
        "transport" to Pair(NavRoutes.SHUTTLE_SCHEDULE, "Shuttle Schedule"),
        "dashboard" to Pair(NavRoutes.DASHBOARD, "Dashboard"),
        "home" to Pair(NavRoutes.DASHBOARD, "Dashboard"),
        "timer" to Pair(NavRoutes.STUDY_TIMER, "Study Timer"),
        "pomodoro" to Pair(NavRoutes.STUDY_TIMER, "Study Timer"),
        "diary" to Pair(NavRoutes.DIARY, "Diary"),
        "journal" to Pair(NavRoutes.DIARY, "Diary"),
        "profile" to Pair(NavRoutes.PROFILE, "Profile"),
        "life hub" to Pair(NavRoutes.LIFE_HUB, "Life Hub")
    )

    fun resolveRoute(screenName: String): Pair<String, String>? {
        val clean = screenName.trim().lowercase()
        return routeMap[clean] ?: routeMap.entries.firstOrNull { clean.contains(it.key) }?.value
    }

    fun openScreen(screenName: String): ScreenNavigationResult {
        val match = resolveRoute(screenName)
        if (match == null) {
            return ScreenNavigationResult(
                success = false,
                targetRoute = null,
                displayName = screenName,
                message = "I couldn't find a screen named '$screenName' in Logic Loom. Available screens include Settings, Timetable, Notes, Vault, Budget, Calendar, and GPA."
            )
        }

        val (route, name) = match
        onNavigateRequested?.invoke(route)

        return ScreenNavigationResult(
            success = true,
            targetRoute = route,
            displayName = name,
            message = "Done — opened $name for you."
        )
    }
}
