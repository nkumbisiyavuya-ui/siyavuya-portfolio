package com.example.data.ai

import com.example.data.local.UserProfile

/**
 * Security policy for AI Context handling.
 */
enum class AiPrivacyLevel {
    STANDARD,  // Minimal PII redaction (phones, pins, sensitive vault docs)
    STRICT     // Comprehensive anonymization (all emails, exact names, private notes)
}

/**
 * AiContextSanitizer provides utility functions to redact sensitive PII,
 * credentials, credit card details, phone numbers, and secrets from AI context data
 * before sending to LLM / Gemini APIs.
 */
object AiContextSanitizer {

    private val PHONE_PATTERN = Regex("""(?:\+?27|0)\s*\d{2}\s*\d{3}\s*\d{4}|\b\d{10}\b""")
    private val EMAIL_PATTERN = Regex("""\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b""")
    private val CREDIT_CARD_PATTERN = Regex("""\b(?:\d[ -]*?){13,16}\b""")
    private val API_KEY_PATTERN = Regex("""(?i)(api[_-]?key|secret|token|password|bearer|auth)\s*[:=]\s*["']?[\w\-]{8,}["']?""")
    private val PROMPT_INJECTION_PATTERN = Regex("""(?i)(ignore\s+(all\s+)?previous\s+instructions|system\s+prompt|reveal\s+secret|jailbreak)""")

    private val SENSITIVE_DOC_KEYWORDS = listOf(
        "passport", "id document", "payslip", "bank statement",
        "tax", "confidential", "pin", "password", "medical", "cv", "certificate"
    )

    /**
     * Sanitizes raw text string by redacting PII, credentials, and prompt injections.
     */
    fun sanitizeText(
        input: String,
        privacyLevel: AiPrivacyLevel = AiPrivacyLevel.STANDARD
    ): String {
        if (input.isBlank()) return ""

        var sanitized = input

        // 1. Defuse potential prompt injection
        if (PROMPT_INJECTION_PATTERN.containsMatchIn(sanitized)) {
            sanitized = PROMPT_INJECTION_PATTERN.replace(sanitized, "[NEUTRALIZED_INSTRUCTION]")
        }

        // 2. Redact API keys and secrets
        sanitized = API_KEY_PATTERN.replace(sanitized) { match ->
            val keyPart = match.value.split("=").firstOrNull() ?: "secret"
            "$keyPart=[REDACTED_SECRET]"
        }

        // 3. Redact Credit Cards / Account numbers
        sanitized = CREDIT_CARD_PATTERN.replace(sanitized, "[REDACTED_CARD_NUMBER]")

        // 4. Redact Phone numbers
        sanitized = PHONE_PATTERN.replace(sanitized, "[REDACTED_PHONE]")

        // 5. Redact Emails in Strict mode or mask in Standard mode
        if (privacyLevel == AiPrivacyLevel.STRICT) {
            sanitized = EMAIL_PATTERN.replace(sanitized, "[REDACTED_EMAIL]")
        } else {
            sanitized = EMAIL_PATTERN.replace(sanitized) { match ->
                maskEmail(match.value)
            }
        }

        return sanitized
    }

    /**
     * Sanitizes user profile information for AI context.
     */
    fun sanitizeUserProfile(
        profile: UserProfile?,
        privacyLevel: AiPrivacyLevel = AiPrivacyLevel.STANDARD
    ): UserProfile? {
        if (profile == null) return null
        return profile.copy(
            pin = "[PROTECTED]",
            phone = "[REDACTED_PHONE]",
            email = if (privacyLevel == AiPrivacyLevel.STRICT) "[REDACTED_EMAIL]" else maskEmail(profile.email)
        )
    }

    /**
     * Filters out sensitive vault documents that should never be sent to LLM context.
     */
    fun isVaultDocumentAllowedForAi(documentTitle: String, category: String): Boolean {
        val titleLower = documentTitle.lowercase()
        val catLower = category.lowercase()

        val isSensitiveTitle = SENSITIVE_DOC_KEYWORDS.any { keyword ->
            titleLower.contains(keyword)
        }
        val isSensitiveCategory = catLower.contains("personal") || catLower.contains("cv") || catLower.contains("certificate")

        return !isSensitiveTitle && !isSensitiveCategory
    }

    /**
     * Masks email address preserving first letter and domain for basic user context.
     */
    private fun maskEmail(email: String): String {
        val parts = email.split("@")
        if (parts.size != 2) return "[REDACTED_EMAIL]"
        val username = parts[0]
        val domain = parts[1]
        val maskedUser = if (username.length > 2) {
            "${username.first()}***${username.last()}"
        } else {
            "***"
        }
        return "$maskedUser@$domain"
    }
}
