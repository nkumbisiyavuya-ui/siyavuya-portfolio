package com.example.data.ai.orchestrator

/**
 * Task classification taxonomy for Chuma AI.
 * Represents the classified intent of a user's request.
 */
enum class ChumaTaskType {
    // Explicit Chuma Intent Categories
    CURRENT_DATE,
    DATE_LOOKUP,
    DATE_DIFFERENCE,
    PUBLIC_HOLIDAY_CHECK,
    HOLIDAY_LOOKUP,
    EVENT_LOOKUP,
    HISTORICAL_DATE_LOOKUP,
    WEATHER_LOOKUP,
    TRANSPORT_LOOKUP,
    FARE_LOOKUP,
    LOCATION_LOOKUP,
    NEARBY_SEARCH,
    WEB_RESEARCH,
    FILE_SEARCH,
    PERSONAL_KNOWLEDGE_SEARCH,
    MEMORY_OPERATION,
    COMPARE,
    CREATE,
    UPDATE_USER_DATA,
    DELETE_USER_DATA,
    GENERAL_QA,

    // Auxiliary Task Types
    REASONING,
    WRITING,
    EDITING,
    SUMMARIZATION,
    TRANSLATION,
    MATHEMATICS,
    CODING,
    DEBUGGING,
    RESEARCH,
    CURRENT_INFORMATION,
    COMPARISON,
    PLANNING,
    FILE_ANALYSIS,
    DATA_ANALYSIS,
    TOOL_REQUEST,
    MULTI_STEP_TASK,
    UNKNOWN
}
