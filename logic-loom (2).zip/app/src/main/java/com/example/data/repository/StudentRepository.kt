package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow

/**
 * Clean Repository abstraction for managing student productivity data
 * including academic tasks, course schedules, timetable, and study reminders.
 */
interface StudentRepository {
    // User Profile
    val userProfile: Flow<UserProfile?>
    suspend fun getUserProfileDirect(): UserProfile?
    suspend fun updateUserProfile(profile: UserProfile)

    // Academic Tasks (Student Tasks)
    val academicTasks: Flow<List<AcademicTask>>
    fun getAcademicTaskById(id: Long): Flow<AcademicTask?>
    fun getAcademicTasksByStatus(status: String): Flow<List<AcademicTask>>
    fun getAcademicTasksByModule(module: String): Flow<List<AcademicTask>>
    suspend fun addAcademicTask(task: AcademicTask): Long
    suspend fun updateAcademicTask(task: AcademicTask)
    suspend fun deleteAcademicTask(id: Long)
    suspend fun deleteAcademicTask(task: AcademicTask)

    // Todo Tasks
    val todoTasks: Flow<List<TodoTask>>
    fun getTodoTaskById(id: Long): Flow<TodoTask?>
    suspend fun addTodoTask(task: TodoTask): Long
    suspend fun updateTodoTask(task: TodoTask)
    suspend fun deleteTodoTask(id: Long)
    suspend fun deleteTodoTask(task: TodoTask)

    // Course Schedules & Calendar Events
    val calendarEvents: Flow<List<CalendarEvent>>
    fun getCalendarEventById(id: Long): Flow<CalendarEvent?>
    suspend fun addCalendarEvent(event: CalendarEvent): Long
    suspend fun updateCalendarEvent(event: CalendarEvent)
    suspend fun deleteCalendarEvent(id: Long)
    suspend fun deleteCalendarEvent(event: CalendarEvent)

    // Timetable Slots (Course Schedule)
    val timetableSlots: Flow<List<TimetableSlot>>
    fun getTimetableSlotById(id: Long): Flow<TimetableSlot?>
    suspend fun addTimetableSlot(slot: TimetableSlot): Long
    suspend fun updateTimetableSlot(slot: TimetableSlot)
    suspend fun deleteTimetableSlot(id: Long)
    suspend fun deleteTimetableSlot(slot: TimetableSlot)

    // Notes
    val notes: Flow<List<NoteItem>>
    fun getNoteById(id: Long): Flow<NoteItem?>
    suspend fun addNote(note: NoteItem): Long
    suspend fun updateNote(note: NoteItem)
    suspend fun deleteNote(id: Long)
    suspend fun deleteNote(note: NoteItem)

    // Vault Documents
    val vaultDocuments: Flow<List<VaultDocument>>
    fun getVaultDocumentById(id: Long): Flow<VaultDocument?>
    suspend fun addVaultDocument(doc: VaultDocument): Long
    suspend fun updateVaultDocument(doc: VaultDocument)
    suspend fun deleteVaultDocument(id: Long)
    suspend fun deleteVaultDocument(doc: VaultDocument)

    // Budget
    val budgetItems: Flow<List<BudgetItem>>
    fun getBudgetItemById(id: Long): Flow<BudgetItem?>
    fun getBudgetItemsByType(type: String): Flow<List<BudgetItem>>
    fun getBudgetItemsByCategory(category: String): Flow<List<BudgetItem>>
    suspend fun addBudgetItem(item: BudgetItem): Long
    suspend fun updateBudgetItem(item: BudgetItem)
    suspend fun deleteBudgetItem(id: Long)
    suspend fun deleteBudgetItem(item: BudgetItem)

    val budgetGoals: Flow<List<BudgetGoal>>
    fun getBudgetGoalById(id: Long): Flow<BudgetGoal?>
    suspend fun addBudgetGoal(goal: BudgetGoal): Long
    suspend fun updateBudgetGoal(goal: BudgetGoal)
    suspend fun deleteBudgetGoal(id: Long)
    suspend fun deleteBudgetGoal(goal: BudgetGoal)

    // Goals
    val goals: Flow<List<GoalItem>>
    fun getGoalById(id: Long): Flow<GoalItem?>
    suspend fun addGoal(goal: GoalItem): Long
    suspend fun updateGoal(goal: GoalItem)
    suspend fun deleteGoal(id: Long)
    suspend fun deleteGoal(goal: GoalItem)

    // Diary Entries
    val diaryEntries: Flow<List<DiaryEntry>>
    fun getDiaryEntryById(id: Long): Flow<DiaryEntry?>
    suspend fun addDiaryEntry(entry: DiaryEntry): Long
    suspend fun updateDiaryEntry(entry: DiaryEntry)
    suspend fun deleteDiaryEntry(id: Long)
    suspend fun deleteDiaryEntry(entry: DiaryEntry)

    // GPA Modules
    val gpaModules: Flow<List<GpaModule>>
    fun getGpaModuleById(id: Long): Flow<GpaModule?>
    suspend fun addGpaModule(module: GpaModule): Long
    suspend fun updateGpaModule(module: GpaModule)
    suspend fun deleteGpaModule(id: Long)
    suspend fun deleteGpaModule(module: GpaModule)

    // Shuttle Schedules
    val shuttleSchedules: Flow<List<ShuttleSchedule>>
    fun getShuttleScheduleById(id: Long): Flow<ShuttleSchedule?>
    suspend fun addShuttleSchedule(shuttle: ShuttleSchedule): Long
    suspend fun updateShuttleSchedule(shuttle: ShuttleSchedule)
    suspend fun deleteShuttleSchedule(id: Long)
    suspend fun deleteShuttleSchedule(shuttle: ShuttleSchedule)

    // Global Search
    fun searchNotes(query: String): Flow<List<NoteItem>>
    fun searchAcademicTasks(query: String): Flow<List<AcademicTask>>
    fun searchBudgetItems(query: String): Flow<List<BudgetItem>>
    fun searchVaultDocuments(query: String): Flow<List<VaultDocument>>

    // Flashcard Decks & Cards
    val flashcardDecks: Flow<List<FlashcardDeck>>
    val allFlashcards: Flow<List<Flashcard>>
    fun getFlashcardsForDeck(deckId: Long): Flow<List<Flashcard>>
    suspend fun addFlashcardDeck(deck: FlashcardDeck): Long
    suspend fun deleteFlashcardDeck(deckId: Long)
    suspend fun addFlashcard(card: Flashcard): Long
    suspend fun updateFlashcard(card: Flashcard)
    suspend fun deleteFlashcard(cardId: Long)

    // Shopping Items
    val shoppingItems: Flow<List<ShoppingItem>>
    suspend fun addShoppingItem(item: ShoppingItem): Long
    suspend fun updateShoppingItem(item: ShoppingItem)
    suspend fun deleteShoppingItem(id: Long)

    // Transport Requests
    val transportRequests: Flow<List<TransportRequest>>
    suspend fun addTransportRequest(request: TransportRequest): Long
    suspend fun updateTransportRequest(request: TransportRequest)
    suspend fun deleteTransportRequest(id: Long)

    // Food Orders
    val foodOrders: Flow<List<FoodOrder>>
    suspend fun addFoodOrder(order: FoodOrder): Long
    suspend fun updateFoodOrder(order: FoodOrder)
    suspend fun deleteFoodOrder(id: Long)

    // Payment Methods
    val paymentMethods: Flow<List<PaymentMethodEntity>>
    suspend fun addPaymentMethod(method: PaymentMethodEntity): Long
    suspend fun deletePaymentMethod(id: Long)

    // SA Academic Tasks
    val tasks: Flow<List<Task>>
    fun getTaskById(id: Long): Flow<Task?>
    fun getTasksByCourseCode(courseCode: String): Flow<List<Task>>
    fun getTasksByAcademicPeriod(academicPeriod: String): Flow<List<Task>>
    suspend fun addTask(task: Task): Long
    suspend fun updateTask(task: Task)
    suspend fun deleteTask(id: Long)
    suspend fun deleteTask(task: Task)

    // SA Academic Courses
    val courses: Flow<List<Course>>
    fun getCourseById(id: Long): Flow<Course?>
    fun getCourseByCode(courseCode: String): Flow<Course?>
    fun getCoursesByAcademicPeriod(academicPeriod: String): Flow<List<Course>>
    suspend fun addCourse(course: Course): Long
    suspend fun updateCourse(course: Course)
    suspend fun deleteCourse(id: Long)
    suspend fun deleteCourse(course: Course)

    // Reminders
    val activeReminders: Flow<List<Reminder>>
    val allReminders: Flow<List<Reminder>>
    fun getReminderById(id: Long): Flow<Reminder?>
    fun getRemindersByCourseCode(courseCode: String): Flow<List<Reminder>>
    suspend fun addReminder(reminder: Reminder): Long
    suspend fun updateReminder(reminder: Reminder)
    suspend fun deleteReminder(id: Long)
    suspend fun deleteReminder(reminder: Reminder)
}
