package com.example.data.ai

import com.example.data.local.*

data class CanvasMateContext(
    val userProfile: UserProfile? = null,
    val timetableSlots: List<TimetableSlot> = emptyList(),
    val calendarEvents: List<CalendarEvent> = emptyList(),
    val academicTasks: List<AcademicTask> = emptyList(),
    val todoTasks: List<TodoTask> = emptyList(),
    val gpaModules: List<GpaModule> = emptyList(),
    val budgetItems: List<BudgetItem> = emptyList(),
    val vaultDocuments: List<VaultDocument> = emptyList(),
    val notes: List<NoteItem> = emptyList(),
    val shoppingItems: List<ShoppingItem> = emptyList(),
    val transportRequests: List<TransportRequest> = emptyList(),
    val foodOrders: List<FoodOrder> = emptyList(),
    val locationPermissionGranted: Boolean = true,
    val userLocationArea: String = "University Campus / Rondebosch, Cape Town"
)
