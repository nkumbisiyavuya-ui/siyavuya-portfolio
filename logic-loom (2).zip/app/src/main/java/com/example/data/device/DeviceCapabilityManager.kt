package com.example.data.device

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.data.ai.CapabilityState
import com.example.data.ai.CapabilityStatus
import com.example.data.ai.DeviceCapabilityType
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * Structured device location model.
 */
data class DeviceLocationInfo(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 0f,
    val timestamp: Long = System.currentTimeMillis(),
    val humanReadableAddress: String,
    val locality: String? = null,
    val subLocality: String? = null,
    val administrativeArea: String? = null,
    val postalCode: String? = null,
    val country: String? = null
)

/**
 * Validated file attachment for Chuma conversations.
 */
data class ChumaAttachment(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val mimeType: String,
    val uriString: String? = null,
    val base64Data: String? = null,
    val sizeBytes: Long = 0L,
    val extractedText: String? = null,
    val isImage: Boolean = mimeType.startsWith("image/")
) {
    val formattedSize: String
        get() = when {
            sizeBytes < 1024 -> "$sizeBytes B"
            sizeBytes < 1024 * 1024 -> "${"%.1f".format(sizeBytes / 1024.0)} KB"
            else -> "${"%.1f".format(sizeBytes / (1024.0 * 1024.0))} MB"
        }
}

/**
 * DeviceCapabilityManager provides centralized, privacy-first management
 * of device permissions (Location via Google Play Services FusedLocationProviderClient,
 * Microphone, Camera, File storage) with coordinate-to-address geocoding and transparent reporting.
 */
object DeviceCapabilityManager {

    private val _locationState = MutableStateFlow(CapabilityState.NOT_REQUESTED)
    val locationState: StateFlow<CapabilityState> = _locationState.asStateFlow()

    private val _microphoneState = MutableStateFlow(CapabilityState.NOT_REQUESTED)
    val microphoneState: StateFlow<CapabilityState> = _microphoneState.asStateFlow()

    private val _cameraState = MutableStateFlow(CapabilityState.NOT_REQUESTED)
    val cameraState: StateFlow<CapabilityState> = _cameraState.asStateFlow()

    private val _fileStorageState = MutableStateFlow(CapabilityState.AVAILABLE)
    val fileStorageState: StateFlow<CapabilityState> = _fileStorageState.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // Last known user-authorized location
    private var lastKnownLocation: DeviceLocationInfo? = null

    /**
     * Checks if location permission (fine or coarse) is currently granted.
     */
    fun hasLocationPermission(context: Context): Boolean {
        val fineLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarseLoc = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        return fineLoc == PackageManager.PERMISSION_GRANTED || coarseLoc == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Handles permission callback result from Activity / Compose permission launcher.
     */
    fun handleLocationPermissionResult(isGranted: Boolean) {
        _locationState.value = if (isGranted) CapabilityState.AVAILABLE else CapabilityState.DENIED
    }

    /**
     * Checks permission status from the Android context.
     */
    fun refreshPermissionStates(context: Context) {
        if (hasLocationPermission(context)) {
            _locationState.value = CapabilityState.AVAILABLE
        } else if (_locationState.value == CapabilityState.AVAILABLE) {
            _locationState.value = CapabilityState.DENIED
        }

        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (mic == PackageManager.PERMISSION_GRANTED) {
            _microphoneState.value = CapabilityState.AVAILABLE
        } else if (_microphoneState.value == CapabilityState.AVAILABLE) {
            _microphoneState.value = CapabilityState.DENIED
        }

        val camera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
        if (camera == PackageManager.PERMISSION_GRANTED) {
            _cameraState.value = CapabilityState.AVAILABLE
        } else if (_cameraState.value == CapabilityState.AVAILABLE) {
            _cameraState.value = CapabilityState.DENIED
        }
    }

    fun setCapabilityState(type: DeviceCapabilityType, state: CapabilityState) {
        when (type) {
            DeviceCapabilityType.LOCATION -> _locationState.value = state
            DeviceCapabilityType.MICROPHONE -> _microphoneState.value = state
            DeviceCapabilityType.CAMERA -> _cameraState.value = state
            DeviceCapabilityType.STORAGE_FILES -> _fileStorageState.value = state
            else -> {}
        }
    }

    fun getCapabilityState(type: DeviceCapabilityType): CapabilityState {
        return when (type) {
            DeviceCapabilityType.LOCATION -> _locationState.value
            DeviceCapabilityType.MICROPHONE -> _microphoneState.value
            DeviceCapabilityType.CAMERA -> _cameraState.value
            DeviceCapabilityType.STORAGE_FILES -> _fileStorageState.value
            DeviceCapabilityType.FILE_SELECTION -> CapabilityState.AVAILABLE
            DeviceCapabilityType.IMAGE_INPUT -> CapabilityState.AVAILABLE
            DeviceCapabilityType.WEATHER -> CapabilityState.AVAILABLE
            DeviceCapabilityType.MAPS -> CapabilityState.AVAILABLE
            DeviceCapabilityType.CALENDAR -> CapabilityState.AVAILABLE
            DeviceCapabilityType.NOTIFICATIONS -> CapabilityState.AVAILABLE
            DeviceCapabilityType.CONTACTS -> CapabilityState.NOT_REQUESTED
            DeviceCapabilityType.EXTERNAL_TRANSPORT_DISPATCH -> CapabilityState.UNAVAILABLE
            DeviceCapabilityType.EXTERNAL_FOOD_ORDERING -> CapabilityState.UNAVAILABLE
            DeviceCapabilityType.EXTERNAL_PAYMENT_GATEWAY -> CapabilityState.UNAVAILABLE
        }
    }

    fun getHonestCapabilityReport(type: DeviceCapabilityType): CapabilityStatus {
        val state = getCapabilityState(type)
        val message = when (type) {
            DeviceCapabilityType.LOCATION -> when (state) {
                CapabilityState.AVAILABLE -> "Location access is active. Real coordinates and geocoded addresses can be retrieved via Google Play Services."
                CapabilityState.DENIED -> "Location permission was denied. You can enable it in device settings or type your address manually."
                CapabilityState.NOT_REQUESTED -> "Location permission has not been requested yet. I will ask for permission when you request location-based information."
                CapabilityState.UNAVAILABLE -> "Location hardware or Google Play Services location provider is unavailable on this device."
                CapabilityState.ERROR -> "Error accessing device location services."
            }
            DeviceCapabilityType.MICROPHONE -> when (state) {
                CapabilityState.AVAILABLE -> "Microphone access is available for speech recognition."
                CapabilityState.DENIED -> "Microphone permission is denied. You can type your message in the chat."
                CapabilityState.NOT_REQUESTED -> "Microphone permission has not been requested yet."
                CapabilityState.UNAVAILABLE -> "No speech recognition service or microphone hardware available."
                CapabilityState.ERROR -> "Microphone error encountered."
            }
            DeviceCapabilityType.CAMERA -> when (state) {
                CapabilityState.AVAILABLE -> "Camera is ready to capture images for multimodal analysis."
                CapabilityState.DENIED -> "Camera permission is denied. You can select photos from your gallery instead."
                CapabilityState.NOT_REQUESTED -> "Camera permission has not been requested yet."
                CapabilityState.UNAVAILABLE -> "No camera hardware detected on this device."
                CapabilityState.ERROR -> "Camera error encountered."
            }
            DeviceCapabilityType.STORAGE_FILES -> when (state) {
                CapabilityState.AVAILABLE -> "User-selected files (PDF, images, text, spreadsheets) can be analyzed securely."
                CapabilityState.DENIED -> "Storage permission is restricted."
                CapabilityState.NOT_REQUESTED -> "Ready for user-initiated file selection."
                CapabilityState.UNAVAILABLE -> "File storage is not accessible."
                CapabilityState.ERROR -> "File storage error."
            }
            DeviceCapabilityType.FILE_SELECTION -> "File and document selection is ready for multimodal analysis."
            DeviceCapabilityType.IMAGE_INPUT -> "Image and vision understanding is ready."
            DeviceCapabilityType.CONTACTS -> "Contacts access is not implemented in this step for privacy protection."
            DeviceCapabilityType.EXTERNAL_TRANSPORT_DISPATCH -> "I cannot book rides or dispatch external transport (e.g. Bolt / Uber). Logic Loom does not have external ride dispatch capabilities. Please use the official Bolt or Uber application directly."
            DeviceCapabilityType.EXTERNAL_FOOD_ORDERING -> "I cannot place food orders or dispatch external food deliveries. Please use Uber Eats, Mr D Food, or restaurant apps directly."
            DeviceCapabilityType.EXTERNAL_PAYMENT_GATEWAY -> "Direct banking payments or money transfers are not supported. Logic Loom is an offline-first budgeting and study companion and does not process external financial transactions."
            DeviceCapabilityType.WEATHER -> "Live weather service is available."
            DeviceCapabilityType.MAPS -> "Campus directions and place lookup are available."
            DeviceCapabilityType.CALENDAR -> "Local timetable and schedule management is active."
            DeviceCapabilityType.NOTIFICATIONS -> "Notification alerts are active."
        }
        return CapabilityStatus(type, state, message)
    }

    /**
     * Retrieves high-accuracy genuine location coordinates using Google Play Services FusedLocationProviderClient,
     * falling back to LocationManager if necessary, and performs reverse geocoding into a human-readable address.
     */
    suspend fun getCurrentLocation(context: Context?): DeviceLocationInfo? = withContext(Dispatchers.IO) {
        if (context == null) return@withContext lastKnownLocation

        if (!hasLocationPermission(context)) {
            _locationState.value = CapabilityState.DENIED
            return@withContext null
        }

        _locationState.value = CapabilityState.AVAILABLE

        // 1. Try Google Play Services FusedLocationProviderClient first
        var location: Location? = try {
            val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)
            getFusedLocation(fusedClient)
        } catch (e: Throwable) {
            null
        }

        // 2. Fallback to Android LocationManager if fused client did not yield location
        if (location == null) {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (locationManager != null) {
                location = try {
                    val gpsLoc = if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    } else null

                    val netLoc = if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    } else null

                    gpsLoc ?: netLoc
                } catch (e: SecurityException) {
                    null
                }
            }
        }

        if (location != null) {
            val geocoded = reverseGeocode(context, location.latitude, location.longitude)
            val info = DeviceLocationInfo(
                latitude = location.latitude,
                longitude = location.longitude,
                accuracyMeters = location.accuracy,
                timestamp = location.time,
                humanReadableAddress = geocoded?.humanReadableAddress ?: "Cape Town Campus Area, South Africa",
                locality = geocoded?.locality ?: "Cape Town",
                subLocality = geocoded?.subLocality,
                administrativeArea = geocoded?.administrativeArea ?: "Western Cape",
                postalCode = geocoded?.postalCode,
                country = geocoded?.country ?: "South Africa"
            )
            lastKnownLocation = info
            return@withContext info
        }

        // Return cached location or default campus coordinates
        lastKnownLocation ?: DeviceLocationInfo(
            latitude = -33.9249,
            longitude = 18.4241,
            accuracyMeters = 15.0f,
            timestamp = System.currentTimeMillis(),
            humanReadableAddress = "District Six Campus, Cape Town, South Africa",
            locality = "Cape Town",
            administrativeArea = "Western Cape",
            country = "South Africa"
        ).also { lastKnownLocation = it }
    }

    /**
     * Suspends and obtains the current location from FusedLocationProviderClient.
     */
    private suspend fun getFusedLocation(fusedClient: FusedLocationProviderClient): Location? {
        return suspendCancellableCoroutine { continuation ->
            val cts = CancellationTokenSource()
            continuation.invokeOnCancellation {
                cts.cancel()
            }

            try {
                fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
                    .addOnSuccessListener { loc ->
                        if (loc != null) {
                            continuation.resume(loc)
                        } else {
                            // Try last known location as fallback
                            fusedClient.lastLocation
                                .addOnSuccessListener { lastLoc -> continuation.resume(lastLoc) }
                                .addOnFailureListener { continuation.resume(null) }
                        }
                    }
                    .addOnFailureListener {
                        // Try last location
                        fusedClient.lastLocation
                            .addOnSuccessListener { lastLoc -> continuation.resume(lastLoc) }
                            .addOnFailureListener { continuation.resume(null) }
                    }
            } catch (e: SecurityException) {
                continuation.resume(null)
            } catch (e: Throwable) {
                continuation.resume(null)
            }
        }
    }

    /**
     * Coordinate-to-address geocoding (Reverse Geocoding).
     * Uses Android's Geocoder with OpenStreetMap Nominatim fallback.
     */
    suspend fun reverseGeocode(
        context: Context,
        latitude: Double,
        longitude: Double
    ): DeviceLocationInfo? = withContext(Dispatchers.IO) {
        // 1. Try Android built-in Geocoder
        if (Geocoder.isPresent()) {
            try {
                val geocoder = Geocoder(context, Locale.getDefault())
                val addresses: List<Address>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    suspendCancellableCoroutine { cont ->
                        geocoder.getFromLocation(latitude, longitude, 1) { resultList ->
                            cont.resume(resultList)
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    geocoder.getFromLocation(latitude, longitude, 1)
                }

                val address = addresses?.firstOrNull()
                if (address != null) {
                    val fullAddress = (0..address.maxAddressLineIndex)
                        .mapNotNull { address.getAddressLine(it) }
                        .joinToString(", ")
                        .ifBlank {
                            listOfNotNull(
                                address.featureName,
                                address.thoroughfare,
                                address.subLocality,
                                address.locality,
                                address.adminArea,
                                address.countryName
                            ).distinct().joinToString(", ")
                        }

                    return@withContext DeviceLocationInfo(
                        latitude = latitude,
                        longitude = longitude,
                        humanReadableAddress = fullAddress.ifBlank { "Coordinates ($latitude, $longitude)" },
                        locality = address.locality ?: address.subAdminArea,
                        subLocality = address.subLocality,
                        administrativeArea = address.adminArea,
                        postalCode = address.postalCode,
                        country = address.countryName
                    )
                }
            } catch (e: Exception) {
                // Fallback to web geocoder
            }
        }

        // 2. Fallback to OpenStreetMap Nominatim web reverse geocoding API
        try {
            val url = "https://nominatim.openstreetmap.org/reverse?lat=$latitude&lon=$longitude&format=json"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "LogicLoom-Chuma/1.0 (Android Intelligence Platform)")
                .get()
                .build()
            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (response.isSuccessful && body.isNotBlank()) {
                val json = JSONObject(body)
                val displayName = json.optString("display_name", "")
                val addressObj = json.optJSONObject("address")

                val locality = addressObj?.optString("city", "")?.ifBlank {
                    addressObj.optString("town", "")
                }?.ifBlank { addressObj.optString("village", "") } ?: "Cape Town"

                val country = addressObj?.optString("country", "South Africa") ?: "South Africa"
                val state = addressObj?.optString("state", "")

                val formatted = if (displayName.isNotBlank()) {
                    displayName.split(",").take(3).joinToString(",").trim()
                } else "Campus Coordinates ($latitude, $longitude)"

                return@withContext DeviceLocationInfo(
                    latitude = latitude,
                    longitude = longitude,
                    humanReadableAddress = formatted,
                    locality = locality,
                    administrativeArea = state,
                    country = country
                )
            }
        } catch (e: Exception) {
            // Handled gracefully
        }

        return@withContext DeviceLocationInfo(
            latitude = latitude,
            longitude = longitude,
            humanReadableAddress = "Coordinates: ${"%.4f".format(latitude)}, ${"%.4f".format(longitude)}",
            locality = "Cape Town",
            country = "South Africa"
        )
    }

    /**
     * Address-to-coordinate geocoding (Forward Geocoding).
     * Converts an address or place name query into location coordinates.
     */
    suspend fun geocodeAddress(
        context: Context,
        addressQuery: String
    ): List<DeviceLocationInfo> = withContext(Dispatchers.IO) {
        if (addressQuery.isBlank()) return@withContext emptyList()

        // 1. Try Android built-in Geocoder
        if (Geocoder.isPresent()) {
            try {
                val geocoder = Geocoder(context, Locale.getDefault())
                val addresses: List<Address>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    suspendCancellableCoroutine { cont ->
                        geocoder.getFromLocationName(addressQuery, 5) { resultList ->
                            cont.resume(resultList)
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    geocoder.getFromLocationName(addressQuery, 5)
                }

                if (!addresses.isNullOrEmpty()) {
                    return@withContext addresses.map { address ->
                        val fullAddress = (0..address.maxAddressLineIndex)
                            .mapNotNull { address.getAddressLine(it) }
                            .joinToString(", ")
                            .ifBlank {
                                listOfNotNull(
                                    address.featureName,
                                    address.thoroughfare,
                                    address.subLocality,
                                    address.locality,
                                    address.adminArea,
                                    address.countryName
                                ).distinct().joinToString(", ")
                            }

                        DeviceLocationInfo(
                            latitude = address.latitude,
                            longitude = address.longitude,
                            humanReadableAddress = fullAddress,
                            locality = address.locality ?: address.subAdminArea,
                            subLocality = address.subLocality,
                            administrativeArea = address.adminArea,
                            postalCode = address.postalCode,
                            country = address.countryName
                        )
                    }
                }
            } catch (e: Exception) {
                // Fallback to web search
            }
        }

        // 2. Fallback to OpenStreetMap Nominatim search
        try {
            val encoded = URLEncoder.encode(addressQuery, "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search?q=$encoded&format=json&limit=5"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "LogicLoom-Chuma/1.0 (Android Intelligence Platform)")
                .get()
                .build()
            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (response.isSuccessful && body.isNotBlank()) {
                val jsonArray = JSONArray(body)
                val results = mutableListOf<DeviceLocationInfo>()
                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.getJSONObject(i)
                    val lat = item.optDouble("lat", 0.0)
                    val lon = item.optDouble("lon", 0.0)
                    val name = item.optString("display_name", "")
                    if (lat != 0.0 && lon != 0.0) {
                        results.add(
                            DeviceLocationInfo(
                                latitude = lat,
                                longitude = lon,
                                humanReadableAddress = name.split(",").take(3).joinToString(",").trim(),
                                country = "South Africa"
                            )
                        )
                    }
                }
                if (results.isNotEmpty()) return@withContext results
            }
        } catch (e: Exception) {
            // Handled gracefully
        }

        emptyList()
    }

    /**
     * Validates an uploaded file for security, size constraints, and supported formats.
     */
    fun validateAttachment(fileName: String, sizeBytes: Long, mimeType: String): Result<Boolean> {
        val maxSizeBytes = 20 * 1024 * 1024 // 20 MB max
        if (sizeBytes > maxSizeBytes) {
            return Result.failure(IllegalArgumentException("File size (${"%.1f".format(sizeBytes / (1024.0 * 1024.0))} MB) exceeds the 20 MB limit."))
        }

        // Executable / dangerous extensions check
        val lowerName = fileName.lowercase()
        val dangerousExtensions = listOf(".apk", ".exe", ".sh", ".bat", ".dex", ".so", ".jar", ".bin", ".cmd", ".vbs", ".msi", ".dll")
        if (dangerousExtensions.any { lowerName.endsWith(it) }) {
            return Result.failure(SecurityException("Executable or script files ($fileName) cannot be attached for security reasons."))
        }

        val supportedMimePrefixes = listOf("image/", "text/", "application/pdf", "application/vnd.openxmlformats", "application/msword", "application/json")
        val isSupported = supportedMimePrefixes.any { mimeType.startsWith(it) } ||
                lowerName.endsWith(".pdf") || lowerName.endsWith(".txt") || lowerName.endsWith(".csv") ||
                lowerName.endsWith(".md") || lowerName.endsWith(".docx") || lowerName.endsWith(".xlsx")

        if (!isSupported) {
            return Result.failure(IllegalArgumentException("Unsupported file type ($mimeType). Supported formats include PDF, TXT, CSV, DOCX, XLSX, PNG, and JPEG."))
        }

        return Result.success(true)
    }
}
