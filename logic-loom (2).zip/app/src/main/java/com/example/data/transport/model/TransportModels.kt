package com.example.data.transport.model

/**
 * Supported transport modes in the Logic Loom Transport Hub.
 */
enum class TransportMode(val displayName: String, val iconName: String) {
    TRAIN("Train / Rail", "DirectionsSubway"),
    BUS("Bus (MyCiTi / Golden Arrow)", "DirectionsBus"),
    OTHER("Taxi / Other Public", "LocalTaxi"),
    ALL("All Modes", "Explore")
}

/**
 * Station or transit stop representation with coordinates where available.
 */
data class TransitStation(
    val id: String,
    val name: String,
    val operator: String, // e.g. "PRASA / Metrorail", "MyCiTi", "Golden Arrow"
    val region: String, // e.g. "Western Cape", "Gauteng", "KwaZulu-Natal"
    val lineOrCorridor: String, // e.g. "Southern Line", "Northern Line (via Bellville)", "Central Line"
    val latitude: Double,
    val longitude: Double,
    val zone: Int = 1,
    val isOperational: Boolean = true,
    val notice: String? = null
)

enum class TransportDataType(val label: String) {
    LIVE_API_DATA("Live API Data"),
    OFFICIAL_PUBLISHED_DATA("Official Published Data"),
    GOVERNMENT_PUBLIC_DATA("Government / Publicly Published Data"),
    THIRD_PARTY_DATA("Third-Party Data"),
    DEVELOPER_ESTIMATED_DATA("Developer-Created / Assumed"),
    UNAVAILABLE("Unavailable")
}

/**
 * Published fare breakdown with explicit freshness and source attribution.
 */
data class PublishedFare(
    val singleZar: Double?,
    val returnZar: Double? = null,
    val weeklyZar: Double? = null,
    val monthlyZar: Double? = null,
    val fareCategory: String, // e.g. "Metro (Standard)", "MetroPlus (First Class)", "Zone 1-3"
    val sourceName: String, // e.g. "PRASA / Metrorail Official Published Tariff"
    val effectiveDateText: String, // e.g. "Effective 2024–2026 tariff schedule"
    val dataType: TransportDataType = TransportDataType.OFFICIAL_PUBLISHED_DATA,
    val isLive: Boolean = false,
    val freshnessStatus: String = "Static Published Data (Not Live API)",
    val disclaimer: String = "Published static fare. Ticket prices and concessions are subject to change by the operator. Always verify with the station ticket office before travel."
)

/**
 * Individual travel option / route discovered between origin and destination.
 */
data class TransportOption(
    val id: String,
    val operator: String,
    val mode: TransportMode,
    val originStationOrStop: String,
    val destinationStationOrStop: String,
    val routeName: String,
    val corridor: String,
    val straightLineDistanceKm: Double,
    val estimatedTrackDistanceKm: Double?,
    val intermediateStopsCount: Int,
    val publishedFare: PublishedFare?,
    val frequencyNotice: String,
    val operatingHoursNotice: String,
    val serviceStatusNotice: String? = null,
    val officialSource: String,
    val sourceUrl: String? = null,
    val lastUpdatedDate: String = "September 2026",
    val requiresBooking: Boolean = false,
    val notes: String = ""
)

/**
 * Query submitted to the Transport Hub search engine.
 */
data class TransportSearchQuery(
    val origin: String,
    val destination: String,
    val preferredMode: TransportMode = TransportMode.ALL,
    val originLat: Double? = null,
    val originLng: Double? = null,
    val destLat: Double? = null,
    val destLng: Double? = null
)

/**
 * Result returned from a search across transport providers.
 */
data class TransportSearchResult(
    val query: TransportSearchQuery,
    val options: List<TransportOption>,
    val straightLineDistanceKm: Double?,
    val suggestedOriginStation: TransitStation? = null,
    val suggestedDestinationStation: TransitStation? = null,
    val generalNotice: String? = null,
    val sourcesConsulted: List<String>,
    val timestamp: Long = System.currentTimeMillis()
)
