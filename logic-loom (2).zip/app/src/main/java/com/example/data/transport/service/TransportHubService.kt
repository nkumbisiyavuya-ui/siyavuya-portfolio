package com.example.data.transport.service

import com.example.data.transport.model.*
import com.example.data.transport.provider.PrasaMetrorailProvider
import com.example.data.transport.provider.PublicBusProvider
import com.example.data.transport.provider.TransportProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * High-level service coordinating multiple public transport providers.
 * Calculates straight-line vs actual travel distances, collects published fares,
 * and maintains transparent data provenance.
 */
class TransportHubService(
    private val providers: List<TransportProvider> = listOf(
        PrasaMetrorailProvider(),
        PublicBusProvider()
    )
) {

    suspend fun getAllStations(): List<TransitStation> = withContext(Dispatchers.IO) {
        providers.flatMap { it.getStations() }.distinctBy { it.id }
    }

    suspend fun findNearestStation(lat: Double, lng: Double): TransitStation? = withContext(Dispatchers.IO) {
        val allStations = getAllStations()
        allStations.minByOrNull { s ->
            calculateHaversineDistanceKm(lat, lng, s.latitude, s.longitude)
        }
    }

    suspend fun searchTransport(query: TransportSearchQuery): TransportSearchResult = withContext(Dispatchers.IO) {
        val cleanOrigin = query.origin.trim()
        val cleanDest = query.destination.trim()

        if (cleanOrigin.isBlank() || cleanDest.isBlank()) {
            return@withContext TransportSearchResult(
                query = query,
                options = emptyList(),
                straightLineDistanceKm = null,
                sourcesConsulted = providers.map { it.officialSourceInfo },
                generalNotice = "Please provide both an origin and a destination to search transport information."
            )
        }

        val allStations = getAllStations()
        val origStation = allStations.find {
            it.name.contains(cleanOrigin, ignoreCase = true) || cleanOrigin.contains(it.name, ignoreCase = true)
        }
        val destStation = allStations.find {
            it.name.contains(cleanDest, ignoreCase = true) || cleanDest.contains(it.name, ignoreCase = true)
        }

        val straightDist = if (origStation != null && destStation != null) {
            val dist = calculateHaversineDistanceKm(
                origStation.latitude, origStation.longitude,
                destStation.latitude, destStation.longitude
            )
            kotlin.math.round(dist * 10.0) / 10.0
        } else {
            null
        }

        val collectedOptions = mutableListOf<TransportOption>()
        for (provider in providers) {
            if (query.preferredMode == TransportMode.ALL || provider.supportedModes.contains(query.preferredMode)) {
                try {
                    val opts = provider.searchRoutes(query)
                    collectedOptions.addAll(opts)
                } catch (e: Exception) {
                    // Fail safely per provider
                }
            }
        }

        val notice = if (collectedOptions.isEmpty()) {
            "No direct published commuter routes were found between \"$cleanOrigin\" and \"$cleanDest\". You can search via a central interchange (e.g. Cape Town Station or Bellville)."
        } else null

        TransportSearchResult(
            query = query,
            options = collectedOptions,
            straightLineDistanceKm = straightDist,
            suggestedOriginStation = origStation,
            suggestedDestinationStation = destStation,
            generalNotice = notice,
            sourcesConsulted = providers.map { it.officialSourceInfo }
        )
    }

    private fun calculateHaversineDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = kotlin.math.sin(dLat / 2).let { it * it } +
                kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
                kotlin.math.sin(dLon / 2).let { it * it }
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        return r * c
    }
}
