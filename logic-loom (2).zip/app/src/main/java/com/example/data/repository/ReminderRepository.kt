package com.example.data.repository

import com.example.data.local.Reminder
import kotlinx.coroutines.flow.Flow

interface ReminderRepository {
    val activeReminders: Flow<List<Reminder>>
    val allReminders: Flow<List<Reminder>>
    fun getReminderById(id: Long): Flow<Reminder?>
    fun getRemindersByCourseCode(courseCode: String): Flow<List<Reminder>>
    suspend fun insertReminder(reminder: Reminder): Long
    suspend fun insertReminders(reminders: List<Reminder>): List<Long>
    suspend fun updateReminder(reminder: Reminder)
    suspend fun deleteReminder(reminder: Reminder)
    suspend fun deleteReminderById(id: Long)
}
