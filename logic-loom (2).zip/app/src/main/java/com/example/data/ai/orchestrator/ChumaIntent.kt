package com.example.data.ai.orchestrator

/**
 * Extracted semantic entities from the user prompt.
 */
data class ExtractedEntities(
    val date: String? = null,
    val country: String? = null,
    val city: String? = null,
    val location: String? = null,
    val origin: String? = null,
    val destination: String? = null,
    val subject: String? = null,
    val requestedAction: String? = null,
    val comparisonItems: List<String> = emptyList()
)

/**
 * Encapsulates the classified semantic intent of a user prompt,
 * including required capabilities, decomposition steps, confidence, and extracted entities.
 */
data class ChumaIntent(
    val taskType: ChumaTaskType,
    val primaryCategory: String = "general",
    val subAction: String? = null,
    val requiredCapabilities: Set<ChumaCapability> = emptySet(),
    val confidence: ChumaConfidence = ChumaConfidence.MEDIUM,
    val isSearchRequired: Boolean = false,
    val isMultiStep: Boolean = false,
    val steps: List<String> = emptyList(),
    val parameters: Map<String, String> = emptyMap(),
    val explanation: String? = null,
    val entities: ExtractedEntities = ExtractedEntities()
)
