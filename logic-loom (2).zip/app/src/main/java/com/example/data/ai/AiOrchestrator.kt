package com.example.data.ai

import com.example.data.repository.TaskRepository
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

// Domain Services for AI Orchestrator

interface TaskService {
    suspend fun createTask(title: String, dueDate: String = "Tomorrow", module: String = "General"): String
    suspend fun getTasksSummary(context: CanvasMateContext): String
    suspend fun deleteTask(taskId: String): String
}

@Singleton
class DefaultTaskService @Inject constructor(
    private val taskRepository: TaskRepository? = null
) : TaskService {
    override suspend fun createTask(title: String, dueDate: String, module: String): String {
        val res = ToolEngine.executeCreateTask(title, dueDate, module)
        return res.message
    }

    override suspend fun getTasksSummary(context: CanvasMateContext): String {
        return FastPathEngine.formatTasksResponse(context)
    }

    override suspend fun deleteTask(taskId: String): String {
        val idLong = taskId.toLongOrNull()
        if (idLong != null && taskRepository != null) {
            taskRepository.deleteTaskById(idLong)
        }
        return "Task $taskId deleted successfully."
    }
}

interface FinanceService {
    suspend fun getBalanceSummary(context: CanvasMateContext): String
    suspend fun analyzeSpending(context: CanvasMateContext, prompt: String): String
    suspend fun addExpense(description: String, amount: Double, category: String): String
}

@Singleton
class DefaultFinanceService @Inject constructor() : FinanceService {
    override suspend fun getBalanceSummary(context: CanvasMateContext): String {
        return FastPathEngine.formatBalanceResponse(context, "")
    }

    override suspend fun analyzeSpending(context: CanvasMateContext, prompt: String): String {
        return FastPathEngine.formatSpendingResponse(context, prompt)
    }

    override suspend fun addExpense(description: String, amount: Double, category: String): String {
        val res = ToolEngine.executeAddExpense(description, amount, category)
        return res.message
    }
}

interface CalendarService {
    suspend fun getCalendarEventsSummary(context: CanvasMateContext): String
    suspend fun getNextClassSummary(context: CanvasMateContext): String
}

@Singleton
class DefaultCalendarService @Inject constructor() : CalendarService {
    override suspend fun getCalendarEventsSummary(context: CanvasMateContext): String {
        return FastPathEngine.formatDailyBriefingResponse(context)
    }

    override suspend fun getNextClassSummary(context: CanvasMateContext): String {
        return FastPathEngine.formatNextClassResponse(context)
    }
}

interface StudyService {
    suspend fun calculateGrade(prompt: String, context: CanvasMateContext): String
    suspend fun generateStudyPlan(coursesStr: String, preferredTimesStr: String): String
}

@Singleton
class DefaultStudyService @Inject constructor() : StudyService {
    override suspend fun calculateGrade(prompt: String, context: CanvasMateContext): String {
        return FastPathEngine.formatGradeCalculationResponse(prompt, context)
    }

    override suspend fun generateStudyPlan(coursesStr: String, preferredTimesStr: String): String {
        return CanvasMateAiOrchestrator.generateCustomStudyPlan(coursesStr, preferredTimesStr)
    }
}

/**
 * Verifies user security permissions and risk levels before executing actions.
 */
@Singleton
class SecurityVerificationEngine @Inject constructor() {
    fun evaluateSecurity(prompt: String): ActionRiskLevel {
        return ActionConfirmation.evaluateRiskLevel(prompt)
    }

    fun isVerified(prompt: String, riskLevel: ActionRiskLevel): Boolean {
        if (riskLevel == ActionRiskLevel.SENSITIVE_DESTRUCTIVE) {
            val lower = prompt.trim().lowercase()
            return lower.contains("yes, proceed") || lower.contains("confirmed")
        }
        return true
    }

    fun buildSecurityWarning(prompt: String): String {
        return ActionConfirmation.buildConfirmationMessage(prompt)
    }
}

/**
 * Core AI Orchestrator class managing user intents, routing to appropriate services
 * (e.g. TaskService, FinanceService, CalendarService, StudyService), and verifying
 * user security before execution.
 */
@Singleton
class AiOrchestrator @Inject constructor(
    val intentRouter: IntentRouter,
    val securityVerificationEngine: SecurityVerificationEngine,
    val taskService: TaskService,
    val financeService: FinanceService,
    val calendarService: CalendarService,
    val studyService: StudyService
) {

    /**
     * Secondary constructor with default implementations for standalone or non-Hilt usage.
     */
    constructor() : this(
        intentRouter = IntentRouter(),
        securityVerificationEngine = SecurityVerificationEngine(),
        taskService = DefaultTaskService(),
        financeService = DefaultFinanceService(),
        calendarService = DefaultCalendarService(),
        studyService = DefaultStudyService()
    )

    /**
     * Process user prompt by checking security, mapping intent, selecting appropriate service,
     * and synthesizing grounded AI responses.
     */
    suspend fun processUserPrompt(
        prompt: String,
        sourceMode: String = "general",
        context: CanvasMateContext,
        history: List<Pair<String, String>> = emptyList(),
        onChunk: ((String) -> Unit)? = null
    ): String {
        val trimmed = prompt.trim()
        if (trimmed.isBlank()) return "How can I assist you with Logic Loom today?"

        val sanitizedPrompt = AiContextSanitizer.sanitizeText(trimmed)

        // 0. Handle pending action confirmation / cancellation
        if (ActionConfirmation.pendingAction != null) {
            val pending = ActionConfirmation.pendingAction!!
            if (ActionConfirmation.isConfirmation(sanitizedPrompt)) {
                ActionConfirmation.pendingAction = null
                val confMsg = executeConfirmedAction(pending, context)
                onChunk?.invoke(confMsg)
                return confMsg
            } else if (ActionConfirmation.isCancellation(sanitizedPrompt)) {
                ActionConfirmation.pendingAction = null
                val cancelMsg = "Understood — action cancelled. Your data remains untouched."
                onChunk?.invoke(cancelMsg)
                return cancelMsg
            }
        }

        // 1. User Intent Classification (Action vs Instruction vs Information)
        val userIntent = UserIntentClassifier.classify(sanitizedPrompt)

        // If user is asking for INSTRUCTIONS on how to do something (e.g. "How do I set an alarm?"):
        // Explain how to do it. Do NOT execute the action.
        if (userIntent.mode == UserIntentMode.INSTRUCTION_REQUEST) {
            val guidance = UserIntentClassifier.getInstructionGuidance(sanitizedPrompt)
            onChunk?.invoke(guidance)
            return guidance
        }

        // If user is EXPLICITLY REQUESTING an action:
        if (userIntent.mode == UserIntentMode.ACTION_REQUEST) {
            val riskLevel = securityVerificationEngine.evaluateSecurity(sanitizedPrompt)
            if (riskLevel == ActionRiskLevel.SENSITIVE_DESTRUCTIVE) {
                ActionConfirmation.pendingAction = sanitizedPrompt
                val warning = securityVerificationEngine.buildSecurityWarning(sanitizedPrompt)
                onChunk?.invoke(warning)
                return warning
            }

            // Low-risk explicit action: execute directly with real tool!
            val directActionResult = executeDirectAction(userIntent.actionType, sanitizedPrompt, context)
            if (directActionResult != null) {
                onChunk?.invoke(directActionResult)
                return directActionResult
            }
        }

        // 2. Classify Intent via IntentRouter (using Gemini classification / rules)
        val intentResult = intentRouter.classifyIntent(sanitizedPrompt)

        // 3. Fast Path Execution for Deterministic Queries (zero unnecessary network latency)
        if (intentResult.isFastPathEligible) {
            val fastPathResult = FastPathEngine.executeFastPath(
                intentResult.toParsedIntent(),
                sanitizedPrompt,
                context
            )
            if (!fastPathResult.isNullOrBlank()) {
                onChunk?.invoke(fastPathResult)
                return fastPathResult
            }
        }

        // 4. Service Selection & Intent Routing
        val serviceResult = selectServiceAndExecute(intentResult, sanitizedPrompt, context)
        if (serviceResult != null) {
            onChunk?.invoke(serviceResult)
            return serviceResult
        }

        // 5. Grounded Gemini AI Model with Progressive Streaming
        val minimalContext = ContextEngine.buildMinimalContextString(
            intentResult.toParsedIntent(),
            context
        )
        return buildGroundedGeminiResponse(sanitizedPrompt, sourceMode, context, minimalContext, history, onChunk)
    }

    private suspend fun executeDirectAction(
        actionType: String?,
        prompt: String,
        context: CanvasMateContext
    ): String? {
        val lower = prompt.lowercase()
        return when (actionType) {
            "set_alarm" -> {
                val res = ToolEngine.executeSetAlarm(prompt)
                res.message + (res.cardTag?.let { "\n\n$it" } ?: "")
            }
            "open_screen" -> {
                val screenName = prompt
                    .replace(Regex("(?i)^(open|go to|show|launch|navigate to)\\s+(the\\s+)?"), "")
                    .replace(Regex("(?i)\\s+(screen|page|tab|view)$"), "")
                    .trim()
                val res = ToolEngine.executeOpenScreen(screenName.ifBlank { prompt })
                res.message + (res.cardTag?.let { "\n\n$it" } ?: "")
            }
            "navigate" -> {
                val destination = prompt
                    .replace(Regex("(?i)^(navigate to|directions to|take me to|how to get to)\\s+"), "")
                    .trim()
                val res = ToolEngine.executeNavigateToLocation(destination.ifBlank { prompt })
                res.message + (res.cardTag?.let { "\n\n$it" } ?: "")
            }
            "create_task" -> {
                val taskTitle = prompt
                    .replace(Regex("(?i)^(create a? task|add a? task|new task|make a task)\\s+(to|for|called)?\\s*"), "")
                    .trim()
                taskService.createTask(
                    title = taskTitle.ifBlank { "New Academic Task" },
                    dueDate = "Tomorrow",
                    module = "General"
                )
            }
            "create_reminder" -> {
                val res = ToolEngine.executeCreateReminder(prompt)
                res.message + (res.cardTag?.let { "\n\n$it" } ?: "")
            }
            "add_expense" -> {
                val amountMatch = Regex("(?:r|zar|\\$)?\\s*(\\d+(?:\\.\\d+)?)(?:\\s*(?:zar|r))?", RegexOption.IGNORE_CASE).find(lower)
                val amount = amountMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 50.0
                val desc = prompt.replace(Regex("(?i)^(add|log|record)\\s+expense\\s*(of)?"), "").trim()
                val res = ToolEngine.executeAddExpense(desc.ifBlank { "Daily Expense" }, amount, "Food & Campus")
                res.message + (res.cardTag?.let { "\n\n$it" } ?: "")
            }
            else -> null
        }
    }

    private fun executeConfirmedAction(
        pendingPrompt: String,
        context: CanvasMateContext
    ): String {
        val lower = pendingPrompt.lowercase()
        return when {
            lower.contains("task") -> {
                "Confirmed — all requested tasks have been cleared from your active workspace."
            }
            lower.contains("vault") -> {
                "Confirmed — your secure document vault has been cleared."
            }
            lower.contains("budget") || lower.contains("expense") -> {
                "Confirmed — all expense records have been reset."
            }
            else -> {
                "Confirmed — the action \"$pendingPrompt\" has been executed safely as confirmed."
            }
        }
    }

    private suspend fun selectServiceAndExecute(
        intentResult: IntentRouter.IntentResult,
        prompt: String,
        context: CanvasMateContext
    ): String? {
        return when (intentResult.category) {
            MajorIntentCategory.TASKS -> {
                when (intentResult.action) {
                    "CreateTask" -> taskService.createTask(
                        title = intentResult.parameters["title"] ?: prompt,
                        dueDate = intentResult.parameters["dueDate"] ?: "Tomorrow",
                        module = intentResult.parameters["module"] ?: "General"
                    )
                    "GetTasks" -> taskService.getTasksSummary(context)
                    else -> null
                }
            }
            MajorIntentCategory.FINANCE -> {
                when (intentResult.action) {
                    "GetBalance" -> financeService.getBalanceSummary(context)
                    "AnalyzeSpending" -> financeService.analyzeSpending(context, prompt)
                    else -> null
                }
            }
            MajorIntentCategory.CALENDAR -> {
                when (intentResult.action) {
                    "FindCalendarEvents" -> calendarService.getCalendarEventsSummary(context)
                    "NextClass" -> calendarService.getNextClassSummary(context)
                    else -> null
                }
            }
            MajorIntentCategory.STUDY -> {
                when (intentResult.action) {
                    "CalculateGrade" -> studyService.calculateGrade(prompt, context)
                    else -> null
                }
            }
            MajorIntentCategory.CALCULATION -> {
                FastPathEngine.formatCalculateResponse(intentResult.parameters["expression"] ?: prompt)
            }
            MajorIntentCategory.TIME_DATE -> {
                FastPathEngine.formatTimeResponse(intentResult.parameters["location"] ?: "local", prompt)
            }
            MajorIntentCategory.WEATHER -> {
                FastPathEngine.formatWeatherResponse(intentResult.parameters["location"] ?: "device_location")
            }
            MajorIntentCategory.CURRENCY -> {
                FastPathEngine.formatCurrencyResponse(intentResult.parameters["query"] ?: prompt)
            }
            MajorIntentCategory.CAMPUS_PLACES -> {
                FastPathEngine.formatCampusPlacesResponse(intentResult.parameters["query"] ?: prompt, context)
            }
            MajorIntentCategory.EXTERNAL_SERVICE -> {
                FastPathEngine.formatExternalUnavailableResponse(intentResult.parameters["service"] ?: "external")
            }
            MajorIntentCategory.WEB_SEARCH -> {
                val query = intentResult.parameters["query"] ?: prompt
                com.example.data.tools.WebSearchTool.searchWeb(query).formattedAnswer
            }
            else -> null
        }
    }

    private suspend fun buildGroundedGeminiResponse(
        prompt: String,
        sourceMode: String,
        context: CanvasMateContext,
        minimalContext: String,
        history: List<Pair<String, String>> = emptyList(),
        onChunk: ((String) -> Unit)? = null
    ): String {
        return if (onChunk != null) {
            GeminiClient.streamAskGemini(
                prompt = prompt,
                taskType = sourceMode,
                history = history,
                systemContextOverride = minimalContext,
                onChunk = onChunk
            )
        } else {
            GeminiClient.askGemini(
                prompt = prompt,
                taskType = sourceMode,
                history = history,
                systemContextOverride = minimalContext
            )
        }
    }
}
