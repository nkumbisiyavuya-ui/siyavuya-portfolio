package com.example.data.ai.orchestrator

import java.util.Locale

/**
 * Semantic intent classification and capability decomposition engine for Chuma AI.
 * Classifies requests into specific task types without blindly matching single keywords,
 * extracts semantic entities, and prevents date confusion or data fabrication.
 */
object ChumaTaskClassifier {

    /**
     * Classifies a user request into a rich ChumaIntent with capabilities, entities, and multi-step decomposition.
     */
    fun classify(
        request: String,
        attachedFiles: List<AttachedFileContext> = emptyList(),
        hintMode: String? = null
    ): ChumaIntent {
        val trimmed = request.trim()
        if (trimmed.isBlank()) {
            return ChumaIntent(
                taskType = ChumaTaskType.GENERAL_QA,
                confidence = ChumaConfidence.LOW,
                explanation = "Empty input"
            )
        }

        val lower = trimmed.lowercase(Locale.ROOT)

        // 1. Attached file presence or file analysis request
        if (attachedFiles.isNotEmpty() || isFileAnalysisIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.FILE_ANALYSIS,
                primaryCategory = "files",
                requiredCapabilities = setOf(ChumaCapability.FILE_ANALYSIS, ChumaCapability.FILE_RETRIEVAL, ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "File or document analysis requested"
            )
        }

        // 2. Multi-step task detection
        val multiStepPlan = detectMultiStepPlan(trimmed, lower)
        if (multiStepPlan.isNotEmpty()) {
            val reqCaps = mutableSetOf(ChumaCapability.GEMINI)
            if (shouldSearchWeb(lower, trimmed)) reqCaps.add(ChumaCapability.WEB_SEARCH)
            if (isMathQuery(lower)) reqCaps.add(ChumaCapability.CALCULATOR)
            return ChumaIntent(
                taskType = ChumaTaskType.MULTI_STEP_TASK,
                primaryCategory = "orchestration",
                isMultiStep = true,
                steps = multiStepPlan,
                requiredCapabilities = reqCaps,
                isSearchRequired = reqCaps.contains(ChumaCapability.WEB_SEARCH),
                confidence = ChumaConfidence.HIGH,
                explanation = "Multi-step complex workflow detected"
            )
        }

        // 3. User Data operations (Delete, Update, Create)
        val userDataIntent = detectUserDataIntent(lower, trimmed)
        if (userDataIntent != null) {
            return userDataIntent
        }

        // 4. Date and Holiday intents (CRITICAL: before general QA or search to prevent overriding explicit dates)
        val dateOrHolidayIntent = detectDateOrHolidayIntent(lower, trimmed)
        if (dateOrHolidayIntent != null) {
            return dateOrHolidayIntent
        }

        // 5. Public Transport & Fares (PRASA, Trains, Buses, Fares, Distances)
        val transportIntent = detectTransportIntent(lower, trimmed)
        if (transportIntent != null) {
            return transportIntent
        }

        // 6. Weather Forecast & Current Weather
        val weatherIntent = detectWeatherIntent(lower, trimmed)
        if (weatherIntent != null) {
            return weatherIntent
        }

        // 7. Location & Nearby Places
        val locationIntent = detectLocationOrNearbyIntent(lower, trimmed)
        if (locationIntent != null) {
            return locationIntent
        }

        // 8. Memory & Knowledge Vault Search
        val searchOrMemoryIntent = detectSearchOrMemoryIntent(lower, trimmed)
        if (searchOrMemoryIntent != null) {
            return searchOrMemoryIntent
        }

        // 9. Comparison
        val comparisonIntent = detectComparisonIntent(lower, trimmed)
        if (comparisonIntent != null) {
            return comparisonIntent
        }

        // 10. Debugging (Code crashes, stack traces, compiler errors)
        if (isDebuggingIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.DEBUGGING,
                primaryCategory = "code",
                requiredCapabilities = setOf(ChumaCapability.CODE_ANALYSIS, ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Code debugging or crash resolution requested"
            )
        }

        // 11. Coding (Writing new code, implementations, syntax)
        if (isCodingIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.CODING,
                primaryCategory = "code",
                requiredCapabilities = setOf(ChumaCapability.CODE_ANALYSIS, ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Software development or coding requested"
            )
        }

        // 12. Direct Tool Requests (Alarm, Screen navigation)
        val toolIntent = detectToolRequestIntent(lower, trimmed)
        if (toolIntent != null) {
            return toolIntent
        }

        // 13. Mathematics / Calculation
        if (isMathQuery(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.MATHEMATICS,
                primaryCategory = "calculator",
                subAction = "calculate",
                requiredCapabilities = setOf(ChumaCapability.CALCULATOR),
                parameters = mapOf("expression" to extractMathExpression(trimmed)),
                confidence = ChumaConfidence.HIGH,
                explanation = "Mathematical calculation requested"
            )
        }

        // 14. Current Information / Web Search
        if (shouldSearchWeb(lower, trimmed)) {
            return ChumaIntent(
                taskType = ChumaTaskType.WEB_RESEARCH,
                primaryCategory = "search",
                subAction = "web_search",
                requiredCapabilities = setOf(ChumaCapability.WEB_SEARCH, ChumaCapability.GEMINI),
                isSearchRequired = true,
                parameters = mapOf("query" to trimmed),
                confidence = ChumaConfidence.HIGH,
                explanation = "Time-sensitive or external current information requested"
            )
        }

        // 15. In-depth Academic Research
        if (isResearchIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.RESEARCH,
                primaryCategory = "research",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "In-depth research or academic analysis requested"
            )
        }

        // 16. Planning & Timetables
        if (isPlanningIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.PLANNING,
                primaryCategory = "planning",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Scheduling or structured planning requested"
            )
        }

        // 17. Writing / Drafting
        if (isWritingIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.WRITING,
                primaryCategory = "writing",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Content creation or drafting requested"
            )
        }

        // 18. Editing / Proofreading
        if (isEditingIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.EDITING,
                primaryCategory = "editing",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Text editing or proofreading requested"
            )
        }

        // 19. Summarization
        if (isSummarizationIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.SUMMARIZATION,
                primaryCategory = "summarization",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Text condensation or summarization requested"
            )
        }

        // 20. Translation
        if (isTranslationIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.TRANSLATION,
                primaryCategory = "translation",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Language translation requested"
            )
        }

        // 21. Data Analysis
        if (isDataAnalysisIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.DATA_ANALYSIS,
                primaryCategory = "analysis",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Data interpretation requested"
            )
        }

        // 22. Logical Reasoning
        if (isReasoningIntent(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.REASONING,
                primaryCategory = "reasoning",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Deductive or conceptual reasoning requested"
            )
        }

        // 23. General Q&A vs Unknown
        if (isGeneralQa(lower)) {
            return ChumaIntent(
                taskType = ChumaTaskType.GENERAL_QA,
                primaryCategory = "general",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "General knowledge or conceptual inquiry"
            )
        }

        return ChumaIntent(
            taskType = ChumaTaskType.UNKNOWN,
            primaryCategory = "general",
            requiredCapabilities = setOf(ChumaCapability.GEMINI),
            confidence = ChumaConfidence.LOW,
            explanation = "Uncertain intent; defaulting to unified intelligence"
        )
    }

    /**
     * Determines strictly if search is justified.
     */
    fun shouldSearchWeb(lower: String, raw: String): Boolean {
        if (isMathQuery(lower) || isTranslationIntent(lower) || isEditingIntent(lower) || isWritingIntent(lower)) {
            return false
        }
        if (lower.startsWith("what is a ") || lower.startsWith("what is an ") || lower.startsWith("explain what is ") || lower.startsWith("explain what an ")) {
            val term = lower.removePrefix("what is a ").removePrefix("what is an ").removePrefix("explain what is ").removePrefix("explain what an ").trim()
            if (term in setOf("calendar", "computer", "compiler", "algorithm", "database", "api", "photosynthesis", "gravity", "cell")) {
                return false
            }
        }

        if (lower.startsWith("search") || lower.contains("search for") || lower.contains("search the web") || lower.contains("google this") || lower.contains("look up online")) {
            return true
        }

        if (lower.contains("latest") || lower.contains("current") || lower.contains("today's") || lower.contains("today") || lower.contains("recent") || lower.contains("this year") || lower.contains("breaking news")) {
            return true
        }

        if ((lower.contains("price") || lower.contains("cost") || lower.contains("worth") || lower.contains("stock")) &&
            (lower.contains("current") || lower.contains("now") || lower.contains("today") || lower.contains("how much is") || lower.contains("market"))
        ) {
            return true
        }

        if (lower.contains("internship") || lower.contains("vacancies") || lower.contains("job opening") || lower.contains("hiring")) {
            return true
        }

        if (lower.contains("release") || lower.contains("announced") || lower.contains("version 202") || lower.contains("android studio release")) {
            return true
        }

        if (lower.contains("regulation") || lower.contains("policy update") || lower.contains("statute") || lower.contains("law changed")) {
            return true
        }

        if (lower.contains("scores") || lower.contains("match result") || lower.contains("tournament winner") || lower.contains("who won yesterday")) {
            return true
        }

        if (lower.contains("external sources") || lower.contains("cite sources") || lower.contains("with citations") || lower.contains("find articles")) {
            return true
        }

        return false
    }

    private fun detectDateOrHolidayIntent(lower: String, raw: String): ChumaIntent? {
        val explicitDate = com.example.data.tools.HolidayCalendarEngine.parseExplicitDate(raw)
        val hasDate = explicitDate != null
        val dateStr = explicitDate?.let { "${it.first} ${it.second.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ENGLISH)}" }

        // 1. South Africa / Public Holiday Check
        if (lower.contains("holiday") || lower.contains("public holiday") || lower.contains("heritage day") || lower.contains("freedom day") || lower.contains("youth day")) {
            val taskType = if (lower.contains("is ") && (lower.contains("a holiday") || lower.contains("a public holiday"))) {
                ChumaTaskType.PUBLIC_HOLIDAY_CHECK
            } else {
                ChumaTaskType.HOLIDAY_LOOKUP
            }
            return ChumaIntent(
                taskType = taskType,
                primaryCategory = "calendar",
                subAction = "time",
                requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Public holiday verification",
                entities = ExtractedEntities(
                    date = dateStr,
                    country = if (lower.contains("south africa") || lower.contains("sa") || lower.contains("rsa")) "South Africa" else null,
                    requestedAction = "holiday_lookup"
                )
            )
        }

        // 2. Date difference ("how many days until 27 September")
        if (lower.contains("how many days") || lower.contains("days until") || lower.contains("days between") || lower.contains("days to")) {
            return ChumaIntent(
                taskType = ChumaTaskType.DATE_DIFFERENCE,
                primaryCategory = "calendar",
                subAction = "time",
                requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Date difference calculation",
                entities = ExtractedEntities(
                    date = dateStr,
                    requestedAction = "date_difference"
                )
            )
        }

        // 3. Historical date query ("what happened on 27 September")
        if (lower.contains("what happened on") || (hasDate && (lower.contains("history") || lower.contains("historical")))) {
            return ChumaIntent(
                taskType = ChumaTaskType.HISTORICAL_DATE_LOOKUP,
                primaryCategory = "history",
                subAction = "web_search",
                requiredCapabilities = setOf(ChumaCapability.WEB_SEARCH, ChumaCapability.GEMINI),
                isSearchRequired = true,
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Historical date query",
                entities = ExtractedEntities(
                    date = dateStr,
                    requestedAction = "historical_date_lookup"
                )
            )
        }

        // 4. Event lookup ("what is on my calendar on 27 September", "events on Friday")
        if (lower.contains("calendar") || lower.contains("events on") || lower.contains("timetable on") || lower.contains("schedule on")) {
            return ChumaIntent(
                taskType = ChumaTaskType.EVENT_LOOKUP,
                primaryCategory = "calendar",
                subAction = "FindCalendarEvents",
                requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Calendar event lookup",
                entities = ExtractedEntities(
                    date = dateStr,
                    requestedAction = "event_lookup"
                )
            )
        }

        // 5. Date Lookup (Explicit date provided, asking what day it is or info about that date)
        if (hasDate && (lower.contains("what is") || lower.contains("which day") || lower.contains("day is") || lower.contains("day of the week"))) {
            return ChumaIntent(
                taskType = ChumaTaskType.DATE_LOOKUP,
                primaryCategory = "calendar",
                subAction = "time",
                requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Explicit date resolution",
                entities = ExtractedEntities(
                    date = dateStr,
                    requestedAction = "date_lookup"
                )
            )
        }

        // 6. Current Date & Time (Only when explicitly asking for current time/today's date)
        if (lower.contains("today's date") || lower.contains("what is today") || lower.contains("current date") ||
            lower.contains("what date is it") || lower.contains("what time is it") || lower.contains("current time") ||
            lower == "date" || lower == "time" || lower == "today") {
            return ChumaIntent(
                taskType = ChumaTaskType.CURRENT_DATE,
                primaryCategory = "time",
                subAction = "time",
                requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                parameters = mapOf("location" to "local"),
                confidence = ChumaConfidence.HIGH,
                explanation = "Current date and time request",
                entities = ExtractedEntities(
                    requestedAction = "current_date"
                )
            )
        }

        return null
    }

    private fun detectTransportIntent(lower: String, raw: String): ChumaIntent? {
        val hasTransportKeyword = lower.contains("train") || lower.contains("prasa") || lower.contains("metrorail") ||
                lower.contains("fare from") || lower.contains("train fare") || lower.contains("bus fare") ||
                lower.contains("how much is the train") || lower.contains("how far is") || lower.contains("bus from") ||
                (lower.contains("bus") && (lower.contains("fare") || lower.contains("route") || lower.contains("schedule")))

        if (!hasTransportKeyword) return null

        val mode = if (lower.contains("train") || lower.contains("prasa") || lower.contains("metrorail") || lower.contains("rail")) {
            "train"
        } else if (lower.contains("bus") || lower.contains("gabs") || lower.contains("myciti")) {
            "bus"
        } else {
            "all"
        }

        val isFare = lower.contains("how much") || lower.contains("fare") || lower.contains("cost") || lower.contains("price") || lower.contains("ticket")
        val isDistance = lower.contains("how far") || lower.contains("distance")
        val isRoute = lower.contains("what train") || lower.contains("which train") || lower.contains("can i use") || lower.contains("schedule") || lower.contains("route")

        val requestedAction = when {
            isFare -> "fare_inquiry"
            isDistance -> "distance_inquiry"
            isRoute -> "route_inquiry"
            else -> "transport_lookup"
        }

        val taskType = if (isFare) ChumaTaskType.FARE_LOOKUP else ChumaTaskType.TRANSPORT_LOOKUP

        var origin: String? = null
        var destination: String? = null

        if (raw.contains(" to ", ignoreCase = true)) {
            val parts = raw.split(Regex("(?i)\\s+to\\s+"), limit = 2)
            val fromRaw = parts[0]
                .replace(Regex("(?i)^(what is the|find|how much is the|how far is the|how far is|what trains can i use from|train fare from|bus fare from|train from|fare from|bus from|prasa from|train|bus)\\s+"), "")
                .replace(Regex("(?i).*\\bfrom\\s+"), "")
                .trim()
            val toRaw = parts[1]
                .replace(Regex("(?i)\\s+(by train|by bus|on prasa|today|please|fare|cost|distance|schedule).*"), "")
                .replace("?", "")
                .trim()

            if (fromRaw.isNotBlank()) origin = fromRaw
            if (toRaw.isNotBlank()) destination = toRaw
        }

        val params = mutableMapOf<String, String>()
        params["mode"] = mode
        params["intent"] = requestedAction
        if (origin != null) params["origin"] = origin
        if (destination != null) params["destination"] = destination

        return ChumaIntent(
            taskType = taskType,
            primaryCategory = "transport",
            subAction = "transport_hub",
            requiredCapabilities = setOf(ChumaCapability.MAPS),
            parameters = params,
            confidence = ChumaConfidence.HIGH,
            explanation = "Public transport fare and route discovery",
            entities = ExtractedEntities(
                origin = origin,
                destination = destination,
                subject = mode,
                requestedAction = requestedAction
            )
        )
    }

    private fun detectWeatherIntent(lower: String, raw: String): ChumaIntent? {
        if (lower.startsWith("weather") || lower.contains("what is the weather") || lower.contains("forecast") || lower.contains("will it rain") || lower.contains("temperature in")) {
            val city = Regex("(?i)(?:in|for)\\s+([a-zA-Z\\s]+)").find(lower)?.groupValues?.get(1)?.trim() ?: "local"
            return ChumaIntent(
                taskType = ChumaTaskType.WEATHER_LOOKUP,
                primaryCategory = "tools",
                subAction = "weather",
                requiredCapabilities = setOf(ChumaCapability.WEATHER),
                parameters = mapOf("location" to city),
                confidence = ChumaConfidence.HIGH,
                explanation = "Weather tool execution",
                entities = ExtractedEntities(city = city, requestedAction = "weather")
            )
        }
        return null
    }

    private fun detectLocationOrNearbyIntent(lower: String, raw: String): ChumaIntent? {
        if (lower.contains("nearby") || lower.contains("near me") || lower.contains("closest ") || lower.contains("close to me")) {
            val subject = lower.replace(Regex(".*?(find|show|where are|search for|is there any|are there any)?\\s*"), "")
                .replace(Regex("\\s+(nearby|near me|close to me).*"), "").trim()
            return ChumaIntent(
                taskType = ChumaTaskType.NEARBY_SEARCH,
                primaryCategory = "maps",
                subAction = "place_search",
                requiredCapabilities = setOf(ChumaCapability.MAPS),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Nearby discovery request",
                entities = ExtractedEntities(subject = subject, requestedAction = "nearby_search")
            )
        }

        if (lower.startsWith("where is") || lower.startsWith("how do i get to") || lower.startsWith("directions to")) {
            val place = lower.replace(Regex("^(where is|how do i get to|directions to)\\s+"), "").replace("?", "").trim()
            return ChumaIntent(
                taskType = ChumaTaskType.LOCATION_LOOKUP,
                primaryCategory = "maps",
                subAction = "place_search",
                requiredCapabilities = setOf(ChumaCapability.MAPS),
                parameters = mapOf("location" to place),
                confidence = ChumaConfidence.HIGH,
                explanation = "Location lookup",
                entities = ExtractedEntities(location = place, requestedAction = "location_lookup")
            )
        }

        return null
    }

    private fun detectUserDataIntent(lower: String, raw: String): ChumaIntent? {
        // DELETE
        if (lower.startsWith("delete all") || lower.startsWith("clear all") || lower.startsWith("wipe") || lower.startsWith("remove all")) {
            val subject = when {
                lower.contains("task") -> "tasks"
                lower.contains("budget") || lower.contains("expense") -> "budget"
                lower.contains("note") -> "notes"
                lower.contains("module") -> "modules"
                else -> "data"
            }
            return ChumaIntent(
                taskType = ChumaTaskType.DELETE_USER_DATA,
                primaryCategory = "user_data",
                subAction = "delete_user_data",
                confidence = ChumaConfidence.HIGH,
                explanation = "Destructive user data deletion requested",
                entities = ExtractedEntities(subject = subject, requestedAction = "delete")
            )
        }

        // UPDATE
        if (lower.startsWith("set my budget") || lower.startsWith("set budget") || lower.startsWith("update profile") ||
            lower.startsWith("change my name") || lower.startsWith("edit budget") || lower.startsWith("set student number")) {
            val subject = when {
                lower.contains("budget") -> "budget"
                lower.contains("profile") || lower.contains("name") -> "profile"
                lower.contains("student") -> "student_number"
                else -> "settings"
            }
            return ChumaIntent(
                taskType = ChumaTaskType.UPDATE_USER_DATA,
                primaryCategory = "user_data",
                subAction = "update_user_data",
                confidence = ChumaConfidence.HIGH,
                explanation = "User data update requested",
                entities = ExtractedEntities(subject = subject, requestedAction = "update")
            )
        }

        // CREATE
        if (lower.startsWith("add task") || lower.startsWith("create task") || lower.startsWith("new task") ||
            lower.startsWith("add expense") || lower.startsWith("log expense") || lower.startsWith("new note") || lower.startsWith("add module")) {
            val subject = when {
                lower.contains("task") -> "task"
                lower.contains("expense") -> "expense"
                lower.contains("note") -> "note"
                lower.contains("module") -> "module"
                else -> "item"
            }
            return ChumaIntent(
                taskType = ChumaTaskType.CREATE,
                primaryCategory = "user_data",
                subAction = "create_user_data",
                confidence = ChumaConfidence.HIGH,
                explanation = "User item creation requested",
                entities = ExtractedEntities(subject = subject, requestedAction = "create")
            )
        }

        return null
    }

    private fun detectSearchOrMemoryIntent(lower: String, raw: String): ChumaIntent? {
        if (lower.startsWith("remember that") || lower.startsWith("don't forget that") || lower.startsWith("remember:")) {
            return ChumaIntent(
                taskType = ChumaTaskType.MEMORY_OPERATION,
                primaryCategory = "memory",
                subAction = "store_memory",
                parameters = mapOf("content" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Explicit user memory storage request",
                entities = ExtractedEntities(requestedAction = "store_memory")
            )
        }

        if (lower.contains("search my notes") || lower.contains("in my notes") || lower.contains("find in notes") || lower.contains("in my vault")) {
            return ChumaIntent(
                taskType = ChumaTaskType.PERSONAL_KNOWLEDGE_SEARCH,
                primaryCategory = "vault",
                subAction = "search_notes",
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Personal knowledge search",
                entities = ExtractedEntities(requestedAction = "personal_knowledge_search")
            )
        }

        if (lower.contains("search files") || lower.contains("in my files") || lower.contains("find document")) {
            return ChumaIntent(
                taskType = ChumaTaskType.FILE_SEARCH,
                primaryCategory = "files",
                subAction = "search_files",
                requiredCapabilities = setOf(ChumaCapability.FILE_RETRIEVAL),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "File search requested",
                entities = ExtractedEntities(requestedAction = "file_search")
            )
        }

        return null
    }

    private fun detectComparisonIntent(lower: String, raw: String): ChumaIntent? {
        if (lower.startsWith("compare ") || lower.contains(" versus ") || lower.contains(" vs ") || lower.contains("difference between")) {
            val items = if (lower.contains(" and ")) {
                val clean = lower.replace(Regex("^(compare|what is the difference between|difference between)\\s+"), "").replace("?", "")
                clean.split(" and ").map { it.trim() }
            } else if (lower.contains(" vs ")) {
                lower.replace(Regex("^(compare)\\s+"), "").replace("?", "").split(" vs ").map { it.trim() }
            } else if (lower.contains(" versus ")) {
                lower.replace(Regex("^(compare)\\s+"), "").replace("?", "").split(" versus ").map { it.trim() }
            } else emptyList()

            return ChumaIntent(
                taskType = ChumaTaskType.COMPARE,
                primaryCategory = "reasoning",
                requiredCapabilities = setOf(ChumaCapability.GEMINI),
                confidence = ChumaConfidence.HIGH,
                explanation = "Comparative evaluation requested",
                entities = ExtractedEntities(comparisonItems = items, requestedAction = "compare")
            )
        }
        return null
    }

    private fun detectToolRequestIntent(lower: String, raw: String): ChumaIntent? {
        if (lower.startsWith("set alarm") || lower.startsWith("set an alarm") || lower.contains("wake me up at") || lower.contains("alarm for")) {
            return ChumaIntent(
                taskType = ChumaTaskType.TOOL_REQUEST,
                primaryCategory = "tools",
                subAction = "set_alarm",
                requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                parameters = mapOf("query" to raw),
                confidence = ChumaConfidence.HIGH,
                explanation = "Alarm tool execution"
            )
        }

        if (lower.startsWith("open ") || lower.startsWith("go to ") || lower.startsWith("navigate to ") || lower.startsWith("show screen")) {
            val screen = lower.replace(Regex("^(open|go to|navigate to|show screen)\\s+"), "").trim()
            if (screen in setOf("notes", "settings", "tasks", "timetable", "gpa", "budget", "vault", "analytics", "dashboard", "transport")) {
                return ChumaIntent(
                    taskType = ChumaTaskType.TOOL_REQUEST,
                    primaryCategory = "tools",
                    subAction = "screen_navigation",
                    requiredCapabilities = setOf(ChumaCapability.OTHER_TOOLS),
                    parameters = mapOf("screenName" to screen),
                    confidence = ChumaConfidence.HIGH,
                    explanation = "Screen navigation execution"
                )
            }
        }

        return null
    }

    private fun detectMultiStepPlan(raw: String, lower: String): List<String> {
        if (lower.contains(" and ") && (lower.contains("find") || lower.contains("search")) && (lower.contains("compare") || lower.contains("tell me which") || lower.contains("summarize"))) {
            return listOf(
                "Retrieve information for candidate entities",
                "Extract and normalize attributes (fees, criteria, requirements)",
                "Conduct comparative synthesis and identify optimum choice"
            )
        }

        if (lower.contains("first") && lower.contains("then") && (lower.contains("finally") || lower.contains("next"))) {
            return listOf(
                "Phase 1: Initial discovery and retrieval",
                "Phase 2: Intermediate transformation and verification",
                "Phase 3: Final integrated synthesis"
            )
        }

        if (lower.contains("plan my day") && lower.contains("calculate") && lower.contains("explain")) {
            return listOf(
                "Organize daily academic schedule",
                "Perform exact grade calculation",
                "Synthesize conceptual explanation"
            )
        }

        return emptyList()
    }

    private fun isFileAnalysisIntent(lower: String): Boolean {
        return (lower.contains("pdf") || lower.contains("document") || lower.contains("file") || lower.contains("attachment") || lower.contains("vault")) &&
                (lower.contains("analyse") || lower.contains("analyze") || lower.contains("read") || lower.contains("extract") || lower.contains("summarize") || lower.contains("methodology"))
    }

    private fun isDebuggingIntent(lower: String): Boolean {
        return lower.contains("crash") || lower.contains("exception") || lower.contains("stack trace") ||
                lower.contains("nullpointer") || lower.contains("error:") || lower.contains("why is it failing") ||
                (lower.contains("why is my") && (lower.contains("not working") || lower.contains("crashing") || lower.contains("broken"))) ||
                (lower.contains("fix") && (lower.contains("bug") || lower.contains("issue") || lower.contains("error") || lower.contains("function")))
    }

    private fun isCodingIntent(lower: String): Boolean {
        return (lower.contains("code") || lower.contains("function") || lower.contains("class") || lower.contains("implement") || lower.contains("kotlin") || lower.contains("compose") || lower.contains("algorithm") || lower.contains("syntax")) &&
                (lower.contains("write") || lower.contains("how to") || lower.contains("create") || lower.contains("example") || lower.contains("build"))
    }

    private fun isMathQuery(lower: String): Boolean {
        if (lower.contains("calculate") || lower.contains("solve") || lower.contains("compound interest")) {
            return true
        }
        val mathRegex = Regex("^[\\d\\s\\+\\-\\*/×÷\\(\\)\\.%\\^=r]+$", RegexOption.IGNORE_CASE)
        val stripped = lower.replace("what is", "").replace("evaluate", "").trim()
        return mathRegex.matches(stripped) && stripped.any { it.isDigit() } && stripped.any { it in "+-*/×÷%^" }
    }

    private fun extractMathExpression(raw: String): String {
        return raw.replace(Regex("(?i)^(what is|calculate|evaluate|solve)\\s*"), "").replace("?", "").trim()
    }

    private fun isResearchIntent(lower: String): Boolean {
        return lower.startsWith("research") || lower.contains("literature review") || lower.contains("deep dive into") || lower.contains("methodology of") || lower.contains("academic study on")
    }

    private fun isPlanningIntent(lower: String): Boolean {
        return lower.startsWith("plan") || lower.contains("schedule") || lower.contains("itinerary") || lower.contains("timetable") || lower.contains("roadmap") || lower.contains("study plan")
    }

    private fun isWritingIntent(lower: String): Boolean {
        return lower.startsWith("write an email") || lower.startsWith("write a letter") || lower.startsWith("draft an essay") || lower.startsWith("write a story") || lower.startsWith("write a proposal") || lower.contains("asking my lecturer for an extension")
    }

    private fun isEditingIntent(lower: String): Boolean {
        return lower.startsWith("proofread") || lower.startsWith("edit this") || lower.contains("fix typos") || lower.contains("improve phrasing") || lower.contains("grammar check")
    }

    private fun isSummarizationIntent(lower: String): Boolean {
        return lower.startsWith("summarize") || lower.startsWith("summarise") || lower.startsWith("give me a summary") || lower.contains("tldr") || lower.contains("in short bullet points")
    }

    private fun isTranslationIntent(lower: String): Boolean {
        return lower.startsWith("translate") || lower.contains("in french") || lower.contains("in isixhosa") || lower.contains("in afrikaans") || lower.contains("in zulu") || lower.contains("in spanish") || lower.contains("in german")
    }

    private fun isDataAnalysisIntent(lower: String): Boolean {
        return lower.contains("dataset") || lower.contains("csv") || lower.contains("spending trend") || lower.contains("statistical variance") || lower.contains("distribution of marks")
    }

    private fun isReasoningIntent(lower: String): Boolean {
        return lower.startsWith("why ") || lower.startsWith("if ") || lower.contains("deduce") || lower.contains("implications of") || lower.contains("logical conclusion")
    }

    private fun isGeneralQa(lower: String): Boolean {
        return lower.startsWith("what is") || lower.startsWith("explain") || lower.startsWith("tell me about") || lower.startsWith("who is") || lower.startsWith("where is") || lower.startsWith("how does") || lower.endsWith("?")
    }
}
