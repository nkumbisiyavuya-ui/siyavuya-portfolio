package com.example.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Represents the current operational state of Voice Recognition.
 */
sealed class VoiceSearchState {
    object Idle : VoiceSearchState()
    object Listening : VoiceSearchState()
    data class Processing(val partialText: String = "") : VoiceSearchState()
    data class Success(val recognizedText: String) : VoiceSearchState()
    data class Error(val message: String) : VoiceSearchState()
}

/**
 * Lifecycle-aware, privacy-first Android SpeechRecognizer wrapper for voice search.
 * Only activates when explicitly invoked by user tap on a microphone button.
 * Never records continuously or secretly.
 */
class VoiceInputManager(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null

    private val _voiceState = MutableStateFlow<VoiceSearchState>(VoiceSearchState.Idle)
    val voiceState: StateFlow<VoiceSearchState> = _voiceState.asStateFlow()

    fun isAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Start listening for speech input once user explicitly requests it.
     */
    fun startListening(onResult: (String) -> Unit = {}) {
        if (!isAvailable()) {
            _voiceState.value = VoiceSearchState.Error("Speech recognition is not available on this device.")
            return
        }

        stopListening()

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _voiceState.value = VoiceSearchState.Listening
                    }

                    override fun onBeginningOfSpeech() {
                        _voiceState.value = VoiceSearchState.Listening
                    }

                    override fun onRmsChanged(rmsdB: Float) {}

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _voiceState.value = VoiceSearchState.Processing()
                    }

                    override fun onError(error: Int) {
                        val errorMsg = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_CLIENT -> "Client speech recognition error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                            SpeechRecognizer.ERROR_NETWORK -> "Network error during speech recognition"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please speak clearly."
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognition service busy"
                            SpeechRecognizer.ERROR_SERVER -> "Server recognition error"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input detected."
                            else -> "Voice recognition error ($error)"
                        }
                        _voiceState.value = VoiceSearchState.Error(errorMsg)
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull()?.trim() ?: ""
                        if (spokenText.isNotBlank()) {
                            _voiceState.value = VoiceSearchState.Success(spokenText)
                            onResult(spokenText)
                        } else {
                            _voiceState.value = VoiceSearchState.Error("No clear speech detected.")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partial = matches?.firstOrNull() ?: ""
                        if (partial.isNotBlank()) {
                            _voiceState.value = VoiceSearchState.Processing(partial)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak origin, destination, or transport query...")
            }

            speechRecognizer?.startListening(intent)
            _voiceState.value = VoiceSearchState.Listening
        } catch (e: Exception) {
            _voiceState.value = VoiceSearchState.Error("Failed to initiate voice input: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    /**
     * Stops listening and cleans up microphone resources immediately.
     */
    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // Safe cleanup
        } finally {
            speechRecognizer = null
            if (_voiceState.value is VoiceSearchState.Listening || _voiceState.value is VoiceSearchState.Processing) {
                _voiceState.value = VoiceSearchState.Idle
            }
        }
    }

    fun reset() {
        stopListening()
        _voiceState.value = VoiceSearchState.Idle
    }
}
