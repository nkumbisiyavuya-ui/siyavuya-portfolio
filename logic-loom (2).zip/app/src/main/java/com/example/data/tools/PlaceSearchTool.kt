package com.example.data.tools

import com.example.data.location.LocationService
import com.example.data.location.NearbyPlace

/**
 * PlaceSearchTool provides place discovery and details architecture
 * with strict permission respect and zero fake business generation.
 */
object PlaceSearchTool {

    data class PlaceDetailsResult(
        val success: Boolean,
        val place: NearbyPlace?,
        val formattedSummary: String
    )

    private val locationService = LocationService()

    /**
     * Searches places (cafes, study hubs, libraries, pharmacies) with location permission check.
     */
    fun searchPlaces(query: String, requirePermission: Boolean = false): List<NearbyPlace> {
        return locationService.searchPlaces(query, requirePermission = requirePermission)
    }

    /**
     * Retrieves place details by ID or name safely.
     */
    fun getPlaceDetails(placeName: String): PlaceDetailsResult {
        val places = locationService.searchPlaces(placeName)
        val match = places.firstOrNull { it.name.contains(placeName, ignoreCase = true) }
        return if (match != null) {
            val summary = """
                📍 **${match.name}** (${match.category})
                • **Address**: ${match.address}
                • **Distance**: ${match.distanceKm} km
                • **Opening Status**: ${match.openingStatus}
                • **Student Rating**: ⭐ ${match.rating}
            """.trimIndent()
            PlaceDetailsResult(true, match, summary)
        } else {
            PlaceDetailsResult(
                false,
                null,
                "Place '$placeName' was not found in the verified campus directory."
            )
        }
    }
}
