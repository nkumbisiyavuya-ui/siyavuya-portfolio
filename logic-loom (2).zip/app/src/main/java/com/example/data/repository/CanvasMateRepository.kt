package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Concrete implementation of [StudentRepository] that delegates Room database operations
 * to [CanvasMateDao] using coroutines and Flow streams.
 */
class CanvasMateRepository(private val dao: CanvasMateDao) : StudentRepository {

    // User Profile
    override val userProfile: Flow<UserProfile?> = dao.getUserProfile()
    override suspend fun getUserProfileDirect(): UserProfile? = withContext(Dispatchers.IO) {
        dao.getUserProfileDirect()
    }
    override suspend fun updateUserProfile(profile: UserProfile) = withContext(Dispatchers.IO) {
        dao.insertOrUpdateUserProfile(profile)
    }

    // Academic Tasks (Student Tasks)
    override val academicTasks: Flow<List<AcademicTask>> = dao.getAllAcademicTasks()
    override fun getAcademicTaskById(id: Long): Flow<AcademicTask?> = dao.getAcademicTaskById(id)
    override fun getAcademicTasksByStatus(status: String): Flow<List<AcademicTask>> = dao.getAcademicTasksByStatus(status)
    override fun getAcademicTasksByModule(module: String): Flow<List<AcademicTask>> = dao.getAcademicTasksByModule(module)
    override suspend fun addAcademicTask(task: AcademicTask): Long = withContext(Dispatchers.IO) {
        dao.insertAcademicTask(task)
    }
    override suspend fun updateAcademicTask(task: AcademicTask) = withContext(Dispatchers.IO) {
        dao.updateAcademicTask(task)
    }
    override suspend fun deleteAcademicTask(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteAcademicTask(id)
    }
    override suspend fun deleteAcademicTask(task: AcademicTask) = withContext(Dispatchers.IO) {
        dao.deleteAcademicTask(task)
    }

    // Todo Tasks
    override val todoTasks: Flow<List<TodoTask>> = dao.getAllTodoTasks()
    override fun getTodoTaskById(id: Long): Flow<TodoTask?> = dao.getTodoTaskById(id)
    override suspend fun addTodoTask(task: TodoTask): Long = withContext(Dispatchers.IO) {
        dao.insertTodoTask(task)
    }
    override suspend fun updateTodoTask(task: TodoTask) = withContext(Dispatchers.IO) {
        dao.updateTodoTask(task)
    }
    override suspend fun deleteTodoTask(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteTodoTask(id)
    }
    override suspend fun deleteTodoTask(task: TodoTask) = withContext(Dispatchers.IO) {
        dao.deleteTodoTask(task)
    }

    // Calendar Events (Course Schedule & Reminders)
    override val calendarEvents: Flow<List<CalendarEvent>> = dao.getAllCalendarEvents()
    override fun getCalendarEventById(id: Long): Flow<CalendarEvent?> = dao.getCalendarEventById(id)
    override suspend fun addCalendarEvent(event: CalendarEvent): Long = withContext(Dispatchers.IO) {
        dao.insertCalendarEvent(event)
    }
    override suspend fun updateCalendarEvent(event: CalendarEvent) = withContext(Dispatchers.IO) {
        dao.updateCalendarEvent(event)
    }
    override suspend fun deleteCalendarEvent(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteCalendarEvent(id)
    }
    override suspend fun deleteCalendarEvent(event: CalendarEvent) = withContext(Dispatchers.IO) {
        dao.deleteCalendarEvent(event)
    }

    // Timetable Slots (Course Schedule)
    override val timetableSlots: Flow<List<TimetableSlot>> = dao.getAllTimetableSlots()
    override fun getTimetableSlotById(id: Long): Flow<TimetableSlot?> = dao.getTimetableSlotById(id)
    override suspend fun addTimetableSlot(slot: TimetableSlot): Long = withContext(Dispatchers.IO) {
        dao.insertTimetableSlot(slot)
    }
    override suspend fun updateTimetableSlot(slot: TimetableSlot) = withContext(Dispatchers.IO) {
        dao.updateTimetableSlot(slot)
    }
    override suspend fun deleteTimetableSlot(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteTimetableSlot(id)
    }
    override suspend fun deleteTimetableSlot(slot: TimetableSlot) = withContext(Dispatchers.IO) {
        dao.deleteTimetableSlot(slot)
    }

    // Notes
    override val notes: Flow<List<NoteItem>> = dao.getAllNotes()
    override fun getNoteById(id: Long): Flow<NoteItem?> = dao.getNoteById(id)
    override suspend fun addNote(note: NoteItem): Long = withContext(Dispatchers.IO) {
        dao.insertNote(note)
    }
    override suspend fun updateNote(note: NoteItem) = withContext(Dispatchers.IO) {
        dao.updateNote(note)
    }
    override suspend fun deleteNote(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteNote(id)
    }
    override suspend fun deleteNote(note: NoteItem) = withContext(Dispatchers.IO) {
        dao.deleteNote(note)
    }

    // Vault
    override val vaultDocuments: Flow<List<VaultDocument>> = dao.getAllVaultDocuments()
    override fun getVaultDocumentById(id: Long): Flow<VaultDocument?> = dao.getVaultDocumentById(id)
    override suspend fun addVaultDocument(doc: VaultDocument): Long = withContext(Dispatchers.IO) {
        dao.insertVaultDocument(doc)
    }
    override suspend fun updateVaultDocument(doc: VaultDocument) = withContext(Dispatchers.IO) {
        dao.updateVaultDocument(doc)
    }
    override suspend fun deleteVaultDocument(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteVaultDocument(id)
    }
    override suspend fun deleteVaultDocument(doc: VaultDocument) = withContext(Dispatchers.IO) {
        dao.deleteVaultDocument(doc)
    }

    // Budget
    override val budgetItems: Flow<List<BudgetItem>> = dao.getAllBudgetItems()
    override fun getBudgetItemById(id: Long): Flow<BudgetItem?> = dao.getBudgetItemById(id)
    override fun getBudgetItemsByType(type: String): Flow<List<BudgetItem>> = dao.getBudgetItemsByType(type)
    override fun getBudgetItemsByCategory(category: String): Flow<List<BudgetItem>> = dao.getBudgetItemsByCategory(category)
    override suspend fun addBudgetItem(item: BudgetItem): Long = withContext(Dispatchers.IO) {
        dao.insertBudgetItem(item)
    }
    override suspend fun updateBudgetItem(item: BudgetItem) = withContext(Dispatchers.IO) {
        dao.updateBudgetItem(item)
    }
    override suspend fun deleteBudgetItem(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteBudgetItem(id)
    }
    override suspend fun deleteBudgetItem(item: BudgetItem) = withContext(Dispatchers.IO) {
        dao.deleteBudgetItem(item)
    }

    override val budgetGoals: Flow<List<BudgetGoal>> = dao.getAllBudgetGoals()
    override fun getBudgetGoalById(id: Long): Flow<BudgetGoal?> = dao.getBudgetGoalById(id)
    override suspend fun addBudgetGoal(goal: BudgetGoal): Long = withContext(Dispatchers.IO) {
        dao.insertBudgetGoal(goal)
    }
    override suspend fun updateBudgetGoal(goal: BudgetGoal) = withContext(Dispatchers.IO) {
        dao.updateBudgetGoal(goal)
    }
    override suspend fun deleteBudgetGoal(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteBudgetGoal(id)
    }
    override suspend fun deleteBudgetGoal(goal: BudgetGoal) = withContext(Dispatchers.IO) {
        dao.deleteBudgetGoal(goal)
    }

    // Goals
    override val goals: Flow<List<GoalItem>> = dao.getAllGoals()
    override fun getGoalById(id: Long): Flow<GoalItem?> = dao.getGoalById(id)
    override suspend fun addGoal(goal: GoalItem): Long = withContext(Dispatchers.IO) {
        dao.insertGoal(goal)
    }
    override suspend fun updateGoal(goal: GoalItem) = withContext(Dispatchers.IO) {
        dao.updateGoal(goal)
    }
    override suspend fun deleteGoal(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteGoal(id)
    }
    override suspend fun deleteGoal(goal: GoalItem) = withContext(Dispatchers.IO) {
        dao.deleteGoal(goal)
    }

    // Diary
    override val diaryEntries: Flow<List<DiaryEntry>> = dao.getAllDiaryEntries()
    override fun getDiaryEntryById(id: Long): Flow<DiaryEntry?> = dao.getDiaryEntryById(id)
    override suspend fun addDiaryEntry(entry: DiaryEntry): Long = withContext(Dispatchers.IO) {
        dao.insertDiaryEntry(entry)
    }
    override suspend fun updateDiaryEntry(entry: DiaryEntry) = withContext(Dispatchers.IO) {
        dao.updateDiaryEntry(entry)
    }
    override suspend fun deleteDiaryEntry(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteDiaryEntry(id)
    }
    override suspend fun deleteDiaryEntry(entry: DiaryEntry) = withContext(Dispatchers.IO) {
        dao.deleteDiaryEntry(entry)
    }

    // GPA Modules
    override val gpaModules: Flow<List<GpaModule>> = dao.getAllGpaModules()
    override fun getGpaModuleById(id: Long): Flow<GpaModule?> = dao.getGpaModuleById(id)
    override suspend fun addGpaModule(module: GpaModule): Long = withContext(Dispatchers.IO) {
        dao.insertGpaModule(module)
    }
    override suspend fun updateGpaModule(module: GpaModule) = withContext(Dispatchers.IO) {
        dao.updateGpaModule(module)
    }
    override suspend fun deleteGpaModule(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteGpaModule(id)
    }
    override suspend fun deleteGpaModule(module: GpaModule) = withContext(Dispatchers.IO) {
        dao.deleteGpaModule(module)
    }

    // Shuttle Schedules
    override val shuttleSchedules: Flow<List<ShuttleSchedule>> = dao.getAllShuttleSchedules()
    override fun getShuttleScheduleById(id: Long): Flow<ShuttleSchedule?> = dao.getShuttleScheduleById(id)
    override suspend fun addShuttleSchedule(shuttle: ShuttleSchedule): Long = withContext(Dispatchers.IO) {
        dao.insertShuttleSchedule(shuttle)
    }
    override suspend fun updateShuttleSchedule(shuttle: ShuttleSchedule) = withContext(Dispatchers.IO) {
        dao.updateShuttleSchedule(shuttle)
    }
    override suspend fun deleteShuttleSchedule(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteShuttleSchedule(id)
    }
    override suspend fun deleteShuttleSchedule(shuttle: ShuttleSchedule) = withContext(Dispatchers.IO) {
        dao.deleteShuttleSchedule(shuttle)
    }

    // Global Search
    override fun searchNotes(query: String): Flow<List<NoteItem>> = dao.searchNotes(query)
    override fun searchAcademicTasks(query: String): Flow<List<AcademicTask>> = dao.searchAcademicTasks(query)
    override fun searchBudgetItems(query: String): Flow<List<BudgetItem>> = dao.searchBudgetItems(query)
    override fun searchVaultDocuments(query: String): Flow<List<VaultDocument>> = dao.searchVaultDocuments(query)

    // Flashcard Decks & Cards
    override val flashcardDecks: Flow<List<FlashcardDeck>> = dao.getAllFlashcardDecks()
    override val allFlashcards: Flow<List<Flashcard>> = dao.getAllFlashcards()
    override fun getFlashcardsForDeck(deckId: Long): Flow<List<Flashcard>> = dao.getFlashcardsForDeck(deckId)
    override suspend fun addFlashcardDeck(deck: FlashcardDeck): Long = withContext(Dispatchers.IO) {
        dao.insertFlashcardDeck(deck)
    }
    override suspend fun deleteFlashcardDeck(deckId: Long) = withContext(Dispatchers.IO) {
        dao.deleteFlashcardDeck(deckId)
    }
    override suspend fun addFlashcard(card: Flashcard): Long = withContext(Dispatchers.IO) {
        dao.insertFlashcard(card)
    }
    override suspend fun updateFlashcard(card: Flashcard) = withContext(Dispatchers.IO) {
        dao.updateFlashcard(card)
    }
    override suspend fun deleteFlashcard(cardId: Long) = withContext(Dispatchers.IO) {
        dao.deleteFlashcard(cardId)
    }

    // Shopping Items
    override val shoppingItems: Flow<List<ShoppingItem>> = dao.getAllShoppingItems()
    override suspend fun addShoppingItem(item: ShoppingItem): Long = withContext(Dispatchers.IO) {
        dao.insertShoppingItem(item)
    }
    override suspend fun updateShoppingItem(item: ShoppingItem) = withContext(Dispatchers.IO) {
        dao.updateShoppingItem(item)
    }
    override suspend fun deleteShoppingItem(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteShoppingItem(id)
    }

    // Transport Requests
    override val transportRequests: Flow<List<TransportRequest>> = dao.getAllTransportRequests()
    override suspend fun addTransportRequest(request: TransportRequest): Long = withContext(Dispatchers.IO) {
        dao.insertTransportRequest(request)
    }
    override suspend fun updateTransportRequest(request: TransportRequest) = withContext(Dispatchers.IO) {
        dao.updateTransportRequest(request)
    }
    override suspend fun deleteTransportRequest(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteTransportRequest(id)
    }

    // Food Orders
    override val foodOrders: Flow<List<FoodOrder>> = dao.getAllFoodOrders()
    override suspend fun addFoodOrder(order: FoodOrder): Long = withContext(Dispatchers.IO) {
        dao.insertFoodOrder(order)
    }
    override suspend fun updateFoodOrder(order: FoodOrder) = withContext(Dispatchers.IO) {
        dao.updateFoodOrder(order)
    }
    override suspend fun deleteFoodOrder(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteFoodOrder(id)
    }

    // Payment Methods
    override val paymentMethods: Flow<List<PaymentMethodEntity>> = dao.getAllPaymentMethods()
    override suspend fun addPaymentMethod(method: PaymentMethodEntity): Long = withContext(Dispatchers.IO) {
        dao.insertPaymentMethod(method)
    }
    override suspend fun deletePaymentMethod(id: Long) = withContext(Dispatchers.IO) {
        dao.deletePaymentMethod(id)
    }

    // SA Academic Tasks
    override val tasks: Flow<List<Task>> = dao.getAllTasks()
    override fun getTaskById(id: Long): Flow<Task?> = dao.getTaskById(id)
    override fun getTasksByCourseCode(courseCode: String): Flow<List<Task>> = dao.getTasksByCourseCode(courseCode)
    override fun getTasksByAcademicPeriod(academicPeriod: String): Flow<List<Task>> = dao.getTasksByAcademicPeriod(academicPeriod)
    override suspend fun addTask(task: Task): Long = withContext(Dispatchers.IO) {
        dao.insertTask(task)
    }
    override suspend fun updateTask(task: Task) = withContext(Dispatchers.IO) {
        dao.updateTask(task)
    }
    override suspend fun deleteTask(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteTask(id)
    }
    override suspend fun deleteTask(task: Task) = withContext(Dispatchers.IO) {
        dao.deleteTask(task)
    }

    // SA Academic Courses
    override val courses: Flow<List<Course>> = dao.getAllCourses()
    override fun getCourseById(id: Long): Flow<Course?> = dao.getCourseById(id)
    override fun getCourseByCode(courseCode: String): Flow<Course?> = dao.getCourseByCode(courseCode)
    override fun getCoursesByAcademicPeriod(academicPeriod: String): Flow<List<Course>> = dao.getCoursesByAcademicPeriod(academicPeriod)
    override suspend fun addCourse(course: Course): Long = withContext(Dispatchers.IO) {
        dao.insertCourse(course)
    }
    override suspend fun updateCourse(course: Course) = withContext(Dispatchers.IO) {
        dao.updateCourse(course)
    }
    override suspend fun deleteCourse(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteCourse(id)
    }
    override suspend fun deleteCourse(course: Course) = withContext(Dispatchers.IO) {
        dao.deleteCourse(course)
    }

    // Reminders
    override val activeReminders: Flow<List<Reminder>> = dao.getAllActiveReminders()
    override val allReminders: Flow<List<Reminder>> = dao.getAllReminders()
    override fun getReminderById(id: Long): Flow<Reminder?> = dao.getReminderById(id)
    override fun getRemindersByCourseCode(courseCode: String): Flow<List<Reminder>> = dao.getRemindersByCourseCode(courseCode)
    override suspend fun addReminder(reminder: Reminder): Long = withContext(Dispatchers.IO) {
        dao.insertReminder(reminder)
    }
    override suspend fun updateReminder(reminder: Reminder) = withContext(Dispatchers.IO) {
        dao.updateReminder(reminder)
    }
    override suspend fun deleteReminder(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteReminder(id)
    }
    override suspend fun deleteReminder(reminder: Reminder) = withContext(Dispatchers.IO) {
        dao.deleteReminder(reminder)
    }
}
