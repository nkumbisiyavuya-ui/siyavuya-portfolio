package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.SocketTimeoutException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Result wrapper for AI operations.
 */
sealed class AiResult<out T> {
    data class Success<out T>(
        val data: T,
        val modelUsed: String = AiService.DEFAULT_MODEL
    ) : AiResult<T>()

    data class Error(
        val message: String,
        val cause: Throwable? = null,
        val isRetryable: Boolean = false
    ) : AiResult<Nothing>()
}

/**
 * AiService communicates with the Gemini API / Firebase AI SDK runtime,
 * providing secure key management, error handling, model selection,
 * streaming, and structured response parsing.
 */
@Singleton
class AiService @Inject constructor() {

    companion object {
        const val DEFAULT_MODEL = "gemini-3.5-flash"
        const val COMPLEX_REASONING_MODEL = "gemini-3.1-pro-preview"
        const val IMAGE_MODEL = "gemini-2.5-flash-image"

        private const val PLACEHOLDER_KEY = "MY_GEMINI_API_KEY"

        /**
         * Securely checks if a valid Gemini API key is configured.
         */
        fun isApiKeyConfigured(): Boolean {
            val key = getApiKeySafely()
            return key.isNotBlank() && key != PLACEHOLDER_KEY
        }

        /**
         * Retrieves the API key securely without exposing it in plaintext logging.
         */
        private fun getApiKeySafely(): String {
            return try {
                BuildConfig.GEMINI_API_KEY.trim()
            } catch (e: Throwable) {
                ""
            }
        }
    }

    /**
     * Generates textual response using the specified model and prompt with secure handling and fallback.
     */
    suspend fun generateContent(
        prompt: String,
        model: String = DEFAULT_MODEL,
        systemInstruction: String? = null,
        taskType: String = "general"
    ): AiResult<String> = withContext(Dispatchers.IO) {
        val trimmedPrompt = prompt.trim()
        if (trimmedPrompt.isBlank()) {
            return@withContext AiResult.Error("Prompt cannot be blank.", isRetryable = false)
        }

        if (!isApiKeyConfigured()) {
            val offlineResponse = GeminiClient.evaluateOfflineIntelligence(trimmedPrompt, taskType)
            return@withContext AiResult.Success(
                data = offlineResponse,
                modelUsed = "local-grounded-evaluator"
            )
        }

        return@withContext executeWithRetry {
            val response = GeminiClient.askGemini(
                prompt = trimmedPrompt,
                taskType = taskType,
                systemContextOverride = systemInstruction
            )
            if (response.isBlank()) {
                throw IOException("Received empty response from Gemini API.")
            }
            response
        }
    }

    /**
     * Streaming response generator for real-time response chunks.
     */
    suspend fun generateStreamingContent(
        prompt: String,
        onChunk: (String) -> Unit,
        model: String = DEFAULT_MODEL,
        taskType: String = "general"
    ): AiResult<String> = withContext(Dispatchers.IO) {
        if (!isApiKeyConfigured()) {
            val fallback = GeminiClient.generateOfflineAiResponse(prompt, taskType)
            onChunk(fallback)
            return@withContext AiResult.Success(fallback, "local-grounded-fallback")
        }

        try {
            val fullText = GeminiClient.askGemini(prompt, taskType)
            // Emit full text or chunks
            val words = fullText.split(" ")
            val chunkSize = 5
            val sb = StringBuilder()
            for (i in words.indices) {
                sb.append(words[i]).append(" ")
                if ((i + 1) % chunkSize == 0 || i == words.size - 1) {
                    onChunk(sb.toString())
                    sb.clear()
                }
            }
            AiResult.Success(fullText, model)
        } catch (e: Throwable) {
            handleError(e)
        }
    }

    /**
     * Generates a structured JSON response based on expected schema or system directive.
     */
    suspend fun generateStructuredJson(
        prompt: String,
        jsonSchemaDescription: String
    ): AiResult<String> = withContext(Dispatchers.IO) {
        val structuredPrompt = """
            $prompt
            
            Return ONLY a valid JSON object matching this schema description:
            $jsonSchemaDescription
        """.trimIndent()

        generateContent(structuredPrompt, model = DEFAULT_MODEL, taskType = "general")
    }

    /**
     * Executes a registered AI Tool or function call dynamically.
     */
    suspend fun executeToolCall(
        toolName: String,
        args: Map<String, Any?>
    ): AiResult<ToolExecutionResult> = withContext(Dispatchers.IO) {
        try {
            val result = AiToolRegistry.executeTool(toolName, args)
            AiResult.Success(result)
        } catch (e: Throwable) {
            handleError(e)
        }
    }

    /**
     * Returns list of registered AI tools available for Gemini function calling.
     */
    fun getRegisteredTools(): List<AiTool> {
        return AiToolRegistry.getAllTools()
    }

    /**
     * Executes AI call with safe error handling and standard retries for network glitches.
     */
    private suspend fun <T> executeWithRetry(
        maxRetries: Int = 2,
        block: suspend () -> T
    ): AiResult<T> {
        var lastException: Throwable? = null
        repeat(maxRetries) { attempt ->
            try {
                val result = block()
                return AiResult.Success(result)
            } catch (e: SocketTimeoutException) {
                lastException = e
            } catch (e: IOException) {
                lastException = e
            } catch (e: Throwable) {
                return handleError(e)
            }
        }
        return handleError(lastException ?: IOException("Failed after retries."))
    }

    /**
     * Sanitizes errors to ensure API keys or sensitive internal tokens are never leaked in error logs.
     */
    private fun handleError(throwable: Throwable): AiResult.Error {
        val message = throwable.localizedMessage ?: "An unexpected error occurred during AI processing."
        val sanitizedMsg = sanitizeErrorMessage(message)
        val isRetryable = throwable is SocketTimeoutException || throwable is IOException
        return AiResult.Error(
            message = sanitizedMsg,
            cause = throwable,
            isRetryable = isRetryable
        )
    }

    private fun sanitizeErrorMessage(rawMessage: String): String {
        var clean = rawMessage
        val key = getApiKeySafely()
        if (key.isNotBlank() && clean.contains(key)) {
            clean = clean.replace(key, "[REDACTED_API_KEY]")
        }
        return clean
    }
}
