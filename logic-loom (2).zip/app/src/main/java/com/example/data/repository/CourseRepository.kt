package com.example.data.repository

import com.example.data.local.Course
import kotlinx.coroutines.flow.Flow

interface CourseRepository {
    val allCourses: Flow<List<Course>>
    fun getCourseById(id: Long): Flow<Course?>
    fun getCourseByCode(courseCode: String): Flow<Course?>
    fun getCoursesByAcademicPeriod(academicPeriod: String): Flow<List<Course>>
    suspend fun insertCourse(course: Course): Long
    suspend fun insertCourses(courses: List<Course>): List<Long>
    suspend fun updateCourse(course: Course)
    suspend fun deleteCourse(course: Course)
    suspend fun deleteCourseById(id: Long)
}
