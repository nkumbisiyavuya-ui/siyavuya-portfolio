package com.example.data.repository

import com.example.data.local.Reminder
import com.example.data.local.ReminderDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReminderRepositoryImpl @Inject constructor(
    private val reminderDao: ReminderDao
) : ReminderRepository {

    override val activeReminders: Flow<List<Reminder>> = reminderDao.getAllActiveReminders()

    override val allReminders: Flow<List<Reminder>> = reminderDao.getAllReminders()

    override fun getReminderById(id: Long): Flow<Reminder?> = reminderDao.getReminderById(id)

    override fun getRemindersByCourseCode(courseCode: String): Flow<List<Reminder>> =
        reminderDao.getRemindersByCourseCode(courseCode)

    override suspend fun insertReminder(reminder: Reminder): Long = withContext(Dispatchers.IO) {
        reminderDao.insertReminder(reminder)
    }

    override suspend fun insertReminders(reminders: List<Reminder>): List<Long> = withContext(Dispatchers.IO) {
        reminderDao.insertReminders(reminders)
    }

    override suspend fun updateReminder(reminder: Reminder) = withContext(Dispatchers.IO) {
        reminderDao.updateReminder(reminder)
    }

    override suspend fun deleteReminder(reminder: Reminder) = withContext(Dispatchers.IO) {
        reminderDao.deleteReminder(reminder)
    }

    override suspend fun deleteReminderById(id: Long) = withContext(Dispatchers.IO) {
        reminderDao.deleteReminderById(id)
    }
}
