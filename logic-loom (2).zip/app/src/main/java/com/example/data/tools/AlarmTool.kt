package com.example.data.tools

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.AlarmClock
import android.util.Log
import com.example.CanvasMateApplication
import java.util.Calendar
import java.util.Locale

/**
 * Result of attempting to execute an alarm action on Android.
 */
data class AlarmExecutionResult(
    val success: Boolean,
    val message: String,
    val hour: Int? = null,
    val minute: Int? = null,
    val errorReason: String? = null
)

/**
 * Android system integration tool for setting alarms and timers.
 * Executes genuine Android system alarms via AlarmClock.ACTION_SET_ALARM.
 * Strictly adheres to honesty: never returns success unless the system execution succeeded.
 */
object AlarmTool {

    private const val TAG = "AlarmTool"

    // Optional override hook for unit and Robolectric tests
    var overrideExecutor: ((hour: Int, minute: Int, label: String, isTomorrow: Boolean) -> AlarmExecutionResult)? = null

    /**
     * Parses an alarm time and optional label from natural language.
     * Examples:
     * - "Set an alarm for 7 AM tomorrow" -> hour: 7, minute: 0, isTomorrow: true
     * - "Set alarm for 6:30" -> hour: 6, minute: 30
     * - "Alarm at 8 pm" -> hour: 20, minute: 0
     * - "Set an alarm for 14:45" -> hour: 14, minute: 45
     */
    fun parseAlarmRequest(prompt: String): Pair<Int, Int>? {
        val lower = prompt.lowercase(Locale.ROOT)

        // 1. Check for HH:mm format (e.g. 6:30, 07:00, 18:45)
        val timeColonMatch = Regex("(\\b\\d{1,2}):(\\d{2})\\s*(am|pm)?").find(lower)
        if (timeColonMatch != null) {
            var hour = timeColonMatch.groupValues[1].toIntOrNull() ?: return null
            val minute = timeColonMatch.groupValues[2].toIntOrNull() ?: return null
            val amPm = timeColonMatch.groupValues[3].ifBlank { null }

            if (amPm == "pm" && hour < 12) hour += 12
            if (amPm == "am" && hour == 12) hour = 0

            if (hour in 0..23 && minute in 0..59) {
                return Pair(hour, minute)
            }
        }

        // 2. Check for "7 am", "8 pm", "7am", "8pm"
        val amPmMatch = Regex("(\\b\\d{1,2})\\s*(am|pm)\\b").find(lower)
        if (amPmMatch != null) {
            var hour = amPmMatch.groupValues[1].toIntOrNull() ?: return null
            val amPm = amPmMatch.groupValues[2]

            if (amPm == "pm" && hour < 12) hour += 12
            if (amPm == "am" && hour == 12) hour = 0

            if (hour in 0..23) {
                return Pair(hour, 0)
            }
        }

        // 3. Check for "alarm for 7", "alarm at 7" (assume morning/next logical hour if <= 12)
        val simpleNumberMatch = Regex("(?:alarm|remind me)\\s+(?:for|at)?\\s*(\\d{1,2})\\b").find(lower)
        if (simpleNumberMatch != null) {
            val num = simpleNumberMatch.groupValues[1].toIntOrNull()
            if (num != null && num in 0..23) {
                // If simple single digit 1..11, default to morning or standard hour
                return Pair(num, 0)
            }
        }

        return null
    }

    fun isTomorrowRequested(prompt: String): Boolean {
        return prompt.contains("tomorrow", ignoreCase = true)
    }

    /**
     * Executes real Android alarm setting.
     */
    fun setAlarm(
        context: Context? = CanvasMateApplication.safeAppContext,
        hour: Int,
        minute: Int,
        label: String = "Logic Loom Alarm",
        isTomorrow: Boolean = false
    ): AlarmExecutionResult {
        // Test override takes precedence if configured
        overrideExecutor?.let { executor ->
            return executor(hour, minute, label, isTomorrow)
        }

        if (context == null) {
            Log.w(TAG, "Cannot set alarm: Android Context is null.")
            return AlarmExecutionResult(
                success = false,
                message = "I couldn't set the alarm because Android system services are currently unreachable.",
                errorReason = "Context is null"
            )
        }

        // Validate time boundaries
        if (hour !in 0..23 || minute !in 0..59) {
            return AlarmExecutionResult(
                success = false,
                message = "I couldn't set the alarm because $hour:${"%02d".format(minute)} is not a valid 24-hour time.",
                errorReason = "Invalid time bounds"
            )
        }

        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        val amPm = if (hour >= 12) "PM" else "AM"
        val formattedTime = "%d:%02d %s".format(displayHour, minute, amPm)
        val daySuffix = if (isTomorrow) " tomorrow" else ""

        val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            val pm = context.packageManager
            val activities = pm.queryIntentActivities(alarmIntent, PackageManager.MATCH_DEFAULT_ONLY)

            if (activities.isNotEmpty()) {
                context.startActivity(alarmIntent)
                Log.i(TAG, "Successfully invoked AlarmClock.ACTION_SET_ALARM for $hour:$minute")
                AlarmExecutionResult(
                    success = true,
                    message = "Done — your alarm is set for $formattedTime$daySuffix.",
                    hour = hour,
                    minute = minute
                )
            } else {
                // Check if device AlarmManager can be used or report clock app absence
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                if (alarmManager != null) {
                    // Try direct intent without query matching (some OEMs restrict queryIntentActivities)
                    context.startActivity(alarmIntent)
                    AlarmExecutionResult(
                        success = true,
                        message = "Done — your alarm is set for $formattedTime$daySuffix.",
                        hour = hour,
                        minute = minute
                    )
                } else {
                    AlarmExecutionResult(
                        success = false,
                        message = "I couldn't set the alarm because no clock app is available on this device to handle system alarms.",
                        errorReason = "No clock activity found"
                    )
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while setting alarm", e)
            AlarmExecutionResult(
                success = false,
                message = "I couldn't set the alarm because the alarm permission is unavailable or denied by the system.",
                errorReason = e.message
            )
        } catch (e: Exception) {
            Log.e(TAG, "Exception while setting alarm", e)
            AlarmExecutionResult(
                success = false,
                message = "I couldn't set the alarm: ${e.localizedMessage ?: "unexpected error"}.",
                errorReason = e.message
            )
        }
    }
}
