package com.example.data.model

/**
 * Three-State User Data Model for Logic Loom
 *
 * In accordance with LOGIC LOOM GLOBAL USER DATA INTEGRITY:
 * 1. EMPTY: The user has not supplied the value. Display an appropriate empty state.
 * 2. SUGGESTED: Chuma may propose a value, but it is NOT user-owned data.
 *    Actions: [Use] [Edit] [Dismiss]
 * 3. CONFIRMED: The user explicitly accepted or entered the value.
 *    Only confirmed values may become persistent user data.
 *    Never silently convert SUGGESTED into CONFIRMED.
 */
enum class UserDataStatus {
    EMPTY,
    SUGGESTED,
    CONFIRMED
}

data class UserDataField<T>(
    val status: UserDataStatus = UserDataStatus.EMPTY,
    val value: T? = null,
    val suggestionReason: String? = null,
    val suggestionSource: String? = null
) {
    val isEmpty: Boolean get() = status == UserDataStatus.EMPTY || value == null
    val isSuggested: Boolean get() = status == UserDataStatus.SUGGESTED && value != null
    val isConfirmed: Boolean get() = status == UserDataStatus.CONFIRMED && value != null

    companion object {
        fun <T> empty(): UserDataField<T> = UserDataField(status = UserDataStatus.EMPTY, value = null)

        fun <T> suggested(
            value: T,
            reason: String? = null,
            source: String? = "Chuma AI"
        ): UserDataField<T> = UserDataField(
            status = UserDataStatus.SUGGESTED,
            value = value,
            suggestionReason = reason,
            suggestionSource = source
        )

        fun <T> confirmed(value: T): UserDataField<T> = UserDataField(
            status = UserDataStatus.CONFIRMED,
            value = value
        )
    }
}
