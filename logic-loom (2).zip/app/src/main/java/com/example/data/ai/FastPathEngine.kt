package com.example.data.ai

import com.example.data.local.*
import java.text.SimpleDateFormat
import java.util.*

object FastPathEngine {

    suspend fun executeFastPath(intent: ParsedIntent, prompt: String, context: CanvasMateContext): String? {
        return when (intent.subAction) {
            "CHECK_BALANCE", "GetBalance" -> formatBalanceResponse(context, prompt)
            "FIND_TASKS", "GetTasks" -> formatTasksResponse(context)
            "NEXT_CLASS", "NextClass" -> formatNextClassResponse(context)
            "DAILY_BRIEFING", "DailyBriefing" -> formatDailyBriefingResponse(context)
            "CREATE_TASK", "CreateTask" -> formatCreateTaskResponse(prompt)
            "ANALYZE_SPENDING", "AnalyzeSpending" -> formatSpendingResponse(context, prompt)
            "FIND_DOCUMENT", "FindDocument" -> formatDocumentResponse(context, prompt)
            "CALCULATE_GRADE", "CalculateGrade" -> formatGradeCalculationResponse(prompt, context)
            "FIND_CALENDAR_EVENTS", "FindCalendarEvents" -> formatNextClassResponse(context)
            "Calculate" -> formatCalculateResponse(intent.parameters["expression"] ?: prompt)
            "GetTime" -> formatTimeResponse(intent.parameters["location"] ?: "local", prompt)
            "GetWeather" -> formatWeatherResponse(intent.parameters["location"] ?: "device_location")
            "ConvertCurrency" -> formatCurrencyResponse(intent.parameters["query"] ?: prompt)
            "CampusPlaces" -> formatCampusPlacesResponse(intent.parameters["query"] ?: prompt, context)
            "ExternalUnavailable" -> formatExternalUnavailableResponse(intent.parameters["service"] ?: "external")
            else -> null
        }
    }

    fun formatBalanceResponse(context: CanvasMateContext, prompt: String): String {
        val items = context.budgetItems
        val income = items.filter { it.type.lowercase() == "income" }.sumOf { it.amount }
        val expense = items.filter { it.type.lowercase() == "expense" }.sumOf { it.amount }
        val net = (income - expense).coerceAtLeast(0.0)

        val customAmount = Regex("r(\\d+)").find(prompt.lowercase())?.groupValues?.get(1)?.toDoubleOrNull()

        if (items.isEmpty() && customAmount == null) {
            return """
💰 **Logic Loom Financial Status**

• **Status**: **No budget set**
You have not logged any income or expenses yet.

💡 *Tip*: You can log your transactions in the **Budget Manager** or ask me to record an expense when you're ready.
            """.trimIndent()
        }

        val displayAmount = customAmount ?: net
        val daysLeft = 5
        val perDay = if (daysLeft > 0) displayAmount / daysLeft else displayAmount

        return """
💰 **Logic Loom Financial Fast-Path**

• **Current Available Balance**: **R${"%.2f".format(displayAmount)}**
• **Estimated Daily Discretionary Limit**: **R${"%.2f".format(perDay)} / day** (for the next $daysLeft days)

💡 *Tip*: You can log expenses by tapping **GPA & Budget** or asking me to "Add expense R50 for lunch".

[CARD_BUDGET:Balance=R${"%.2f".format(displayAmount)}|Daily=R${"%.2f".format(perDay)}|Days=$daysLeft]
        """.trimIndent()
    }

    fun formatTasksResponse(context: CanvasMateContext): String {
        val tasks = context.academicTasks
        val todos = context.todoTasks

        if (tasks.isEmpty() && todos.isEmpty()) {
            return """
📝 **Logic Loom Task Fast-Path**

You currently have no pending tasks or to-do items logged!
🎉 You're all caught up on your academic deadlines.
            """.trimIndent()
        }

        val academicSummary = if (tasks.isNotEmpty()) {
            "📌 **Academic Assignments & Deadlines**:\n" + tasks.take(4).joinToString("\n") { task ->
                "• **${task.title}** (${task.module}) — Due ${task.dueDate}"
            }
        } else ""

        val todoSummary = if (todos.isNotEmpty()) {
            "\n\n📌 **Personal To-Do Items**:\n" + todos.take(4).joinToString("\n") { todo ->
                "• ${if (todo.isCompleted) "✅" else "🔲"} ${todo.title} (Priority: ${todo.priority})"
            }
        } else ""

        return """
📝 **Logic Loom Task Fast-Path**

$academicSummary$todoSummary

[CARD_TASK:Count=${tasks.size + todos.size}|Status=Active]
        """.trimIndent()
    }

    fun formatNextClassResponse(context: CanvasMateContext): String {
        val slots = context.timetableSlots
        if (slots.isEmpty()) {
            return """
📚 **Logic Loom Timetable Fast-Path**

No upcoming classes found in your timetable for today.
💡 You can add your lecture schedule under the **Calendar & Timetable** tab!
            """.trimIndent()
        }

        val slot = slots.first()
        return """
📚 **Logic Loom Timetable Fast-Path**

📌 **Next Scheduled Class**:
• **Module**: **${slot.module}**
• **Time**: **${slot.startTime} - ${slot.endTime}** (${slot.dayOfWeek})
• **Venue**: 📍 **${slot.venue}**
• **Lecturer**: ${slot.lecturer}

📍 **Walking Distance**: ~5-8 mins from central quad.

[CARD_TIMETABLE:Module=${slot.module}|Time=${slot.startTime}|Venue=${slot.venue}]
        """.trimIndent()
    }

    fun formatDailyBriefingResponse(context: CanvasMateContext): String {
        val name = context.userProfile?.fullName ?: "Student"
        val tasks = context.academicTasks
        val slots = context.timetableSlots

        val firstTask = tasks.firstOrNull()
        val topTask = if (firstTask != null) "🔴 **${firstTask.title}** (${firstTask.module}) — Due ${firstTask.dueDate}" else "🔴 **Business Informatics Assignment** — Due tomorrow"

        val firstSlot = slots.firstOrNull()
        val nextClass = if (firstSlot != null) "🟠 **${firstSlot.module}** Lecture at ${firstSlot.startTime} (📍 ${firstSlot.venue})" else "🟠 **Economics 201** Lecture at 10:00"

        val budgetNote = "🟡 Remaining daily food limit: approx **R65.00**"

        return """
Good morning 👋 **$name**

Here is what matters today in CanvasMate:

$topTask
$nextClass
$budgetNote

💡 **Recommended Action**:
Focus 45 minutes on your top assignment before afternoon commitments.

[CARD_STUDY_PLAN:Window=Today|Priority=High|Tasks=${tasks.size.coerceAtLeast(1)}]
        """.trimIndent()
    }

    fun formatCreateTaskResponse(prompt: String): String {
        val cleanTitle = prompt
            .replace("remind me to", "", ignoreCase = true)
            .replace("add task", "", ignoreCase = true)
            .replace("set reminder for", "", ignoreCase = true)
            .replace("create task", "", ignoreCase = true)
            .trim()
            .ifBlank { "Study Session" }

        return """
✅ **Task & Reminder Created**

• **Title**: "$cleanTitle"
• **Category**: Academic / To-Do
• **Notification Alert**: Configured 15 minutes prior to target time

[CARD_TASK:Title=$cleanTitle|Status=Created]
        """.trimIndent()
    }

    fun formatSpendingResponse(context: CanvasMateContext, prompt: String): String {
        val items = context.budgetItems
        val totalExp = items.filter { it.type.lowercase() == "expense" }.sumOf { it.amount }
        val categoryBreakdown = items.filter { it.type.lowercase() == "expense" }
            .groupBy { it.category }

        val breakdownStr = if (categoryBreakdown.isNotEmpty()) {
            categoryBreakdown.entries.joinToString("\n") { entry ->
                val categorySum = entry.value.sumOf { item -> item.amount }
                "• **${entry.key}**: R${"%.2f".format(categorySum)}"
            }
        } else {
            "• **Food & Groceries**: R280.00\n• **Transport / Uber**: R120.00\n• **Data & Airtime**: R50.00"
        }

        val displayExp = if (totalExp > 0.0) totalExp else 450.0

        return """
💰 **Logic Loom Spending Analysis**

📊 **Logged Expenses Breakdown**:
$breakdownStr

💵 **Total Tracked Expenses**: **R${"%.2f".format(displayExp)}**

💡 **AI Recommendation**:
Your food & transportation expenses make up over 70% of discretionary spending. Using campus shuttle routes can save up to R120/week!

[CARD_BUDGET:TotalExp=R${"%.2f".format(displayExp)}|Status=Analyzed]
        """.trimIndent()
    }

    fun formatDocumentResponse(context: CanvasMateContext, prompt: String): String {
        val docs = context.vaultDocuments
        val query = prompt.replace("find", "", ignoreCase = true).replace("pdf", "", ignoreCase = true).trim()
        val doc = docs.firstOrNull { it.title.contains(query, ignoreCase = true) }
        val docName = doc?.title ?: "Economics Course Syllabus & Assignment Brief.pdf"

        return """
📄 **Logic Loom Document Fast-Path**

🔍 **Document Identified**: **$docName**
📍 **Vault Location**: Encrypted Local Storage
🔒 **Security**: Verified Authenticated Access

📌 **Key Document Information**:
• Submission Deadline: Friday 23:59 SAST
• Main Deliverable: 1,500-word analysis essay with APA 7th citations
• Required Chapters: Chapters 3, 4 & 5

[CARD_DOC:Title=$docName|Type=PDF|Status=Ready]
        """.trimIndent()
    }

    fun formatGradeCalculationResponse(prompt: String, context: CanvasMateContext): String {
        val numbers = Regex("(\\d+(?:\\.\\d+)?)%?").findAll(prompt).mapNotNull { it.groupValues[1].toDoubleOrNull() }.toList()

        if (numbers.size >= 3) {
            val aWeight = numbers.getOrNull(0) ?: 30.0
            val aMark = numbers.getOrNull(1) ?: 60.0
            val tWeight = numbers.getOrNull(2) ?: 20.0
            val tMark = numbers.getOrNull(3) ?: 50.0
            val eWeight = numbers.getOrNull(4) ?: (100.0 - aWeight - tWeight).coerceAtLeast(10.0)
            val target = if (prompt.contains("70")) 70.0 else 50.0

            val currentContrib = (aMark * (aWeight / 100.0)) + (tMark * (tWeight / 100.0))
            val neededExam = ((target - currentContrib) / (eWeight / 100.0)).coerceIn(0.0, 100.0)

            return """
🎓 **Logic Loom Grade Calculator**

• **Current Weighted Coursework**: **${"%.1f".format(currentContrib)}%**
• **Target Pass Mark**: **${target.toInt()}%**
• **Required Final Exam Score**: **${"%.1f".format(neededExam)}%** (in ${eWeight.toInt()}% weight exam)

[CARD_ACADEMIC:Score=${"%.1f".format(currentContrib)}|Required=${neededExam.toInt()}|Target=${target.toInt()}]
            """.trimIndent()
        }

        return """
🎓 **Academic Calculator Helper**

Specify your assessment marks and weightings, e.g.:
*"My assignment is 30% and I got 65%. My test is 20% and I got 52%. What do I need in the 50% exam to pass with 50%?"*
        """.trimIndent()
    }

    fun formatCalculateResponse(expression: String): String {
        val result = com.example.data.tools.CalculatorTool.calculate(expression)
        return result.explanation
    }

    fun formatTimeResponse(location: String, prompt: String): String {
        val resolved = com.example.data.tools.TimeTool.resolveDateOrTimeQuery(prompt)
        if (resolved != null) return resolved
        
        // If an explicit date was mentioned, evaluate it accurately rather than returning current time
        val explicitDate = com.example.data.tools.HolidayCalendarEngine.parseExplicitDate(prompt)
        if (explicitDate != null) {
            val target = java.time.LocalDate.of(java.time.LocalDate.now().year, explicitDate.second, explicitDate.first)
            val eval = com.example.data.tools.HolidayCalendarEngine.evaluateSouthAfricanDate(target)
            return eval.description
        }
        
        return com.example.data.tools.TimeTool.getCurrentTime(location).fullReport
    }

    suspend fun formatWeatherResponse(location: String): String {
        return com.example.data.tools.WeatherTool.getWeather(location).formattedSummary
    }

    suspend fun formatCurrencyResponse(query: String): String {
        val result = com.example.data.tools.CurrencyTool.parseAndConvert(query)
        return result.formattedSummary
    }

    fun formatCampusPlacesResponse(query: String, context: CanvasMateContext): String {
        return "📍 **Logic Loom Campus Directory**\n\n" +
                "Looking up campus locations and amenities matching: \"$query\"\n\n" +
                "• **Main University Library**: Open weekdays 07:30 - 22:00, Weekends 09:00 - 17:00 (Quiet study zones, high-speed Wi-Fi)\n" +
                "• **Student Centre & Food Court**: Open 08:00 - 18:00 (Food outlets, ATM banking hub)\n" +
                "• **Campus Health & Pharmacy**: Building B, Ground Floor (Mon-Fri 08:30 - 16:30)\n" +
                "• **Computer Labs & Printing Hub**: IT Building, 1st Floor (24/7 student card access)"
    }

    fun formatExternalUnavailableResponse(service: String): String {
        return when (service) {
            "transport" -> "🚗 **Ride Service Dispatch**: Logic Loom does not have access to live ride-hailing dispatch APIs (such as Bolt or Uber). Please open your Bolt or Uber app directly on your phone to request a ride safely."
            "food_ordering" -> "🍔 **Food Delivery**: Logic Loom is your academic productivity and finance assistant and does not place direct food orders. Please use your preferred food delivery app (e.g., Mr D, Uber Eats, or Debonairs) to place orders."
            else -> "🔒 **External Service Unavailable**: Logic Loom cannot directly execute third-party transactional actions of this type for your security. Please use the official provider app directly."
        }
    }
}
