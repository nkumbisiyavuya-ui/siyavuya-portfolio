package com.example.data.tools

import java.time.LocalDate
import java.time.Month
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/**
 * Authoritative South African and International Holiday & Date Engine.
 *
 * In accordance with:
 * - South African Public Holidays Act (Act No. 36 of 1994)
 * - UN / International Commemorative Observance Calendars
 *
 * Distinguishes strictly between:
 * 1. Statutory National Public Holidays
 * 2. Commemorative / Observance Days (not public holidays)
 * 3. Ordinary Calendar Dates
 *
 * Never substitutes an explicitly queried date with today's date or a nearby date.
 */
object HolidayCalendarEngine {

    data class HolidayResult(
        val date: LocalDate,
        val formattedDate: String,
        val isPublicHoliday: Boolean,
        val category: HolidayCategory,
        val name: String,
        val description: String,
        val nearbyHolidaysNote: String? = null
    )

    enum class HolidayCategory {
        STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
        COMMEMORATIVE_OBSERVANCE,
        CULTURAL_OBSERVANCE,
        ORDINARY_CALENDAR_DATE
    }

    /**
     * Evaluates a specific date in South Africa.
     */
    fun evaluateSouthAfricanDate(targetDate: LocalDate): HolidayResult {
        val currentYear = targetDate.year
        val month = targetDate.month
        val day = targetDate.dayOfMonth
        val dayOfWeek = targetDate.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
        val formattedDate = "${day} ${month.getDisplayName(TextStyle.FULL, Locale.ENGLISH)} $currentYear ($dayOfWeek)"

        // 1. Check Statutory South African Public Holidays (Act 36 of 1994)
        when {
            month == Month.JANUARY && day == 1 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "New Year's Day",
                    description = "Official South African statutory public holiday celebrating the start of the year."
                )
            }
            month == Month.MARCH && day == 21 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Human Rights Day",
                    description = "Statutory public holiday commemorating the 1960 Sharpeville massacre and affirming democratic human rights."
                )
            }
            isGoodFriday(targetDate) -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Good Friday",
                    description = "Statutory public holiday observed on the Friday before Easter Sunday."
                )
            }
            isFamilyDay(targetDate) -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Family Day (Easter Monday)",
                    description = "Statutory public holiday observed on the Monday following Easter Sunday."
                )
            }
            month == Month.APRIL && day == 27 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Freedom Day",
                    description = "Statutory public holiday commemorating South Africa's first democratic elections on 27 April 1994."
                )
            }
            month == Month.MAY && day == 1 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Workers' Day",
                    description = "Statutory public holiday honouring the contributions of workers and trade unions."
                )
            }
            month == Month.JUNE && day == 16 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Youth Day",
                    description = "Statutory public holiday commemorating the 1976 Soweto student uprising."
                )
            }
            month == Month.AUGUST && day == 9 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "National Women's Day",
                    description = "Statutory public holiday commemorating the 1956 march of 20,000 women against the pass laws."
                )
            }
            month == Month.SEPTEMBER && day == 24 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Heritage Day",
                    description = "Statutory public holiday celebrating the diverse cultural heritage and traditions of all South Africans."
                )
            }
            month == Month.DECEMBER && day == 16 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Day of Reconciliation",
                    description = "Statutory public holiday promoting national unity and racial reconciliation in South Africa."
                )
            }
            month == Month.DECEMBER && day == 25 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Christmas Day",
                    description = "Statutory public holiday celebrating Christmas."
                )
            }
            month == Month.DECEMBER && day == 26 -> {
                return HolidayResult(
                    date = targetDate,
                    formattedDate = formattedDate,
                    isPublicHoliday = true,
                    category = HolidayCategory.STATUTORY_NATIONAL_PUBLIC_HOLIDAY,
                    name = "Day of Goodwill",
                    description = "Statutory public holiday following Christmas Day (Boxing Day)."
                )
            }
        }

        // 2. Check Commemorative & Observance Days (NOT public holidays)
        if (month == Month.SEPTEMBER && day == 27) {
            return HolidayResult(
                date = targetDate,
                formattedDate = formattedDate,
                isPublicHoliday = false,
                category = HolidayCategory.COMMEMORATIVE_OBSERVANCE,
                name = "World Tourism Day",
                description = "27 September is not a South African statutory public holiday. It is observed internationally and by South African Tourism as World Tourism Day (an official commemorative observance).",
                nearbyHolidaysNote = "Heritage Day is South Africa's statutory public holiday in September, observed on 24 September."
            )
        }

        if (month == Month.JULY && day == 18) {
            return HolidayResult(
                date = targetDate,
                formattedDate = formattedDate,
                isPublicHoliday = false,
                category = HolidayCategory.COMMEMORATIVE_OBSERVANCE,
                name = "Nelson Mandela International Day",
                description = "18 July is observed internationally and across South Africa as Nelson Mandela Day (67 minutes of community service). It is a national commemorative day, but NOT a statutory public holiday."
            )
        }

        if (month == Month.MAY && day == 25) {
            return HolidayResult(
                date = targetDate,
                formattedDate = formattedDate,
                isPublicHoliday = false,
                category = HolidayCategory.COMMEMORATIVE_OBSERVANCE,
                name = "Africa Day",
                description = "25 May commemorates the founding of the Organisation of African Unity (now African Union). It is a cultural/continental commemorative day, but NOT a statutory South African public holiday."
            )
        }

        // 3. Ordinary calendar date
        return HolidayResult(
            date = targetDate,
            formattedDate = formattedDate,
            isPublicHoliday = false,
            category = HolidayCategory.ORDINARY_CALENDAR_DATE,
            name = "Ordinary Calendar Date",
            description = "$formattedDate is not a national public holiday or statutory observance in South Africa."
        )
    }

    /**
     * Calculates the exact number of days from reference date until the requested target date.
     */
    fun calculateDaysUntil(
        targetDay: Int,
        targetMonth: Month,
        targetYear: Int? = null,
        fromDate: LocalDate = LocalDate.now()
    ): Pair<Long, LocalDate> {
        val year = targetYear ?: if (LocalDate.of(fromDate.year, targetMonth, targetDay).isBefore(fromDate)) {
            fromDate.year + 1
        } else {
            fromDate.year
        }
        val target = LocalDate.of(year, targetMonth, targetDay)
        val days = ChronoUnit.DAYS.between(fromDate, target)
        return Pair(days, target)
    }

    /**
     * Computes Easter Sunday for a given year using Anonymous Gregorian algorithm (Meeus/Jones/Butcher).
     */
    fun computeEasterSunday(year: Int): LocalDate {
        val a = year % 19
        val b = year / 100
        val c = year % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        return LocalDate.of(year, month, day)
    }

    private fun isGoodFriday(date: LocalDate): Boolean {
        val easter = computeEasterSunday(date.year)
        val goodFriday = easter.minusDays(2)
        return date == goodFriday
    }

    private fun isFamilyDay(date: LocalDate): Boolean {
        val easter = computeEasterSunday(date.year)
        val familyDay = easter.plusDays(1)
        return date == familyDay
    }

    /**
     * Extracts an explicit date from natural language, e.g. "27 September", "24 September 2026", "September 27".
     */
    fun parseExplicitDate(text: String): Pair<Int, Month>? {
        val lower = text.lowercase().trim()
        val months = listOf(
            "january" to Month.JANUARY, "february" to Month.FEBRUARY, "march" to Month.MARCH,
            "april" to Month.APRIL, "may" to Month.MAY, "june" to Month.JUNE,
            "july" to Month.JULY, "august" to Month.AUGUST, "september" to Month.SEPTEMBER,
            "october" to Month.OCTOBER, "november" to Month.NOVEMBER, "december" to Month.DECEMBER,
            "jan" to Month.JANUARY, "feb" to Month.FEBRUARY, "mar" to Month.MARCH,
            "apr" to Month.APRIL, "jun" to Month.JUNE, "jul" to Month.JULY,
            "aug" to Month.AUGUST, "sep" to Month.SEPTEMBER, "sept" to Month.SEPTEMBER,
            "oct" to Month.OCTOBER, "nov" to Month.NOVEMBER, "dec" to Month.DECEMBER
        )

        for ((monthName, monthEnum) in months) {
            // Match "27 september" or "27th september" or "27th of september"
            val pattern1 = Regex("(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?$monthName\\b")
            val match1 = pattern1.find(lower)
            if (match1 != null) {
                val day = match1.groupValues[1].toIntOrNull()
                if (day != null && day in 1..31) return Pair(day, monthEnum)
            }

            // Match "september 27" or "september 27th"
            val pattern2 = Regex("\\b$monthName\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b")
            val match2 = pattern2.find(lower)
            if (match2 != null) {
                val day = match2.groupValues[1].toIntOrNull()
                if (day != null && day in 1..31) return Pair(day, monthEnum)
            }
        }
        return null
    }
}
