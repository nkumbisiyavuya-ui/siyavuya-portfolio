package com.example.data.ai

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Status of a logged Gemini API interaction.
 */
enum class GeminiLogStatus {
    IN_FLIGHT,
    SUCCESS,
    FAILED,
    OFFLINE_EVALUATOR
}

/**
 * Visual validation badge representing an assertion on payload integrity.
 */
data class ValidationBadge(
    val title: String,
    val isPassed: Boolean,
    val description: String
)

/**
 * Comprehensive log entry capturing the exact request payload sent to Gemini,
 * binding verification, timing metrics, and model response.
 */
data class GeminiPayloadLogEntry(
    val id: String,
    val timestamp: Long,
    val formattedTimestamp: String,
    val taskType: String,
    val rawUserPrompt: String,
    val boundUserMessage: String,
    val systemInstructionText: String,
    val historyCount: Int,
    val modelsAttempted: List<String>,
    val toolsEnabled: List<String>,
    val payloadJsonPretty: String,
    val status: GeminiLogStatus,
    val httpStatusCode: Int? = null,
    val modelUsed: String? = null,
    val responseSnippet: String? = null,
    val rawResponseJsonPretty: String? = null,
    val durationMs: Long = 0L,
    val groundingCitationsCount: Int = 0,
    val groundingQueries: List<String> = emptyList(),
    val isUserMessageBoundCorrectly: Boolean = true,
    val isFreshNotCached: Boolean = true,
    val isSystemInstructionIsolated: Boolean = true,
    val validationBadges: List<ValidationBadge> = emptyList()
)

/**
 * Detailed verification report for inspecting a constructed payload.
 */
data class PayloadVerificationReport(
    val isValid: Boolean,
    val isExactMatch: Boolean,
    val isSystemIsolated: Boolean,
    val isFresh: Boolean,
    val extractedUserText: String,
    val systemInstructionText: String,
    val historyTurnsCount: Int,
    val validationNotes: List<String>
)

/**
 * GeminiDebugLogService provides real-time logging, payload inspection,
 * and integrity verification for Gemini API requests and responses.
 *
 * It ensures that:
 * 1. The actual user message is accurately and immutably bound into the API request JSON.
 * 2. System instructions and student context are isolated in `systemInstruction`.
 * 3. Fresh request IDs and timestamps prevent stale or cached data replay.
 * 4. Logs are inspectable both programmatically and via the UI inspector.
 */
object GeminiDebugLogService {
    private const val TAG = "GeminiPayloadInspector"
    private const val MAX_LOG_ENTRIES = 60

    private val _logs = MutableStateFlow<List<GeminiPayloadLogEntry>>(emptyList())
    val logs: StateFlow<List<GeminiPayloadLogEntry>> = _logs.asStateFlow()

    private val _latestLog = MutableStateFlow<GeminiPayloadLogEntry?>(null)
    val latestLog: StateFlow<GeminiPayloadLogEntry?> = _latestLog.asStateFlow()

    private val timeFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    /**
     * Records the start of a live Gemini API request and inspects payload structure.
     */
    fun recordRequestStart(
        requestId: String,
        rawPrompt: String,
        payloadJson: JSONObject,
        taskType: String,
        systemInstruction: String,
        targetModels: List<String>
    ): GeminiPayloadLogEntry {
        val timestamp = System.currentTimeMillis()
        val formattedTime = timeFormatter.format(Date(timestamp))

        // Extract user message from contents array (last element with role = 'user')
        var extractedBoundUserText = ""
        var historyCount = 0
        val toolsList = mutableListOf<String>()

        try {
            val contents = payloadJson.optJSONArray("contents")
            if (contents != null) {
                val totalItems = contents.length()
                if (totalItems > 1) {
                    historyCount = totalItems - 1
                }
                for (i in (totalItems - 1) downTo 0) {
                    val item = contents.optJSONObject(i)
                    if (item?.optString("role") == "user") {
                        val parts = item.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            extractedBoundUserText = parts.optJSONObject(0)?.optString("text") ?: ""
                            break
                        }
                    }
                }
            }

            val tools = payloadJson.optJSONArray("tools")
            if (tools != null) {
                for (t in 0 until tools.length()) {
                    val toolObj = tools.optJSONObject(t)
                    if (toolObj?.has("googleSearch") == true) {
                        toolsList.add("Google Search Grounding")
                    } else if (toolObj?.has("codeExecution") == true) {
                        toolsList.add("Code Execution")
                    } else {
                        toolsList.add("Tool ($t)")
                    }
                }
            }
        } catch (e: Throwable) {
            safeLogE(TAG, "Error extracting payload info for request $requestId", e)
        }

        val isExactMatch = rawPrompt.trim() == extractedBoundUserText.trim()
        val isSystemIsolated = systemInstruction.isNotBlank() &&
                !extractedBoundUserText.contains("Student Academic Context:") &&
                !extractedBoundUserText.contains("You are Chuma")
        val isFresh = rawPrompt.isNotBlank() && timestamp > 0L

        val validationBadges = listOf(
            ValidationBadge(
                title = "User Message Bound",
                isPassed = isExactMatch,
                description = if (isExactMatch) "User prompt bound directly without mutation" else "Mismatch between raw prompt and payload content"
            ),
            ValidationBadge(
                title = "System Prompt Isolated",
                isPassed = isSystemIsolated,
                description = if (isSystemIsolated) "System instructions separated in systemInstruction object" else "System instructions found inside user content"
            ),
            ValidationBadge(
                title = "Fresh Payload (No Cache)",
                isPassed = isFresh,
                description = "Generated at $formattedTime with request ID #$requestId"
            ),
            ValidationBadge(
                title = "Grounding Tools",
                isPassed = true,
                description = if (toolsList.isNotEmpty()) toolsList.joinToString(", ") else "Standard Model Execution"
            )
        )

        val prettyPayload = try {
            payloadJson.toString(2)
        } catch (e: Throwable) {
            payloadJson.toString()
        }

        val entry = GeminiPayloadLogEntry(
            id = requestId,
            timestamp = timestamp,
            formattedTimestamp = formattedTime,
            taskType = taskType,
            rawUserPrompt = rawPrompt,
            boundUserMessage = extractedBoundUserText,
            systemInstructionText = systemInstruction,
            historyCount = historyCount,
            modelsAttempted = targetModels,
            toolsEnabled = toolsList,
            payloadJsonPretty = prettyPayload,
            status = GeminiLogStatus.IN_FLIGHT,
            isUserMessageBoundCorrectly = isExactMatch,
            isFreshNotCached = isFresh,
            isSystemInstructionIsolated = isSystemIsolated,
            validationBadges = validationBadges
        )

        safeLogD(TAG, """
            |========================================================================
            |🚀 [GEMINI REQUEST PAYLOAD INSPECTED] Request ID: $requestId
            |⏰ Timestamp: $formattedTime
            |🎯 Task Type: $taskType | Models: ${targetModels.joinToString(", ")}
            |📝 Raw User Prompt: "$rawPrompt"
            |🔗 Bound User Text: "$extractedBoundUserText"
            |✅ Correctly Bound: $isExactMatch
            |🛡️ System Isolated: $isSystemIsolated
            |📚 History Turns: $historyCount
            |📦 Payload Size: ${prettyPayload.length} chars
            |========================================================================
        """.trimMargin())

        appendLogEntry(entry)
        return entry
    }

    /**
     * Records a successful live API response.
     */
    fun recordResponseSuccess(
        requestId: String,
        modelUsed: String,
        httpStatusCode: Int,
        responseText: String,
        rawResponseJson: String?,
        durationMs: Long,
        citationsCount: Int = 0,
        groundingQueries: List<String> = emptyList()
    ) {
        val prettyResponse = try {
            if (!rawResponseJson.isNullOrBlank()) {
                JSONObject(rawResponseJson).toString(2)
            } else ""
        } catch (e: Throwable) {
            rawResponseJson ?: ""
        }

        updateLogEntry(requestId) { current ->
            current.copy(
                status = GeminiLogStatus.SUCCESS,
                httpStatusCode = httpStatusCode,
                modelUsed = modelUsed,
                responseSnippet = responseText.take(500),
                rawResponseJsonPretty = prettyResponse,
                durationMs = durationMs,
                groundingCitationsCount = citationsCount,
                groundingQueries = groundingQueries
            )
        }

        safeLogD(TAG, """
            |========================================================================
            |✅ [GEMINI RESPONSE 200 OK] Request ID: $requestId
            |🤖 Model Used: $modelUsed (Latency: ${durationMs}ms)
            |📑 Citations: $citationsCount | Queries: ${groundingQueries.joinToString(", ")}
            |💬 Response: "${responseText.take(150)}..."
            |========================================================================
        """.trimMargin())
    }

    /**
     * Records a failed API attempt or network error.
     */
    fun recordResponseError(
        requestId: String,
        modelUsed: String?,
        httpStatusCode: Int,
        errorMessage: String,
        rawResponse: String?,
        durationMs: Long
    ) {
        val prettyResponse = try {
            if (!rawResponse.isNullOrBlank()) {
                JSONObject(rawResponse).toString(2)
            } else ""
        } catch (e: Throwable) {
            rawResponse ?: ""
        }

        updateLogEntry(requestId) { current ->
            current.copy(
                status = GeminiLogStatus.FAILED,
                httpStatusCode = httpStatusCode,
                modelUsed = modelUsed,
                responseSnippet = "Error: $errorMessage",
                rawResponseJsonPretty = prettyResponse,
                durationMs = durationMs
            )
        }

        safeLogW(TAG, "❌ [GEMINI REQUEST FAILED] Request ID: $requestId | HTTP: $httpStatusCode | Error: $errorMessage")
    }

    /**
     * Records deterministic offline intelligence execution when operating without online API credentials.
     */
    fun recordOfflineEvaluation(
        requestId: String,
        prompt: String,
        taskType: String,
        resultText: String,
        historyCount: Int,
        durationMs: Long
    ) {
        val timestamp = System.currentTimeMillis()
        val formattedTime = timeFormatter.format(Date(timestamp))

        val validationBadges = listOf(
            ValidationBadge("Offline Evaluator", true, "Deterministic intelligence engine evaluated user prompt"),
            ValidationBadge("Prompt Bound", true, "Prompt passed directly to evaluation rules"),
            ValidationBadge("Latency", true, "${durationMs}ms local evaluation")
        )

        val entry = GeminiPayloadLogEntry(
            id = requestId,
            timestamp = timestamp,
            formattedTimestamp = formattedTime,
            taskType = taskType,
            rawUserPrompt = prompt,
            boundUserMessage = prompt,
            systemInstructionText = "Local Grounded Knowledge Rules & Tool Evaluator",
            historyCount = historyCount,
            modelsAttempted = listOf("chuma-offline-evaluator"),
            toolsEnabled = listOf("Calculator", "Time", "Weather", "Offline Rules"),
            payloadJsonPretty = "{\n  \"engine\": \"offline_grounded_evaluator\",\n  \"prompt\": \"${JSONObject.quote(prompt)}\"\n}",
            status = GeminiLogStatus.OFFLINE_EVALUATOR,
            httpStatusCode = 200,
            modelUsed = "chuma-offline-evaluator",
            responseSnippet = resultText.take(500),
            rawResponseJsonPretty = "{\n  \"status\": \"success\",\n  \"output\": \"${JSONObject.quote(resultText.take(200))}\"\n}",
            durationMs = durationMs,
            isUserMessageBoundCorrectly = true,
            isFreshNotCached = true,
            isSystemInstructionIsolated = true,
            validationBadges = validationBadges
        )

        appendLogEntry(entry)
    }

    /**
     * Inspects a JSONObject payload directly and returns a structured verification report.
     */
    fun verifyPayloadBinding(rawPrompt: String, payloadJson: JSONObject): PayloadVerificationReport {
        var boundUserText = ""
        var systemInstruction = ""
        var historyCount = 0
        val notes = mutableListOf<String>()

        try {
            val systemObj = payloadJson.optJSONObject("systemInstruction")
            val systemParts = systemObj?.optJSONArray("parts")
            if (systemParts != null && systemParts.length() > 0) {
                systemInstruction = systemParts.optJSONObject(0)?.optString("text") ?: ""
            }

            val contents = payloadJson.optJSONArray("contents")
            if (contents != null) {
                val total = contents.length()
                if (total > 1) {
                    historyCount = total - 1
                }
                for (i in (total - 1) downTo 0) {
                    val item = contents.optJSONObject(i)
                    if (item?.optString("role") == "user") {
                        val parts = item.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            boundUserText = parts.optJSONObject(0)?.optString("text") ?: ""
                            break
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            notes.add("Error reading payload JSON: ${e.message}")
        }

        val isExactMatch = rawPrompt.trim() == boundUserText.trim()
        val isSystemIsolated = systemInstruction.isNotBlank() &&
                !boundUserText.contains("Student Academic Context:") &&
                !boundUserText.contains("You are Chuma")
        val isFresh = rawPrompt.isNotBlank()

        if (isExactMatch) {
            notes.add("✅ User message is bound directly to payload contents[last].parts[0].text without alterations.")
        } else {
            notes.add("⚠️ Mismatch: Raw prompt length ${rawPrompt.length} vs bound text length ${boundUserText.length}.")
        }

        if (isSystemIsolated) {
            notes.add("✅ System instructions and context are strictly placed in systemInstruction, not prepended to user prompt.")
        } else {
            notes.add("⚠️ System prompt may be polluted into user prompt.")
        }

        return PayloadVerificationReport(
            isValid = isExactMatch && isSystemIsolated,
            isExactMatch = isExactMatch,
            isSystemIsolated = isSystemIsolated,
            isFresh = isFresh,
            extractedUserText = boundUserText,
            systemInstructionText = systemInstruction,
            historyTurnsCount = historyCount,
            validationNotes = notes
        )
    }

    /**
     * Clears all recorded payload logs.
     */
    fun clearLogs() {
        _logs.value = emptyList()
        _latestLog.value = null
    }

    /**
     * Gets all recorded logs.
     */
    fun getAllLogs(): List<GeminiPayloadLogEntry> = _logs.value

    /**
     * Gets the most recent payload log entry.
     */
    fun getLatestLog(): GeminiPayloadLogEntry? = _latestLog.value

    private fun appendLogEntry(entry: GeminiPayloadLogEntry) {
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > MAX_LOG_ENTRIES) {
            current.removeAt(current.lastIndex)
        }
        _logs.value = current
        _latestLog.value = entry
    }

    private fun updateLogEntry(requestId: String, update: (GeminiPayloadLogEntry) -> GeminiPayloadLogEntry) {
        val current = _logs.value.toMutableList()
        val index = current.indexOfFirst { it.id == requestId }
        if (index >= 0) {
            val updated = update(current[index])
            current[index] = updated
            _logs.value = current
            if (_latestLog.value?.id == requestId) {
                _latestLog.value = updated
            }
        }
    }

    private fun safeLogD(tag: String, msg: String) {
        try {
            Log.d(tag, msg)
        } catch (e: Throwable) {
            println("[$tag] DEBUG: $msg")
        }
    }

    private fun safeLogW(tag: String, msg: String) {
        try {
            Log.w(tag, msg)
        } catch (e: Throwable) {
            println("[$tag] WARN: $msg")
        }
    }

    private fun safeLogE(tag: String, msg: String, tr: Throwable? = null) {
        try {
            if (tr != null) Log.e(tag, msg, tr) else Log.e(tag, msg)
        } catch (e: Throwable) {
            println("[$tag] ERROR: $msg ${tr?.message ?: ""}")
        }
    }
}
