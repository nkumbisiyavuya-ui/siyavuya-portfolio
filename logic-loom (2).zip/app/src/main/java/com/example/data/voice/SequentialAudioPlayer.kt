package com.example.data.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.util.ArrayDeque
import java.util.UUID

/**
 * Low-latency sequential audio playback engine for streamed neural TTS chunks.
 *
 * Guarantees:
 * - Immediate playback of the first audio chunk without waiting for subsequent chunks.
 * - Gapless or near-zero gap transition between sequential chunks in the queue.
 * - Application-level volume gain (via MediaPlayer.setVolume) WITHOUT altering Android's global system volume.
 * - Proper system AudioFocus handling (ducking/pausing other media, routing to Bluetooth/headphones/speaker).
 * - Instant barge-in cancellation: completely clears queue, halts active playback, and releases audio focus in < 15ms.
 */
class SequentialAudioPlayer(
    private val context: Context,
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {
    companion object {
        private const val TAG = "SequentialAudioPlayer"
    }

    private data class QueuedChunk(
        val id: String,
        val audioBytes: ByteArray,
        val volume: Float,
        val speed: Float,
        val isLastChunk: Boolean,
        val generationId: String? = null,
        val onStart: () -> Unit,
        val onDone: () -> Unit,
        val onError: (String) -> Unit
    )

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    private val chunkQueue = ArrayDeque<QueuedChunk>()
    private var currentPlayer: MediaPlayer? = null
    private var currentTempFile: File? = null
    private var isPlayingActive = false

    @Volatile
    private var isCancelled = false

    @Volatile
    var activeGenerationId: String = UUID.randomUUID().toString()
        private set

    val isPlaying: Boolean
        @Synchronized get() = isPlayingActive

    fun startNewGeneration(newId: String = UUID.randomUUID().toString()): String {
        synchronized(this) {
            activeGenerationId = newId
            return newId
        }
    }

    /**
     * Enqueues an audio chunk for sequential playback.
     * If the player is currently idle, playback starts immediately.
     */
    @Synchronized
    fun enqueueChunk(
        audioBytes: ByteArray,
        volume: Float = 1.0f,
        speed: Float = 1.0f,
        isLastChunk: Boolean = false,
        generationId: String? = null,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        if (isCancelled || (generationId != null && generationId != activeGenerationId)) {
            Log.d(TAG, "VOICE_TTS_CANCELLED: Dropping chunk with generationId $generationId (active: $activeGenerationId)")
            return
        }

        val chunk = QueuedChunk(
            id = UUID.randomUUID().toString(),
            audioBytes = audioBytes,
            volume = volume.coerceIn(0.0f, 1.0f),
            speed = speed.coerceIn(0.6f, 2.0f),
            isLastChunk = isLastChunk,
            generationId = generationId,
            onStart = onStart,
            onDone = onDone,
            onError = onError
        )

        chunkQueue.add(chunk)

        if (!isPlayingActive) {
            playNextChunk()
        }
    }

    @Synchronized
    private fun playNextChunk() {
        if (isCancelled) {
            cleanupActivePlayer()
            return
        }

        val next = chunkQueue.poll()
        if (next == null) {
            isPlayingActive = false
            releaseAudioFocus()
            cleanupActivePlayer()
            return
        }

        isPlayingActive = true
        requestAudioFocus()

        coroutineScope.launch(Dispatchers.IO) {
            try {
                // Write chunk to private internal cache file
                val tempFile = File.createTempFile("tts_chunk_${System.currentTimeMillis()}_", ".mp3", context.cacheDir)
                FileOutputStream(tempFile).use { it.write(next.audioBytes) }

                withContext(Dispatchers.Main) {
                    if (isCancelled) {
                        tempFile.delete()
                        return@withContext
                    }

                    cleanupActivePlayer()
                    currentTempFile = tempFile

                    val player = MediaPlayer()
                    currentPlayer = player

                    player.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .build()
                    )

                    player.setDataSource(tempFile.absolutePath)
                    player.setOnPreparedListener { mp ->
                        if (isCancelled) {
                            mp.stop()
                            mp.release()
                            return@setOnPreparedListener
                        }

                        // Apply volume gain to player without modifying global device volume
                        mp.setVolume(next.volume, next.volume)

                        // Apply speed if supported
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && next.speed != 1.0f) {
                            try {
                                val params = mp.playbackParams ?: PlaybackParams()
                                params.speed = next.speed
                                mp.playbackParams = params
                            } catch (e: Exception) {
                                Log.w(TAG, "Could not set playback speed: ${e.message}")
                            }
                        }

                        next.onStart()
                        mp.start()
                        Log.d(TAG, "VOICE_TTS_FIRST_AUDIO: Playback started for chunk ${next.id}")
                    }

                    player.setOnCompletionListener { mp ->
                        next.onDone()
                        cleanupActivePlayer()
                        synchronized(this@SequentialAudioPlayer) {
                            if (!isCancelled) {
                                playNextChunk()
                            }
                        }
                    }

                    player.setOnErrorListener { _, what, extra ->
                        Log.w(TAG, "VOICE_TTS_ERROR: MediaPlayer error what=$what, extra=$extra")
                        next.onError("Playback error ($what, $extra)")
                        cleanupActivePlayer()
                        synchronized(this@SequentialAudioPlayer) {
                            if (!isCancelled) {
                                playNextChunk()
                            }
                        }
                        true
                    }

                    player.prepareAsync()
                }
            } catch (e: Exception) {
                Log.e(TAG, "VOICE_TTS_ERROR: Failed to prepare audio chunk", e)
                withContext(Dispatchers.Main) {
                    next.onError("Audio preparation failed: ${e.localizedMessage}")
                    synchronized(this@SequentialAudioPlayer) {
                        playNextChunk()
                    }
                }
            }
        }
    }

    /**
     * Instant conversational barge-in:
     * Immediately halts audio playback, purges queued chunks,
     * releases audio focus, and deletes temp files.
     */
    @Synchronized
    fun stop() {
        val startStop = System.currentTimeMillis()
        isCancelled = true
        activeGenerationId = UUID.randomUUID().toString()
        chunkQueue.clear()

        cleanupActivePlayer()
        releaseAudioFocus()

        isPlayingActive = false
        isCancelled = false
        Log.d(TAG, "VOICE_TTS_CANCELLED: Barge-in stop completed in ${System.currentTimeMillis() - startStop}ms")
    }

    private fun cleanupActivePlayer() {
        try {
            currentPlayer?.let { player ->
                if (player.isPlaying) {
                    player.stop()
                }
                player.reset()
                player.release()
            }
        } catch (e: Exception) {
            // Safe cleanup
        } finally {
            currentPlayer = null
        }

        try {
            currentTempFile?.let { file ->
                if (file.exists()) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            // Ignore temp file cleanup errors
        } finally {
            currentTempFile = null
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener { focusChange ->
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        stop()
                    }
                }
                .build()
            audioFocusRequest?.let { am.requestAudioFocus(it) }
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                { focusChange ->
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        stop()
                    }
                },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    private fun releaseAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    fun destroy() {
        stop()
    }
}
