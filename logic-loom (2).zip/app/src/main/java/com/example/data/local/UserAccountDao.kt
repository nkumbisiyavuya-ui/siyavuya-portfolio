package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserAccountDao {
    @Query("SELECT * FROM user_accounts WHERE LOWER(email) = LOWER(:email) LIMIT 1")
    suspend fun getUserByEmailDirect(email: String): UserAccount?

    @Query("SELECT * FROM user_accounts WHERE LOWER(email) = LOWER(:email) LIMIT 1")
    fun getUserByEmail(email: String): Flow<UserAccount?>

    @Query("SELECT * FROM user_accounts WHERE userId = :userId LIMIT 1")
    suspend fun getUserByIdDirect(userId: String): UserAccount?

    @Query("SELECT * FROM user_accounts WHERE resetToken = :resetToken LIMIT 1")
    suspend fun getUserByResetTokenDirect(resetToken: String): UserAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserAccount(userAccount: UserAccount)

    @Update
    suspend fun updateUserAccount(userAccount: UserAccount)

    @Query("DELETE FROM user_accounts WHERE LOWER(email) = LOWER(:email)")
    suspend fun deleteUserAccount(email: String)
}
