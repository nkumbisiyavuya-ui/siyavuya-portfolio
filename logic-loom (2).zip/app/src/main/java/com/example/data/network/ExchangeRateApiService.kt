package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import java.util.concurrent.TimeUnit

data class ExchangeRateResponse(
    @Json(name = "result") val result: String? = null,
    @Json(name = "base_code") val baseCode: String? = null,
    @Json(name = "rates") val rates: Map<String, Double>? = null
)

interface ExchangeRateApiService {
    @GET("v6/latest/ZAR")
    suspend fun getZarRates(): ExchangeRateResponse
}

object ExchangeRateNetworkService {
    private const val BASE_URL = "https://open.er-api.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val apiService: ExchangeRateApiService = retrofit.create(ExchangeRateApiService::class.java)

    // Fallback default exchange rates relative to 1 ZAR if network fails or device is offline
    val fallbackRates: Map<String, Double> = mapOf(
        "ZAR" to 1.0,
        "USD" to 0.0545,  // ~ R18.35 per USD
        "EUR" to 0.0502,  // ~ R19.92 per EUR
        "GBP" to 0.0428,  // ~ R23.36 per GBP
        "CAD" to 0.0748,  // ~ R13.37 per CAD
        "AUD" to 0.0832,  // ~ R12.02 per AUD
        "JPY" to 8.2500,  // ~ R0.12 per JPY
        "CNY" to 0.3920   // ~ R2.55 per CNY
    )
}
