package com.example.data.ai.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

val Context.chumaTaskDataStore: DataStore<Preferences> by preferencesDataStore(name = "chuma_task_execution_state")

/**
 * Jetpack DataStore layer for persisting and restoring the active Chuma AI task execution state.
 * Enables the AI agent's execution progress, intent analysis, and step pipeline to remain intact
 * across device reboots, app process restarts, and activity lifecycles.
 */
@Singleton
class ChumaTaskExecutionDataStore @Inject constructor(
    private val context: Context
) {
    private val dataStore = context.chumaTaskDataStore

    companion object {
        val KEY_TASK_ID = stringPreferencesKey("chuma_task_id")
        val KEY_PROMPT = stringPreferencesKey("chuma_task_prompt")
        val KEY_TASK_TYPE = stringPreferencesKey("chuma_task_type")
        val KEY_STATUS = stringPreferencesKey("chuma_task_status")
        val KEY_PROGRESS = floatPreferencesKey("chuma_task_progress")
        val KEY_CURRENT_STEP = stringPreferencesKey("chuma_task_current_step")
        val KEY_CURRENT_STEP_INDEX = intPreferencesKey("chuma_task_current_step_index")
        val KEY_TOTAL_STEPS = intPreferencesKey("chuma_task_total_steps")
        val KEY_PARTIAL_OUTPUT = stringPreferencesKey("chuma_task_partial_output")
        val KEY_FINAL_RESPONSE = stringPreferencesKey("chuma_task_final_response")
        val KEY_ERROR_MESSAGE = stringPreferencesKey("chuma_task_error_message")
        val KEY_STARTED_AT = longPreferencesKey("chuma_task_started_at")
        val KEY_UPDATED_AT = longPreferencesKey("chuma_task_updated_at")
        val KEY_COMPLETED_AT = longPreferencesKey("chuma_task_completed_at")
    }

    /**
     * Continuous Flow emitting the persisted Chuma AI task execution state.
     */
    val executionStateFlow: Flow<ChumaTaskExecutionState> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            mapPreferencesToState(prefs)
        }

    /**
     * Synchronous snapshot retrieval of the current persisted execution state.
     */
    suspend fun getCurrentState(): ChumaTaskExecutionState {
        return try {
            val prefs = dataStore.data.first()
            mapPreferencesToState(prefs)
        } catch (e: Exception) {
            ChumaTaskExecutionState.DEFAULT
        }
    }

    /**
     * Start and persist a new task execution.
     */
    suspend fun startTask(
        taskId: String,
        prompt: String,
        taskType: String,
        initialStep: String = "Queued in Chuma agent engine...",
        totalSteps: Int = 4
    ): ChumaTaskExecutionState {
        val now = System.currentTimeMillis()
        val newState = ChumaTaskExecutionState(
            taskId = taskId,
            prompt = prompt,
            taskType = taskType,
            status = ChumaTaskStatus.QUEUED,
            progress = 0.05f,
            currentStep = initialStep,
            currentStepIndex = 1,
            totalSteps = totalSteps,
            startedAt = now,
            updatedAt = now
        )
        saveState(newState)
        return newState
    }

    /**
     * Update active task execution progress and current processing step.
     */
    suspend fun updateStep(
        taskId: String,
        status: ChumaTaskStatus,
        stepIndex: Int,
        stepDescription: String,
        progress: Float,
        partialOutput: String? = null
    ) {
        val now = System.currentTimeMillis()
        dataStore.edit { prefs ->
            val currentId = prefs[KEY_TASK_ID]
            if (currentId == taskId || currentId.isNullOrBlank()) {
                prefs[KEY_TASK_ID] = taskId
                prefs[KEY_STATUS] = status.name
                prefs[KEY_CURRENT_STEP_INDEX] = stepIndex
                prefs[KEY_CURRENT_STEP] = stepDescription
                prefs[KEY_PROGRESS] = progress.coerceIn(0f, 1f)
                prefs[KEY_UPDATED_AT] = now
                if (partialOutput != null) {
                    prefs[KEY_PARTIAL_OUTPUT] = partialOutput
                }
            }
        }
    }

    /**
     * Mark the task as successfully completed with its synthesized final response.
     */
    suspend fun completeTask(taskId: String, finalResponse: String) {
        val now = System.currentTimeMillis()
        dataStore.edit { prefs ->
            if (prefs[KEY_TASK_ID] == taskId) {
                prefs[KEY_STATUS] = ChumaTaskStatus.COMPLETED.name
                prefs[KEY_PROGRESS] = 1.0f
                prefs[KEY_CURRENT_STEP] = "Task synthesis complete"
                prefs[KEY_FINAL_RESPONSE] = finalResponse
                prefs[KEY_UPDATED_AT] = now
                prefs[KEY_COMPLETED_AT] = now
            }
        }
    }

    /**
     * Mark the task as failed with an error description.
     */
    suspend fun failTask(taskId: String, errorMessage: String) {
        val now = System.currentTimeMillis()
        dataStore.edit { prefs ->
            if (prefs[KEY_TASK_ID] == taskId) {
                prefs[KEY_STATUS] = ChumaTaskStatus.FAILED.name
                prefs[KEY_ERROR_MESSAGE] = errorMessage
                prefs[KEY_CURRENT_STEP] = "Execution halted: $errorMessage"
                prefs[KEY_UPDATED_AT] = now
            }
        }
    }

    /**
     * Cancel an active task execution.
     */
    suspend fun cancelTask(taskId: String) {
        val now = System.currentTimeMillis()
        dataStore.edit { prefs ->
            if (prefs[KEY_TASK_ID] == taskId) {
                prefs[KEY_STATUS] = ChumaTaskStatus.CANCELLED.name
                prefs[KEY_CURRENT_STEP] = "Execution cancelled by user"
                prefs[KEY_UPDATED_AT] = now
            }
        }
    }

    /**
     * Clear and reset all persisted task execution keys.
     */
    suspend fun clearState() {
        dataStore.edit { prefs ->
            prefs.remove(KEY_TASK_ID)
            prefs.remove(KEY_PROMPT)
            prefs.remove(KEY_TASK_TYPE)
            prefs.remove(KEY_STATUS)
            prefs.remove(KEY_PROGRESS)
            prefs.remove(KEY_CURRENT_STEP)
            prefs.remove(KEY_CURRENT_STEP_INDEX)
            prefs.remove(KEY_TOTAL_STEPS)
            prefs.remove(KEY_PARTIAL_OUTPUT)
            prefs.remove(KEY_FINAL_RESPONSE)
            prefs.remove(KEY_ERROR_MESSAGE)
            prefs.remove(KEY_STARTED_AT)
            prefs.remove(KEY_UPDATED_AT)
            prefs.remove(KEY_COMPLETED_AT)
        }
    }

    /**
     * Directly save a full execution state.
     */
    suspend fun saveState(state: ChumaTaskExecutionState) {
        dataStore.edit { prefs ->
            prefs[KEY_TASK_ID] = state.taskId
            prefs[KEY_PROMPT] = state.prompt
            prefs[KEY_TASK_TYPE] = state.taskType
            prefs[KEY_STATUS] = state.status.name
            prefs[KEY_PROGRESS] = state.progress
            prefs[KEY_CURRENT_STEP] = state.currentStep
            prefs[KEY_CURRENT_STEP_INDEX] = state.currentStepIndex
            prefs[KEY_TOTAL_STEPS] = state.totalSteps
            prefs[KEY_PARTIAL_OUTPUT] = state.partialOutput
            prefs[KEY_FINAL_RESPONSE] = state.finalResponse
            if (state.errorMessage != null) {
                prefs[KEY_ERROR_MESSAGE] = state.errorMessage
            } else {
                prefs.remove(KEY_ERROR_MESSAGE)
            }
            prefs[KEY_STARTED_AT] = state.startedAt
            prefs[KEY_UPDATED_AT] = state.updatedAt
            if (state.completedAt != null) {
                prefs[KEY_COMPLETED_AT] = state.completedAt
            } else {
                prefs.remove(KEY_COMPLETED_AT)
            }
        }
    }

    private fun mapPreferencesToState(prefs: Preferences): ChumaTaskExecutionState {
        val taskId = prefs[KEY_TASK_ID] ?: ""
        if (taskId.isBlank()) {
            return ChumaTaskExecutionState.DEFAULT
        }
        val statusStr = prefs[KEY_STATUS] ?: ChumaTaskStatus.IDLE.name
        val status = try {
            ChumaTaskStatus.valueOf(statusStr)
        } catch (e: Exception) {
            ChumaTaskStatus.IDLE
        }

        return ChumaTaskExecutionState(
            taskId = taskId,
            prompt = prefs[KEY_PROMPT] ?: "",
            taskType = prefs[KEY_TASK_TYPE] ?: "general",
            status = status,
            progress = prefs[KEY_PROGRESS] ?: 0f,
            currentStep = prefs[KEY_CURRENT_STEP] ?: "",
            currentStepIndex = prefs[KEY_CURRENT_STEP_INDEX] ?: 0,
            totalSteps = prefs[KEY_TOTAL_STEPS] ?: 4,
            partialOutput = prefs[KEY_PARTIAL_OUTPUT] ?: "",
            finalResponse = prefs[KEY_FINAL_RESPONSE] ?: "",
            errorMessage = prefs[KEY_ERROR_MESSAGE],
            startedAt = prefs[KEY_STARTED_AT] ?: 0L,
            updatedAt = prefs[KEY_UPDATED_AT] ?: 0L,
            completedAt = prefs[KEY_COMPLETED_AT]
        )
    }
}
