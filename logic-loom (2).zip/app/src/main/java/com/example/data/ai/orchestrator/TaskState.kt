package com.example.data.ai.orchestrator

/**
 * Individual step inside a multi-step orchestration plan.
 */
data class TaskStep(
    val stepIndex: Int,
    val description: String,
    val requiredCapability: ChumaCapability,
    var isCompleted: Boolean = false,
    var isFailed: Boolean = false,
    var stepOutput: String? = null,
    var error: String? = null
)

/**
 * Concise execution state maintained internally for decomposed multi-step tasks.
 * Private chain-of-thought is never exposed to the user.
 */
data class TaskState(
    val intent: ChumaIntent,
    val requiredCapabilities: Set<ChumaCapability>,
    val steps: List<TaskStep>,
    val sources: MutableList<String> = mutableListOf(),
    var confidence: ChumaConfidence = ChumaConfidence.MEDIUM,
    val partialResults: MutableMap<String, String> = mutableMapOf(),
    var result: String? = null
) {
    val completedSteps: List<TaskStep> get() = steps.filter { it.isCompleted }
    val failedSteps: List<TaskStep> get() = steps.filter { it.isFailed }
    val isAllCompleted: Boolean get() = steps.isNotEmpty() && steps.all { it.isCompleted }
}
