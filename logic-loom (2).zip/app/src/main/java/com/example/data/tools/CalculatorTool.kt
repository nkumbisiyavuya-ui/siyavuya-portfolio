package com.example.data.tools

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat

/**
 * CalculatorTool provides deterministic, safe arithmetic evaluation without arbitrary code execution.
 */
object CalculatorTool {

    private val numberFormat = DecimalFormat("#,##0.######")

    data class CalculationResult(
        val success: Boolean,
        val expression: String,
        val result: Double,
        val formattedResult: String,
        val explanation: String
    )

    /**
     * Evaluates a mathematical expression safely.
     * Supports: +, -, *, ×, x, /, ÷, %, ^, parentheses (), and percentage expressions (e.g. "25% of R800", "15% of 2500").
     */
    fun calculate(rawExpression: String): CalculationResult {
        val cleaned = rawExpression
            .replace("what is", "", ignoreCase = true)
            .replace("calculate", "", ignoreCase = true)
            .replace("evaluate", "", ignoreCase = true)
            .replace("solve", "", ignoreCase = true)
            .replace("=", "")
            .replace("?", "")
            .trim()

        if (cleaned.isBlank()) {
            return CalculationResult(
                success = false,
                expression = rawExpression,
                result = 0.0,
                formattedResult = "Error",
                explanation = "Empty calculation expression provided."
            )
        }

        try {
            // Handle "X% of Y" pattern with support for currency prefixes (e.g. "25% of R800")
            val percentOfRegex = Regex("(?i)(\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*([R$€£]?\\s*[0-9,]+(?:\\.[0-9]+)?)")
            val percentMatch = percentOfRegex.find(cleaned)
            if (percentMatch != null) {
                val percentage = percentMatch.groupValues[1].toDouble()
                val totalStr = percentMatch.groupValues[2]
                val hasRand = totalStr.contains("R", ignoreCase = true)
                val cleanTotal = totalStr.replace(Regex("[R$€£,]"), "").trim().toDouble()
                val calculated = (percentage / 100.0) * cleanTotal
                val prefix = if (hasRand) "R" else ""
                val formatted = prefix + numberFormat.format(calculated)
                val formattedTotal = (if (hasRand) "R" else "") + numberFormat.format(cleanTotal)
                return CalculationResult(
                    success = true,
                    expression = "${percentage}% of $formattedTotal",
                    result = calculated,
                    formattedResult = formatted,
                    explanation = "$percentage% of $formattedTotal = $formatted"
                )
            }

            // Normalize arithmetic operators and strip currency symbols / commas
            val normalized = cleaned
                .replace("×", "*")
                .replace("x", "*", ignoreCase = true)
                .replace("÷", "/")
                .replace("plus", "+", ignoreCase = true)
                .replace("minus", "-", ignoreCase = true)
                .replace("times", "*", ignoreCase = true)
                .replace("divided by", "/", ignoreCase = true)
                .replace("percent of", "* 0.01 *", ignoreCase = true)
                .replace("%", "* 0.01")
                .replace(Regex("[R$€£,]"), "")
                .replace(" ", "")

            val evaluator = ExpressionEvaluator(normalized)
            val resultValue = evaluator.parse()
            val formatted = numberFormat.format(resultValue)

            return CalculationResult(
                success = true,
                expression = cleaned,
                result = resultValue,
                formattedResult = formatted,
                explanation = "$cleaned = $formatted"
            )
        } catch (e: Exception) {
            return CalculationResult(
                success = false,
                expression = rawExpression,
                result = 0.0,
                formattedResult = "Error",
                explanation = "Could not evaluate expression '$rawExpression': ${e.message ?: "Invalid syntax"}"
            )
        }
    }

    /**
     * Attempts to identify and dynamically calculate a math prompt if it contains mathematical expressions.
     */
    fun tryCalculate(prompt: String): CalculationResult? {
        val lower = prompt.lowercase().trim()
        val hasPercentOf = Regex("(?i)\\d+(?:\\.\\d+)?\\s*%\\s*of\\s*[R$€£]?\\s*\\d+").containsMatchIn(lower)
        val hasMathKeywords = lower.startsWith("what is ") || lower.startsWith("calculate ") || lower.startsWith("solve ") || lower.startsWith("evaluate ")
        val hasOperators = lower.contains("+") || lower.contains("-") || lower.contains("*") || lower.contains("/") || lower.contains("×") || lower.contains("÷") || lower.contains("^") || hasPercentOf

        if ((hasMathKeywords && hasOperators) || hasPercentOf || Regex("^[0-9\\s+\\-*/×÷^().,R$€£%]+$").matches(lower)) {
            val res = calculate(prompt)
            if (res.success) return res
        }
        return null
    }

    /**
     * Safe recursive descent parser for arithmetic expressions.
     * Grammar:
     *   expression = term (('+' | '-') term)*
     *   term = factor (('*' | '/') factor)*
     *   factor = unary ('^' factor)*
     *   unary = ('+' | '-')* primary
     *   primary = number | '(' expression ')'
     */
    private class ExpressionEvaluator(private val str: String) {
        private var pos = -1
        private var ch = 0

        private fun nextChar() {
            ch = if (++pos < str.length) str[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < str.length) throw IllegalArgumentException("Unexpected character: " + ch.toChar())
            return x
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> {
                        val divisor = parseFactor()
                        if (divisor == 0.0) throw ArithmeticException("Division by zero")
                        x /= divisor
                    }
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                if (!eat(')'.code)) throw IllegalArgumentException("Missing closing parenthesis")
            } else if ((ch >= '0'.code && ch <= '9'.code) || ch == '.'.code) {
                while ((ch >= '0'.code && ch <= '9'.code) || ch == '.'.code) nextChar()
                x = str.substring(startPos, pos).toDouble()
            } else {
                throw IllegalArgumentException("Unexpected symbol: " + (if (ch == -1) "end of input" else ch.toChar().toString()))
            }

            if (eat('^'.code)) x = Math.pow(x, parseFactor())

            return x
        }
    }
}
