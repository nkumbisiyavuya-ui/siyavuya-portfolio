package com.example.data.local

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Ensures clean, empty user data on fresh database launch.
 * In accordance with LOGIC LOOM GLOBAL USER DATA INTEGRITY:
 * EMPTY MEANS EMPTY.
 * No hardcoded, seeded, placeholder, demonstration, guessed, or fabricated user data is inserted.
 * Reference exchange rates (external market data) are initialized if absent.
 */
object SampleDataGenerator {
    suspend fun populateIfEmpty(dao: CanvasMateDao) = withContext(Dispatchers.IO) {
        // Ensure an initial UserProfile record exists if completely null, strictly with empty fields
        if (dao.getUserProfileDirect() == null) {
            val emptyProfile = UserProfile(
                id = 1,
                fullName = "",
                studentNumber = "",
                university = "",
                faculty = "",
                course = "",
                yearOfStudy = "",
                email = "",
                phone = "",
                isLoggedIn = false,
                hasCompletedOnboarding = false
            )
            dao.insertOrUpdateUserProfile(emptyProfile)
        }

        // Initialize fallback reference exchange rates (external reference data, NOT user data)
        val existingRates = dao.getAllExchangeRatesDirect()
        if (existingRates.isEmpty()) {
            val referenceRates = listOf(
                ExchangeRateEntity("USD", 18.25),
                ExchangeRateEntity("EUR", 19.80),
                ExchangeRateEntity("GBP", 23.40),
                ExchangeRateEntity("CAD", 13.45),
                ExchangeRateEntity("AUD", 11.95),
                ExchangeRateEntity("JPY", 0.12),
                ExchangeRateEntity("CHF", 20.75),
                ExchangeRateEntity("CNY", 2.52),
                ExchangeRateEntity("INR", 0.22),
                ExchangeRateEntity("ZAR", 1.0)
            )
            dao.insertExchangeRates(referenceRates)
        }

        // Purge any previously seeded legacy sample data to guarantee clean state
        try {
            dao.purgeSampleShoppingItems()
            dao.purgeSampleTasks()
            dao.purgeSampleTransportRequests()
            dao.purgeSampleShuttles()
            dao.purgeSampleGpaModules()
            dao.purgeSampleTimetableSlots()
            dao.purgeSampleCalendarEvents()
            dao.purgeSampleBudgetGoals()
            dao.purgeSampleBudgetItems()
        } catch (_: Exception) {
            // Safe fallback
        }
    }
}
