package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        UserProfile::class,
        AcademicTask::class,
        CalendarEvent::class,
        TimetableSlot::class,
        NoteItem::class,
        VaultDocument::class,
        BudgetItem::class,
        BudgetGoal::class,
        GoalItem::class,
        DiaryEntry::class,
        TodoTask::class,
        GpaModule::class,
        ShuttleSchedule::class,
        ExchangeRateEntity::class,
        FlashcardDeck::class,
        Flashcard::class,
        ShoppingItem::class,
        TransportRequest::class,
        FoodOrder::class,
        PaymentMethodEntity::class,
        Task::class,
        Course::class,
        Reminder::class,
        UserAccount::class,
        AcademicSchedule::class
    ],
    version = 8,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class CanvasMateDatabase : RoomDatabase() {
    abstract fun dao(): CanvasMateDao
    abstract fun taskDao(): TaskDao
    abstract fun courseDao(): CourseDao
    abstract fun reminderDao(): ReminderDao
    abstract fun userAccountDao(): UserAccountDao
    abstract fun academicScheduleDao(): AcademicScheduleDao

    companion object {
        @Volatile
        private var INSTANCE: CanvasMateDatabase? = null

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `tasks` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `title` TEXT NOT NULL,
                        `courseCode` TEXT NOT NULL,
                        `academicPeriod` TEXT NOT NULL,
                        `description` TEXT NOT NULL,
                        `dueDate` TEXT NOT NULL,
                        `dueTime` TEXT NOT NULL,
                        `priority` TEXT NOT NULL,
                        `weightPercentage` REAL NOT NULL,
                        `status` TEXT NOT NULL,
                        `isCompleted` INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `courses` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `courseCode` TEXT NOT NULL,
                        `courseName` TEXT NOT NULL,
                        `academicPeriod` TEXT NOT NULL,
                        `nqfLevel` INTEGER NOT NULL,
                        `saqaCredits` INTEGER NOT NULL,
                        `lecturerName` TEXT NOT NULL,
                        `department` TEXT NOT NULL,
                        `venue` TEXT NOT NULL,
                        `colorHex` TEXT NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `reminders` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `title` TEXT NOT NULL,
                        `courseCode` TEXT NOT NULL,
                        `academicPeriod` TEXT NOT NULL,
                        `reminderDateTime` TEXT NOT NULL,
                        `reminderType` TEXT NOT NULL,
                        `notes` TEXT NOT NULL,
                        `isDismissed` INTEGER NOT NULL,
                        `isNotificationEnabled` INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): CanvasMateDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CanvasMateDatabase::class.java,
                    "logicloom_db"
                )
                .addMigrations(MIGRATION_5_6)
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
