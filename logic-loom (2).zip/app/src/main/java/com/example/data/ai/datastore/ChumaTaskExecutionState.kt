package com.example.data.ai.datastore

/**
 * Lifecycle and execution status phases of a Chuma AI agent task.
 */
enum class ChumaTaskStatus {
    IDLE,
    QUEUED,
    ANALYZING_INTENT,
    RETRIEVING_CONTEXT,
    EXECUTING_TOOLS,
    SYNTHESIZING,
    COMPLETED,
    FAILED,
    CANCELLED;

    val isInProgress: Boolean
        get() = this in setOf(QUEUED, ANALYZING_INTENT, RETRIEVING_CONTEXT, EXECUTING_TOOLS, SYNTHESIZING)
}

/**
 * Represents the persistent snapshot of an active or recent Chuma AI task execution.
 * Persisted using Jetpack DataStore to ensure agent progress remains intact across app restarts,
 * background kills, and process recreation.
 */
data class ChumaTaskExecutionState(
    val taskId: String = "",
    val prompt: String = "",
    val taskType: String = "general",
    val status: ChumaTaskStatus = ChumaTaskStatus.IDLE,
    val progress: Float = 0f,
    val currentStep: String = "",
    val currentStepIndex: Int = 0,
    val totalSteps: Int = 4,
    val partialOutput: String = "",
    val finalResponse: String = "",
    val errorMessage: String? = null,
    val startedAt: Long = 0L,
    val updatedAt: Long = 0L,
    val completedAt: Long? = null
) {
    val isExecuting: Boolean
        get() = status.isInProgress

    val isInterrupted: Boolean
        get() = isExecuting && (System.currentTimeMillis() - updatedAt > INTERRUPTED_TIMEOUT_MS)

    val percentInt: Int
        get() = (progress.coerceIn(0f, 1f) * 100).toInt()

    companion object {
        const val INTERRUPTED_TIMEOUT_MS = 60_000L // 60s of silence while marked in-progress indicates crash or killed process
        val DEFAULT = ChumaTaskExecutionState()
    }
}
