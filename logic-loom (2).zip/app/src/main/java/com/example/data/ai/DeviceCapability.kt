package com.example.data.ai

/**
 * Capability states defining hardware, permission, and integration status.
 */
enum class CapabilityState {
    AVAILABLE,
    DENIED,
    NOT_REQUESTED,
    UNAVAILABLE,
    ERROR
}

/**
 * Supported or external device/system capabilities.
 */
enum class DeviceCapabilityType(val displayName: String) {
    LOCATION("Device Location"),
    WEATHER("Live Weather Service"),
    MAPS("Navigation & Maps"),
    CALENDAR("Academic & Device Calendar"),
    STORAGE_FILES("Storage & Vault Files"),
    MICROPHONE("Microphone & Voice Input"),
    CAMERA("Camera & Photo Capture"),
    FILE_SELECTION("File & Document Input"),
    IMAGE_INPUT("Image & Vision Input"),
    CONTACTS("Device Contacts"),
    NOTIFICATIONS("Push Notifications"),
    EXTERNAL_TRANSPORT_DISPATCH("Bolt / Uber Ride Dispatch"),
    EXTERNAL_FOOD_ORDERING("Live Food Ordering"),
    EXTERNAL_PAYMENT_GATEWAY("Direct Bank Payment Gateway")
}

data class CapabilityStatus(
    val type: DeviceCapabilityType,
    val state: CapabilityState,
    val message: String
) {
    val isAvailable: Boolean get() = state == CapabilityState.AVAILABLE
}

/**
 * CapabilityRegistry provides honest, transparent evaluation of device capabilities
 * and external integrations.
 */
object CapabilityRegistry {

    private val capabilityStateMap = mutableMapOf<DeviceCapabilityType, CapabilityState>(
        DeviceCapabilityType.LOCATION to CapabilityState.NOT_REQUESTED,
        DeviceCapabilityType.WEATHER to CapabilityState.AVAILABLE,
        DeviceCapabilityType.MAPS to CapabilityState.AVAILABLE,
        DeviceCapabilityType.CALENDAR to CapabilityState.AVAILABLE,
        DeviceCapabilityType.STORAGE_FILES to CapabilityState.AVAILABLE,
        DeviceCapabilityType.MICROPHONE to CapabilityState.NOT_REQUESTED,
        DeviceCapabilityType.CONTACTS to CapabilityState.NOT_REQUESTED,
        DeviceCapabilityType.NOTIFICATIONS to CapabilityState.AVAILABLE,
        // External services that are not integrated directly to prevent fake actions
        DeviceCapabilityType.EXTERNAL_TRANSPORT_DISPATCH to CapabilityState.UNAVAILABLE,
        DeviceCapabilityType.EXTERNAL_FOOD_ORDERING to CapabilityState.UNAVAILABLE,
        DeviceCapabilityType.EXTERNAL_PAYMENT_GATEWAY to CapabilityState.UNAVAILABLE
    )

    fun getCapabilityState(type: DeviceCapabilityType): CapabilityState {
        return capabilityStateMap[type] ?: CapabilityState.UNAVAILABLE
    }

    fun setCapabilityState(type: DeviceCapabilityType, state: CapabilityState) {
        capabilityStateMap[type] = state
    }

    fun getHonestCapabilityReport(type: DeviceCapabilityType): CapabilityStatus {
        val state = getCapabilityState(type)
        val message = when (type) {
            DeviceCapabilityType.LOCATION -> when (state) {
                CapabilityState.AVAILABLE -> "Location access is active. I can use your current coordinates for localized campus and weather information."
                CapabilityState.DENIED -> "I don't currently have permission to access your location. You can enable Location permission in your device settings."
                CapabilityState.NOT_REQUESTED -> "Location permission has not been requested yet. Please grant Location permission when prompted if you'd like location-based assistance."
                CapabilityState.UNAVAILABLE -> "Location services are unavailable or disabled on this device."
                CapabilityState.ERROR -> "An error occurred while attempting to access device location services."
            }
            DeviceCapabilityType.MICROPHONE -> when (state) {
                CapabilityState.AVAILABLE -> "Microphone access is available for voice speech recognition."
                CapabilityState.DENIED -> "Microphone permission is currently denied. You can enable it in device settings to use voice input."
                CapabilityState.NOT_REQUESTED -> "Microphone permission has not been requested yet."
                CapabilityState.UNAVAILABLE -> "No functional microphone was detected on this device."
                CapabilityState.ERROR -> "An error occurred while accessing the microphone hardware."
            }
            DeviceCapabilityType.CONTACTS -> when (state) {
                CapabilityState.AVAILABLE -> "Contacts access is enabled."
                CapabilityState.DENIED -> "I do not have access to your device contacts."
                CapabilityState.NOT_REQUESTED -> "Contacts access has not been requested."
                CapabilityState.UNAVAILABLE -> "Contacts access is not available."
                CapabilityState.ERROR -> "Unable to read device contacts."
            }
            DeviceCapabilityType.STORAGE_FILES -> when (state) {
                CapabilityState.AVAILABLE -> "Storage and local Logic Loom Vault files are accessible."
                CapabilityState.DENIED -> "Storage permission is denied. Logic Loom cannot read external files."
                CapabilityState.NOT_REQUESTED -> "Storage permission has not been requested."
                CapabilityState.UNAVAILABLE -> "Device storage is not accessible."
                CapabilityState.ERROR -> "Storage error encountered."
            }
            DeviceCapabilityType.WEATHER -> when (state) {
                CapabilityState.AVAILABLE -> "Weather guidance is available."
                CapabilityState.UNAVAILABLE -> "Live weather service is currently offline or unreachable."
                else -> "Weather service status: $state."
            }
            DeviceCapabilityType.MAPS -> when (state) {
                CapabilityState.AVAILABLE -> "Campus directions and place lookup are available."
                else -> "Maps functionality is currently limited."
            }
            DeviceCapabilityType.CAMERA -> when (state) {
                CapabilityState.AVAILABLE -> "Camera access is ready for photo capture and visual analysis."
                CapabilityState.DENIED -> "Camera permission is denied. Enable it in device settings to take photos."
                CapabilityState.NOT_REQUESTED -> "Camera permission has not been requested yet."
                CapabilityState.UNAVAILABLE -> "Camera hardware is not available on this device."
                CapabilityState.ERROR -> "Camera error encountered."
            }
            DeviceCapabilityType.FILE_SELECTION -> when (state) {
                CapabilityState.AVAILABLE -> "File and document selection is ready."
                CapabilityState.DENIED -> "File access is restricted."
                else -> "File selection status: $state."
            }
            DeviceCapabilityType.IMAGE_INPUT -> when (state) {
                CapabilityState.AVAILABLE -> "Multimodal image and vision processing is ready."
                else -> "Image processing status: $state."
            }
            DeviceCapabilityType.CALENDAR -> "Logic Loom local timetable and schedule management is available."
            DeviceCapabilityType.NOTIFICATIONS -> "Notification alerts for study plans and deadlines are active."
            DeviceCapabilityType.EXTERNAL_TRANSPORT_DISPATCH -> "I cannot book rides or dispatch external transport (e.g. Bolt / Uber). Logic Loom does not have external ride dispatch capabilities. Please use the official Bolt or Uber application directly."
            DeviceCapabilityType.EXTERNAL_FOOD_ORDERING -> "I cannot place food orders or dispatch external food deliveries. Please use Uber Eats, Mr D Food, or restaurant apps directly."
            DeviceCapabilityType.EXTERNAL_PAYMENT_GATEWAY -> "Direct banking payments or money transfers are not supported. Logic Loom is an offline-first budgeting and study companion and does not process external financial transactions."
        }
        return CapabilityStatus(type, state, message)
    }
}
