package com.example.data.ai

import java.util.UUID

enum class StudyQuestionType(val displayName: String, val iconEmoji: String, val tag: String) {
    MULTIPLE_CHOICE("Multiple Choice", "🔘", "MCQ"),
    CONCEPTUAL_SHORT_ANSWER("Conceptual & Short Answer", "💡", "CONCEPT"),
    TRUE_FALSE("True / False", "⚖️", "TF"),
    SCENARIO_APPLICATION("Applied Scenario", "🧩", "SCENARIO")
}

data class StudyQuestionItem(
    val id: Int,
    val questionNumber: Int,
    val questionText: String,
    val questionType: StudyQuestionType,
    val options: List<String> = emptyList(), // For MCQ or True/False
    val correctOptionIndex: Int = -1, // 0-based index if MCQ/TF
    val correctAnswer: String,
    val explanation: String,
    val hint: String = "",
    val targetConcept: String = "Core Concept",
    val difficulty: String = "University Level",
    val userSelectedOptionIndex: Int? = null,
    val userAnswerText: String = "",
    val isAnswerRevealed: Boolean = false,
    val isMastered: Boolean = false
)

data class StudyQuestionsQuiz(
    val id: String = UUID.randomUUID().toString(),
    val noteTitle: String,
    val noteContentSnippet: String,
    val folder: String = "General",
    val questionTypePreference: String = "Mixed",
    val difficulty: String = "University Level",
    val questions: List<StudyQuestionItem> = emptyList(),
    val generatedAt: String = "August 2026",
    val rawAiResponse: String = ""
) {
    val totalCount: Int get() = questions.size
    val masteredCount: Int get() = questions.count { it.isMastered }
    val revealedCount: Int get() = questions.count { it.isAnswerRevealed }
    val masteryPercentage: Int get() = if (totalCount > 0) (masteredCount * 100) / totalCount else 0
}

data class StudyQuestionsGeneratorConfig(
    val selectedNoteId: Long? = null,
    val noteTitle: String = "",
    val noteContent: String = "",
    val folder: String = "General",
    val questionFormat: String = "Mixed (MCQ + Conceptual + Applied)",
    val difficulty: String = "University Level",
    val questionCount: Int = 5,
    val focusArea: String = "Active Recall & Conceptual Mastery"
)
