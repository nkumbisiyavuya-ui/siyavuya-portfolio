package com.example.data.ai.orchestrator

/**
 * Execution route strategy selected by the CapabilityRouter.
 */
enum class RouteType {
    FAST_PATH_TOOL,
    DIRECT_ACTION,
    SEARCH_GROUNDED_GEMINI,
    GEMINI_REASONING,
    MULTI_STEP_ORCHESTRATION,
    OFFLINE_INTELLIGENCE,
    UNAVAILABLE_CAPABILITY_NOTICE
}

/**
 * Represents the routing decision made for executing a classified ChumaIntent.
 */
data class ChumaRoute(
    val routeType: RouteType,
    val primaryCapability: ChumaCapability,
    val secondaryCapabilities: Set<ChumaCapability> = emptySet(),
    val toolName: String? = null,
    val searchRequired: Boolean = false,
    val confidence: ChumaConfidence = ChumaConfidence.HIGH,
    val reason: String = ""
)
