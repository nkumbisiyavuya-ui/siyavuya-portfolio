package com.example.data.ai

enum class ActionRiskLevel {
    INFORMATION,
    SUGGESTION,
    USER_DATA_MODIFICATION,
    EXTERNAL_ACTION,
    HIGH_IMPACT_IRREVERSIBLE;

    // Backward-compatibility aliases
    companion object {
        val SAFE_READ = INFORMATION
        val LOW_RISK_ACTION = USER_DATA_MODIFICATION
        val SENSITIVE_DESTRUCTIVE = HIGH_IMPACT_IRREVERSIBLE
    }
}

object ActionConfirmation {

    var pendingAction: String? = null
    var pendingRiskLevel: ActionRiskLevel = ActionRiskLevel.INFORMATION

    fun evaluateRiskLevel(prompt: String): ActionRiskLevel {
        val lower = prompt.trim().lowercase()

        // 1. High-impact / irreversible actions
        if (lower.contains("delete all") ||
            lower.contains("delete entire") ||
            lower.contains("wipe") ||
            lower.contains("clear all data") ||
            lower.contains("permanently delete") ||
            lower.contains("delete account") ||
            lower.contains("reset account") ||
            lower.contains("transfer money") ||
            lower.contains("send money") ||
            lower.contains("make purchase") ||
            lower.contains("buy ") ||
            lower.contains("change password") ||
            lower.contains("reset pin") ||
            lower.contains("change pin") ||
            lower.contains("wipe vault")
        ) {
            return ActionRiskLevel.HIGH_IMPACT_IRREVERSIBLE
        }

        // 2. External Actions (Sending emails/messages, external broadcasts)
        if (lower.startsWith("send email") ||
            lower.startsWith("send message") ||
            lower.startsWith("share with") ||
            lower.startsWith("post to") ||
            lower.startsWith("call ")
        ) {
            return ActionRiskLevel.EXTERNAL_ACTION
        }

        // 3. User Data Modifications (Modifying user-owned state)
        if (lower.startsWith("set my budget") ||
            lower.startsWith("set budget") ||
            lower.startsWith("update profile") ||
            lower.startsWith("change my name") ||
            lower.startsWith("delete task") ||
            lower.startsWith("remove module") ||
            lower.startsWith("save location") ||
            lower.startsWith("set student number")
        ) {
            return ActionRiskLevel.USER_DATA_MODIFICATION
        }

        // 4. Suggestion (Advisory suggestions)
        if (lower.contains("suggest") ||
            lower.startsWith("propose") ||
            lower.startsWith("recommend")
        ) {
            return ActionRiskLevel.SUGGESTION
        }

        return ActionRiskLevel.INFORMATION
    }

    fun isConfirmation(reply: String): Boolean {
        val clean = reply.trim().lowercase()
        return clean in listOf(
            "yes", "yes, proceed", "yes proceed", "proceed", "confirm",
            "confirmed", "sure, proceed", "do it", "ok proceed", "yes please",
            "confirm change", "save"
        )
    }

    fun isCancellation(reply: String): Boolean {
        val clean = reply.trim().lowercase()
        return clean in listOf(
            "no", "cancel", "don't", "stop", "abort", "nevermind", "no thanks",
            "dismiss", "keep current"
        )
    }

    fun buildConfirmationMessage(prompt: String, level: ActionRiskLevel = ActionRiskLevel.HIGH_IMPACT_IRREVERSIBLE): String {
        return when (level) {
            ActionRiskLevel.HIGH_IMPACT_IRREVERSIBLE -> """
⚠️ **High-Impact Action Confirmation Required**

You requested:
*"$prompt"*

This action is irreversible and will permanently modify or delete your stored data.
**Are you sure you want to proceed?**
Reply **"Confirm"** to execute or **"Cancel"** to abort.
            """.trimIndent()

            ActionRiskLevel.EXTERNAL_ACTION -> """
📤 **External Action Confirmation**

You requested:
*"$prompt"*

This action will communicate externally on your behalf.
**Do you approve sending this?**
Reply **"Confirm"** or **"Cancel"**.
            """.trimIndent()

            ActionRiskLevel.USER_DATA_MODIFICATION -> """
✏️ **Confirm Data Modification**

Do you want me to update your stored data with:
*"$prompt"*?

Reply **"Confirm"** to save or **"Cancel"** to keep current values.
            """.trimIndent()

            else -> """
Please confirm if you want to proceed with:
*"$prompt"*
            """.trimIndent()
        }
    }
}
