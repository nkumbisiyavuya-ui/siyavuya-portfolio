package com.example.data.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * WeatherTool retrieves real, current live weather data using Open-Meteo API.
 * Never fabricates coordinates or weather data. Gracefully reports errors when offline or service unavailable.
 */
object WeatherTool {

    data class WeatherReport(
        val success: Boolean,
        val locationName: String,
        val country: String?,
        val temperatureCelsius: Double,
        val feelsLikeCelsius: Double,
        val conditionDescription: String,
        val humidityPercent: Int,
        val windSpeedKmh: Double,
        val precipitationMm: Double,
        val retrievalTimestamp: String,
        val formattedSummary: String,
        val errorMessage: String? = null
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Default coordinate fallbacks for major South African student hubs if geocoding fails
    private val cityCoordinates = mapOf(
        "cape town" to Pair(-33.9249, 18.4241),
        "bellville" to Pair(-33.8943, 18.6294),
        "johannesburg" to Pair(-26.2041, 28.0473),
        "pretoria" to Pair(-25.7479, 28.2293),
        "durban" to Pair(-29.8587, 31.0218),
        "gqeberha" to Pair(-33.9608, 25.6022),
        "port elizabeth" to Pair(-33.9608, 25.6022),
        "stellenbosch" to Pair(-33.9321, 18.8602),
        "grahamstown" to Pair(-33.3106, 26.5256),
        "makhanda" to Pair(-33.3106, 26.5256),
        "bloemfontein" to Pair(-29.1183, 26.2249),
        "london" to Pair(51.5074, -0.1278),
        "tokyo" to Pair(35.6762, 139.6503),
        "new york" to Pair(40.7128, -74.0060)
    )

    /**
     * Retrieves real live weather for a given city or location query.
     */
    suspend fun getWeather(locationQuery: String): WeatherReport = withContext(Dispatchers.IO) {
        val cleanQuery = cleanLocationQuery(locationQuery)

        // If user asks "near me" or "here", verify location permission
        if (cleanQuery == "near me" || cleanQuery == "here" || cleanQuery == "current location") {
            val locationService = com.example.data.location.LocationService()
            if (!locationService.canUseLocation()) {
                return@withContext WeatherReport(
                    success = false,
                    locationName = "Current Location",
                    country = null,
                    temperatureCelsius = 0.0,
                    feelsLikeCelsius = 0.0,
                    conditionDescription = "",
                    humidityPercent = 0,
                    windSpeedKmh = 0.0,
                    precipitationMm = 0.0,
                    retrievalTimestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                    formattedSummary = "I don't have permission to access your location. You can specify a city (for example: 'What is the weather in Cape Town?') or enable location permissions in settings.",
                    errorMessage = "Location permission not granted"
                )
            }
        }

        val effectiveCity = if (cleanQuery.isBlank() || cleanQuery == "near me" || cleanQuery == "here") {
            "Cape Town"
        } else {
            cleanQuery
        }

        try {
            // 1. Geocode location query
            val geocodeResult = geocodeCity(effectiveCity)
            val (lat, lon, resolvedName, country) = geocodeResult ?: run {
                val fallbackCoords = cityCoordinates[effectiveCity.lowercase()]
                if (fallbackCoords != null) {
                    Quadruple(fallbackCoords.first, fallbackCoords.second, effectiveCity.capitalizeWords(), "South Africa")
                } else {
                    return@withContext WeatherReport(
                        success = false,
                        locationName = effectiveCity,
                        country = null,
                        temperatureCelsius = 0.0,
                        feelsLikeCelsius = 0.0,
                        conditionDescription = "",
                        humidityPercent = 0,
                        windSpeedKmh = 0.0,
                        precipitationMm = 0.0,
                        retrievalTimestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                        formattedSummary = "I couldn't find location coordinates for '$effectiveCity'. Please check the spelling or specify a nearby city.",
                        errorMessage = "Location not found"
                    )
                }
            }

            // 2. Fetch live weather from Open-Meteo
            val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m"
            val request = Request.Builder().url(weatherUrl).get().build()
            val response = httpClient.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""

            if (!response.isSuccessful || bodyString.isBlank()) {
                return@withContext WeatherReport(
                    success = false,
                    locationName = resolvedName,
                    country = country,
                    temperatureCelsius = 0.0,
                    feelsLikeCelsius = 0.0,
                    conditionDescription = "",
                    humidityPercent = 0,
                    windSpeedKmh = 0.0,
                    precipitationMm = 0.0,
                    retrievalTimestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                    formattedSummary = "I couldn't retrieve live weather data right now. Please try again in a moment.",
                    errorMessage = "HTTP ${response.code}"
                )
            }

            val json = JSONObject(bodyString)
            val current = json.getJSONObject("current")
            val temp = current.getDouble("temperature_2m")
            val feelsLike = current.getDouble("apparent_temperature")
            val humidity = current.getInt("relative_humidity_2m")
            val windSpeed = current.getDouble("wind_speed_10m")
            val precip = current.getDouble("precipitation")
            val weatherCode = current.getInt("weather_code")

            val conditionDesc = mapWeatherCodeToDescription(weatherCode)
            val timeStr = SimpleDateFormat("HH:mm, EEEE d MMMM yyyy", Locale.getDefault()).format(Date())

            val countrySuffix = if (!country.isNullOrBlank()) ", $country" else ""
            val formatted = """
                🌤️ **Current Weather for $resolvedName$countrySuffix**
                
                • **Temperature**: ${"%.1f".format(temp)}°C (Feels like ${"%.1f".format(feelsLike)}°C)
                • **Condition**: $conditionDesc
                • **Humidity**: $humidity%
                • **Wind Speed**: ${"%.1f".format(windSpeed)} km/h
                • **Precipitation**: ${"%.1f".format(precip)} mm
                • **Updated**: $timeStr (Live from Open-Meteo)
            """.trimIndent()

            WeatherReport(
                success = true,
                locationName = resolvedName,
                country = country,
                temperatureCelsius = temp,
                feelsLikeCelsius = feelsLike,
                conditionDescription = conditionDesc,
                humidityPercent = humidity,
                windSpeedKmh = windSpeed,
                precipitationMm = precip,
                retrievalTimestamp = timeStr,
                formattedSummary = formatted
            )
        } catch (e: Exception) {
            WeatherReport(
                success = false,
                locationName = effectiveCity,
                country = null,
                temperatureCelsius = 0.0,
                feelsLikeCelsius = 0.0,
                conditionDescription = "",
                humidityPercent = 0,
                windSpeedKmh = 0.0,
                precipitationMm = 0.0,
                retrievalTimestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                formattedSummary = "I couldn't retrieve live weather data right now. Please check your internet connection and try again.",
                errorMessage = e.message
            )
        }
    }

    private fun geocodeCity(cityName: String): Quadruple<Double, Double, String, String>? {
        return try {
            val encoded = java.net.URLEncoder.encode(cityName, "UTF-8")
            val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json"
            val request = Request.Builder().url(geoUrl).get().build()
            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val results = json.optJSONArray("results")
            if (results != null && results.length() > 0) {
                val first = results.getJSONObject(0)
                val lat = first.getDouble("latitude")
                val lon = first.getDouble("longitude")
                val name = first.getString("name")
                val country = first.optString("country", "South Africa")
                Quadruple(lat, lon, name, country)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun mapWeatherCodeToDescription(code: Int): String {
        return when (code) {
            0 -> "Clear sky ☀️"
            1 -> "Mainly clear 🌤️"
            2 -> "Partly cloudy ⛅"
            3 -> "Overcast ☁️"
            45, 48 -> "Foggy 🌫️"
            51, 53, 55 -> "Drizzle 🌦️"
            56, 57 -> "Freezing drizzle 🌧️"
            61, 63, 65 -> "Rain showers 🌧️"
            66, 67 -> "Freezing rain 🌨️"
            71, 73, 75 -> "Snow fall ❄️"
            77 -> "Snow grains ❄️"
            80, 81, 82 -> "Rain showers 🌦️"
            85, 86 -> "Snow showers 🌨️"
            95 -> "Thunderstorm ⛈️"
            96, 99 -> "Thunderstorm with hail ⛈️"
            else -> "Partly cloudy ⛅"
        }
    }

    private fun cleanLocationQuery(query: String): String {
        return query
            .replace("what is the weather in", "", ignoreCase = true)
            .replace("what is the weather like in", "", ignoreCase = true)
            .replace("what's the weather in", "", ignoreCase = true)
            .replace("what's the weather like in", "", ignoreCase = true)
            .replace("weather in", "", ignoreCase = true)
            .replace("weather at", "", ignoreCase = true)
            .replace("weather for", "", ignoreCase = true)
            .replace("weather", "", ignoreCase = true)
            .replace("today", "", ignoreCase = true)
            .replace("current", "", ignoreCase = true)
            .replace("?", "")
            .trim()
    }

    private fun String.capitalizeWords(): String {
        return this.split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
    }

    private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
