package com.example.data.ai.orchestrator

import android.util.Log

/**
 * Structured observability and logging for the Chuma AI Orchestrator lifecycle.
 * Ensures security: never logs API keys, auth tokens, passwords, or raw sensitive credentials.
 */
object ChumaOrchestratorLogger {
    private const val TAG = "ChumaOrchestrator"

    fun logEvent(event: String, details: Map<String, Any?> = emptyMap()) {
        val sanitizedDetails = details.mapValues { (key, value) ->
            if (key.contains("key", ignoreCase = true) ||
                key.contains("token", ignoreCase = true) ||
                key.contains("secret", ignoreCase = true) ||
                key.contains("password", ignoreCase = true)
            ) {
                "[REDACTED]"
            } else {
                value?.toString()?.take(200) ?: "null"
            }
        }
        val formatted = "event=$event | $sanitizedDetails"
        try {
            Log.i(TAG, formatted)
        } catch (e: Throwable) {
            println("[$TAG] $formatted")
        }
    }

    fun requestReceived(requestId: String, taskTypeHint: String, promptLength: Int) {
        logEvent("request_received", mapOf("requestId" to requestId, "hint" to taskTypeHint, "length" to promptLength))
    }

    fun intentClassified(requestId: String, taskType: ChumaTaskType, confidence: ChumaConfidence, isMultiStep: Boolean) {
        logEvent("intent_classified", mapOf("requestId" to requestId, "taskType" to taskType.name, "confidence" to confidence.name, "isMultiStep" to isMultiStep))
    }

    fun capabilitiesSelected(requestId: String, capabilities: Set<ChumaCapability>) {
        logEvent("capabilities_selected", mapOf("requestId" to requestId, "capabilities" to capabilities.map { it.name }))
    }

    fun executionStarted(requestId: String, routeType: RouteType) {
        logEvent("execution_started", mapOf("requestId" to requestId, "route" to routeType.name))
    }

    fun toolStarted(requestId: String, toolName: String) {
        logEvent("tool_started", mapOf("requestId" to requestId, "tool" to toolName))
    }

    fun toolCompleted(requestId: String, toolName: String, success: Boolean) {
        logEvent("tool_completed", mapOf("requestId" to requestId, "tool" to toolName, "success" to success))
    }

    fun toolFailed(requestId: String, toolName: String, error: String?) {
        logEvent("tool_failed", mapOf("requestId" to requestId, "tool" to toolName, "error" to error))
    }

    fun verificationStarted(requestId: String) {
        logEvent("verification_started", mapOf("requestId" to requestId))
    }

    fun verificationCompleted(requestId: String, isVerified: Boolean, notes: String?) {
        logEvent("verification_completed", mapOf("requestId" to requestId, "isVerified" to isVerified, "notes" to notes))
    }

    fun responseGenerated(requestId: String, outputLength: Int, durationMs: Long) {
        logEvent("response_generated", mapOf("requestId" to requestId, "length" to outputLength, "durationMs" to durationMs))
    }

    fun requestCancelled(requestId: String) {
        logEvent("request_cancelled", mapOf("requestId" to requestId))
    }

    fun requestFailed(requestId: String, error: String?) {
        logEvent("request_failed", mapOf("requestId" to requestId, "error" to error))
    }
}
