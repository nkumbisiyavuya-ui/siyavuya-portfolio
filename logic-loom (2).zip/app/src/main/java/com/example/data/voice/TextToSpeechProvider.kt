package com.example.data.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/**
 * Modular abstraction for Text-To-Speech (TTS) providers.
 * Allows switching between Android native TTS, cloud neural voices (ElevenLabs, Play.ht, etc.)
 * without changing conversational or reasoning logic.
 */
interface TextToSpeechProvider {
    val isReady: Boolean
    val providerName: String get() = "System"
    fun speak(
        text: String,
        profile: VoiceProfile,
        volume: Float = 1.0f,
        speed: Float = 1.0f,
        utteranceId: String = java.util.UUID.randomUUID().toString(),
        onStart: () -> Unit = {},
        onDone: () -> Unit = {},
        onError: (String) -> Unit = {}
    )

    fun speakChunk(
        chunk: String,
        isLastChunk: Boolean,
        profile: VoiceProfile,
        volume: Float = 1.0f,
        speed: Float = 1.0f,
        utteranceId: String = java.util.UUID.randomUUID().toString(),
        onStart: () -> Unit = {},
        onDone: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        speak(chunk, profile, volume, speed, utteranceId, onStart, onDone, onError)
    }

    fun stop()
    fun destroy()
}

/**
 * Production-quality Android TextToSpeech implementation with audio focus management,
 * voice profile pitch and rate adjustments, and instant barge-in support.
 */
class AndroidTextToSpeechProvider(
    private val context: Context
) : TextToSpeechProvider {

    override val providerName: String = "Android System TTS"
    private var tts: TextToSpeech? = null
    override var isReady: Boolean = false
        private set

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    private var currentOnStart: (() -> Unit)? = null
    private var currentOnDone: (() -> Unit)? = null
    private var currentOnError: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.let { engine ->
                    // Set South Africa or standard English locale
                    val locale = Locale("en", "ZA")
                    val result = engine.setLanguage(locale)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.language = Locale.ENGLISH
                    }

                    // Setup speech audio attributes
                    val audioAttributes = AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .build()
                    engine.setAudioAttributes(audioAttributes)

                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            currentOnStart?.invoke()
                        }

                        override fun onDone(utteranceId: String?) {
                            releaseAudioFocus()
                            currentOnDone?.invoke()
                        }

                        override fun onError(utteranceId: String?) {
                            releaseAudioFocus()
                            currentOnError?.invoke("Text-to-speech rendering failed.")
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            releaseAudioFocus()
                            currentOnError?.invoke("TTS error ($errorCode)")
                        }

                        override fun onStop(utteranceId: String?, interrupted: Boolean) {
                            releaseAudioFocus()
                            if (interrupted) {
                                currentOnDone?.invoke()
                            }
                        }
                    })

                    isReady = true
                }
            } else {
                isReady = false
            }
        }
    }

    override fun speak(
        text: String,
        profile: VoiceProfile,
        volume: Float,
        speed: Float,
        utteranceId: String,
        onStart: () -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (!isReady || tts == null) {
            onError("Voice engine is initializing. Please try again.")
            return
        }

        // Clean markdown symbols for natural TTS speech
        val cleanedText = cleanTextForSpeech(text)
        if (cleanedText.isBlank()) {
            onDone()
            return
        }

        currentOnStart = onStart
        currentOnDone = onDone
        currentOnError = onError

        requestAudioFocus()

        tts?.let { engine ->
            // Apply voice profile pitch
            engine.setPitch(profile.pitch)

            // Combined speed: profile base rate * user slider multiplier
            val effectiveRate = (profile.rate * speed).coerceIn(0.6f, 2.0f)
            engine.setSpeechRate(effectiveRate)

            // Select matching system voice if available
            selectBestVoice(engine, profile)

            // Bundle parameters (Volume control: 0.0 to 1.0)
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0.0f, 1.0f))
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }

            engine.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    /**
     * Immediately stops playback for conversational barge-in.
     */
    override fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Safe cleanup
        } finally {
            releaseAudioFocus()
        }
    }

    override fun destroy() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            // Safe cleanup
        } finally {
            tts = null
            isReady = false
        }
    }

    private fun selectBestVoice(engine: TextToSpeech, profile: VoiceProfile) {
        try {
            val voices = engine.voices ?: return
            val matchedVoice = when (profile.id) {
                "female" -> voices.firstOrNull { v ->
                    (v.name.contains("female", ignoreCase = true) || v.name.contains("#female", ignoreCase = true) || v.name.contains("en-za", ignoreCase = true)) &&
                            !v.isNetworkConnectionRequired
                }
                "male" -> voices.firstOrNull { v ->
                    (v.name.contains("male", ignoreCase = true) || v.name.contains("#male", ignoreCase = true)) &&
                            !v.isNetworkConnectionRequired
                }
                else -> voices.firstOrNull { v ->
                    v.locale.language == "en" && !v.isNetworkConnectionRequired
                }
            }

            if (matchedVoice != null) {
                engine.voice = matchedVoice
            }
        } catch (e: Exception) {
            // Pitch and rate fallbacks remain active if custom voice mapping fails
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener { focusChange ->
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        stop()
                    }
                }
                .build()
            audioFocusRequest?.let { am.requestAudioFocus(it) }
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                { focusChange ->
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        stop()
                    }
                },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    private fun releaseAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    /**
     * Sanitizes markdown, asterisks, bullet formatting, and URLs for natural voice delivery.
     */
    private fun cleanTextForSpeech(input: String): String {
        return input
            .replace(Regex("""\*\*(.*?)\*\*"""), "$1")
            .replace(Regex("""\*(.*?)\*"""), "$1")
            .replace(Regex("""`{1,3}.*?`{1,3}"""), "code snippet")
            .replace(Regex("""#+\s*"""), "")
            .replace(Regex("""[-*•]\s+"""), ", ")
            .replace(Regex("""\[(.*?)\]\(.*?\)"""), "$1")
            .replace(Regex("""https?://\S+"""), "link")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }
}
