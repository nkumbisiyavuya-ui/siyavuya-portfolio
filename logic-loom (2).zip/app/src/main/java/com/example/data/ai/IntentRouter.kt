package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * IntentRouter maps natural language user messages to specific system actions
 * (e.g. 'CreateTask', 'GetBalance', 'FindCalendarEvents') using the Gemini API
 * for intent classification with local rule-based fallback.
 */
@Singleton
class IntentRouter @Inject constructor() {

    enum class SystemAction(val actionName: String, val category: MajorIntentCategory) {
        CREATE_TASK("CreateTask", MajorIntentCategory.TASKS),
        GET_BALANCE("GetBalance", MajorIntentCategory.FINANCE),
        FIND_CALENDAR_EVENTS("FindCalendarEvents", MajorIntentCategory.CALENDAR),
        GET_TASKS("GetTasks", MajorIntentCategory.TASKS),
        NEXT_CLASS("NextClass", MajorIntentCategory.CALENDAR),
        DAILY_BRIEFING("DailyBriefing", MajorIntentCategory.PRODUCTIVITY),
        ANALYZE_SPENDING("AnalyzeSpending", MajorIntentCategory.FINANCE),
        FIND_DOCUMENT("FindDocument", MajorIntentCategory.DOCUMENTS),
        CALCULATE_GRADE("CalculateGrade", MajorIntentCategory.STUDY),
        EXPLAIN_CONCEPT("ExplainConcept", MajorIntentCategory.STUDY),
        DESTRUCTIVE_WIPE("DestructiveWipe", MajorIntentCategory.SYSTEM),
        GET_TIME("GetTime", MajorIntentCategory.TIME_DATE),
        GET_WEATHER("GetWeather", MajorIntentCategory.WEATHER),
        CALCULATE("Calculate", MajorIntentCategory.CALCULATION),
        CONVERT_CURRENCY("ConvertCurrency", MajorIntentCategory.CURRENCY),
        WEB_SEARCH("WebSearch", MajorIntentCategory.WEB_SEARCH),
        CAMPUS_PLACES("CampusPlaces", MajorIntentCategory.CAMPUS_PLACES),
        EXTERNAL_UNAVAILABLE("ExternalUnavailable", MajorIntentCategory.EXTERNAL_SERVICE),
        GENERAL_QUERY("GeneralQuery", MajorIntentCategory.GENERAL)
    }

    /**
     * Classified intent result with action name, category, parameters, and metadata.
     */
    data class IntentResult(
        val action: String,
        val category: MajorIntentCategory,
        val isFastPathEligible: Boolean = true,
        val requiresConfirmation: Boolean = false,
        val confidence: Double = 1.0,
        val parameters: Map<String, String> = emptyMap()
    ) {
        fun toParsedIntent(): ParsedIntent = ParsedIntent(
            category = category,
            subAction = action,
            isFastPathEligible = isFastPathEligible,
            requiresConfirmation = requiresConfirmation,
            parameters = parameters
        )
    }

    /**
     * Classifies a natural language user message to a system action using Gemini API classification,
     * with local rule-based fallback and fast path optimization.
     */
    suspend fun classifyIntent(userMessage: String): IntentResult = withContext(Dispatchers.IO) {
        val trimmed = userMessage.trim()
        if (trimmed.isBlank()) {
            return@withContext IntentResult("GeneralQuery", MajorIntentCategory.GENERAL)
        }

        // Fast local check first for deterministic response & speed
        val localMatch = routeLocalRule(trimmed)
        if (localMatch.action != "GeneralQuery") {
            return@withContext localMatch
        }

        // Use Gemini API for classification if API key is present
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
                val classificationPrompt = """
                    You are an intent classification system for Logic Loom AI assistant (Chuma AI).
                    Classify the user message into exactly ONE of the following system actions:
                    - CreateTask: Creating a new task, assignment, or reminder (e.g. "remind me to...", "add task...")
                    - GetBalance: Checking financial balance, budget remaining, or money available
                    - FindCalendarEvents: Finding or listing calendar events, lectures, or schedule for dates
                    - GetTasks: Looking up existing tasks, overdue tasks, or due items
                    - NextClass: Finding the next class, lecture location, or upcoming timetable slot
                    - DailyBriefing: Requesting daily summary, priority list, or day plan
                    - AnalyzeSpending: Reviewing spending, expenses, budget breakdown
                    - FindDocument: Locating PDFs, course notes, vault files
                    - CalculateGrade: Calculating grades, exam scores needed, pass marks
                    - GetTime: Current time, time in a city, today's date, day of week, year, or holiday date
                    - GetWeather: Weather forecast, current temperature, rain conditions, or umbrella advice
                    - Calculate: Mathematical calculations, arithmetic, percentages (e.g. "25% of R800", "15 * 7")
                    - ConvertCurrency: Currency conversion between ZAR, USD, EUR, GBP, etc.
                    - WebSearch: Live web search for recent news or external information
                    - CampusPlaces: Campus buildings, venues, facilities, or nearby student amenities
                    - ExternalUnavailable: External ride-hailing (Bolt/Uber) or external food delivery
                    - ExplainConcept: Asking academic explanations, definitions, derivations
                    - DestructiveWipe: Requesting data wipe, deleting all data
                    - GeneralQuery: General chat, greeting, or unclassified query

                    User message: "$trimmed"

                    Return ONLY a JSON object with:
                    {
                      "action": "ActionName",
                      "confidence": 0.95,
                      "parameters": { "paramName": "value" }
                    }
                """.trimIndent()

                val rawResponse = GeminiClient.askGemini(classificationPrompt, "general")
                val jsonMatch = Regex("\\{.*\\}", RegexOption.DOT_MATCHES_ALL).find(rawResponse)?.value
                if (jsonMatch != null) {
                    val jsonObj = JSONObject(jsonMatch)
                    val actionStr = jsonObj.optString("action", "GeneralQuery")
                    val confidence = jsonObj.optDouble("confidence", 0.85)
                    val paramsMap = mutableMapOf<String, String>()
                    val paramsObj = jsonObj.optJSONObject("parameters")
                    paramsObj?.keys()?.forEach { key ->
                        paramsMap[key] = paramsObj.getString(key)
                    }

                    val systemAction = SystemAction.values().firstOrNull {
                        it.actionName.equals(actionStr, ignoreCase = true)
                    } ?: SystemAction.GENERAL_QUERY

                    return@withContext IntentResult(
                        action = systemAction.actionName,
                        category = systemAction.category,
                        isFastPathEligible = systemAction != SystemAction.EXPLAIN_CONCEPT && systemAction != SystemAction.GENERAL_QUERY,
                        requiresConfirmation = systemAction == SystemAction.DESTRUCTIVE_WIPE,
                        confidence = confidence,
                        parameters = paramsMap
                    )
                }
            }
        } catch (e: Exception) {
            // Fall back to local rule if API fails or offline
        }

        return@withContext localMatch
    }

    /**
     * Map natural language user message using local rules.
     */
    fun routeLocalRule(prompt: String): IntentResult {
        val lower = prompt.trim().lowercase()

        // 1. Destructive system actions
        if (lower.contains("delete all") || lower.contains("delete entire") || lower.contains("wipe my") || lower.contains("clear all data")) {
            return IntentResult(
                action = SystemAction.DESTRUCTIVE_WIPE.actionName,
                category = MajorIntentCategory.SYSTEM,
                isFastPathEligible = false,
                requiresConfirmation = true,
                parameters = mapOf("target" to "all_data")
            )
        }

        // 2. Unavailable external services (transparently identified)
        if (lower.contains("book a bolt") || lower.contains("book bolt") || lower.contains("call a bolt") || lower.contains("order a bolt") ||
            lower.contains("book an uber") || lower.contains("book uber") || lower.contains("call an uber") ||
            lower.contains("order food") || lower.contains("order pizza") || lower.contains("order debonairs") ||
            lower.contains("order ubereats") || lower.contains("order mr d") || lower.contains("wire money") || lower.contains("bank transfer")) {
            val serviceType = when {
                lower.contains("bolt") || lower.contains("uber") -> "transport"
                lower.contains("food") || lower.contains("pizza") || lower.contains("debonairs") || lower.contains("ubereats") || lower.contains("mr d") -> "food_ordering"
                else -> "banking"
            }
            return IntentResult(
                action = SystemAction.EXTERNAL_UNAVAILABLE.actionName,
                category = MajorIntentCategory.EXTERNAL_SERVICE,
                isFastPathEligible = true,
                parameters = mapOf("service" to serviceType)
            )
        }

        // 3. Mathematical calculation / Arithmetic / Percentages (e.g. "What is 25% of R800?", "What is 15 * 7?")
        val calcResult = com.example.data.tools.CalculatorTool.tryCalculate(prompt)
        if (calcResult != null) {
            return IntentResult(
                action = SystemAction.CALCULATE.actionName,
                category = MajorIntentCategory.CALCULATION,
                isFastPathEligible = true,
                parameters = mapOf("expression" to prompt)
            )
        }

        // 4. Time, Date, Day of Week, and Calendar inquiries (e.g. "What time is it?", "What time is it in Tokyo?", "What is today's date?")
        val isTimeQuery = lower == "what time is it" || lower == "what time is it?" || lower == "what is the time" || lower == "what is the time?" ||
                lower.contains("current time") || lower.contains("time in ") || lower.contains("time at ") ||
                lower.contains("today's date") || lower.contains("date today") || lower == "what is the date" || lower == "what is the date?" ||
                lower == "what day is it" || lower == "what day is it?" || lower == "what day is today" || lower == "what day is today?" ||
                lower.contains("day of the week") || lower.contains("what year is it") || lower.contains("what month is it") ||
                lower.contains("is today a weekend") || lower.contains("is it the weekend") ||
                com.example.data.tools.TimeTool.resolveCalendarEventDate(prompt) != null

        if (isTimeQuery) {
            val locationParam = if (lower.contains(" in ")) prompt.substring(lower.indexOf(" in ") + 4).removeSuffix("?").trim() else "local"
            return IntentResult(
                action = SystemAction.GET_TIME.actionName,
                category = MajorIntentCategory.TIME_DATE,
                isFastPathEligible = true,
                parameters = mapOf("location" to locationParam, "query" to prompt)
            )
        }

        // 5. Weather inquiries (e.g. "What is the weather?", "Weather in Cape Town", "Do I need an umbrella?")
        if (lower.contains("weather") || lower.contains("temperature") || lower.contains("forecast") ||
            lower.contains("will it rain") || lower.contains("need an umbrella") || lower.contains("is it raining")) {
            val locationParam = when {
                lower.contains(" in ") -> prompt.substring(lower.indexOf(" in ") + 4).removeSuffix("?").trim()
                lower.contains(" at ") -> prompt.substring(lower.indexOf(" at ") + 4).removeSuffix("?").trim()
                lower.contains(" for ") -> prompt.substring(lower.indexOf(" for ") + 4).removeSuffix("?").trim()
                lower.contains("near me") || lower.contains("here") -> "near_me"
                else -> "device_location"
            }
            return IntentResult(
                action = SystemAction.GET_WEATHER.actionName,
                category = MajorIntentCategory.WEATHER,
                isFastPathEligible = true,
                parameters = mapOf("location" to locationParam)
            )
        }

        // 6. Currency conversion inquiries (e.g. "Convert 500 ZAR to USD")
        if ((lower.contains("convert") && (lower.contains("zar") || lower.contains("usd") || lower.contains("rand") || lower.contains("eur") || lower.contains("gbp"))) ||
            (lower.contains("how much is") && (lower.contains("dollar") || lower.contains("rand") || lower.contains("zar")))) {
            return IntentResult(
                action = SystemAction.CONVERT_CURRENCY.actionName,
                category = MajorIntentCategory.CURRENCY,
                isFastPathEligible = true,
                parameters = mapOf("query" to prompt)
            )
        }

        // 7. Web search inquiries
        if (lower.startsWith("search the web") || lower.startsWith("web search") || lower.startsWith("search for news") ||
            lower.startsWith("latest news") || lower.startsWith("search online") || lower.startsWith("google ")) {
            val queryParam = prompt
                .removePrefix("search the web for")
                .removePrefix("search the web")
                .removePrefix("web search for")
                .removePrefix("web search")
                .removePrefix("search online for")
                .removePrefix("google")
                .trim()
            return IntentResult(
                action = SystemAction.WEB_SEARCH.actionName,
                category = MajorIntentCategory.WEB_SEARCH,
                isFastPathEligible = true,
                parameters = mapOf("query" to queryParam)
            )
        }

        // 8. Campus places and facilities
        if (lower.startsWith("where is ") || lower.contains("nearest library") || lower.contains("nearest pharmacy") ||
            lower.contains("nearest atm") || lower.contains("coffee on campus") || lower.contains("study spot")) {
            return IntentResult(
                action = SystemAction.CAMPUS_PLACES.actionName,
                category = MajorIntentCategory.CAMPUS_PLACES,
                isFastPathEligible = true,
                parameters = mapOf("query" to prompt)
            )
        }

        // 9. Student's explicit balance queries
        if (lower == "what is my balance" || lower == "my balance" || lower == "check my balance" || lower.contains("how much money do i have") || lower.contains("what's my balance") || lower.contains("current balance")) {
            return IntentResult(
                action = SystemAction.GET_BALANCE.actionName,
                category = MajorIntentCategory.FINANCE,
                isFastPathEligible = true
            )
        }

        // 10. Student's explicit task creation
        if (lower.startsWith("remind me to ") || lower.startsWith("add task ") || lower.startsWith("set reminder ") || lower.startsWith("create task ") || lower.startsWith("add a task ")) {
            return IntentResult(
                action = SystemAction.CREATE_TASK.actionName,
                category = MajorIntentCategory.TASKS,
                isFastPathEligible = true
            )
        }

        // 11. Student's personal calendar queries (not "what is a calendar")
        if (lower == "show my calendar" || lower == "my calendar" || lower == "my events" || lower == "schedule today" || lower.contains("find my calendar events") || lower.contains("what is on my calendar today")) {
            return IntentResult(
                action = SystemAction.FIND_CALENDAR_EVENTS.actionName,
                category = MajorIntentCategory.CALENDAR,
                isFastPathEligible = true
            )
        }

        // 12. Student's personal tasks list
        if (lower == "show my tasks" || lower == "my tasks" || lower == "show tasks" || lower.contains("my overdue tasks") || lower.contains("my tasks due")) {
            return IntentResult(
                action = SystemAction.GET_TASKS.actionName,
                category = MajorIntentCategory.TASKS,
                isFastPathEligible = true
            )
        }

        // 13. Student's class schedule
        if (lower.contains("my next class") || lower.contains("next lecture") || lower == "where is my class" || lower == "what is my next class") {
            return IntentResult(
                action = SystemAction.NEXT_CLASS.actionName,
                category = MajorIntentCategory.CALENDAR,
                isFastPathEligible = true
            )
        }

        if (lower == "daily briefing" || lower == "plan my day" || lower == "give me my daily briefing") {
            return IntentResult(
                action = SystemAction.DAILY_BRIEFING.actionName,
                category = MajorIntentCategory.PRODUCTIVITY,
                isFastPathEligible = true
            )
        }

        // 14. Student's personal spending analysis
        if (lower == "analyze my spending" || lower == "my spending" || lower.contains("analyze my budget") || lower.contains("can i afford this with my budget")) {
            return IntentResult(
                action = SystemAction.ANALYZE_SPENDING.actionName,
                category = MajorIntentCategory.FINANCE,
                isFastPathEligible = true
            )
        }

        if (lower.contains("vault document") || lower.contains("my notes file") || lower.contains("find my pdf")) {
            return IntentResult(
                action = SystemAction.FIND_DOCUMENT.actionName,
                category = MajorIntentCategory.DOCUMENTS,
                isFastPathEligible = true
            )
        }

        if ((lower.contains("pass") || lower.contains("mark") || lower.contains("exam") || lower.contains("needed")) &&
            (lower.contains("test") || lower.contains("assignment") || lower.contains("calculate"))) {
            return IntentResult(
                action = SystemAction.CALCULATE_GRADE.actionName,
                category = MajorIntentCategory.STUDY,
                isFastPathEligible = true
            )
        }

        return IntentResult(
            action = SystemAction.GENERAL_QUERY.actionName,
            category = MajorIntentCategory.GENERAL,
            isFastPathEligible = false
        )
    }

    companion object {
        private val defaultInstance = IntentRouter()

        @JvmStatic
        fun route(prompt: String): ParsedIntent {
            return defaultInstance.routeLocalRule(prompt).toParsedIntent()
        }

        @JvmStatic
        suspend fun routeWithGemini(prompt: String): ParsedIntent {
            return defaultInstance.classifyIntent(prompt).toParsedIntent()
        }
    }
}
