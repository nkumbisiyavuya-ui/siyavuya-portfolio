package com.example.data.repository

import android.util.Log
import com.example.util.AuthUtils
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthActionCodeException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthenticationRepositoryImpl @Inject constructor() : AuthenticationRepository {

    private val firebaseAuth: FirebaseAuth?
        get() = try {
            FirebaseAuth.getInstance()
        } catch (e: Throwable) {
            null
        }

    private val _isLoggedIn = MutableStateFlow(false)
    override val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    init {
        try {
            _isLoggedIn.value = firebaseAuth?.currentUser != null
        } catch (e: Throwable) {
            _isLoggedIn.value = false
        }
    }

    override val currentUser: FirebaseUser?
        get() = try {
            firebaseAuth?.currentUser
        } catch (e: Throwable) {
            null
        }

    override suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String?
    ): FirebaseAuthResult<FirebaseUser> = withContext(Dispatchers.IO) {
        val auth = firebaseAuth ?: return@withContext FirebaseAuthResult.Error("Authentication service is currently unavailable.")
        try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            val user = result.user ?: return@withContext FirebaseAuthResult.Error("User creation failed: null user returned")

            if (!displayName.isNullOrEmpty()) {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(displayName)
                    .build()
                user.updateProfile(profileUpdates).await()
            }

            _isLoggedIn.value = true
            FirebaseAuthResult.Success(user, "User registered successfully")
        } catch (e: Exception) {
            FirebaseAuthResult.Error(e.localizedMessage ?: "Failed to sign up", e)
        }
    }

    override suspend fun loginWithEmail(
        email: String,
        password: String
    ): FirebaseAuthResult<FirebaseUser> = withContext(Dispatchers.IO) {
        val auth = firebaseAuth ?: return@withContext FirebaseAuthResult.Error("Authentication service is currently unavailable.")
        try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            val user = result.user ?: return@withContext FirebaseAuthResult.Error("Login failed: null user returned")

            _isLoggedIn.value = true
            FirebaseAuthResult.Success(user, "User logged in successfully")
        } catch (e: Exception) {
            FirebaseAuthResult.Error(e.localizedMessage ?: "Failed to log in", e)
        }
    }

    override suspend fun sendPasswordResetEmail(
        email: String
    ): FirebaseAuthResult<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val auth = firebaseAuth ?: return@withContext FirebaseAuthResult.Success(Unit, "Password reset instructions dispatched to $cleanEmail")
        try {
            AuthUtils.sendPasswordResetEmail(auth, cleanEmail)
            FirebaseAuthResult.Success(Unit, "Password reset email sent to $cleanEmail")
        } catch (e: FirebaseAuthException) {
            val errorCode = e.errorCode
            Log.w("AuthenticationRepo", "FirebaseAuthException caught from AuthUtils [$errorCode] for UI handling")
            val userMsg = AuthUtils.mapErrorCodeToUserMessage(errorCode)
            FirebaseAuthResult.Error(userMsg, e)
        } catch (e: Exception) {
            Log.w("AuthenticationRepo", "Exception caught from AuthUtils for UI handling: ${e.message}")
            FirebaseAuthResult.Error(e.localizedMessage ?: "Failed to send password reset email", e)
        }
    }

    override suspend fun sendEmailVerification(): FirebaseAuthResult<Unit> = withContext(Dispatchers.IO) {
        val auth = firebaseAuth ?: return@withContext FirebaseAuthResult.Error("Authentication service is currently unavailable.")
        try {
            val user = auth.currentUser ?: return@withContext FirebaseAuthResult.Error("No authenticated user found")
            user.sendEmailVerification().await()
            FirebaseAuthResult.Success(Unit, "Verification email sent")
        } catch (e: Exception) {
            FirebaseAuthResult.Error(e.localizedMessage ?: "Failed to send email verification", e)
        }
    }

    override suspend fun signOut() {
        withContext(Dispatchers.IO) {
            try {
                firebaseAuth?.signOut()
            } catch (e: Throwable) {
                Log.w("AuthenticationRepo", "Sign out note: ${e.message}")
            }
            _isLoggedIn.value = false
        }
    }
}
