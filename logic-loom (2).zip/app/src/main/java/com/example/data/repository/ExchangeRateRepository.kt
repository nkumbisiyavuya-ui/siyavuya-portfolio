package com.example.data.repository

import com.example.data.local.CanvasMateDao
import com.example.data.local.ExchangeRateEntity
import com.example.data.network.ExchangeRateNetworkService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ExchangeRateResult(
    val rates: Map<String, Double>,
    val isLive: Boolean,
    val isFromRoomCache: Boolean
)

class ExchangeRateRepository(private val dao: CanvasMateDao? = null) {

    /**
     * Fetches ZAR exchange rates from network API or falls back to Room database cache when offline.
     */
    suspend fun getZarExchangeRates(): ExchangeRateResult = withContext(Dispatchers.IO) {
        try {
            val response = ExchangeRateNetworkService.apiService.getZarRates()
            if (response.rates != null && response.rates.isNotEmpty()) {
                val ratesMap = response.rates
                // Cache into Room database if DAO is present
                dao?.let {
                    val entities = ratesMap.map { (currency, rate) ->
                        ExchangeRateEntity(
                            currencyCode = currency,
                            rateAgainstZar = rate,
                            lastUpdatedTimestamp = System.currentTimeMillis()
                        )
                    }
                    it.insertExchangeRates(entities)
                }
                return@withContext ExchangeRateResult(rates = ratesMap, isLive = true, isFromRoomCache = false)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Network error / offline -> Try loading from Room database cache
        val cachedEntities = dao?.getAllExchangeRatesDirect() ?: emptyList()
        if (cachedEntities.isNotEmpty()) {
            val cachedMap = cachedEntities.associate { it.currencyCode to it.rateAgainstZar }
            return@withContext ExchangeRateResult(rates = cachedMap, isLive = false, isFromRoomCache = true)
        }

        // Fallback default static rates if Room database is empty
        return@withContext ExchangeRateResult(
            rates = ExchangeRateNetworkService.fallbackRates,
            isLive = false,
            isFromRoomCache = false
        )
    }

    /**
     * Convert an amount in a foreign currency (e.g., $100 USD) to ZAR (South African Rand).
     * Since API returns rates relative to 1 ZAR (e.g. 1 ZAR = 0.0545 USD),
     * Amount in ZAR = Amount in USD / Rate(USD).
     */
    fun convertForeignToZar(foreignAmount: Double, currency: String, rates: Map<String, Double>): Double {
        if (currency == "ZAR") return foreignAmount
        val ratePerZar = rates[currency] ?: ExchangeRateNetworkService.fallbackRates[currency] ?: 1.0
        return if (ratePerZar > 0) foreignAmount / ratePerZar else foreignAmount
    }

    /**
     * Convert an amount in ZAR to a foreign currency.
     * Amount in Foreign Currency = Amount in ZAR * Rate(ForeignCurrency).
     */
    fun convertZarToForeign(zarAmount: Double, currency: String, rates: Map<String, Double>): Double {
        if (currency == "ZAR") return zarAmount
        val ratePerZar = rates[currency] ?: ExchangeRateNetworkService.fallbackRates[currency] ?: 1.0
        return zarAmount * ratePerZar
    }
}
