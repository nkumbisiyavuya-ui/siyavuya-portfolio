package com.example.data.location

import com.example.data.ai.CanvasMateContext
import com.example.data.local.TimetableSlot

data class NearbyPlace(
    val name: String,
    val category: String,
    val distanceKm: Double,
    val openingStatus: String,
    val rating: Double,
    val address: String,
    val studyFriendly: Boolean = true,
    val features: List<String> = emptyList()
)

data class CampusBuilding(
    val id: String,
    val name: String,
    val code: String,
    val description: String,
    val campusArea: String,
    val openingHours: String,
    val isAccessible: Boolean = true
)

/**
 * LocationService handles campus building searches, place searches,
 * and location permission checks (integrated as an optional feature as per requirement 45).
 */
class LocationService(
    var isPermissionGranted: Boolean = true,
    var manualLocationOverride: String? = null,
    val defaultCampusLocation: String = "Central Campus Quad"
) {

    /**
     * Checks if location usage is authorized or manually overridden.
     */
    fun canUseLocation(): Boolean = isPermissionGranted || !manualLocationOverride.isNullOrBlank()

    /**
     * Retrieves active location area name respecting permissions and optional overrides.
     */
    fun getActiveLocationName(context: CanvasMateContext? = null): String {
        return manualLocationOverride
            ?: if (isPermissionGranted) {
                context?.userLocationArea ?: defaultCampusLocation
            } else {
                defaultCampusLocation // Graceful fallback when permission is disabled
            }
    }

    /**
     * Performs place search (cafes, libraries, pharmacies, transit stops, study hubs).
     * Permission checks integrated as an optional feature: if requirePermission is true
     * and permission is denied, returns an explicit empty list or permission error indication;
     * otherwise falls back to default campus location.
     */
    fun searchPlaces(
        query: String,
        locationArea: String? = null,
        requirePermission: Boolean = false
    ): List<NearbyPlace> {
        if (requirePermission && !canUseLocation()) {
            return emptyList()
        }

        val effectiveLocation = locationArea
            ?: getActiveLocationName()

        return PlacesService.searchNearbyPlaces(query, effectiveLocation)
    }

    /**
     * Searches campus buildings and faculty venues by query string.
     */
    fun searchCampusBuildings(query: String): List<CampusBuilding> {
        val lower = query.lowercase().trim()
        val allBuildings = getSampleCampusBuildings()
        if (lower.isBlank()) return allBuildings

        return allBuildings.filter { b ->
            b.name.lowercase().contains(lower) ||
            b.code.lowercase().contains(lower) ||
            b.campusArea.lowercase().contains(lower) ||
            b.description.lowercase().contains(lower)
        }
    }

    /**
     * Finds direction and navigation details for a timetable lecture slot.
     */
    fun locateVenueForSlot(slot: TimetableSlot): String {
        return CampusService.locateVenueForSlot(slot)
    }

    private fun getSampleCampusBuildings(): List<CampusBuilding> {
        return listOf(
            CampusBuilding(
                id = "b1",
                name = "Jagger Library & Knowledge Commons",
                code = "JAGGER",
                description = "Main research library, 24-hour study center, computer labs, printing hub",
                campusArea = "Upper Campus",
                openingHours = "24/7 during semester"
            ),
            CampusBuilding(
                id = "b2",
                name = "Menzies Engineering Building",
                code = "MENZIES",
                description = "Faculty of Engineering & Built Environment lectures and design labs",
                campusArea = "Upper Campus North",
                openingHours = "07:30 - 20:00"
            ),
            CampusBuilding(
                id = "b3",
                name = "Steve Biko Student Union Building",
                code = "BIKO",
                description = "Student governance, campus health clinic, pharmacy, food court, ATMs",
                campusArea = "Central Campus",
                openingHours = "07:00 - 18:00"
            ),
            CampusBuilding(
                id = "b4",
                name = "Leslie Social Sciences Building",
                code = "LESLIE",
                description = "Humanities lecture theatres, computer labs, cafeteria, economics library",
                campusArea = "Upper Campus South",
                openingHours = "07:30 - 21:00"
            ),
            CampusBuilding(
                id = "b5",
                name = "Computer Science Building",
                code = "CS",
                description = "Department of Computer Science labs, lecture halls, and staff offices",
                campusArea = "Upper Campus East",
                openingHours = "07:00 - 22:00"
            )
        )
    }

    companion object {
        private val defaultInstance = LocationService()

        var isPermissionGranted: Boolean
            get() = defaultInstance.isPermissionGranted
            set(value) { defaultInstance.isPermissionGranted = value }

        var manualLocationOverride: String?
            get() = defaultInstance.manualLocationOverride
            set(value) { defaultInstance.manualLocationOverride = value }

        fun getActiveLocationName(context: CanvasMateContext): String =
            defaultInstance.getActiveLocationName(context)

        fun canUseLocation(): Boolean = defaultInstance.canUseLocation()

        fun searchPlaces(query: String, locationArea: String? = null, requirePermission: Boolean = false): List<NearbyPlace> =
            defaultInstance.searchPlaces(query, locationArea, requirePermission)

        fun searchCampusBuildings(query: String): List<CampusBuilding> =
            defaultInstance.searchCampusBuildings(query)

        fun locateVenueForSlot(slot: TimetableSlot): String =
            defaultInstance.locateVenueForSlot(slot)

        fun getInstance(): LocationService = defaultInstance
    }
}

object PlacesService {

    fun searchNearbyPlaces(query: String, locationArea: String): List<NearbyPlace> {
        val lower = query.lowercase()

        return when {
            lower.contains("library") || lower.contains("study") -> listOf(
                NearbyPlace(
                    name = "Central Campus Library",
                    category = "Library & Study Hub",
                    distanceKm = 0.8,
                    openingStatus = "Open until 22:00",
                    rating = 4.8,
                    address = "University Central Quad",
                    studyFriendly = true,
                    features = listOf("Silent Zones", "Wi-Fi", "Computer Labs", "Power Outlets")
                ),
                NearbyPlace(
                    name = "Jagger Knowledge Commons",
                    category = "24-Hour Study Center",
                    distanceKm = 1.1,
                    openingStatus = "Open 24 Hours",
                    rating = 4.7,
                    address = "Upper Campus Commons",
                    studyFriendly = true,
                    features = listOf("Group Study Rooms", "High-Speed Printing", "Vending")
                ),
                NearbyPlace(
                    name = "Engineering & Science Reading Room",
                    category = "Academic Reading Room",
                    distanceKm = 1.4,
                    openingStatus = "Open until 20:00",
                    rating = 4.6,
                    address = "Menzies Building Level 3",
                    studyFriendly = true,
                    features = listOf("Quiet Tables", "Drafting Boards")
                )
            )

            lower.contains("coffee") || lower.contains("cafe") || lower.contains("café") -> listOf(
                NearbyPlace(
                    name = "Faculty Quad Espresso Bar",
                    category = "Coffee & Snack Bar",
                    distanceKm = 0.3,
                    openingStatus = "Open until 16:30",
                    rating = 4.8,
                    address = "Arts Block Quadrangle",
                    studyFriendly = true,
                    features = listOf("Artisan Coffee", "Outdoor Seating", "Power Outlets")
                ),
                NearbyPlace(
                    name = "Student Union Plaza Café",
                    category = "Café & Bakery",
                    distanceKm = 0.6,
                    openingStatus = "Open until 18:00",
                    rating = 4.4,
                    address = "Student Union Building",
                    studyFriendly = true,
                    features = listOf("Fresh Wraps", "Juices", "Wi-Fi")
                )
            )

            lower.contains("pharmacy") || lower.contains("health") || lower.contains("doctor") -> listOf(
                NearbyPlace(
                    name = "Student Health Campus Pharmacy",
                    category = "Campus Pharmacy",
                    distanceKm = 0.4,
                    openingStatus = "Open until 17:00",
                    rating = 4.6,
                    address = "Steve Biko Building Level 2",
                    studyFriendly = false,
                    features = listOf("Prescriptions", "First Aid", "Student Medical Aid Support")
                ),
                NearbyPlace(
                    name = "Dis-Chem Pharmacies",
                    category = "Retail Pharmacy",
                    distanceKm = 1.5,
                    openingStatus = "Open until 19:00",
                    rating = 4.5,
                    address = "Main Road, Rondebosch",
                    studyFriendly = false,
                    features = listOf("Full Clinic", "Supplements", "Toiletries")
                )
            )

            lower.contains("shuttle") || lower.contains("bus") -> listOf(
                NearbyPlace(
                    name = "North Stop Campus Shuttle Terminal",
                    category = "Transit Stop",
                    distanceKm = 0.2,
                    openingStatus = "Active (Shuttles every 10 mins)",
                    rating = 4.9,
                    address = "North Loop Road",
                    studyFriendly = false,
                    features = listOf("Live GPS Tracking", "Covered Waiting Shelter")
                ),
                NearbyPlace(
                    name = "South Residence Shuttle Hub",
                    category = "Transit Hub",
                    distanceKm = 0.7,
                    openingStatus = "Active (Shuttles every 15 mins)",
                    rating = 4.5,
                    address = "South Residence Quad",
                    studyFriendly = false,
                    features = listOf("Night Route Services", "Security Station")
                )
            )

            else -> listOf(
                NearbyPlace(
                    name = "Campus Student Centre & Food Court",
                    category = "Student Amenities",
                    distanceKm = 0.5,
                    openingStatus = "Open until 18:00",
                    rating = 4.6,
                    address = "Central Plaza",
                    studyFriendly = true,
                    features = listOf("ATMs", "Print Shop", "Grocery Outlet", "Food Vendors")
                )
            )
        }
    }
}

object CampusService {

    fun locateVenueForSlot(slot: TimetableSlot): String {
        return """
📌 **Venue Navigation Guide**:
• **Module**: ${slot.module}
• **Venue**: 📍 ${slot.venue}
• **Scheduled Time**: ${slot.startTime} - ${slot.endTime} (${slot.dayOfWeek})
• **Walking Distance**: ~5-8 minutes from central campus quad.
• **Directions**: Take the main stairs opposite the Student Centre, enter North Wing Level 2.
        """.trimIndent()
    }
}

