package com.example.data.repository

import com.example.data.local.Course
import com.example.data.local.CourseDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CourseRepositoryImpl @Inject constructor(
    private val courseDao: CourseDao
) : CourseRepository {

    override val allCourses: Flow<List<Course>> = courseDao.getAllCourses()

    override fun getCourseById(id: Long): Flow<Course?> = courseDao.getCourseById(id)

    override fun getCourseByCode(courseCode: String): Flow<Course?> =
        courseDao.getCourseByCode(courseCode)

    override fun getCoursesByAcademicPeriod(academicPeriod: String): Flow<List<Course>> =
        courseDao.getCoursesByAcademicPeriod(academicPeriod)

    override suspend fun insertCourse(course: Course): Long = withContext(Dispatchers.IO) {
        courseDao.insertCourse(course)
    }

    override suspend fun insertCourses(courses: List<Course>): List<Long> = withContext(Dispatchers.IO) {
        courseDao.insertCourses(courses)
    }

    override suspend fun updateCourse(course: Course) = withContext(Dispatchers.IO) {
        courseDao.updateCourse(course)
    }

    override suspend fun deleteCourse(course: Course) = withContext(Dispatchers.IO) {
        courseDao.deleteCourse(course)
    }

    override suspend fun deleteCourseById(id: Long) = withContext(Dispatchers.IO) {
        courseDao.deleteCourseById(id)
    }
}
