package com.example.data.ai.orchestrator

import com.example.data.ai.CanvasMateContext
import com.example.data.tools.WebSearchResult
import java.util.UUID

/**
 * Metadata for attached or uploaded files in the execution context.
 */
data class AttachedFileContext(
    val name: String,
    val mimeType: String,
    val contentSnippet: String,
    val uri: String? = null,
    val sizeBytes: Long = 0L
)

/**
 * Execution status tracking phases of the orchestrator.
 */
enum class ChumaExecutionStatus {
    INITIALIZING,
    ANALYZING_INTENT,
    SELECTING_CAPABILITIES,
    EXECUTING_TOOLS,
    SEARCHING_WEB,
    CALLING_GEMINI,
    VERIFYING_OUTPUT,
    COMPLETED,
    CANCELLED,
    FAILED
}

/**
 * Contextual state provided to and maintained by the Chuma AI Orchestrator during execution.
 */
data class ChumaExecutionContext(
    val userRequest: String,
    val conversationId: String = UUID.randomUUID().toString(),
    val conversationHistory: List<Pair<String, String>> = emptyList(),
    val canvasContext: CanvasMateContext? = null,
    val attachedFiles: List<AttachedFileContext> = emptyList(),
    val memoryContext: String? = null,
    val availableCapabilities: Set<ChumaCapability> = emptySet(),
    val searchResults: List<WebSearchResult> = emptyList(),
    var executionStatus: ChumaExecutionStatus = ChumaExecutionStatus.INITIALIZING,
    val isCancelled: () -> Boolean = { false },
    val onChunk: ((String) -> Unit)? = null
)
