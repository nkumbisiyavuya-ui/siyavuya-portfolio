package com.example.data.repository

import com.example.data.local.Task
import com.example.data.local.TaskDao
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskRepositoryImpl @Inject constructor(
    private val taskDao: TaskDao,
    private val firestore: FirebaseFirestore
) : TaskRepository {

    override val allTasks: Flow<List<Task>> = taskDao.getAllTasks()

    override val firestoreTasks: Flow<List<Task>> = callbackFlow {
        val listener = firestore.collection("tasks")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val tasks = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        Task(
                            id = doc.getLong("id") ?: (doc.id.hashCode().toLong().let { if (it < 0) -it else it }),
                            title = doc.getString("title") ?: "",
                            courseCode = doc.getString("courseCode") ?: "",
                            academicPeriod = doc.getString("academicPeriod") ?: "Semester 1",
                            description = doc.getString("description") ?: "",
                            dueDate = doc.getString("dueDate") ?: "",
                            dueTime = doc.getString("dueTime") ?: "23:59",
                            priority = doc.getString("priority") ?: "Medium",
                            weightPercentage = doc.getDouble("weightPercentage") ?: 10.0,
                            status = doc.getString("status") ?: "Pending",
                            isCompleted = doc.getBoolean("isCompleted") ?: false
                        )
                    } catch (e: Exception) {
                        null
                    }
                } ?: emptyList()
                trySend(tasks)
            }
        awaitClose { listener.remove() }
    }

    override fun getTaskById(id: Long): Flow<Task?> = taskDao.getTaskById(id)

    override fun getTasksByCourseCode(courseCode: String): Flow<List<Task>> =
        taskDao.getTasksByCourseCode(courseCode)

    override fun getTasksByAcademicPeriod(academicPeriod: String): Flow<List<Task>> =
        taskDao.getTasksByAcademicPeriod(academicPeriod)

    override suspend fun insertTask(task: Task): Long = withContext(Dispatchers.IO) {
        val insertedId = taskDao.insertTask(task)
        val taskWithId = if (task.id == 0L) task.copy(id = insertedId) else task
        saveTaskToFirestore(taskWithId)
        insertedId
    }

    override suspend fun insertTasks(tasks: List<Task>): List<Long> = withContext(Dispatchers.IO) {
        val ids = taskDao.insertTasks(tasks)
        tasks.forEachIndexed { index, task ->
            val id = ids.getOrNull(index) ?: task.id
            saveTaskToFirestore(task.copy(id = id))
        }
        ids
    }

    override suspend fun updateTask(task: Task) = withContext(Dispatchers.IO) {
        taskDao.updateTask(task)
        saveTaskToFirestore(task)
        Unit
    }

    override suspend fun deleteTask(task: Task) = withContext(Dispatchers.IO) {
        taskDao.deleteTask(task)
        deleteTaskFromFirestore(task.id.toString())
        Unit
    }

    override suspend fun deleteTaskById(id: Long) = withContext(Dispatchers.IO) {
        taskDao.deleteTaskById(id)
        deleteTaskFromFirestore(id.toString())
        Unit
    }

    override suspend fun saveTaskToFirestore(task: Task): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val docId = task.id.toString()
            val taskMap = hashMapOf(
                "id" to task.id,
                "title" to task.title,
                "courseCode" to task.courseCode,
                "academicPeriod" to task.academicPeriod,
                "description" to task.description,
                "dueDate" to task.dueDate,
                "dueTime" to task.dueTime,
                "priority" to task.priority,
                "weightPercentage" to task.weightPercentage,
                "status" to task.status,
                "isCompleted" to task.isCompleted,
                "updatedAt" to System.currentTimeMillis()
            )
            firestore.collection("tasks").document(docId).set(taskMap).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteTaskFromFirestore(taskId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            firestore.collection("tasks").document(taskId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncTasksWithFirestore(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val snapshot = firestore.collection("tasks").get().await()
            val remoteTasks = snapshot.documents.mapNotNull { doc ->
                try {
                    Task(
                        id = doc.getLong("id") ?: (doc.id.hashCode().toLong().let { if (it < 0) -it else it }),
                        title = doc.getString("title") ?: "",
                        courseCode = doc.getString("courseCode") ?: "",
                        academicPeriod = doc.getString("academicPeriod") ?: "Semester 1",
                        description = doc.getString("description") ?: "",
                        dueDate = doc.getString("dueDate") ?: "",
                        dueTime = doc.getString("dueTime") ?: "23:59",
                        priority = doc.getString("priority") ?: "Medium",
                        weightPercentage = doc.getDouble("weightPercentage") ?: 10.0,
                        status = doc.getString("status") ?: "Pending",
                        isCompleted = doc.getBoolean("isCompleted") ?: false
                    )
                } catch (e: Exception) {
                    null
                }
            }
            if (remoteTasks.isNotEmpty()) {
                taskDao.insertTasks(remoteTasks)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
