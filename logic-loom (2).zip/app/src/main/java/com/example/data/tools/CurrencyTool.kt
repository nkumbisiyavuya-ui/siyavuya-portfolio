package com.example.data.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * CurrencyTool provides real-time financial currency conversion and exchange rate lookups.
 */
object CurrencyTool {

    data class ExchangeRateResult(
        val success: Boolean,
        val baseCurrency: String,
        val targetCurrency: String,
        val rate: Double,
        val originalAmount: Double,
        val convertedAmount: Double,
        val formattedSummary: String,
        val timestamp: String,
        val isLive: Boolean = true
    )

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val numberFormat = DecimalFormat("#,##0.00")

    /**
     * Converts an amount from base currency to target currency.
     */
    suspend fun convertCurrency(
        amount: Double,
        baseCurrency: String = "ZAR",
        targetCurrency: String = "USD"
    ): ExchangeRateResult = withContext(Dispatchers.IO) {
        val base = baseCurrency.uppercase().trim().ifBlank { "ZAR" }
        val target = targetCurrency.uppercase().trim().ifBlank { "USD" }
        val timeStr = SimpleDateFormat("HH:mm, d MMMM yyyy", Locale.getDefault()).format(Date())

        try {
            val url = "https://open.er-api.com/v6/latest/$base"
            val request = Request.Builder().url(url).get().build()
            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful && body.isNotBlank()) {
                val json = JSONObject(body)
                val rates = json.optJSONObject("rates")
                if (rates != null && rates.has(target)) {
                    val rate = rates.getDouble(target)
                    val converted = amount * rate
                    val lastUpdate = json.optString("time_last_update_utc", timeStr)

                    val summary = """
                        💱 **Currency Conversion**:
                        • **Original Amount**: $base ${numberFormat.format(amount)}
                        • **Exchange Rate**: 1 $base = ${"%.4f".format(rate)} $target
                        • **Converted Total**: **$target ${numberFormat.format(converted)}**
                        • **Data Source**: Real-time Exchange Rate API (Updated: $lastUpdate)
                    """.trimIndent()

                    return@withContext ExchangeRateResult(
                        success = true,
                        baseCurrency = base,
                        targetCurrency = target,
                        rate = rate,
                        originalAmount = amount,
                        convertedAmount = converted,
                        formattedSummary = summary,
                        timestamp = lastUpdate,
                        isLive = true
                    )
                }
            }
        } catch (e: Exception) {
            // Handled below
        }

        // Graceful fallback message when API is unreachable
        val fallbackSummary = "I couldn't retrieve a current live exchange rate right now. Please check your internet connection and try again."
        ExchangeRateResult(
            success = false,
            baseCurrency = base,
            targetCurrency = target,
            rate = 0.0,
            originalAmount = amount,
            convertedAmount = 0.0,
            formattedSummary = fallbackSummary,
            timestamp = timeStr,
            isLive = false
        )
    }

    /**
     * Parses currency conversion queries such as "How much is R1000 in US dollars today?".
     */
    suspend fun parseAndConvert(prompt: String): ExchangeRateResult {
        val lower = prompt.lowercase()
        var amount = 1000.0

        val amountRegex = Regex("(?i)(?:r|zar|\\$|usd|eur|gbp)?\\s*(\\d+(?:[.,]\\d+)?)")
        val match = amountRegex.find(prompt)
        if (match != null) {
            amount = match.groupValues[1].replace(",", "").toDoubleOrNull() ?: 1000.0
        }

        var base = "ZAR"
        var target = "USD"

        if (lower.contains("usd") || lower.contains("dollar") || lower.contains("us dollar") || lower.contains("dollars")) {
            if (lower.contains("in zar") || lower.contains("in rands") || lower.contains("in r") || lower.contains("to zar") || lower.contains("to rands")) {
                base = "USD"
                target = "ZAR"
            } else {
                base = "ZAR"
                target = "USD"
            }
        } else if (lower.contains("eur") || lower.contains("euro") || lower.contains("euros")) {
            if (lower.contains("in zar") || lower.contains("to zar")) {
                base = "EUR"
                target = "ZAR"
            } else {
                base = "ZAR"
                target = "EUR"
            }
        } else if (lower.contains("gbp") || lower.contains("pound") || lower.contains("pounds")) {
            if (lower.contains("in zar") || lower.contains("to zar")) {
                base = "GBP"
                target = "ZAR"
            } else {
                base = "ZAR"
                target = "GBP"
            }
        }

        return convertCurrency(amount, base, target)
    }
}
