package com.example.data.ai

import java.util.UUID

/**
 * Identifies the sender of a chat message.
 */
enum class MessageSender {
    USER,
    CHUMA,
    SYSTEM
}

/**
 * Data model for a Chuma v1 chat message.
 */
data class ChumaChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false,
    val rawCardTag: String? = null
)
