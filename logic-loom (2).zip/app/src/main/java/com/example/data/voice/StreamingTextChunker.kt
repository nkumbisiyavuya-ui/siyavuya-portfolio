package com.example.data.voice

/**
 * High-performance streaming text chunker for conversational neural TTS.
 *
 * Buffers incoming token deltas from Chuma AI and emits discrete, naturally-paced
 * sentence or phrase chunks as soon as natural boundaries are detected.
 *
 * This allows speech synthesis to commence within hundreds of milliseconds of
 * response generation rather than waiting for multi-paragraph completion.
 */
class StreamingTextChunker(
    private val minChunkLength: Int = 18,
    private val maxChunkLength: Int = 180
) {
    private val buffer = StringBuilder()

    /**
     * Appends a new token delta from the AI response stream and returns any
     * complete sentence chunks ready for immediate TTS synthesis.
     */
    @Synchronized
    fun processToken(token: String): List<String> {
        buffer.append(token)
        val readyChunks = mutableListOf<String>()

        while (true) {
            val text = buffer.toString()
            val boundaryIndex = findNextBoundary(text)
            if (boundaryIndex != -1) {
                val rawChunk = text.substring(0, boundaryIndex).trim()
                buffer.delete(0, boundaryIndex)

                val cleaned = cleanForSpeech(rawChunk)
                if (cleaned.isNotBlank()) {
                    readyChunks.add(cleaned)
                }
            } else {
                break
            }
        }

        return readyChunks
    }

    /**
     * Flushes any remaining text in the buffer when the AI response finishes.
     */
    @Synchronized
    fun flush(): String? {
        val remaining = buffer.toString().trim()
        buffer.setLength(0)
        val cleaned = cleanForSpeech(remaining)
        return if (cleaned.isNotBlank()) cleaned else null
    }

    @Synchronized
    fun reset() {
        buffer.setLength(0)
    }

    /**
     * Finds the index of the next natural sentence or clause boundary.
     */
    private fun findNextBoundary(text: String): Int {
        if (text.length < minChunkLength) return -1

        // 1. Double newline (paragraph break)
        val paragraphIndex = text.indexOf("\n\n")
        if (paragraphIndex != -1 && paragraphIndex >= minChunkLength) {
            return paragraphIndex + 2
        }

        // 2. Sentence-ending punctuation followed by whitespace or end
        val sentenceRegex = Regex("""[.!?](\s+|\n|$)""")
        val match = sentenceRegex.find(text)
        if (match != null) {
            val endIdx = match.range.last + 1
            if (endIdx >= minChunkLength) {
                // Ensure it's not a common abbreviation (e.g. "e.g.", "i.e.", "Mr.", "Dr.")
                val candidate = text.substring(0, endIdx).trim()
                if (!isAbbreviation(candidate)) {
                    return endIdx
                }
            }
        }

        // 3. For long buffered clauses exceeding threshold, split on comma, colon, semicolon, or dash
        if (text.length >= maxChunkLength) {
            val clauseRegex = Regex("""[,:;—-](\s+)""")
            val clauseMatch = clauseRegex.find(text, startIndex = minChunkLength)
            if (clauseMatch != null) {
                return clauseMatch.range.last + 1
            }
        }

        return -1
    }

    private fun isAbbreviation(candidate: String): Boolean {
        val lower = candidate.lowercase()
        return lower.endsWith("e.g.") || lower.endsWith("i.e.") ||
                lower.endsWith("dr.") || lower.endsWith("mr.") ||
                lower.endsWith("ms.") || lower.endsWith("vs.") ||
                lower.endsWith("etc.")
    }

    companion object {
        /**
         * Cleans markdown, formatting artifacts, and code blocks for natural audio rendering.
         */
        fun cleanForSpeech(input: String): String {
            return input
                .replace(Regex("""\*\*(.*?)\*\*"""), "$1")
                .replace(Regex("""\*(.*?)\*"""), "$1")
                .replace(Regex("""`{1,3}.*?`{1,3}"""), "code snippet")
                .replace(Regex("""#+\s*"""), "")
                .replace(Regex("""[-*•]\s+"""), ", ")
                .replace(Regex("""\[(.*?)\]\(.*?\)"""), "$1")
                .replace(Regex("""https?://\S+"""), "link")
                .replace(Regex("""[~_]"""), "")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }

        /**
         * Chunks an already complete multi-sentence text into conversational chunks.
         */
        fun chunkCompleteText(text: String): List<String> {
            val chunker = StreamingTextChunker()
            val chunks = mutableListOf<String>()
            val processed = chunker.processToken(text)
            chunks.addAll(processed)
            val tail = chunker.flush()
            if (tail != null) {
                chunks.add(tail)
            }
            return if (chunks.isEmpty() && text.isNotBlank()) listOf(cleanForSpeech(text)) else chunks
        }
    }
}
