package com.example.data.ai.orchestrator

/**
 * Result returned by the Chuma AI Orchestrator upon completing request processing.
 */
data class ChumaOrchestratorResult(
    val output: String,
    val taskType: ChumaTaskType,
    val confidence: ChumaConfidence,
    val capabilitiesUsed: Set<ChumaCapability> = emptySet(),
    val sources: List<String> = emptyList(),
    val isVerified: Boolean = true,
    val verificationNotes: String? = null,
    val durationMs: Long = 0L,
    val isError: Boolean = false,
    val errorMessage: String? = null
)
