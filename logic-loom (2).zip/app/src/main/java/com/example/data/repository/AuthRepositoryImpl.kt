package com.example.data.repository

import android.util.Log
import com.example.data.local.CanvasMateDao
import com.example.data.local.UserAccount
import com.example.data.local.UserAccountDao
import com.example.data.local.UserProfile
import com.example.security.AuthState
import com.example.security.InputSanitizer
import com.example.security.SecureSessionManager
import com.example.security.UserSession
import com.example.security.ValidationResult
import com.example.util.AuthUtils
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val userAccountDao: UserAccountDao,
    private val canvasMateDao: CanvasMateDao,
    private val sessionManager: SecureSessionManager
) : AuthRepository {

    private val _authState = MutableStateFlow<AuthState>(AuthState.INITIALIZING)
    override val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _currentSession = MutableStateFlow<UserSession?>(null)
    override val currentSession: StateFlow<UserSession?> = _currentSession.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    override val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private var authStateListener: FirebaseAuth.AuthStateListener? = null

    private fun getFirebaseAuthSafe(): FirebaseAuth? {
        return try {
            FirebaseAuth.getInstance()
        } catch (e: Throwable) {
            Log.w("AuthRepositoryImpl", "FirebaseAuth.getInstance() unavailable: ${e.message}")
            null
        }
    }

    init {
        setupAuthStateListener()
    }

    private fun setupAuthStateListener() {
        val auth = getFirebaseAuthSafe()
        if (auth != null) {
            val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
                val firebaseUser = firebaseAuth.currentUser
                Log.d("AuthRepositoryImpl", "AuthStateListener triggered: currentUser=${firebaseUser?.uid} email=${firebaseUser?.email}")
                if (firebaseUser != null) {
                    restoreFirebaseSession(firebaseUser)
                } else {
                    handleUnauthenticated()
                }
            }
            authStateListener = listener
            try {
                auth.addAuthStateListener(listener)
            } catch (e: Throwable) {
                Log.w("AuthRepositoryImpl", "Could not attach AuthStateListener: ${e.message}")
                val currentUser = auth.currentUser
                if (currentUser != null) {
                    restoreFirebaseSession(currentUser)
                } else {
                    handleUnauthenticated()
                }
            }
        } else {
            Log.w("AuthRepositoryImpl", "FirebaseAuth instance unavailable during setupAuthStateListener")
            handleUnauthenticated()
        }
    }

    private fun restoreFirebaseSession(firebaseUser: FirebaseUser) {
        try {
            val savedSession = sessionManager.getCurrentSession()

            val resolvedName = firebaseUser.displayName
                ?: savedSession?.fullName
                ?: firebaseUser.email?.substringBefore("@")?.replace(".", " ")?.replaceFirstChar { it.uppercase() }
                ?: ""

            val resolvedStudentNum = savedSession?.studentNumber ?: ""
            val resolvedUni = savedSession?.university ?: ""
            val isGoogle = firebaseUser.providerData.any { it.providerId.contains("google") }

            val session = UserSession(
                userId = firebaseUser.uid,
                email = firebaseUser.email.orEmpty(),
                fullName = resolvedName,
                studentNumber = resolvedStudentNum,
                university = resolvedUni,
                authProvider = if (isGoogle) "GOOGLE" else "EMAIL_PASSWORD",
                isEmailVerified = firebaseUser.isEmailVerified,
                idToken = null,
                loginTimestamp = savedSession?.loginTimestamp ?: System.currentTimeMillis()
            )

            sessionManager.saveSession(session)
            _currentSession.value = session
            _isLoggedIn.value = true
            _authState.value = AuthState.AUTHENTICATED
            Log.i("AuthRepositoryImpl", "Authenticated Firebase session resolved for ${firebaseUser.email}")
        } catch (e: Throwable) {
            Log.e("AuthRepositoryImpl", "Error restoring Firebase session: ${e.message}", e)
            _authState.value = AuthState.UNAUTHENTICATED
        }
    }

    private fun handleUnauthenticated() {
        val savedSession = sessionManager.getCurrentSession()
        if (savedSession != null && savedSession.userId.isNotEmpty() && !savedSession.userId.startsWith("usr_default")) {
            _currentSession.value = savedSession
            _isLoggedIn.value = true
            _authState.value = AuthState.AUTHENTICATED
            Log.i("AuthRepositoryImpl", "Restored local session for ${savedSession.email}")
        } else {
            _currentSession.value = null
            _isLoggedIn.value = false
            _authState.value = AuthState.UNAUTHENTICATED
            Log.i("AuthRepositoryImpl", "Unauthenticated state resolved: No active user session.")
        }
    }

    override suspend fun registerUser(
        fullName: String,
        email: String,
        studentNumber: String,
        university: String,
        password: String
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanName = InputSanitizer.sanitizeText(fullName)
        val cleanStudentNum = InputSanitizer.sanitizeText(studentNumber)
        val cleanUni = InputSanitizer.sanitizeText(university)

        when (val nameVal = InputSanitizer.validateName(cleanName)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(nameVal.message)
            else -> {}
        }
        when (val emailVal = InputSanitizer.validateEmail(cleanEmail)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(emailVal.message)
            else -> {}
        }
        when (val studentVal = InputSanitizer.validateStudentNumber(cleanStudentNum)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(studentVal.message)
            else -> {}
        }
        when (val passVal = InputSanitizer.validatePassword(password)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(passVal.message)
            else -> {}
        }

        val auth = getFirebaseAuthSafe()
            ?: return@withContext AuthResult.Error("Authentication service is currently unavailable. Please verify Firebase configuration.")

        try {
            val authResult = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
            val user = authResult.user
                ?: return@withContext AuthResult.Error("Registration succeeded but no Firebase user was returned.")

            // Update Firebase User Profile display name
            try {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(cleanName)
                    .build()
                user.updateProfile(profileUpdates).await()
            } catch (e: Exception) {
                Log.w("AuthRepositoryImpl", "Failed to update Firebase profile display name: ${e.message}")
            }

            // Save student profile metadata in Room (passwords are NOT stored locally)
            canvasMateDao.insertOrUpdateUserProfile(
                UserProfile(
                    id = 1,
                    fullName = cleanName,
                    studentNumber = cleanStudentNum,
                    university = cleanUni,
                    email = cleanEmail,
                    isLoggedIn = true
                )
            )

            // Save non-sensitive account record in Room for offline identification
            userAccountDao.insertUserAccount(
                UserAccount(
                    email = cleanEmail,
                    userId = user.uid,
                    fullName = cleanName,
                    studentNumber = cleanStudentNum,
                    university = cleanUni,
                    passwordHash = "",
                    salt = "",
                    authProvider = "EMAIL_PASSWORD",
                    isEmailVerified = user.isEmailVerified
                )
            )

            val session = UserSession(
                userId = user.uid,
                email = cleanEmail,
                fullName = cleanName,
                studentNumber = cleanStudentNum,
                university = cleanUni,
                authProvider = "EMAIL_PASSWORD",
                isEmailVerified = user.isEmailVerified,
                idToken = null,
                loginTimestamp = System.currentTimeMillis()
            )

            sessionManager.saveSession(session)
            _currentSession.value = session
            _isLoggedIn.value = true

            AuthResult.Success(session, "Account registered successfully!")
        } catch (e: FirebaseAuthUserCollisionException) {
            Log.w("AuthRepositoryImpl", "Account collision during registration for $cleanEmail: ${e.message}")
            AuthResult.Error("An account with this email address already exists. Please login instead.")
        } catch (e: FirebaseAuthWeakPasswordException) {
            Log.w("AuthRepositoryImpl", "Weak password during registration: ${e.message}")
            AuthResult.Error("The password is too weak. Please use at least 8 characters with numbers and letters.")
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            if (AuthUtils.isApiKeyError(e)) {
                Log.e("AuthRepositoryImpl", "API key invalid during registration: ${e.message}", e)
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Registration"))
            } else {
                Log.w("AuthRepositoryImpl", "Invalid credentials during registration: ${e.message}")
                AuthResult.Error("The email address is invalid. Please check your email.")
            }
        } catch (e: FirebaseAuthException) {
            val errorCode = e.errorCode
            Log.e("AuthRepositoryImpl", "FirebaseAuthException [$errorCode] during registration: ${e.message}", e)
            if (AuthUtils.isApiKeyError(e)) {
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Registration"))
            } else {
                val errorMsg = when (errorCode) {
                    "ERROR_EMAIL_ALREADY_IN_USE", "EMAIL_ALREADY_IN_USE" ->
                        "An account with this email address already exists. Please login instead."
                    "ERROR_WEAK_PASSWORD", "WEAK_PASSWORD" ->
                        "The password is too weak. Please choose a stronger password."
                    "ERROR_INVALID_EMAIL", "INVALID_EMAIL" ->
                        "The email address is invalid. Please enter a valid email."
                    "ERROR_OPERATION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED" ->
                        "Email/Password registration is currently disabled in Firebase Console."
                    else -> AuthUtils.resolveAuthErrorMessage(e, "Registration")
                }
                AuthResult.Error(errorMsg)
            }
        } catch (e: FirebaseNetworkException) {
            Log.e("AuthRepositoryImpl", "Network exception during registration: ${e.message}", e)
            AuthResult.Error("Network error: Unable to connect to Firebase servers. Please check your internet connection.")
        } catch (e: Exception) {
            if (AuthUtils.isApiKeyError(e)) {
                Log.e("AuthRepositoryImpl", "API key error caught during registration: ${e.message}", e)
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Registration"))
            } else {
                Log.e("AuthRepositoryImpl", "Unexpected registration exception: ${e.message}", e)
                AuthResult.Error(e.localizedMessage ?: "Failed to register account. Please try again.")
            }
        }
    }

    override suspend fun loginUser(email: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()

        when (val emailVal = InputSanitizer.validateEmail(cleanEmail)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(emailVal.message)
            else -> {}
        }
        if (password.isEmpty()) {
            return@withContext AuthResult.Error("Please enter your password.")
        }

        val auth = getFirebaseAuthSafe()
            ?: return@withContext AuthResult.Error("Authentication service is currently unavailable. Please verify Firebase configuration.")

        try {
            val authResult = auth.signInWithEmailAndPassword(cleanEmail, password).await()
            val user = authResult.user
                ?: return@withContext AuthResult.Error("Login succeeded but no Firebase user was returned.")

            val existingProfile = canvasMateDao.getUserProfileDirect()
            val localAccount = userAccountDao.getUserByEmailDirect(cleanEmail)

            val resolvedName = user.displayName
                ?: existingProfile?.fullName
                ?: localAccount?.fullName
                ?: cleanEmail.substringBefore("@").replace(".", " ").replaceFirstChar { it.uppercase() }

            val resolvedStudentNum = existingProfile?.studentNumber
                ?: localAccount?.studentNumber
                ?: ""

            val resolvedUni = existingProfile?.university
                ?: localAccount?.university
                ?: ""

            // Update Room UserProfile
            canvasMateDao.insertOrUpdateUserProfile(
                UserProfile(
                    id = 1,
                    fullName = resolvedName,
                    studentNumber = resolvedStudentNum,
                    university = resolvedUni,
                    email = cleanEmail,
                    isLoggedIn = true
                )
            )

            val session = UserSession(
                userId = user.uid,
                email = cleanEmail,
                fullName = resolvedName,
                studentNumber = resolvedStudentNum,
                university = resolvedUni,
                authProvider = "EMAIL_PASSWORD",
                isEmailVerified = user.isEmailVerified,
                idToken = null,
                loginTimestamp = System.currentTimeMillis()
            )

            sessionManager.saveSession(session)
            _currentSession.value = session
            _isLoggedIn.value = true

            AuthResult.Success(session, "Logged in successfully!")
        } catch (e: FirebaseAuthInvalidUserException) {
            Log.w("AuthRepositoryImpl", "Invalid user during login for $cleanEmail: ${e.message}")
            AuthResult.Error("No account found with this email address. Please check your email or register.")
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            if (AuthUtils.isApiKeyError(e)) {
                Log.e("AuthRepositoryImpl", "API key invalid during login: ${e.message}", e)
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Login"))
            } else {
                Log.w("AuthRepositoryImpl", "Invalid credentials during login for $cleanEmail: ${e.message}")
                AuthResult.Error("Invalid email or password. Please check your credentials.")
            }
        } catch (e: FirebaseAuthException) {
            val errorCode = e.errorCode
            Log.e("AuthRepositoryImpl", "FirebaseAuthException [$errorCode] during login: ${e.message}", e)
            if (AuthUtils.isApiKeyError(e)) {
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Login"))
            } else {
                val errorMsg = when (errorCode) {
                    "ERROR_USER_NOT_FOUND", "USER_NOT_FOUND" ->
                        "No account found with this email address. Please check your email or register."
                    "ERROR_WRONG_PASSWORD", "WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "INVALID_LOGIN_CREDENTIALS" ->
                        "Invalid email or password. Please check your credentials."
                    "ERROR_USER_DISABLED", "USER_DISABLED" ->
                        "This account has been disabled. Please contact support."
                    "ERROR_TOO_MANY_REQUESTS", "TOO_MANY_REQUESTS" ->
                        "Too many unsuccessful login attempts. Please try again later or reset your password."
                    "ERROR_INVALID_EMAIL", "INVALID_EMAIL" ->
                        "The email address is invalid."
                    else -> AuthUtils.resolveAuthErrorMessage(e, "Login")
                }
                AuthResult.Error(errorMsg)
            }
        } catch (e: FirebaseNetworkException) {
            Log.e("AuthRepositoryImpl", "Network exception during login: ${e.message}", e)
            AuthResult.Error("Network error: Unable to connect to Firebase servers. Please check your internet connection.")
        } catch (e: Exception) {
            if (AuthUtils.isApiKeyError(e)) {
                Log.e("AuthRepositoryImpl", "API key error caught during login: ${e.message}", e)
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Login"))
            } else {
                Log.e("AuthRepositoryImpl", "Unexpected login exception: ${e.message}", e)
                AuthResult.Error(e.localizedMessage ?: "Failed to log in. Please try again.")
            }
        }
    }

    override suspend fun loginWithGoogle(
        email: String,
        fullName: String,
        googleIdToken: String?
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val cleanName = InputSanitizer.sanitizeText(fullName).ifEmpty {
            cleanEmail.substringBefore("@").replace(".", " ").replaceFirstChar { it.uppercase() }
        }

        when (val emailVal = InputSanitizer.validateEmail(cleanEmail)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(emailVal.message)
            else -> {}
        }

        val auth = getFirebaseAuthSafe()
        val firebaseUser = auth?.currentUser

        val userId = firebaseUser?.uid ?: ("usr_g_" + UUID.randomUUID().toString().take(8))

        var existingUser = userAccountDao.getUserByEmailDirect(cleanEmail)
        if (existingUser == null) {
            val newGoogleAccount = UserAccount(
                email = cleanEmail,
                userId = userId,
                fullName = cleanName,
                studentNumber = "",
                university = "",
                passwordHash = "",
                salt = "",
                authProvider = "GOOGLE",
                isEmailVerified = true
            )
            userAccountDao.insertUserAccount(newGoogleAccount)
            existingUser = newGoogleAccount
        }

        canvasMateDao.insertOrUpdateUserProfile(
            UserProfile(
                id = 1,
                fullName = cleanName,
                studentNumber = existingUser.studentNumber,
                university = existingUser.university,
                email = cleanEmail,
                isLoggedIn = true
            )
        )

        val session = UserSession(
            userId = userId,
            email = cleanEmail,
            fullName = cleanName,
            studentNumber = existingUser.studentNumber,
            university = existingUser.university,
            authProvider = "GOOGLE",
            isEmailVerified = true,
            idToken = googleIdToken ?: "google_oauth_token_${UUID.randomUUID()}",
            loginTimestamp = System.currentTimeMillis()
        )

        sessionManager.saveSession(session)
        _currentSession.value = session
        _isLoggedIn.value = true

        AuthResult.Success(session, "Signed in with Google successfully!")
    }

    override suspend fun sendPasswordReset(email: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()

        when (val emailVal = InputSanitizer.validateEmail(cleanEmail)) {
            is ValidationResult.Error -> {
                Log.w("AuthRepositoryImpl", "Password reset aborted: Invalid email format '$cleanEmail'")
                return@withContext AuthResult.Error(emailVal.message)
            }
            else -> {}
        }

        Log.d("AuthRepositoryImpl", "Initiating Firebase password reset for email: $cleanEmail")

        val auth = getFirebaseAuthSafe()
            ?: return@withContext AuthResult.Error("Authentication service is currently unavailable. Please verify Firebase configuration.")

        try {
            auth.sendPasswordResetEmail(cleanEmail).await()
            Log.i("AuthRepositoryImpl", "Successfully sent password reset email via Firebase to: $cleanEmail")
            AuthResult.Success(
                session = UserSession("", cleanEmail, "", "", "", "", false, null, 0),
                message = "Password reset instructions have been sent to $cleanEmail. Please check your inbox and spam folder."
            )
        } catch (e: FirebaseAuthInvalidUserException) {
            Log.w("AuthRepositoryImpl", "User not found in Firebase during password reset for $cleanEmail: ${e.message}")
            AuthResult.Error("No account found with this email address. Please check your email or register.")
        } catch (e: FirebaseAuthException) {
            val errorCode = e.errorCode
            Log.w("AuthRepositoryImpl", "FirebaseAuthException [$errorCode] in sendPasswordReset: ${e.message}")
            if (AuthUtils.isApiKeyError(e)) {
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Password reset"))
            } else {
                val errorMsg = when (errorCode) {
                    "ERROR_USER_NOT_FOUND", "USER_NOT_FOUND" ->
                        "No account found with this email address. Please check your email or register."
                    "ERROR_INVALID_EMAIL", "INVALID_EMAIL" ->
                        "Invalid email address format. Please enter a valid email."
                    "ERROR_OPERATION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED" ->
                        "Password reset is currently disabled in Firebase Console."
                    else -> AuthUtils.resolveAuthErrorMessage(e, "Password reset")
                }
                AuthResult.Error(errorMsg)
            }
        } catch (e: FirebaseNetworkException) {
            Log.e("AuthRepositoryImpl", "Network exception in sendPasswordReset: ${e.message}", e)
            AuthResult.Error("Network error: Unable to connect to Firebase servers. Please check your internet connection.")
        } catch (e: Exception) {
            if (AuthUtils.isApiKeyError(e)) {
                Log.e("AuthRepositoryImpl", "API key error caught in sendPasswordReset: ${e.message}", e)
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Password reset"))
            } else {
                Log.e("AuthRepositoryImpl", "Unexpected exception in sendPasswordReset: ${e.message}", e)
                AuthResult.Error(e.localizedMessage ?: "Failed to send password reset email. Please try again.")
            }
        }
    }

    override suspend fun resetPasswordWithToken(resetToken: String, newPassword: String): AuthResult = withContext(Dispatchers.IO) {
        when (val passVal = InputSanitizer.validatePassword(newPassword)) {
            is ValidationResult.Error -> return@withContext AuthResult.Error(passVal.message)
            else -> {}
        }

        val user = userAccountDao.getUserByResetTokenDirect(resetToken)
            ?: return@withContext AuthResult.Error("Invalid or expired password reset token.")

        userAccountDao.updateUserAccount(
            user.copy(resetToken = null)
        )

        AuthResult.Success(
            UserSession(user.userId, user.email, user.fullName, user.studentNumber, user.university, user.authProvider, user.isEmailVerified, null, System.currentTimeMillis()),
            "Password has been reset successfully. Please log in with your new password."
        )
    }

    override suspend fun verifyEmail(): AuthResult = withContext(Dispatchers.IO) {
        val auth = getFirebaseAuthSafe()
        val firebaseUser = auth?.currentUser

        if (firebaseUser != null) {
            try {
                firebaseUser.reload().await()
                val isVerified = firebaseUser.isEmailVerified
                sessionManager.setEmailVerified(isVerified)
                val current = _currentSession.value
                if (current != null) {
                    val updated = current.copy(isEmailVerified = isVerified)
                    _currentSession.value = updated
                }
                return@withContext if (isVerified) {
                    AuthResult.Success(_currentSession.value ?: UserSession("", "", "", "", "", "", true, null, 0), "Email address verified successfully!")
                } else {
                    AuthResult.Error("Email address has not been verified yet. Please check your inbox.")
                }
            } catch (e: Exception) {
                Log.w("AuthRepositoryImpl", "Could not reload Firebase user: ${e.message}")
            }
        }

        val session = _currentSession.value
            ?: return@withContext AuthResult.Error("No active user session found.")

        sessionManager.setEmailVerified(true)
        val updatedSession = session.copy(isEmailVerified = true)
        _currentSession.value = updatedSession

        AuthResult.Success(updatedSession, "Email address verified successfully!")
    }

    override suspend fun changePassword(currentPassword: String, newPassword: String): AuthResult = withContext(Dispatchers.IO) {
        val auth = getFirebaseAuthSafe()
        val firebaseUser = auth?.currentUser

        if (firebaseUser != null) {
            when (val newPassVal = InputSanitizer.validatePassword(newPassword)) {
                is ValidationResult.Error -> return@withContext AuthResult.Error(newPassVal.message)
                else -> {}
            }
            return@withContext try {
                firebaseUser.updatePassword(newPassword).await()
                AuthResult.Success(_currentSession.value ?: UserSession("", "", "", "", "", "", false, null, 0), "Password updated successfully!")
            } catch (e: FirebaseAuthException) {
                AuthResult.Error(AuthUtils.resolveAuthErrorMessage(e, "Password change"))
            } catch (e: Exception) {
                AuthResult.Error(e.localizedMessage ?: "Failed to update password.")
            }
        }

        AuthResult.Error("Please log in to change your password.")
    }

    override suspend fun logout() = withContext(Dispatchers.IO) {
        try {
            getFirebaseAuthSafe()?.signOut()
        } catch (e: Throwable) {
            Log.w("AuthRepositoryImpl", "Firebase signOut note: ${e.message}")
        }
        sessionManager.clearSession()
        _currentSession.value = null
        _isLoggedIn.value = false
        _authState.value = AuthState.UNAUTHENTICATED

        canvasMateDao.insertOrUpdateUserProfile(
            UserProfile(id = 1, isLoggedIn = false)
        )
    }
}
