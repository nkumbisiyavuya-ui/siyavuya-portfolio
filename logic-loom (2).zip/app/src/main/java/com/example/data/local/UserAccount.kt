package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_accounts")
data class UserAccount(
    @PrimaryKey val email: String,
    val userId: String,
    val fullName: String,
    val studentNumber: String,
    val university: String,
    val passwordHash: String,
    val salt: String,
    val authProvider: String = "EMAIL_PASSWORD", // "EMAIL_PASSWORD" or "GOOGLE"
    val isEmailVerified: Boolean = false,
    val resetToken: String? = null,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)
