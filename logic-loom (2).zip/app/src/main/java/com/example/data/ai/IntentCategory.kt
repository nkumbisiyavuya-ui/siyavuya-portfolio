package com.example.data.ai

enum class MajorIntentCategory {
    GENERAL,
    TASKS,
    CALENDAR,
    REMINDERS,
    FINANCE,
    DOCUMENTS,
    STUDY,
    PRODUCTIVITY,
    ACCOUNT,
    SYSTEM,
    TIME_DATE,
    WEATHER,
    CALCULATION,
    CURRENCY,
    WEB_SEARCH,
    CAMPUS_PLACES,
    EXTERNAL_SERVICE
}

data class ParsedIntent(
    val category: MajorIntentCategory,
    val subAction: String,
    val isFastPathEligible: Boolean = false,
    val requiresConfirmation: Boolean = false,
    val parameters: Map<String, String> = emptyMap()
)
