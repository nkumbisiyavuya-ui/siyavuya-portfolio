package com.example.data.repository

import com.example.security.AuthState
import com.example.security.UserSession
import kotlinx.coroutines.flow.StateFlow

sealed class AuthResult {
    data class Success(val session: UserSession, val message: String = "Operation successful") : AuthResult()
    data class Error(val message: String) : AuthResult()
}

interface AuthRepository {
    val authState: StateFlow<AuthState>
    val currentSession: StateFlow<UserSession?>
    val isLoggedIn: StateFlow<Boolean>

    suspend fun registerUser(
        fullName: String,
        email: String,
        studentNumber: String,
        university: String,
        password: String
    ): AuthResult

    suspend fun loginUser(
        email: String,
        password: String
    ): AuthResult

    suspend fun loginWithGoogle(
        email: String,
        fullName: String,
        googleIdToken: String? = null
    ): AuthResult

    suspend fun sendPasswordReset(
        email: String
    ): AuthResult

    suspend fun resetPasswordWithToken(
        resetToken: String,
        newPassword: String
    ): AuthResult

    suspend fun verifyEmail(): AuthResult

    suspend fun changePassword(
        currentPassword: String,
        newPassword: String
    ): AuthResult

    suspend fun logout()
}
