package com.example.data.tools

import java.time.LocalDate
import java.time.Month
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/**
 * TimeTool provides accurate, real-time time, date, and calendar inquiries
 * with timezone support, authoritative South African holiday awareness,
 * and exact date difference calculations.
 *
 * CRITICAL RULE:
 * Never replace an explicitly requested date with today's date.
 */
object TimeTool {

    data class TimeResult(
        val success: Boolean,
        val locationOrTimezone: String,
        val formattedTime: String,
        val formattedDate: String,
        val dayOfWeek: String,
        val timezoneId: String,
        val fullReport: String
    )

    private val cityToZoneIdMap = mapOf(
        "tokyo" to "Asia/Tokyo",
        "japan" to "Asia/Tokyo",
        "cape town" to "Africa/Johannesburg",
        "johannesburg" to "Africa/Johannesburg",
        "pretoria" to "Africa/Johannesburg",
        "durban" to "Africa/Johannesburg",
        "south africa" to "Africa/Johannesburg",
        "london" to "Europe/London",
        "uk" to "Europe/London",
        "united kingdom" to "Europe/London",
        "england" to "Europe/London",
        "new york" to "America/New_York",
        "nyc" to "America/New_York",
        "los angeles" to "America/Los_Angeles",
        "san francisco" to "America/Los_Angeles",
        "chicago" to "America/Chicago",
        "paris" to "Europe/Paris",
        "france" to "Europe/Paris",
        "berlin" to "Europe/Berlin",
        "germany" to "Europe/Berlin",
        "sydney" to "Australia/Sydney",
        "melbourne" to "Australia/Sydney",
        "australia" to "Australia/Sydney",
        "dubai" to "Asia/Dubai",
        "uae" to "Asia/Dubai",
        "nairobi" to "Africa/Nairobi",
        "kenya" to "Africa/Nairobi",
        "cairo" to "Africa/Cairo",
        "egypt" to "Africa/Cairo",
        "lagos" to "Africa/Lagos",
        "nigeria" to "Africa/Lagos",
        "singapore" to "Asia/Singapore",
        "hong kong" to "Asia/Hong_Kong",
        "beijing" to "Asia/Shanghai",
        "shanghai" to "Asia/Shanghai",
        "china" to "Asia/Shanghai",
        "mumbai" to "Asia/Kolkata",
        "new delhi" to "Asia/Kolkata",
        "india" to "Asia/Kolkata",
        "toronto" to "America/Toronto",
        "vancouver" to "America/Vancouver",
        "canada" to "America/Toronto",
        "utc" to "UTC",
        "gmt" to "GMT"
    )

    /**
     * Retrieves accurate current time and date for the local device.
     */
    fun getDeviceDateTimeInfo(): TimeResult {
        return try {
            val zoneId = ZoneId.systemDefault()
            val zonedDateTime = ZonedDateTime.now(zoneId)

            val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
            val dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")

            val timeStr = zonedDateTime.format(timeFormatter)
            val dateStr = zonedDateTime.format(dateFormatter)
            val dayOfWeek = zonedDateTime.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            val zoneIdStr = zoneId.id

            val report = "🕒 Current device time is **$timeStr** ($dayOfWeek, $dateStr, Timezone: `$zoneIdStr`)."

            TimeResult(
                success = true,
                locationOrTimezone = "Local Device (${zoneIdStr})",
                formattedTime = timeStr,
                formattedDate = dateStr,
                dayOfWeek = dayOfWeek,
                timezoneId = zoneIdStr,
                fullReport = report
            )
        } catch (e: Exception) {
            TimeResult(
                success = false,
                locationOrTimezone = "Local Device",
                formattedTime = "",
                formattedDate = "",
                dayOfWeek = "",
                timezoneId = "UTC",
                fullReport = "Could not retrieve device time: ${e.message}"
            )
        }
    }

    /**
     * Comprehensive resolver for date, time, day of week, date differences, and holiday inquiries.
     * Evaluates against actual device clock and authoritative statutory calendar rules.
     */
    fun resolveDateOrTimeQuery(prompt: String): String? {
        val lower = prompt.lowercase().trim()
        val currentYear = LocalDate.now().year

        // 1. Date Difference Queries (e.g. "how many days until 27 september?", "how long until Christmas?")
        if (lower.contains("days until") || lower.contains("how many days") || lower.contains("days till") || lower.contains("how long until")) {
            val parsedDate = HolidayCalendarEngine.parseExplicitDate(prompt)
            if (parsedDate != null) {
                val (days, target) = HolidayCalendarEngine.calculateDaysUntil(parsedDate.first, parsedDate.second)
                val targetMonthName = parsedDate.second.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
                return "⏳ There are **$days day(s)** until **${parsedDate.first} $targetMonthName ${target.year}** (from today, ${LocalDate.now()})."
            }
            if (lower.contains("christmas")) {
                val (days, target) = HolidayCalendarEngine.calculateDaysUntil(25, Month.DECEMBER)
                return "🎄 There are **$days day(s)** until Christmas Day (${target.year})."
            }
            if (lower.contains("new year")) {
                val (days, target) = HolidayCalendarEngine.calculateDaysUntil(1, Month.JANUARY)
                return "🎉 There are **$days day(s)** until New Year's Day (${target.year})."
            }
            if (lower.contains("heritage day")) {
                val (days, target) = HolidayCalendarEngine.calculateDaysUntil(24, Month.SEPTEMBER)
                return "🇿🇦 There are **$days day(s)** until Heritage Day (${target.year})."
            }
            if (lower.contains("freedom day")) {
                val (days, target) = HolidayCalendarEngine.calculateDaysUntil(27, Month.APRIL)
                return "🇿🇦 There are **$days day(s)** until Freedom Day (${target.year})."
            }
            if (lower.contains("youth day")) {
                val (days, target) = HolidayCalendarEngine.calculateDaysUntil(16, Month.JUNE)
                return "🇿🇦 There are **$days day(s)** until Youth Day (${target.year})."
            }
        }

        // 2. Explicit Holiday or Calendar Date Check (e.g. "What is the holiday on 27 September in South Africa?")
        val explicitDate = HolidayCalendarEngine.parseExplicitDate(prompt)
        if (explicitDate != null) {
            val target = LocalDate.of(currentYear, explicitDate.second, explicitDate.first)
            val eval = HolidayCalendarEngine.evaluateSouthAfricanDate(target)

            return buildString {
                if (eval.isPublicHoliday) {
                    append("🇿🇦 **${eval.formattedDate}** is a South African National Public Holiday: **${eval.name}**.\n\n")
                    append(eval.description)
                } else {
                    append("🇿🇦 **${eval.formattedDate}** is **not** a South African statutory national public holiday.\n\n")
                    if (eval.category == HolidayCalendarEngine.HolidayCategory.COMMEMORATIVE_OBSERVANCE) {
                        append("• **Observance**: **${eval.name}** (Official commemorative day, not a statutory paid public holiday).\n")
                        append("• **Details**: ${eval.description}\n")
                    } else {
                        append(eval.description)
                        append("\n")
                    }
                    eval.nearbyHolidaysNote?.let { note ->
                        append("\n💡 **Note**: $note")
                    }
                }
            }
        }

        // 3. Named Holiday lookup (e.g. "When is Freedom Day?", "What day is Christmas?")
        val namedHolidayResult = resolveCalendarEventDate(prompt)
        if (namedHolidayResult != null) {
            return namedHolidayResult
        }

        // 4. City or specific timezone time query (e.g. "what time is it in Tokyo")
        if (lower.contains("time in ") || lower.contains("time at ") || (lower.contains("what time") && lower.contains(" in "))) {
            val city = when {
                lower.contains(" in ") -> prompt.substring(lower.indexOf(" in ") + 4).removeSuffix("?").trim()
                lower.contains(" at ") -> prompt.substring(lower.indexOf(" at ") + 4).removeSuffix("?").trim()
                else -> prompt.removePrefix("time in").removePrefix("what time is it in").removeSuffix("?").trim()
            }
            if (city.isNotBlank()) {
                val res = getCurrentTime(city)
                return if (res.success) res.fullReport else "Could not determine timezone for '$city'."
            }
        }

        val now = ZonedDateTime.now()
        val dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")
        val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
        val dayOfWeek = now.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
        val dateStr = now.format(dateFormatter)
        val timeStr = now.format(timeFormatter)

        // 5. Current Date questions (Strictly only when user explicitly asks for today/current date)
        if (lower.contains("today's date") || lower.contains("date today") || lower == "what is the date" || lower == "what is the date?" || lower == "what date is it" || lower == "what date is it?" || lower.contains("current date")) {
            return "📅 Today's date is **$dateStr** ($dayOfWeek)."
        }

        // 6. Day of the week questions for today
        if (lower.contains("day of the week") || lower == "what day is it?" || lower == "what day is it" || lower == "what day is today?" || lower == "what day is today") {
            return "📅 Today is **$dayOfWeek**, $dateStr."
        }

        // 7. Current Year / Month questions
        if (lower == "what year is it?" || lower == "what year is it" || lower == "current year") {
            return "📅 The current year is **${now.year}**."
        }
        if (lower == "what month is it?" || lower == "what month is it" || lower == "current month") {
            val monthName = now.month.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "📅 The current month is **$monthName ${now.year}**."
        }

        // 8. Weekend checks
        if (lower.contains("is today a weekend") || lower.contains("is it the weekend")) {
            val isWeekend = now.dayOfWeek.value >= 6
            return if (isWeekend) {
                "🎉 Yes, today is **$dayOfWeek**, which is part of the weekend!"
            } else {
                val daysUntilWeekend = 6 - now.dayOfWeek.value
                "💼 No, today is **$dayOfWeek** (a weekday). There are **$daysUntilWeekend day(s)** until the weekend."
            }
        }

        // 9. General local time question
        if (lower == "what time is it?" || lower == "what time is it" || lower == "what is the time" || lower == "what is the time?" || lower.contains("current time")) {
            return "🕒 The current time is **$timeStr** ($dayOfWeek, $dateStr)."
        }

        return null
    }

    /**
     * Retrieves accurate current time and date for a city or timezone identifier.
     */
    fun getCurrentTime(locationQuery: String = "Cape Town"): TimeResult {
        val lower = locationQuery.lowercase().trim()
        val zoneIdStr = resolveZoneId(lower)

        return try {
            val zoneId = ZoneId.of(zoneIdStr)
            val zonedDateTime = ZonedDateTime.now(zoneId)

            val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
            val dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")

            val timeStr = zonedDateTime.format(timeFormatter)
            val dateStr = zonedDateTime.format(dateFormatter)
            val dayOfWeek = zonedDateTime.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            val locationDisplayName = formatLocationName(locationQuery.ifBlank { "Cape Town" })

            val report = "🕒 The current time in **$locationDisplayName** is **$timeStr** ($dayOfWeek, $dateStr, Timezone: `$zoneIdStr`)."

            TimeResult(
                success = true,
                locationOrTimezone = locationDisplayName,
                formattedTime = timeStr,
                formattedDate = dateStr,
                dayOfWeek = dayOfWeek,
                timezoneId = zoneIdStr,
                fullReport = report
            )
        } catch (e: Exception) {
            TimeResult(
                success = false,
                locationOrTimezone = locationQuery,
                formattedTime = "",
                formattedDate = "",
                dayOfWeek = "",
                timezoneId = zoneIdStr,
                fullReport = "Could not retrieve time for '$locationQuery': ${e.message}"
            )
        }
    }

    /**
     * Resolves statutory named holiday questions.
     */
    fun resolveCalendarEventDate(prompt: String): String? {
        val lower = prompt.lowercase().trim()
        val currentYear = LocalDate.now().year

        if (lower.contains("christmas")) {
            val christmasDate = LocalDate.of(currentYear, 12, 25)
            val dayName = christmasDate.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🎄 In **$currentYear**, Christmas Day (December 25) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("new year") && (lower.contains("day") || lower.contains("eve") || lower.contains("what day"))) {
            val newYearDate = LocalDate.of(currentYear, 1, 1)
            val dayName = newYearDate.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🎉 New Year's Day $currentYear (January 1) was on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("human rights day")) {
            val date = LocalDate.of(currentYear, 3, 21)
            val dayName = date.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 South African Human Rights Day $currentYear (March 21) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("freedom day")) {
            val freedomDay = LocalDate.of(currentYear, 4, 27)
            val dayName = freedomDay.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 South African Freedom Day $currentYear (April 27) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("workers' day") || lower.contains("workers day") || lower.contains("worker's day")) {
            val date = LocalDate.of(currentYear, 5, 1)
            val dayName = date.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 South African Workers' Day $currentYear (May 1) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("youth day")) {
            val youthDay = LocalDate.of(currentYear, 6, 16)
            val dayName = youthDay.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 South African Youth Day $currentYear (June 16) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("women's day") || lower.contains("womens day")) {
            val date = LocalDate.of(currentYear, 8, 9)
            val dayName = date.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 South African National Women's Day $currentYear (August 9) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("heritage day")) {
            val heritageDay = LocalDate.of(currentYear, 9, 24)
            val dayName = heritageDay.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 South African Heritage Day $currentYear (September 24) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("day of reconciliation")) {
            val recDay = LocalDate.of(currentYear, 12, 16)
            val dayName = recDay.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 Day of Reconciliation $currentYear (December 16) falls on a **$dayName** (Statutory Public Holiday)."
        }

        if (lower.contains("day of goodwill")) {
            val date = LocalDate.of(currentYear, 12, 26)
            val dayName = date.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            return "🇿🇦 Day of Goodwill $currentYear (December 26) falls on a **$dayName** (Statutory Public Holiday)."
        }

        return null
    }

    private fun resolveZoneId(query: String): String {
        for ((city, zone) in cityToZoneIdMap) {
            if (query.contains(city)) {
                return zone
            }
        }
        return try {
            ZoneId.of(query).id
        } catch (e: Exception) {
            "Africa/Johannesburg"
        }
    }

    private fun formatLocationName(query: String): String {
        return query
            .replace("time in", "", ignoreCase = true)
            .replace("time at", "", ignoreCase = true)
            .replace("what time is it in", "", ignoreCase = true)
            .replace("what time is it", "", ignoreCase = true)
            .replace("?", "")
            .trim()
            .split(" ")
            .joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
            .ifBlank { "Cape Town" }
    }
}
