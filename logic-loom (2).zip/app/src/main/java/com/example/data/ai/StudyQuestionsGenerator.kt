package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object StudyQuestionsGenerator {

    private const val MODEL_FLASH = "gemini-3.5-flash"
    private const val MODEL_PRO = "gemini-3.1-pro-preview"

    /**
     * Generates a targeted set of study questions based on the provided student note.
     */
    suspend fun generateStudyQuestions(
        config: StudyQuestionsGeneratorConfig
    ): StudyQuestionsQuiz = withContext(Dispatchers.IO) {
        val noteTitle = config.noteTitle.ifBlank { "Study Material" }
        val noteContent = config.noteContent.trim()
        val count = config.questionCount.coerceIn(2, 10)
        val format = config.questionFormat
        val difficulty = config.difficulty
        val focusArea = config.focusArea

        val dateStr = try {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        } catch (e: Throwable) {
            "2026-08-25 12:00"
        }

        // Build precise system prompt for Gemini
        val systemInstruction = """
            You are an expert university professor, academic tutor, and exam designer built into CanvasMate (developed and engineered by Moraigne).
            Your goal is to test a student's true conceptual and practical understanding of their study notes through targeted, rigorous, and engaging study questions.
            
            Guidelines:
            - Create questions that test Active Recall, Conceptual Depth, Critical Thinking, and Practical Application rather than superficial trivia.
            - Provide clear, constructive explanations that teach the core reasoning behind why an answer is correct.
            - Include helpful hints for students who are stuck before revealing the answer.
            - Structure questions according to requested formats (Multiple Choice, Conceptual, True/False, Scenario).
        """.trimIndent()

        val prompt = """
            Generate exactly $count targeted study questions to test understanding of this student note.
            
            === STUDENT NOTE DETAILS ===
            Title: $noteTitle
            Folder / Subject: ${config.folder}
            Requested Question Format: $format
            Target Difficulty: $difficulty
            Focus Goal: $focusArea
            
            === NOTE CONTENT ===
            $noteContent
            
            === RESPONSE FORMAT INSTRUCTIONS ===
            Please output your response in TWO parts:
            1. A beautifully formatted Markdown Study Quiz with clear question numbers, options, hints, and expandable answers.
            2. At the very end, enclose a structured JSON array matching this exact format inside ```json ... ```:
            [
              {
                "id": 1,
                "questionNumber": 1,
                "questionText": "What is the primary purpose of...",
                "questionType": "MULTIPLE_CHOICE", // Choose: "MULTIPLE_CHOICE", "CONCEPTUAL_SHORT_ANSWER", "TRUE_FALSE", or "SCENARIO_APPLICATION"
                "options": ["Option A", "Option B", "Option C", "Option D"], // Only if MULTIPLE_CHOICE or TRUE_FALSE (2 items), else empty
                "correctOptionIndex": 0, // 0-based index of correct option if MCQ or TF, else -1
                "correctAnswer": "Complete explanation of correct answer",
                "explanation": "Detailed pedagogical explanation of why this is correct and what concept it tests",
                "hint": "Helpful clue to trigger recall",
                "targetConcept": "Key Concept Name",
                "difficulty": "$difficulty"
              }
            ]
        """.trimIndent()

        // Check if API key is configured
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY.trim()
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val chosenModel = if (difficulty.contains("Exam", ignoreCase = true) || difficulty.contains("Advanced", ignoreCase = true)) {
                    MODEL_PRO
                } else {
                    MODEL_FLASH
                }

                val aiRawResponse = GeminiClient.askGemini(
                    prompt = prompt,
                    taskType = "academic",
                    systemContextOverride = systemInstruction
                )

                if (aiRawResponse.isNotBlank()) {
                    val parsedQuestions = parseQuestionsFromJsonOrText(aiRawResponse, noteTitle, noteContent, count, format, difficulty)
                    if (parsedQuestions.isNotEmpty()) {
                        return@withContext StudyQuestionsQuiz(
                            id = UUID.randomUUID().toString(),
                            noteTitle = noteTitle,
                            noteContentSnippet = noteContent.take(160),
                            folder = config.folder,
                            questionTypePreference = format,
                            difficulty = difficulty,
                            questions = parsedQuestions,
                            generatedAt = dateStr,
                            rawAiResponse = aiRawResponse
                        )
                    }
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        // Offline Grounded Intelligent Fallback
        val offlineQuiz = generateOfflineStudyQuestions(noteTitle, noteContent, count, format, difficulty, config.folder, dateStr)
        return@withContext offlineQuiz
    }

    /**
     * Parses the JSON block out of Gemini's response, or falls back to text parsing.
     */
    private fun parseQuestionsFromJsonOrText(
        aiResponse: String,
        noteTitle: String,
        noteContent: String,
        expectedCount: Int,
        format: String,
        difficulty: String
    ): List<StudyQuestionItem> {
        val jsonPattern = Regex("```json\\s*([\\s\\S]*?)\\s*```")
        val match = jsonPattern.find(aiResponse)
        val jsonString = match?.groups?.get(1)?.value?.trim()

        if (!jsonString.isNullOrBlank()) {
            try {
                val jsonArray = JSONArray(jsonString)
                val items = mutableListOf<StudyQuestionItem>()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val qNum = obj.optInt("questionNumber", i + 1)
                    val qText = obj.optString("questionText", "Question $qNum")
                    val typeStr = obj.optString("questionType", "MULTIPLE_CHOICE")
                    val type = when (typeStr) {
                        "CONCEPTUAL_SHORT_ANSWER" -> StudyQuestionType.CONCEPTUAL_SHORT_ANSWER
                        "TRUE_FALSE" -> StudyQuestionType.TRUE_FALSE
                        "SCENARIO_APPLICATION" -> StudyQuestionType.SCENARIO_APPLICATION
                        else -> StudyQuestionType.MULTIPLE_CHOICE
                    }

                    val optList = mutableListOf<String>()
                    val optArr = obj.optJSONArray("options")
                    if (optArr != null) {
                        for (j in 0 until optArr.length()) {
                            optList.add(optArr.getString(j))
                        }
                    }

                    val correctIdx = obj.optInt("correctOptionIndex", -1)
                    val correctAns = obj.optString("correctAnswer", if (correctIdx in optList.indices) optList[correctIdx] else "See explanation")
                    val explanation = obj.optString("explanation", "Tests comprehension of key material.")
                    val hint = obj.optString("hint", "Review the core concepts in the note.")
                    val concept = obj.optString("targetConcept", "Understanding of $noteTitle")
                    val diff = obj.optString("difficulty", difficulty)

                    items.add(
                        StudyQuestionItem(
                            id = i + 1,
                            questionNumber = qNum,
                            questionText = qText,
                            questionType = type,
                            options = optList,
                            correctOptionIndex = correctIdx,
                            correctAnswer = correctAns,
                            explanation = explanation,
                            hint = hint,
                            targetConcept = concept,
                            difficulty = diff
                        )
                    )
                }

                if (items.isNotEmpty()) {
                    return items
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }

        // If JSON extraction failed, fall back to offline extractor based on note text
        return generateOfflineQuestionsFromNoteContent(noteTitle, noteContent, expectedCount, format, difficulty)
    }

    /**
     * Offline grounded generator that extracts authentic concepts from note content.
     */
    private fun generateOfflineStudyQuestions(
        noteTitle: String,
        noteContent: String,
        count: Int,
        format: String,
        difficulty: String,
        folder: String,
        dateStr: String
    ): StudyQuestionsQuiz {
        val questions = generateOfflineQuestionsFromNoteContent(noteTitle, noteContent, count, format, difficulty)

        val rawMarkdown = buildString {
            append("🎯 **Targeted Study Questions for '$noteTitle'**\n\n")
            append("📂 *Folder: $folder | Difficulty: $difficulty | Format: $format*\n\n")
            questions.forEach { q ->
                append("### Question ${q.questionNumber} (${q.questionType.displayName})\n")
                append("**${q.questionText}**\n\n")
                if (q.options.isNotEmpty()) {
                    q.options.forEachIndexed { idx, opt ->
                        val letter = ('A'.code + idx).toChar()
                        append("• **$letter)** $opt\n")
                    }
                    append("\n")
                }
                append("💡 *Hint*: ${q.hint}\n\n")
                append("✅ **Model Answer**: ${q.correctAnswer}\n\n")
                append("📖 **Explanation & Concept Tested**: ${q.explanation} (Concept: *${q.targetConcept}*)\n\n")
                append("---\n\n")
            }
            append("[CARD_STUDY_QUIZ:Note=$noteTitle|Count=${questions.size}|Difficulty=$difficulty]")
        }

        return StudyQuestionsQuiz(
            id = UUID.randomUUID().toString(),
            noteTitle = noteTitle,
            noteContentSnippet = noteContent.take(160),
            folder = folder,
            questionTypePreference = format,
            difficulty = difficulty,
            questions = questions,
            generatedAt = dateStr,
            rawAiResponse = rawMarkdown
        )
    }

    /**
     * Intelligently parses note lines, bullet points, terms, and paragraphs into high-quality questions.
     */
    private fun generateOfflineQuestionsFromNoteContent(
        noteTitle: String,
        noteContent: String,
        count: Int,
        format: String,
        difficulty: String
    ): List<StudyQuestionItem> {
        val lines = noteContent.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val conceptPairs = mutableListOf<Pair<String, String>>()

        // Extract key terms / definitions (e.g. "Term: Definition" or "• Concept - Details")
        lines.forEach { line ->
            when {
                line.contains(":") -> {
                    val parts = line.split(":", limit = 2)
                    val key = parts[0].removePrefix("•").removePrefix("-").removePrefix("*").trim()
                    val value = parts[1].trim()
                    if (key.length in 3..60 && value.length > 5) {
                        conceptPairs.add(key to value)
                    }
                }
                line.contains(" - ") -> {
                    val parts = line.split(" - ", limit = 2)
                    val key = parts[0].removePrefix("•").removePrefix("-").removePrefix("*").trim()
                    val value = parts[1].trim()
                    if (key.length in 3..60 && value.length > 5) {
                        conceptPairs.add(key to value)
                    }
                }
                line.startsWith("•") || line.startsWith("-") -> {
                    val text = line.removePrefix("•").removePrefix("-").trim()
                    if (text.length > 15) {
                        conceptPairs.add("Key Principle" to text)
                    }
                }
            }
        }

        // If no bullet points were found, extract from sentences
        if (conceptPairs.isEmpty()) {
            val sentences = noteContent.split(Regex("[.!?]\\s+")).map { it.trim() }.filter { it.length > 20 }
            sentences.forEachIndexed { idx, sentence ->
                conceptPairs.add("Core Insight #${idx + 1}" to sentence)
            }
        }

        if (conceptPairs.isEmpty()) {
            conceptPairs.add("Overview" to (noteContent.ifBlank { "Important concepts regarding $noteTitle" }))
        }

        val questions = mutableListOf<StudyQuestionItem>()
        val totalToMake = count.coerceAtMost(conceptPairs.size.coerceAtLeast(3))

        for (i in 0 until totalToMake) {
            val qNum = i + 1
            val conceptIndex = i % conceptPairs.size
            val (term, detail) = conceptPairs[conceptIndex]

            val targetType = when {
                format.contains("Multiple Choice", ignoreCase = true) && !format.contains("Mixed", ignoreCase = true) -> StudyQuestionType.MULTIPLE_CHOICE
                format.contains("Conceptual", ignoreCase = true) && !format.contains("Mixed", ignoreCase = true) -> StudyQuestionType.CONCEPTUAL_SHORT_ANSWER
                format.contains("True / False", ignoreCase = true) -> StudyQuestionType.TRUE_FALSE
                format.contains("Scenario", ignoreCase = true) -> StudyQuestionType.SCENARIO_APPLICATION
                else -> {
                    // Mixed variety
                    when (i % 4) {
                        0 -> StudyQuestionType.MULTIPLE_CHOICE
                        1 -> StudyQuestionType.CONCEPTUAL_SHORT_ANSWER
                        2 -> StudyQuestionType.SCENARIO_APPLICATION
                        else -> StudyQuestionType.TRUE_FALSE
                    }
                }
            }

            when (targetType) {
                StudyQuestionType.MULTIPLE_CHOICE -> {
                    val correctOpt = detail.take(90)
                    val distractor1 = "It exclusively regulates secondary background operations without direct impact on $term."
                    val distractor2 = "It is an outdated concept replaced by standard linear computation models."
                    val distractor3 = "It has no direct relationship with the core thesis of $noteTitle."

                    val options = listOf(
                        correctOpt,
                        distractor1,
                        distractor2,
                        distractor3
                    ).shuffled()

                    val correctIdx = options.indexOf(correctOpt).coerceAtLeast(0)

                    questions.add(
                        StudyQuestionItem(
                            id = qNum,
                            questionNumber = qNum,
                            questionText = if (term != "Key Principle" && term != "Overview") {
                                "According to your notes on '$noteTitle', which statement best characterizes '$term'?"
                            } else {
                                "Which statement accurately represents the fundamental rule outlined in your study notes?"
                            },
                            questionType = StudyQuestionType.MULTIPLE_CHOICE,
                            options = options,
                            correctOptionIndex = correctIdx,
                            correctAnswer = correctOpt,
                            explanation = "As stated in your notes, $term corresponds to: \"$detail\". Testing this ensures you understand the core mechanism rather than confusing it with unrelated mechanisms.",
                            hint = "Recall the definition and primary role associated with '$term'.",
                            targetConcept = term,
                            difficulty = difficulty
                        )
                    )
                }

                StudyQuestionType.CONCEPTUAL_SHORT_ANSWER -> {
                    questions.add(
                        StudyQuestionItem(
                            id = qNum,
                            questionNumber = qNum,
                            questionText = if (term != "Key Principle" && term != "Overview") {
                                "Explain the fundamental significance of '$term' in the context of $noteTitle. How does it function?"
                            } else {
                                "Explain the main insight and underlying rationale described in this section of $noteTitle."
                            },
                            questionType = StudyQuestionType.CONCEPTUAL_SHORT_ANSWER,
                            options = emptyList(),
                            correctOptionIndex = -1,
                            correctAnswer = detail,
                            explanation = "A complete answer articulates the purpose of $term: $detail, demonstrating both factual retention and synthesis of the material.",
                            hint = "Think about why the author or lecturer emphasized this point during review.",
                            targetConcept = term,
                            difficulty = difficulty
                        )
                    )
                }

                StudyQuestionType.TRUE_FALSE -> {
                    val isTrue = (i % 2 == 0)
                    val statement = if (isTrue) {
                        "In $noteTitle, $term is correctly described as: $detail."
                    } else {
                        "In $noteTitle, $term operates strictly in the opposite manner by disabling primary execution parameters."
                    }

                    val options = listOf("True", "False")
                    val correctIdx = if (isTrue) 0 else 1

                    questions.add(
                        StudyQuestionItem(
                            id = qNum,
                            questionNumber = qNum,
                            questionText = statement,
                            questionType = StudyQuestionType.TRUE_FALSE,
                            options = options,
                            correctOptionIndex = correctIdx,
                            correctAnswer = if (isTrue) "True" else "False",
                            explanation = if (isTrue) {
                                "True. The statement directly matches the grounded principle: $detail."
                            } else {
                                "False. The note establishes that $term is: $detail."
                            },
                            hint = "Verify if the statement aligns with the exact notes taken on $term.",
                            targetConcept = term,
                            difficulty = difficulty
                        )
                    )
                }

                StudyQuestionType.SCENARIO_APPLICATION -> {
                    questions.add(
                        StudyQuestionItem(
                            id = qNum,
                            questionNumber = qNum,
                            questionText = "Scenario: Suppose you are tasked with solving a problem in $noteTitle where '$term' is a critical constraint. How should you apply this principle to achieve the desired outcome?",
                            questionType = StudyQuestionType.SCENARIO_APPLICATION,
                            options = emptyList(),
                            correctOptionIndex = -1,
                            correctAnswer = "Apply the rule that $detail, ensuring that the implementation adheres to the properties of $term.",
                            explanation = "This scenario tests your ability to transfer theoretical notes into practical problem-solving environments by applying: $detail.",
                            hint = "Consider the practical implications of $term in real-world scenarios.",
                            targetConcept = term,
                            difficulty = difficulty
                        )
                    )
                }
            }
        }

        return questions
    }
}
