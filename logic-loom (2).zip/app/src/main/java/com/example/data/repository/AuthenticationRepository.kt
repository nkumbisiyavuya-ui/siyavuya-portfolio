package com.example.data.repository

import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.StateFlow

sealed class FirebaseAuthResult<out T> {
    data class Success<T>(val data: T, val message: String = "Operation successful") : FirebaseAuthResult<T>()
    data class Error(val message: String, val exception: Throwable? = null) : FirebaseAuthResult<Nothing>()
}

/**
 * AuthenticationRepository abstracts Firebase Auth operations, providing a clean interface
 * for sign-up, login, and password reset tasks for ViewModels.
 */
interface AuthenticationRepository {
    val currentUser: FirebaseUser?
    val isLoggedIn: StateFlow<Boolean>

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String? = null
    ): FirebaseAuthResult<FirebaseUser>

    suspend fun loginWithEmail(
        email: String,
        password: String
    ): FirebaseAuthResult<FirebaseUser>

    suspend fun sendPasswordResetEmail(
        email: String
    ): FirebaseAuthResult<Unit>

    suspend fun sendEmailVerification(): FirebaseAuthResult<Unit>

    suspend fun signOut()
}
