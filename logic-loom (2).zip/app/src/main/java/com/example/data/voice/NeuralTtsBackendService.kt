package com.example.data.voice

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Payload sent to the secure backend proxy for neural voice synthesis.
 */
data class NeuralTtsSynthesizeRequest(
    val text: String,
    val voiceId: String,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val modelId: String? = null,
    val generationId: String? = null,
    val authToken: String? = null
)

/**
 * Result returned by the neural TTS backend proxy.
 */
data class NeuralTtsSynthesizeResult(
    val audioBytes: ByteArray? = null,
    val mimeType: String = "audio/mpeg",
    val isSuccess: Boolean,
    val errorMessage: String? = null,
    val latencyMs: Long = 0L,
    val ttfbMs: Long = 0L,
    val generationId: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NeuralTtsSynthesizeResult
        return isSuccess == other.isSuccess &&
                mimeType == other.mimeType &&
                errorMessage == other.errorMessage &&
                latencyMs == other.latencyMs &&
                ttfbMs == other.ttfbMs &&
                generationId == other.generationId &&
                (audioBytes?.contentEquals(other.audioBytes ?: ByteArray(0)) ?: (other.audioBytes == null))
    }

    override fun hashCode(): Int {
        var result = isSuccess.hashCode()
        result = 31 * result + (audioBytes?.contentHashCode() ?: 0)
        result = 31 * result + mimeType.hashCode()
        result = 31 * result + (errorMessage?.hashCode() ?: 0)
        result = 31 * result + (generationId?.hashCode() ?: 0)
        return result
    }
}

/**
 * Provider-agnostic contract for communicating with a secure Neural TTS backend proxy.
 *
 * ARCHITECTURE & SECURITY:
 * Long-lived provider API keys (such as ElevenLabs API keys) are strictly managed
 * server-side on the backend proxy or Firebase Cloud Functions.
 * The Android client never handles or stores provider credentials.
 */
interface NeuralTtsBackendClient {
    fun isConfigured(): Boolean
    suspend fun synthesize(
        request: NeuralTtsSynthesizeRequest,
        isCancelled: () -> Boolean = { false }
    ): NeuralTtsSynthesizeResult
}

/**
 * HTTP implementation of the neural TTS backend proxy client.
 * Connects to the secure backend proxy via OkHttpClient.
 */
class HttpNeuralTtsBackendClient(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()
) : NeuralTtsBackendClient {

    companion object {
        private const val TAG = "NeuralTtsBackend"
    }

    override fun isConfigured(): Boolean {
        val proxyUrl = NeuralTtsConfiguration.current.backendProxyUrl
        return !proxyUrl.isNullOrBlank() && NeuralTtsConfiguration.current.isEnabled
    }

    override suspend fun synthesize(
        request: NeuralTtsSynthesizeRequest,
        isCancelled: () -> Boolean
    ): NeuralTtsSynthesizeResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val proxyUrl = NeuralTtsConfiguration.current.backendProxyUrl

        if (proxyUrl.isNullOrBlank()) {
            val latency = System.currentTimeMillis() - startTime
            Log.d(TAG, "VOICE_TTS_FALLBACK: Neural TTS backend proxy URL not configured. Latency: ${latency}ms")
            return@withContext NeuralTtsSynthesizeResult(
                isSuccess = false,
                errorMessage = "Backend proxy URL is not configured. Falling back to device voice.",
                latencyMs = latency,
                generationId = request.generationId
            )
        }

        if (isCancelled()) {
            Log.d(TAG, "VOICE_TTS_CANCELLED: Dropping request prior to dispatch (generationId: ${request.generationId})")
            return@withContext NeuralTtsSynthesizeResult(
                isSuccess = false,
                errorMessage = "Cancelled by user",
                generationId = request.generationId
            )
        }

        try {
            Log.d(TAG, "VOICE_TTS_REQUEST: Synthesizing chunk (${request.text.length} chars) using voiceId: ${request.voiceId} (gen: ${request.generationId})")

            val jsonBody = JSONObject().apply {
                put("text", request.text)
                put("voice_id", request.voiceId)
                put("model_id", request.modelId ?: NeuralTtsConfiguration.current.defaultModelId)
                val voiceSettings = JSONObject().apply {
                    put("stability", 0.5)
                    put("similarity_boost", 0.8)
                    put("speed", request.speed.coerceIn(0.7f, 1.4f))
                }
                put("voice_settings", voiceSettings)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBuilder = Request.Builder()
                .url(proxyUrl)
                .post(jsonBody.toString().toRequestBody(mediaType))
                .header("Accept", "audio/mpeg, audio/wav, audio/*")
                .header("User-Agent", "LogicLoom-VoiceMode/1.0")

            if (!request.authToken.isNullOrBlank()) {
                requestBuilder.header("Authorization", "Bearer ${request.authToken}")
            }
            if (!request.generationId.isNullOrBlank()) {
                requestBuilder.header("X-Generation-ID", request.generationId)
            }

            val call = okHttpClient.newCall(requestBuilder.build())
            val response = call.execute()
            val ttfb = System.currentTimeMillis() - startTime

            if (isCancelled()) {
                response.close()
                Log.d(TAG, "VOICE_TTS_CANCELLED: Discarding response as conversation was interrupted (TTFB: ${ttfb}ms)")
                return@withContext NeuralTtsSynthesizeResult(
                    isSuccess = false,
                    errorMessage = "Cancelled by user",
                    ttfbMs = ttfb,
                    generationId = request.generationId
                )
            }

            if (!response.isSuccessful) {
                val code = response.code
                val errBody = response.body?.string()?.take(200) ?: "Unknown server response"
                val latency = System.currentTimeMillis() - startTime
                Log.w(TAG, "VOICE_TTS_ERROR: HTTP $code from TTS proxy: $errBody. Latency: ${latency}ms, TTFB: ${ttfb}ms")
                return@withContext NeuralTtsSynthesizeResult(
                    isSuccess = false,
                    errorMessage = "Backend TTS proxy returned HTTP $code: $errBody",
                    latencyMs = latency,
                    ttfbMs = ttfb,
                    generationId = request.generationId
                )
            }

            val body = response.body
            if (body == null) {
                val latency = System.currentTimeMillis() - startTime
                Log.w(TAG, "VOICE_TTS_ERROR: Empty response body from TTS proxy. Latency: ${latency}ms")
                return@withContext NeuralTtsSynthesizeResult(
                    isSuccess = false,
                    errorMessage = "Empty response body from TTS proxy.",
                    latencyMs = latency,
                    ttfbMs = ttfb,
                    generationId = request.generationId
                )
            }

            val audioData = body.bytes()
            val totalLatency = System.currentTimeMillis() - startTime

            if (isCancelled()) {
                Log.d(TAG, "VOICE_TTS_CANCELLED: Discarding audio bytes as conversation was interrupted")
                return@withContext NeuralTtsSynthesizeResult(
                    isSuccess = false,
                    errorMessage = "Cancelled by user",
                    latencyMs = totalLatency,
                    ttfbMs = ttfb,
                    generationId = request.generationId
                )
            }

            if (audioData.isEmpty()) {
                Log.w(TAG, "VOICE_TTS_ERROR: Zero audio bytes received. Latency: ${totalLatency}ms")
                return@withContext NeuralTtsSynthesizeResult(
                    isSuccess = false,
                    errorMessage = "Zero audio bytes returned by backend proxy.",
                    latencyMs = totalLatency,
                    ttfbMs = ttfb,
                    generationId = request.generationId
                )
            }

            val contentType = response.header("Content-Type") ?: "audio/mpeg"
            Log.d(TAG, "VOICE_TTS_FIRST_AUDIO: Received ${audioData.size} bytes ($contentType). TTFB: ${ttfb}ms, Total: ${totalLatency}ms")

            NeuralTtsSynthesizeResult(
                audioBytes = audioData,
                mimeType = contentType,
                isSuccess = true,
                latencyMs = totalLatency,
                ttfbMs = ttfb,
                generationId = request.generationId
            )
        } catch (e: IOException) {
            val latency = System.currentTimeMillis() - startTime
            Log.w(TAG, "VOICE_TTS_ERROR: Network I/O exception contacting TTS proxy: ${e.message}. Latency: ${latency}ms")
            NeuralTtsSynthesizeResult(
                isSuccess = false,
                errorMessage = "Network error reaching TTS backend proxy: ${e.localizedMessage}",
                latencyMs = latency,
                generationId = request.generationId
            )
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            Log.e(TAG, "VOICE_TTS_ERROR: Unexpected error during synthesis: ${e.message}. Latency: ${latency}ms", e)
            NeuralTtsSynthesizeResult(
                isSuccess = false,
                errorMessage = "Unexpected synthesis error: ${e.localizedMessage}",
                latencyMs = latency,
                generationId = request.generationId
            )
        }
    }
}
