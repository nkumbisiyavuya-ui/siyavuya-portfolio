package com.example.data.ai.orchestrator

import com.example.data.ai.ContextEngine
import com.example.data.ai.GeminiClient
import com.example.data.ai.IntentRouter
import com.example.data.ai.orchestrator.memory.DefaultMemoryProvider
import com.example.data.ai.orchestrator.memory.MemoryProvider
import com.example.data.ai.orchestrator.tools.DefaultToolRegistry
import com.example.data.ai.orchestrator.tools.ToolRegistry
import com.example.data.ai.orchestrator.tools.ToolRequest
import com.example.data.ai.orchestrator.tools.ToolResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.coroutineContext

/**
 * Interface defining the primary contract of the Chuma AI Orchestrator.
 * Can be mocked or tested independently from Android UI or Hilt.
 */
interface IChumaOrchestrator {
    suspend fun process(
        request: String,
        context: ChumaExecutionContext
    ): ChumaOrchestratorResult
}

/**
 * Central Chuma AI Orchestrator managing request intake, semantic classification,
 * capability routing, tool execution, multi-step decomposition, grounded Gemini inference,
 * verification, and response synthesis.
 */
@Singleton
class ChumaOrchestrator @Inject constructor(
    val toolRegistry: ToolRegistry,
    val memoryProvider: MemoryProvider
) : IChumaOrchestrator {

    /**
     * Default secondary constructor for easy instantiation in unit tests and legacy callers.
     */
    constructor() : this(
        toolRegistry = DefaultToolRegistry(),
        memoryProvider = DefaultMemoryProvider()
    )

    override suspend fun process(
        request: String,
        context: ChumaExecutionContext
    ): ChumaOrchestratorResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val requestId = UUID.randomUUID().toString().take(8)

        // 1. Check for immediate cancellation or blank query
        coroutineContext.ensureActive()
        if (context.isCancelled()) {
            ChumaOrchestratorLogger.requestCancelled(requestId)
            return@withContext ChumaOrchestratorResult(
                output = "Response generation was stopped.",
                taskType = ChumaTaskType.GENERAL_QA,
                confidence = ChumaConfidence.LOW,
                isError = false,
                errorMessage = "Cancelled by user"
            )
        }

        val trimmed = request.trim()
        if (trimmed.isBlank()) {
            val emptyOutput = "How can I assist you with Logic Loom today?"
            context.onChunk?.invoke(emptyOutput)
            return@withContext ChumaOrchestratorResult(
                output = emptyOutput,
                taskType = ChumaTaskType.GENERAL_QA,
                confidence = ChumaConfidence.HIGH,
                durationMs = System.currentTimeMillis() - startTime
            )
        }

        ChumaOrchestratorLogger.requestReceived(requestId, "orchestrator", trimmed.length)

        try {
            // 0. Handle pending action confirmation / cancellation
            if (com.example.data.ai.ActionConfirmation.pendingAction != null) {
                val pending = com.example.data.ai.ActionConfirmation.pendingAction!!
                if (com.example.data.ai.ActionConfirmation.isConfirmation(trimmed)) {
                    com.example.data.ai.ActionConfirmation.pendingAction = null
                    val confMsg = "Confirmed — the action \"$pending\" has been executed safely as confirmed."
                    context.onChunk?.invoke(confMsg)
                    return@withContext ChumaOrchestratorResult(
                        output = confMsg,
                        taskType = ChumaTaskType.TOOL_REQUEST,
                        confidence = ChumaConfidence.HIGH
                    )
                } else if (com.example.data.ai.ActionConfirmation.isCancellation(trimmed)) {
                    com.example.data.ai.ActionConfirmation.pendingAction = null
                    val cancelMsg = "Understood — action cancelled. Your data remains untouched."
                    context.onChunk?.invoke(cancelMsg)
                    return@withContext ChumaOrchestratorResult(
                        output = cancelMsg,
                        taskType = ChumaTaskType.TOOL_REQUEST,
                        confidence = ChumaConfidence.HIGH
                    )
                }
            }

            // 1. User Intent Classification (Action vs Instruction vs Information)
            val userIntent = com.example.data.ai.UserIntentClassifier.classify(trimmed)
            if (userIntent.mode == com.example.data.ai.UserIntentMode.INSTRUCTION_REQUEST) {
                val guidance = com.example.data.ai.UserIntentClassifier.getInstructionGuidance(trimmed)
                context.onChunk?.invoke(guidance)
                return@withContext ChumaOrchestratorResult(
                    output = guidance,
                    taskType = ChumaTaskType.GENERAL_QA,
                    confidence = ChumaConfidence.HIGH
                )
            }

            if (userIntent.mode == com.example.data.ai.UserIntentMode.ACTION_REQUEST) {
                val riskLevel = com.example.data.ai.ActionConfirmation.evaluateRiskLevel(trimmed)
                if (riskLevel == com.example.data.ai.ActionRiskLevel.SENSITIVE_DESTRUCTIVE) {
                    com.example.data.ai.ActionConfirmation.pendingAction = trimmed
                    val warning = com.example.data.ai.ActionConfirmation.buildConfirmationMessage(trimmed)
                    context.onChunk?.invoke(warning)
                    return@withContext ChumaOrchestratorResult(
                        output = warning,
                        taskType = ChumaTaskType.TOOL_REQUEST,
                        confidence = ChumaConfidence.HIGH
                    )
                }
            }

            // 2. Semantic Task Classification
            context.executionStatus = ChumaExecutionStatus.ANALYZING_INTENT
            val intent = ChumaTaskClassifier.classify(
                request = trimmed,
                attachedFiles = context.attachedFiles
            )
            ChumaOrchestratorLogger.intentClassified(requestId, intent.taskType, intent.confidence, intent.isMultiStep)

            // Fast Path Execution for Deterministic Queries (zero unnecessary network latency)
            if (context.canvasContext != null) {
                val fastPathIntent = com.example.data.ai.IntentRouter().classifyIntent(trimmed)
                if (fastPathIntent.isFastPathEligible) {
                    val fastPathResult = com.example.data.ai.FastPathEngine.executeFastPath(
                        fastPathIntent.toParsedIntent(),
                        trimmed,
                        context.canvasContext
                    )
                    if (!fastPathResult.isNullOrBlank()) {
                        context.onChunk?.invoke(fastPathResult)
                        return@withContext ChumaOrchestratorResult(
                            output = fastPathResult,
                            taskType = intent.taskType,
                            confidence = ChumaConfidence.HIGH
                        )
                    }
                }
            }

            // 3. Capability Determination & Routing
            context.executionStatus = ChumaExecutionStatus.SELECTING_CAPABILITIES
            val route = determineRoute(intent)
            ChumaOrchestratorLogger.capabilitiesSelected(requestId, intent.requiredCapabilities)
            ChumaOrchestratorLogger.executionStarted(requestId, route.routeType)

            // 4. Memory / Context Enrichment
            val memorySnippet = memoryProvider.retrieveRelevantMemory(
                prompt = trimmed,
                conversationId = context.conversationId,
                context = context.canvasContext
            )

            // 5. Execution Pipeline
            val executedTools = mutableListOf<Pair<String, ToolResult>>()
            val collectedSources = mutableListOf<String>()
            val rawResponse: String

            when {
                // Route A: Multi-Step Task Orchestration
                intent.isMultiStep && intent.steps.isNotEmpty() -> {
                    rawResponse = executeMultiStepTask(
                        intent = intent,
                        context = context,
                        memorySnippet = memorySnippet,
                        executedTools = executedTools,
                        collectedSources = collectedSources
                    )
                }

                // Route B: Deterministic Local Tool (Calculator, Alarm, Screen Navigation)
                route.routeType == RouteType.FAST_PATH_TOOL && route.toolName != null -> {
                    coroutineContext.ensureActive()
                    context.executionStatus = ChumaExecutionStatus.EXECUTING_TOOLS
                    ChumaOrchestratorLogger.toolStarted(requestId, route.toolName)
                    val tool = toolRegistry.get(route.toolName)
                    if (tool != null && tool.isAvailable()) {
                        val toolResult = tool.execute(
                            ToolRequest(toolName = route.toolName, rawInput = trimmed, parameters = intent.parameters),
                            context
                        )
                        executedTools.add(route.toolName to toolResult)
                        ChumaOrchestratorLogger.toolCompleted(requestId, route.toolName, toolResult.success)
                        rawResponse = if (toolResult.success) {
                            toolResult.formattedMessage
                        } else {
                            // Fallback to Gemini if tool calculation fails
                            fallbackToGemini(trimmed, intent, context, memorySnippet)
                        }
                    } else {
                        ChumaOrchestratorLogger.toolFailed(requestId, route.toolName, "Tool unavailable")
                        rawResponse = fallbackToGemini(trimmed, intent, context, memorySnippet)
                    }
                }

                // Route C: Live Web Search Grounding
                route.routeType == RouteType.SEARCH_GROUNDED_GEMINI || intent.isSearchRequired -> {
                    coroutineContext.ensureActive()
                    context.executionStatus = ChumaExecutionStatus.SEARCHING_WEB
                    val searchTool = toolRegistry.get("web_search")
                    if (searchTool != null && searchTool.isAvailable()) {
                        ChumaOrchestratorLogger.toolStarted(requestId, "web_search")
                        val searchQuery = intent.parameters["query"] ?: trimmed
                        val searchResult = searchTool.execute(
                            ToolRequest(toolName = "web_search", rawInput = searchQuery),
                            context
                        )
                        executedTools.add("web_search" to searchResult)
                        ChumaOrchestratorLogger.toolCompleted(requestId, "web_search", searchResult.success)

                        val searchContext = if (searchResult.success && searchResult.output.isNotBlank()) {
                            collectedSources.addAll(extractSourcesFromSearch(searchResult.output))
                            "Verified Live Search Results:\n${searchResult.output}"
                        } else {
                            "Live web search was attempted but returned no current records. Note honestly that verified external search data is unavailable."
                        }

                        val combinedContext = buildString {
                            if (!memorySnippet.isNullOrBlank()) append(memorySnippet).append("\n\n")
                            append(searchContext)
                        }

                        context.executionStatus = ChumaExecutionStatus.CALLING_GEMINI
                        rawResponse = callGeminiUnified(
                            prompt = trimmed,
                            taskType = mapTaskTypeToString(intent.taskType),
                            history = context.conversationHistory,
                            systemContext = combinedContext,
                            onChunk = context.onChunk
                        )
                    } else {
                        // Search capability unavailable
                        rawResponse = "Current web search capability is presently unavailable. I can provide general knowledge up to my model training, but cannot verify live today's data."
                    }
                }

                // Route D: Direct Standard Neural Intelligence (Gemini)
                else -> {
                    coroutineContext.ensureActive()
                    context.executionStatus = ChumaExecutionStatus.CALLING_GEMINI
                    val minimalSystemContext = buildString {
                        if (!memorySnippet.isNullOrBlank()) append(memorySnippet).append("\n\n")
                        if (context.canvasContext != null) {
                            append(ContextEngine.buildMinimalContextString(
                                com.example.data.ai.ParsedIntent(
                                    category = com.example.data.ai.MajorIntentCategory.GENERAL,
                                    subAction = intent.taskType.name
                                ),
                                context.canvasContext
                            ))
                        }
                    }

                    rawResponse = callGeminiUnified(
                        prompt = trimmed,
                        taskType = mapTaskTypeToString(intent.taskType),
                        history = context.conversationHistory,
                        systemContext = minimalSystemContext.ifBlank { null },
                        onChunk = context.onChunk
                    )
                }
            }

            coroutineContext.ensureActive()

            // 6. Verification Stage
            context.executionStatus = ChumaExecutionStatus.VERIFYING_OUTPUT
            ChumaOrchestratorLogger.verificationStarted(requestId)
            val verification = ChumaVerificationEngine.verify(
                rawOutput = rawResponse,
                intent = intent,
                executedTools = executedTools,
                sources = collectedSources,
                isSearchAvailable = toolRegistry.get("web_search")?.isAvailable() == true
            )
            ChumaOrchestratorLogger.verificationCompleted(requestId, verification.isValid, verification.notes)

            // Final push to onChunk if adjusted
            if (verification.verifiedOutput != rawResponse) {
                context.onChunk?.invoke(verification.verifiedOutput)
            }

            val duration = System.currentTimeMillis() - startTime
            context.executionStatus = ChumaExecutionStatus.COMPLETED
            ChumaOrchestratorLogger.responseGenerated(requestId, verification.verifiedOutput.length, duration)

            val usedCapabilities = mutableSetOf<ChumaCapability>()
            if (rawResponse.isNotBlank()) usedCapabilities.add(ChumaCapability.GEMINI)
            executedTools.forEach { pair ->
                toolRegistry.get(pair.first)?.capability?.let { usedCapabilities.add(it) }
            }

            return@withContext ChumaOrchestratorResult(
                output = verification.verifiedOutput,
                taskType = intent.taskType,
                confidence = if (verification.isValid) intent.confidence else ChumaConfidence.LOW,
                capabilitiesUsed = usedCapabilities,
                sources = collectedSources,
                isVerified = verification.isValid,
                verificationNotes = verification.notes,
                durationMs = duration,
                isError = false
            )

        } catch (e: CancellationException) {
            context.executionStatus = ChumaExecutionStatus.CANCELLED
            ChumaOrchestratorLogger.requestCancelled(requestId)
            val cancelMessage = "Response generation was stopped."
            context.onChunk?.invoke(cancelMessage)
            return@withContext ChumaOrchestratorResult(
                output = cancelMessage,
                taskType = ChumaTaskType.GENERAL_QA,
                confidence = ChumaConfidence.LOW,
                isError = false,
                errorMessage = "Request cancelled"
            )
        } catch (e: Throwable) {
            context.executionStatus = ChumaExecutionStatus.FAILED
            ChumaOrchestratorLogger.requestFailed(requestId, e.message)
            val userErrorMessage = "Chuma couldn't reach the AI service. Check your connection and try again."
            context.onChunk?.invoke(userErrorMessage)
            return@withContext ChumaOrchestratorResult(
                output = userErrorMessage,
                taskType = ChumaTaskType.GENERAL_QA,
                confidence = ChumaConfidence.LOW,
                isError = true,
                errorMessage = e.message ?: "Unknown error"
            )
        }
    }

    private fun determineRoute(intent: ChumaIntent): ChumaRoute {
        return when {
            intent.isMultiStep -> ChumaRoute(
                routeType = RouteType.MULTI_STEP_ORCHESTRATION,
                primaryCapability = ChumaCapability.GEMINI,
                secondaryCapabilities = intent.requiredCapabilities,
                searchRequired = intent.isSearchRequired,
                confidence = ChumaConfidence.HIGH,
                reason = "Decomposed into multi-step workflow"
            )

            intent.taskType == ChumaTaskType.MATHEMATICS -> ChumaRoute(
                routeType = RouteType.FAST_PATH_TOOL,
                primaryCapability = ChumaCapability.CALCULATOR,
                toolName = "calculator",
                confidence = ChumaConfidence.HIGH,
                reason = "Exact local arithmetic"
            )

            intent.taskType == ChumaTaskType.TRANSPORT_LOOKUP || intent.taskType == ChumaTaskType.FARE_LOOKUP -> ChumaRoute(
                routeType = RouteType.FAST_PATH_TOOL,
                primaryCapability = ChumaCapability.MAPS,
                toolName = "transport_hub",
                confidence = ChumaConfidence.HIGH,
                reason = "Deterministic public transport route and published fare lookup"
            )

            intent.taskType == ChumaTaskType.CURRENT_DATE || intent.taskType == ChumaTaskType.DATE_LOOKUP ||
                    intent.taskType == ChumaTaskType.PUBLIC_HOLIDAY_CHECK || intent.taskType == ChumaTaskType.HOLIDAY_LOOKUP ||
                    intent.taskType == ChumaTaskType.DATE_DIFFERENCE -> ChumaRoute(
                routeType = RouteType.FAST_PATH_TOOL,
                primaryCapability = ChumaCapability.OTHER_TOOLS,
                toolName = "time",
                confidence = ChumaConfidence.HIGH,
                reason = "Deterministic date, time, and South African public holiday resolution"
            )

            intent.taskType == ChumaTaskType.WEATHER_LOOKUP -> ChumaRoute(
                routeType = RouteType.FAST_PATH_TOOL,
                primaryCapability = ChumaCapability.WEATHER,
                toolName = "weather",
                confidence = ChumaConfidence.HIGH,
                reason = "Weather forecast lookup"
            )

            intent.taskType == ChumaTaskType.TOOL_REQUEST && intent.subAction != null -> ChumaRoute(
                routeType = RouteType.FAST_PATH_TOOL,
                primaryCapability = ChumaCapability.OTHER_TOOLS,
                toolName = mapSubActionToToolName(intent.subAction),
                confidence = ChumaConfidence.HIGH,
                reason = "Direct tool request"
            )

            intent.isSearchRequired || intent.taskType == ChumaTaskType.CURRENT_INFORMATION -> ChumaRoute(
                routeType = RouteType.SEARCH_GROUNDED_GEMINI,
                primaryCapability = ChumaCapability.WEB_SEARCH,
                secondaryCapabilities = setOf(ChumaCapability.GEMINI),
                toolName = "web_search",
                searchRequired = true,
                confidence = ChumaConfidence.HIGH,
                reason = "Current external knowledge required"
            )

            else -> ChumaRoute(
                routeType = RouteType.GEMINI_REASONING,
                primaryCapability = ChumaCapability.GEMINI,
                confidence = ChumaConfidence.HIGH,
                reason = "Standard neural processing"
            )
        }
    }

    private suspend fun executeMultiStepTask(
        intent: ChumaIntent,
        context: ChumaExecutionContext,
        memorySnippet: String?,
        executedTools: MutableList<Pair<String, ToolResult>>,
        collectedSources: MutableList<String>
    ): String {
        val steps = intent.steps.mapIndexed { idx, desc ->
            TaskStep(
                stepIndex = idx + 1,
                description = desc,
                requiredCapability = if (desc.contains("search", ignoreCase = true) || desc.contains("retrieve", ignoreCase = true)) {
                    ChumaCapability.WEB_SEARCH
                } else if (desc.contains("calculate", ignoreCase = true)) {
                    ChumaCapability.CALCULATOR
                } else {
                    ChumaCapability.GEMINI
                }
            )
        }

        val taskState = TaskState(
            intent = intent,
            requiredCapabilities = intent.requiredCapabilities,
            steps = steps
        )

        // Execute step by step internally
        for (step in taskState.steps) {
            coroutineContext.ensureActive()
            when (step.requiredCapability) {
                ChumaCapability.WEB_SEARCH -> {
                    val searchTool = toolRegistry.get("web_search")
                    if (searchTool != null && searchTool.isAvailable()) {
                        val res = searchTool.execute(ToolRequest("web_search", rawInput = context.userRequest), context)
                        executedTools.add("web_search" to res)
                        step.isCompleted = res.success
                        step.stepOutput = res.output
                        collectedSources.addAll(extractSourcesFromSearch(res.output))
                    } else {
                        step.isFailed = true
                        step.error = "Search tool unavailable"
                    }
                }
                ChumaCapability.CALCULATOR -> {
                    val calc = toolRegistry.get("calculator")
                    if (calc != null && calc.isAvailable()) {
                        val res = calc.execute(ToolRequest("calculator", rawInput = context.userRequest), context)
                        executedTools.add("calculator" to res)
                        step.isCompleted = res.success
                        step.stepOutput = res.output
                    } else {
                        step.isFailed = true
                    }
                }
                else -> {
                    step.isCompleted = true
                }
            }
        }

        // Final synthesis without exposing internal chain of thought
        val synthesisContext = buildString {
            if (!memorySnippet.isNullOrBlank()) append("Memory Context:\n$memorySnippet\n\n")
            val stepOutputs = taskState.steps.mapNotNull { it.stepOutput }.filter { it.isNotBlank() }
            if (stepOutputs.isNotEmpty()) {
                append("Synthesized Facts & Data:\n")
                stepOutputs.forEach { append("- ").append(it).append("\n") }
            }
        }

        return callGeminiUnified(
            prompt = context.userRequest,
            taskType = "complex_reasoning",
            history = context.conversationHistory,
            systemContext = synthesisContext.ifBlank { null },
            onChunk = context.onChunk
        )
    }

    private suspend fun fallbackToGemini(
        prompt: String,
        intent: ChumaIntent,
        context: ChumaExecutionContext,
        memorySnippet: String?
    ): String {
        return callGeminiUnified(
            prompt = prompt,
            taskType = mapTaskTypeToString(intent.taskType),
            history = context.conversationHistory,
            systemContext = memorySnippet,
            onChunk = context.onChunk
        )
    }

    private suspend fun callGeminiUnified(
        prompt: String,
        taskType: String,
        history: List<Pair<String, String>>,
        systemContext: String?,
        onChunk: ((String) -> Unit)?
    ): String {
        return if (onChunk != null) {
            GeminiClient.streamAskGemini(
                prompt = prompt,
                taskType = taskType,
                history = history,
                systemContextOverride = systemContext,
                onChunk = onChunk
            )
        } else {
            GeminiClient.askGemini(
                prompt = prompt,
                taskType = taskType,
                history = history,
                systemContextOverride = systemContext
            )
        }
    }

    private fun mapTaskTypeToString(type: ChumaTaskType): String {
        return when (type) {
            ChumaTaskType.CODING, ChumaTaskType.DEBUGGING -> "coding"
            ChumaTaskType.MATHEMATICS -> "math"
            ChumaTaskType.RESEARCH, ChumaTaskType.REASONING, ChumaTaskType.MULTI_STEP_TASK -> "academic"
            ChumaTaskType.WRITING, ChumaTaskType.EDITING -> "writing"
            ChumaTaskType.SUMMARIZATION -> "summarization"
            ChumaTaskType.TRANSLATION -> "translation"
            else -> "general"
        }
    }

    private fun mapSubActionToToolName(subAction: String): String {
        val lower = subAction.lowercase()
        return when {
            lower.contains("alarm") -> "alarm"
            lower.contains("navigation") || lower.contains("screen") -> "screen_navigation"
            lower.contains("weather") -> "weather"
            lower.contains("time") -> "time"
            lower.contains("currency") -> "currency"
            lower.contains("place") -> "place_search"
            else -> subAction
        }
    }

    private fun extractSourcesFromSearch(output: String): List<String> {
        val regex = Regex("\\[(https?://[^\\]]+)\\]")
        return regex.findAll(output).map { it.groupValues[1] }.distinct().toList()
    }
}
