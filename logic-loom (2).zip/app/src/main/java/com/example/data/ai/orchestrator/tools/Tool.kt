package com.example.data.ai.orchestrator.tools

import com.example.data.ai.orchestrator.ChumaCapability
import com.example.data.ai.orchestrator.ChumaExecutionContext
import com.example.data.ai.orchestrator.ChumaIntent
import com.example.data.ai.orchestrator.ChumaTaskType
import com.example.data.tools.*

/**
 * Request payload passed to a Tool.
 */
data class ToolRequest(
    val toolName: String,
    val parameters: Map<String, String> = emptyMap(),
    val rawInput: String = ""
)

/**
 * Result payload returned from a Tool execution.
 */
data class ToolResult(
    val success: Boolean,
    val output: String,
    val formattedMessage: String,
    val metadata: Map<String, String> = emptyMap(),
    val error: String? = null
)

/**
 * Standard interface for all executable tools in the Chuma ecosystem.
 */
interface Tool {
    val name: String
    val description: String
    val inputSchema: String
    val capability: ChumaCapability
    fun isAvailable(): Boolean
    suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult
}

/**
 * Central registry for querying, registering, and routing tools.
 */
interface ToolRegistry {
    fun register(tool: Tool)
    fun get(name: String): Tool?
    fun getAll(): List<Tool>
    fun getAvailable(): List<Tool>
    fun findToolForIntent(intent: ChumaIntent): Tool?
}

/**
 * Default production registry connecting existing verified tools.
 */
class DefaultToolRegistry : ToolRegistry {
    private val tools = mutableMapOf<String, Tool>()

    init {
        register(CalculatorToolWrapper())
        register(WeatherToolWrapper())
        register(TimeToolWrapper())
        register(CurrencyToolWrapper())
        register(WebSearchToolWrapper())
        register(PlaceSearchToolWrapper())
        register(AlarmToolWrapper())
        register(ScreenNavigationToolWrapper())
        register(TransportDiscoveryToolWrapper())
    }

    override fun register(tool: Tool) {
        tools[tool.name.lowercase()] = tool
    }

    override fun get(name: String): Tool? {
        return tools[name.lowercase()]
    }

    override fun getAll(): List<Tool> {
        return tools.values.toList()
    }

    override fun getAvailable(): List<Tool> {
        return tools.values.filter { it.isAvailable() }
    }

    override fun findToolForIntent(intent: ChumaIntent): Tool? {
        val action = intent.subAction?.lowercase() ?: ""
        return when {
            intent.taskType == ChumaTaskType.MATHEMATICS || action.contains("calculate") -> get("calculator")
            intent.taskType == ChumaTaskType.CURRENT_DATE || intent.taskType == ChumaTaskType.DATE_LOOKUP ||
                    intent.taskType == ChumaTaskType.PUBLIC_HOLIDAY_CHECK || intent.taskType == ChumaTaskType.HOLIDAY_LOOKUP ||
                    intent.taskType == ChumaTaskType.DATE_DIFFERENCE || action.contains("time") -> get("time")
            intent.taskType == ChumaTaskType.WEATHER_LOOKUP || action.contains("weather") -> get("weather")
            intent.taskType == ChumaTaskType.TRANSPORT_LOOKUP || intent.taskType == ChumaTaskType.FARE_LOOKUP ||
                    action.contains("transport") || action.contains("train") || action.contains("prasa") || action.contains("bus") -> get("transport_hub")
            action.contains("currency") -> get("currency")
            action.contains("web_search") || intent.isSearchRequired -> get("web_search")
            action.contains("place") || action.contains("campus") -> get("place_search")
            action.contains("alarm") -> get("alarm")
            action.contains("navigation") || action.contains("screen") -> get("screen_navigation")
            else -> null
        }
    }
}

// Concrete wrappers for existing project tools

class CalculatorToolWrapper : Tool {
    override val name: String = "calculator"
    override val description: String = "Deterministic arithmetic and percentage calculator"
    override val inputSchema: String = "expression: String"
    override val capability: ChumaCapability = ChumaCapability.CALCULATOR
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val expr = request.parameters["expression"] ?: request.rawInput
        val res = CalculatorTool.calculate(expr)
        return if (res.success) {
            ToolResult(
                success = true,
                output = res.result.toString(),
                formattedMessage = res.explanation
            )
        } else {
            ToolResult(
                success = false,
                output = "",
                formattedMessage = res.explanation,
                error = "Calculation failed"
            )
        }
    }
}

class WeatherToolWrapper : Tool {
    override val name: String = "weather"
    override val description: String = "Live weather telemetry and campus clothing advice"
    override val inputSchema: String = "location: String?"
    override val capability: ChumaCapability = ChumaCapability.WEATHER
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val loc = request.parameters["location"] ?: context.canvasContext?.userLocationArea ?: "Gqeberha"
        val report = WeatherTool.getWeather(loc)
        return ToolResult(
            success = true,
            output = "${report.temperatureCelsius}°C, ${report.conditionDescription}",
            formattedMessage = report.formattedSummary,
            metadata = mapOf("location" to report.locationName, "temp" to report.temperatureCelsius.toString())
        )
    }
}

class TimeToolWrapper : Tool {
    override val name: String = "time"
    override val description: String = "Current time, date, and academic period lookup"
    override val inputSchema: String = "location: String?"
    override val capability: ChumaCapability = ChumaCapability.OTHER_TOOLS
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val query = request.parameters["location"] ?: request.rawInput
        val resolved = TimeTool.resolveDateOrTimeQuery(query)
        if (resolved != null) {
            return ToolResult(
                success = true,
                output = resolved,
                formattedMessage = resolved
            )
        }
        val report = TimeTool.getCurrentTime(query)
        return ToolResult(
            success = true,
            output = report.formattedTime,
            formattedMessage = report.fullReport
        )
    }
}

class CurrencyToolWrapper : Tool {
    override val name: String = "currency"
    override val description: String = "Live and cached currency exchange rate converter"
    override val inputSchema: String = "query: String"
    override val capability: ChumaCapability = ChumaCapability.OTHER_TOOLS
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val query = request.parameters["query"] ?: request.rawInput
        val conv = CurrencyTool.parseAndConvert(query)
        return ToolResult(
            success = conv.success,
            output = conv.formattedSummary,
            formattedMessage = conv.formattedSummary,
            error = if (!conv.success) "Currency conversion failed" else null
        )
    }
}

class WebSearchToolWrapper : Tool {
    override val name: String = "web_search"
    override val description: String = "Live factual search with ground-truth snippets and citations"
    override val inputSchema: String = "query: String"
    override val capability: ChumaCapability = ChumaCapability.WEB_SEARCH
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val query = request.parameters["query"] ?: request.rawInput
        val searchResp = WebSearchTool.searchWeb(query)
        return ToolResult(
            success = searchResp.success,
            output = searchResp.results.joinToString("\n") { "${it.title}: ${it.snippet} [${it.url}]" },
            formattedMessage = searchResp.formattedAnswer,
            error = searchResp.errorMessage
        )
    }
}

class PlaceSearchToolWrapper : Tool {
    override val name: String = "place_search"
    override val description: String = "Campus venue and points of interest locator"
    override val inputSchema: String = "query: String"
    override val capability: ChumaCapability = ChumaCapability.MAPS
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val query = request.parameters["query"] ?: request.rawInput
        val report = PlaceSearchTool.getPlaceDetails(query)
        return ToolResult(
            success = report.success,
            output = report.formattedSummary,
            formattedMessage = report.formattedSummary,
            error = if (!report.success) "Location not found" else null
        )
    }
}

class AlarmToolWrapper : Tool {
    override val name: String = "alarm"
    override val description: String = "Sets alarms and academic study timer reminders"
    override val inputSchema: String = "query: String"
    override val capability: ChumaCapability = ChumaCapability.OTHER_TOOLS
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val prompt = request.parameters["query"] ?: request.rawInput
        val parsed = AlarmTool.parseAlarmRequest(prompt)
        return if (parsed != null) {
            val res = AlarmTool.setAlarm(
                hour = parsed.first,
                minute = parsed.second,
                isTomorrow = AlarmTool.isTomorrowRequested(prompt)
            )
            ToolResult(
                success = res.success,
                output = res.message,
                formattedMessage = res.message,
                error = res.errorReason
            )
        } else {
            ToolResult(
                success = false,
                output = "",
                formattedMessage = "Please specify a time for the alarm (e.g., 'Set alarm for 7:30 AM').",
                error = "Time format not recognized"
            )
        }
    }
}

class ScreenNavigationToolWrapper : Tool {
    override val name: String = "screen_navigation"
    override val description: String = "Navigates to specific Logic Loom screens"
    override val inputSchema: String = "screenName: String"
    override val capability: ChumaCapability = ChumaCapability.OTHER_TOOLS
    override fun isAvailable(): Boolean = true

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val screen = request.parameters["screenName"] ?: request.rawInput
        val res = ScreenNavigationTool.openScreen(screen)
        return ToolResult(
            success = res.success,
            output = res.message,
            formattedMessage = res.message,
            error = if (!res.success) "Screen not found" else null
        )
    }
}

class TransportDiscoveryToolWrapper : Tool {
    override val name: String = "transport_hub"
    override val description: String = "Discovers and compares public rail (PRASA / Metrorail) and bus transport options with published fares"
    override val inputSchema: String = "origin: String, destination: String"
    override val capability: ChumaCapability = ChumaCapability.MAPS
    override fun isAvailable(): Boolean = true

    private val service = com.example.data.transport.service.TransportHubService()

    override suspend fun execute(request: ToolRequest, context: ChumaExecutionContext): ToolResult {
        val origin = request.parameters["origin"]?.trim()?.takeIf { it.isNotBlank() }
        val destination = request.parameters["destination"]?.trim()?.takeIf { it.isNotBlank() }

        if (origin == null && destination == null) {
            val message = "To look up transport fares, distance, and routes, please specify your starting station and destination (for example: *\"How much is the train from Cape Town to Bellville?\"*). Logic Loom does not assume or invent your journey."
            return ToolResult(
                success = true,
                output = message,
                formattedMessage = message
            )
        }
        if (origin == null) {
            val message = "Where will you be departing from? Please specify your starting station for your journey to **$destination**."
            return ToolResult(
                success = true,
                output = message,
                formattedMessage = message
            )
        }
        if (destination == null) {
            val message = "Where are you travelling to? Please specify your destination station from **$origin**."
            return ToolResult(
                success = true,
                output = message,
                formattedMessage = message
            )
        }

        val query = com.example.data.transport.model.TransportSearchQuery(
            origin = origin,
            destination = destination
        )
        val result = service.searchTransport(query)

        val sb = StringBuilder()
        sb.appendLine("🚆 **Public Transport Discovery: $origin to $destination**")
        sb.appendLine()
        sb.appendLine("*(Disclaimer: Logic Loom is an informational hub, not a transport operator. We do not dispatch vehicles or issue tickets. Please verify schedules and purchase tickets at the operator station.)*")
        sb.appendLine()

        if (result.straightLineDistanceKm != null) {
            sb.appendLine("• **Straight-line Distance (Euclidean):** ~${result.straightLineDistanceKm} km")
        }

        if (result.options.isEmpty()) {
            sb.appendLine(result.generalNotice ?: "No direct published commuter routes found between $origin and $destination. Consider querying major interchange stations such as Cape Town or Bellville.")
        } else {
            result.options.forEach { opt ->
                sb.appendLine("### ${opt.operator} — ${opt.routeName}")
                sb.appendLine("• **Corridor:** ${opt.corridor}")
                sb.appendLine("• **From:** ${opt.originStationOrStop} ➔ **To:** ${opt.destinationStationOrStop}")
                if (opt.estimatedTrackDistanceKm != null) {
                    val distanceType = if (opt.mode == com.example.data.transport.model.TransportMode.TRAIN) "Estimated Rail Track Distance" else "Estimated Road Distance"
                    sb.appendLine("• **$distanceType:** ~${opt.estimatedTrackDistanceKm} km (${opt.intermediateStopsCount} intermediate stops)")
                }
                if (opt.publishedFare != null) {
                    val fare = opt.publishedFare
                    sb.appendLine("• **Published Fare:** Single R${"%.2f".format(fare.singleZar)}${fare.returnZar?.let { " | Return R${"%.2f".format(it)}" } ?: ""}")
                    if (fare.weeklyZar != null || fare.monthlyZar != null) {
                        val weeklyText = fare.weeklyZar?.let { "Weekly R${"%.2f".format(it)}" } ?: "Weekly unavailable"
                        val monthlyText = fare.monthlyZar?.let { "Monthly R${"%.2f".format(it)}" } ?: "Monthly unavailable"
                        sb.appendLine("• **Commuter Passes:** $weeklyText | $monthlyText")
                    } else {
                        sb.appendLine("• **Commuter Passes:** Weekly / Monthly passes currently vary by corridor; verify at ticket office")
                    }
                    sb.appendLine("• **Data Type:** ${fare.dataType.label} (${fare.freshnessStatus})")
                    sb.appendLine("• **Source:** ${fare.sourceName} (${fare.effectiveDateText})")
                }
                sb.appendLine("• **Frequency:** ${opt.frequencyNotice}")
                sb.appendLine("• **Hours:** ${opt.operatingHoursNotice}")
                if (!opt.serviceStatusNotice.isNullOrBlank()) {
                    sb.appendLine("• **Fleet / Service:** ${opt.serviceStatusNotice}")
                }
                sb.appendLine()
            }
        }

        val outStr = sb.toString().trim()
        return ToolResult(
            success = true,
            output = outStr,
            formattedMessage = outStr,
            metadata = mapOf("optionsCount" to result.options.size.toString())
        )
    }
}

