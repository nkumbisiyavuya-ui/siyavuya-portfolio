package com.example.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Modular abstraction for Speech-To-Text (STT) providers.
 * Allows seamless swapping of offline, on-device Android STT,
 * or cloud streaming providers without refactoring Chuma AI.
 */
interface SpeechRecognitionProvider {
    fun isAvailable(): Boolean
    fun startListening(
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onError: (String) -> Unit,
        onRmsChanged: (Float) -> Unit = {},
        onEndOfSpeech: () -> Unit = {}
    )
    fun stopListening()
    fun cancel()
    fun destroy()
}

/**
 * Production-quality Android SpeechRecognizer implementation.
 * Supports streaming partial transcripts, live audio RMS energy,
 * automatic punctuation where supported, and clean turn completion.
 */
class AndroidSpeechRecognitionProvider(
    private val context: Context
) : SpeechRecognitionProvider {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening: Boolean = false

    override fun isAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    override fun startListening(
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onError: (String) -> Unit,
        onRmsChanged: (Float) -> Unit,
        onEndOfSpeech: () -> Unit
    ) {
        if (!isAvailable()) {
            onError("Speech recognition service is not available on this device.")
            return
        }

        stopListening()

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                    }

                    override fun onBeginningOfSpeech() {
                        isListening = true
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        // Normalize RMS dB (typical range -2dB to ~10dB) to 0.0f..1.0f
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        onRmsChanged(normalized)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        isListening = false
                        onEndOfSpeech()
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        val errorMsg = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Please check microphone."
                            SpeechRecognizer.ERROR_CLIENT -> "Client speech recognition error."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                            SpeechRecognizer.ERROR_NETWORK -> "Network issue encountered during voice recognition."
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice network request timed out."
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please speak clearly."
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognition service is busy."
                            SpeechRecognizer.ERROR_SERVER -> "Voice server returned an error."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input detected."
                            else -> "Voice recognition error ($error)"
                        }
                        onError(errorMsg)
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim() ?: ""
                        if (text.isNotBlank()) {
                            onFinal(text)
                        } else {
                            onError("No speech recognized. Please speak clearly.")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partial = matches?.firstOrNull()?.trim() ?: ""
                        if (partial.isNotBlank()) {
                            onPartial(partial)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra("android.speech.extra.DICTATION_MODE", true)
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            onError("Failed to initiate voice input: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    override fun stopListening() {
        try {
            isListening = false
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            // Safe cleanup
        }
    }

    override fun cancel() {
        try {
            isListening = false
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            // Safe cleanup
        }
    }

    override fun destroy() {
        try {
            isListening = false
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // Safe cleanup
        } finally {
            speechRecognizer = null
        }
    }
}
