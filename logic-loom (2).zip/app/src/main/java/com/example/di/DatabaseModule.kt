package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.local.CanvasMateDao
import com.example.data.local.CanvasMateDatabase
import com.example.data.repository.CanvasMateRepository
import com.example.data.repository.StudentRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideCanvasMateDatabase(
        @ApplicationContext context: Context
    ): CanvasMateDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            CanvasMateDatabase::class.java,
            "logicloom_db"
        )
        .addMigrations(CanvasMateDatabase.MIGRATION_5_6)
        .fallbackToDestructiveMigration()
        .build()
    }

    @Provides
    @Singleton
    fun provideCanvasMateDao(
        database: CanvasMateDatabase
    ): CanvasMateDao {
        return database.dao()
    }

    @Provides
    @Singleton
    fun provideTaskDao(
        database: CanvasMateDatabase
    ): com.example.data.local.TaskDao {
        return database.taskDao()
    }

    @Provides
    @Singleton
    fun provideCourseDao(
        database: CanvasMateDatabase
    ): com.example.data.local.CourseDao {
        return database.courseDao()
    }

    @Provides
    @Singleton
    fun provideReminderDao(
        database: CanvasMateDatabase
    ): com.example.data.local.ReminderDao {
        return database.reminderDao()
    }

    @Provides
    @Singleton
    fun provideUserAccountDao(
        database: CanvasMateDatabase
    ): com.example.data.local.UserAccountDao {
        return database.userAccountDao()
    }
}

