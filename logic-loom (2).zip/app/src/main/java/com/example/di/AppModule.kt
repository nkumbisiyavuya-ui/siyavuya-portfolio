package com.example.di

import android.content.Context
import com.example.data.ai.CanvasMateAiOrchestrator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import javax.inject.Qualifier
import javax.inject.Singleton

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class IoDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MainDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class DefaultDispatcher

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO

    @Provides
    @MainDispatcher
    fun provideMainDispatcher(): CoroutineDispatcher = Dispatchers.Main

    @Provides
    @DefaultDispatcher
    fun provideDefaultDispatcher(): CoroutineDispatcher = Dispatchers.Default

    @Provides
    @Singleton
    fun provideCanvasMateAiOrchestrator(): CanvasMateAiOrchestrator = CanvasMateAiOrchestrator

    @Provides
    @Singleton
    fun provideTaskService(defaultTaskService: com.example.data.ai.DefaultTaskService): com.example.data.ai.TaskService = defaultTaskService

    @Provides
    @Singleton
    fun provideFinanceService(defaultFinanceService: com.example.data.ai.DefaultFinanceService): com.example.data.ai.FinanceService = defaultFinanceService

    @Provides
    @Singleton
    fun provideCalendarService(defaultCalendarService: com.example.data.ai.DefaultCalendarService): com.example.data.ai.CalendarService = defaultCalendarService

    @Provides
    @Singleton
    fun provideStudyService(defaultStudyService: com.example.data.ai.DefaultStudyService): com.example.data.ai.StudyService = defaultStudyService

    @Provides
    @Singleton
    fun provideAiOrchestrator(
        intentRouter: com.example.data.ai.IntentRouter,
        securityVerificationEngine: com.example.data.ai.SecurityVerificationEngine,
        taskService: com.example.data.ai.TaskService,
        financeService: com.example.data.ai.FinanceService,
        calendarService: com.example.data.ai.CalendarService,
        studyService: com.example.data.ai.StudyService
    ): com.example.data.ai.AiOrchestrator = com.example.data.ai.AiOrchestrator(
        intentRouter,
        securityVerificationEngine,
        taskService,
        financeService,
        calendarService,
        studyService
    )

    @Provides
    @Singleton
    fun provideToolRegistry(): com.example.data.ai.orchestrator.tools.ToolRegistry =
        com.example.data.ai.orchestrator.tools.DefaultToolRegistry()

    @Provides
    @Singleton
    fun provideMemoryProvider(): com.example.data.ai.orchestrator.memory.MemoryProvider =
        com.example.data.ai.orchestrator.memory.DefaultMemoryProvider()

    @Provides
    @Singleton
    fun provideChumaOrchestrator(
        toolRegistry: com.example.data.ai.orchestrator.tools.ToolRegistry,
        memoryProvider: com.example.data.ai.orchestrator.memory.MemoryProvider
    ): com.example.data.ai.orchestrator.ChumaOrchestrator =
        com.example.data.ai.orchestrator.ChumaOrchestrator(toolRegistry, memoryProvider)

    @Provides
    @Singleton
    fun provideAiService(): com.example.data.ai.AiService = com.example.data.ai.AiService()

    @Provides
    @Singleton
    fun provideSecureSessionManager(
        @ApplicationContext context: Context
    ): com.example.security.SecureSessionManager {
        return com.example.security.SecureSessionManager(context)
    }

    @Provides
    @Singleton
    fun provideSecureStorageManager(
        @ApplicationContext context: Context
    ): com.example.security.SecureStorageManager {
        return com.example.security.SecureStorageManager(context)
    }

    @Provides
    @Singleton
    fun provideChumaTaskExecutionDataStore(
        @ApplicationContext context: Context
    ): com.example.data.ai.datastore.ChumaTaskExecutionDataStore {
        return com.example.data.ai.datastore.ChumaTaskExecutionDataStore(context)
    }
}
