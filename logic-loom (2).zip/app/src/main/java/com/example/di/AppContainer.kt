package com.example.di

import android.content.Context
import com.example.data.local.CanvasMateDao
import com.example.data.local.CanvasMateDatabase
import com.example.data.repository.CanvasMateRepository
import com.example.data.repository.CourseRepository
import com.example.data.repository.CourseRepositoryImpl
import com.example.data.repository.ReminderRepository
import com.example.data.repository.ReminderRepositoryImpl
import com.example.data.repository.StudentRepository
import com.example.data.repository.TaskRepository
import com.example.data.repository.TaskRepositoryImpl

interface AppContainer {
    val database: CanvasMateDatabase
    val dao: CanvasMateDao
    val repository: CanvasMateRepository
    val studentRepository: StudentRepository
    val taskRepository: TaskRepository
    val courseRepository: CourseRepository
    val reminderRepository: ReminderRepository
    val sessionManager: com.example.security.SecureSessionManager
    val secureStorageManager: com.example.security.SecureStorageManager
    val authRepository: com.example.data.repository.AuthRepository
    val authenticationRepository: com.example.data.repository.AuthenticationRepository
    val chumaTaskDataStore: com.example.data.ai.datastore.ChumaTaskExecutionDataStore
}

class DefaultAppContainer(private val context: Context) : AppContainer {
    override val database: CanvasMateDatabase by lazy {
        CanvasMateDatabase.getDatabase(context)
    }

    override val dao: CanvasMateDao by lazy {
        database.dao()
    }

    override val repository: CanvasMateRepository by lazy {
        CanvasMateRepository(dao)
    }

    override val studentRepository: StudentRepository by lazy {
        repository
    }

    override val taskRepository: TaskRepository by lazy {
        TaskRepositoryImpl(
            database.taskDao(),
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
        )
    }

    override val courseRepository: CourseRepository by lazy {
        CourseRepositoryImpl(database.courseDao())
    }

    override val reminderRepository: ReminderRepository by lazy {
        ReminderRepositoryImpl(database.reminderDao())
    }

    override val sessionManager: com.example.security.SecureSessionManager by lazy {
        com.example.security.SecureSessionManager(context)
    }

    override val secureStorageManager: com.example.security.SecureStorageManager by lazy {
        com.example.security.SecureStorageManager(context)
    }

    override val authRepository: com.example.data.repository.AuthRepository by lazy {
        com.example.data.repository.AuthRepositoryImpl(
            database.userAccountDao(),
            dao,
            sessionManager
        )
    }

    override val authenticationRepository: com.example.data.repository.AuthenticationRepository by lazy {
        com.example.data.repository.AuthenticationRepositoryImpl()
    }

    override val chumaTaskDataStore: com.example.data.ai.datastore.ChumaTaskExecutionDataStore by lazy {
        com.example.data.ai.datastore.ChumaTaskExecutionDataStore(context)
    }
}
