package com.example.di

import com.example.data.local.CanvasMateDao
import com.example.data.local.CourseDao
import com.example.data.local.ReminderDao
import com.example.data.local.TaskDao
import com.example.data.repository.CanvasMateRepository
import com.example.data.repository.CourseRepository
import com.example.data.repository.CourseRepositoryImpl
import com.example.data.repository.ExchangeRateRepository
import com.example.data.repository.ReminderRepository
import com.example.data.repository.ReminderRepositoryImpl
import com.example.data.repository.StudentRepository
import com.example.data.repository.TaskRepository
import com.example.data.repository.TaskRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindStudentRepository(
        canvasMateRepository: CanvasMateRepository
    ): StudentRepository

    @Binds
    @Singleton
    abstract fun bindTaskRepository(
        taskRepositoryImpl: TaskRepositoryImpl
    ): TaskRepository

    @Binds
    @Singleton
    abstract fun bindCourseRepository(
        courseRepositoryImpl: CourseRepositoryImpl
    ): CourseRepository

    @Binds
    @Singleton
    abstract fun bindReminderRepository(
        reminderRepositoryImpl: ReminderRepositoryImpl
    ): ReminderRepository

    @Binds
    @Singleton
    abstract fun bindAuthRepository(
        authRepositoryImpl: com.example.data.repository.AuthRepositoryImpl
    ): com.example.data.repository.AuthRepository

    @Binds
    @Singleton
    abstract fun bindAuthenticationRepository(
        authenticationRepositoryImpl: com.example.data.repository.AuthenticationRepositoryImpl
    ): com.example.data.repository.AuthenticationRepository

    companion object {

        @Provides
        @Singleton
        fun provideCanvasMateRepository(
            dao: CanvasMateDao
        ): CanvasMateRepository {
            return CanvasMateRepository(dao)
        }

        @Provides
        @Singleton
        fun provideExchangeRateRepository(
            dao: CanvasMateDao
        ): ExchangeRateRepository {
            return ExchangeRateRepository(dao)
        }
    }
}
