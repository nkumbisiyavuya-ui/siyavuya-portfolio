package com.example.di

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.CanvasMateApplication
import com.example.ui.CanvasMateViewModel
import com.example.ui.viewmodel.BudgetViewModel
import com.example.ui.viewmodel.ShuttleViewModel
import com.example.ui.viewmodel.TasksViewModel

@Suppress("UNCHECKED_CAST")
class CanvasMateViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {

    private val repository by lazy {
        (application as CanvasMateApplication).repository
    }

    private val dao by lazy {
        (application as CanvasMateApplication).dao
    }

    private val authRepository by lazy {
        (application as CanvasMateApplication).authRepository
    }

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(CanvasMateViewModel::class.java) -> {
                CanvasMateViewModel(application, repository, dao, authRepository) as T
            }
            modelClass.isAssignableFrom(BudgetViewModel::class.java) -> {
                BudgetViewModel(application, repository) as T
            }
            modelClass.isAssignableFrom(TasksViewModel::class.java) -> {
                TasksViewModel(
                    application,
                    repository,
                    (application as CanvasMateApplication).container.taskRepository
                ) as T
            }
            modelClass.isAssignableFrom(ShuttleViewModel::class.java) -> {
                ShuttleViewModel(application, repository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
